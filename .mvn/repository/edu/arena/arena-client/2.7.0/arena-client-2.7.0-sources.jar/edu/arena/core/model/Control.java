package edu.arena.core.model;

import java.util.Objects;

/**
 * One tick's intent: signed throttle/turn in [-1,1], world-space aim and held fire/shield buttons.
 */
public record Control(double throttle, double turn, Vec2 aim, boolean fire, boolean shield) {
    public Control {
        if (!Double.isFinite(throttle)
                || Math.abs(throttle) > 1
                || !Double.isFinite(turn)
                || Math.abs(turn) > 1) {
            throw new IllegalArgumentException("Throttle and turn must be finite values in [-1,1]");
        }
        Objects.requireNonNull(aim, "aim");
    }

    /** Existing strategies keep their previous behavior until they opt into shielding. */
    public Control(double throttle, double turn, Vec2 aim, boolean fire) {
        this(throttle, turn, aim, fire, false);
    }

    public static Control idle(Vec2 aim) {
        return new Control(0, 0, aim, false);
    }
}
