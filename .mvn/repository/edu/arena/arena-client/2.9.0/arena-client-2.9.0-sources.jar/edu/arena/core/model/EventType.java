package edu.arena.core.model;

/** Visible events emitted during a single completed simulation tick. */
public enum EventType {
    SHOT,
    HIT,
    WALL,
    DESTROYED,
    ZONE,
    SHIELD_ACTIVATED,
    SHIELD_BLOCK
}
