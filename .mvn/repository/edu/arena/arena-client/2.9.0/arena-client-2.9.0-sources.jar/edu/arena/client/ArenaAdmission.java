package edu.arena.client;

import edu.arena.protocol.Messages;
import java.io.IOException;
import java.util.function.Consumer;

/** Confirms one admission without repeating a request whose outcome is unknown. */
final class ArenaAdmission {
    private ArenaAdmission() {}

    static Messages.QueueReply enqueue(
            ArenaClient client, String mode, String opponent, String map, Consumer<String> progress)
            throws IOException, InterruptedException {
        String previousAssignment = null;
        boolean baselineKnown = false;
        for (int attempt = 0; attempt < 6; attempt++) {
            boolean admissionSent = false;
            try {
                if (!baselineKnown) {
                    var before = client.me();
                    requireActive(before);
                    if (!before.approved()) {
                        progress.accept(
                                "Ожидание допуска преподавателя. После подтверждения войдём в очередь автоматически.");
                        do {
                            Thread.sleep(1000);
                            before = client.me();
                            requireActive(before);
                        } while (!before.approved());
                    }
                    previousAssignment = before.matchId();
                    baselineKnown = true;
                    if (before.queued()) {
                        return new Messages.QueueReply(true, before.matchId());
                    }
                }
                admissionSent = true;
                return client.queue(mode, opponent, map);
            } catch (IOException failure) {
                if (failure instanceof ArenaException error && !error.transientFailure()) {
                    throw error;
                }
                // The first request may have succeeded while its response was lost.
                try {
                    if (baselineKnown) {
                        var me = client.me();
                        if (me.queued()) {
                            return new Messages.QueueReply(true, me.matchId());
                        }
                        if (me.matchId() != null && !me.matchId().isBlank()) {
                            // A new active assignment proves that the admission reached the server.
                            if (!me.matchId().equals(previousAssignment)) {
                                return new Messages.QueueReply(false, me.matchId());
                            }
                            var assigned = client.match(me.matchId());
                            if (assigned.status().equals("RUNNING")
                                    || assigned.status().equals("SAVING")) {
                                return new Messages.QueueReply(false, me.matchId());
                            }
                        }
                    }
                } catch (ArenaException error) {
                    // An old completed assignment may already have been removed by replay
                    // retention.
                    if (!(error.status() == 404 && error.code().equals("MATCH_NOT_FOUND"))
                            && !error.transientFailure()) {
                        throw error;
                    }
                } catch (IOException ignored) {
                }
                if (admissionSent && !(failure instanceof ArenaException)) {
                    throw new IOException(
                            "Ответ на вход в очередь потерян, а действующее назначение не подтверждено. "
                                    + "Проверьте историю боёв в браузере перед повторным запуском клиента: раунд мог уже завершиться.",
                            failure);
                }
                if (attempt == 5) {
                    throw new IOException(
                            "Не удалось войти в очередь после шести попыток.", failure);
                }
                int delay = Math.min(5000, 250 * (1 << attempt));
                if (failure instanceof ArenaException error) {
                    delay = Math.max(delay, error.retryAfterSeconds() * 1000);
                }
                Thread.sleep(delay);
            }
        }
        throw new IllegalStateException("Unreachable retry state");
    }

    private static void requireActive(Messages.Me participant) throws ArenaException {
        if (participant.revoked()) {
            throw new ArenaException(401, "REVOKED", "Доступ отозван преподавателем.", 0);
        }
    }
}
