package colony.engine;

import colony.api.Colony;
import colony.api.ColonyView;
import colony.api.DepositKind;
import colony.api.Orders;
import colony.api.Rules;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Optional;
import java.util.Set;

/**
 * Полный набор правил движка: лиги и весь запас механик (шаг 2б). Загружается из JSON ({@link RulesLoader}).
 * Коду колонии он не виден: колония получает только правила своей лиги — {@link colony.api.Rules}
 * ({@code view.rules()}).
 *
 * @param maxTicks                 длина матча в тактах
 * @param truceTicks               перемирие с начала матча: оружие не ранит, чужие юниты проходимы
 * @param startEnergy              энергия колонии в начале
 * @param startWorkers             рабочих в начале
 * @param workerCost               цена рабочего
 * @param workerHp                 здоровье рабочего
 * @param workerCarry              сколько энергии несёт рабочий
 * @param workerVision             радиус обзора рабочего
 * @param workerUpkeepEvery        рабочий берёт 1 энергию на содержание на тактах 0, N, 2N…; нет энергии — теряет 1 здоровья
 * @param harvestRate              сколько энергии рабочий добывает за такт из обычной залежи
 * @param homeHarvestRate          сколько энергии рабочий добывает за такт из своей домашней залежи; чужую не добыть
 * @param richHarvestRate          сколько энергии рабочий добывает за такт из богатой залежи; {@code 0} — как из обычной
 *                                 (шаг «Выбор» ДЗ)
 * @param depositRegenEvery        обычная залежь восстанавливает 1 энергию раз в столько тактов
 * @param baseHp                   прочность базы
 * @param baseVision               радиус обзора базы
 * @param tankCost                 цена танка
 * @param tankHp                   здоровье танка
 * @param tankUpkeepEvery          танк берёт 1 энергию на содержание на тактах 0, N, 2N…
 * @param tankVision               радиус обзора танка
 * @param shellSpeed               клеток за такт пролетает снаряд
 * @param shellRange               дальность снаряда в клетках
 * @param shellDamage              урон снаряда
 * @param tankCooldown             тактов между выстрелами танка
 * @param baseFireCost             энергии стоит выстрел базы
 * @param baseFireRange            дальность выстрела базы
 * @param baseFireDamage           урон выстрела базы
 * @param buildCost                цена второй базы
 * @param buildMinDistanceToCenter вторую базу нельзя ставить ближе этого к центру
 * @param maxBases                 больше стольких баз у колонии не бывает
 * @param transferLossPercent      сколько процентов теряется при передаче чужому юниту
 * @param lootMinColonyUnits       трофеи остаются только с колоний не меньше этого числа юнитов
 * @param centerRadius             радиус центра вокруг центральной жилы; в лигах — в шагах ({@code |dx| + |dy|})
 * @param scoreEnergyDivisor       счёт = такты удержания центра + энергия / это число
 * @param raidFirstTick            такт первого налёта
 * @param raidEvery                налёт раз в столько тактов
 * @param raidSize                 налётчиков в одном налёте
 * @param eventEvery               объявленное событие раз в столько тактов
 * @param eventAnnounceTicks       за сколько тактов событие объявляют
 * @param eventDepositAmount       запас залежи, которую открывает событие
 * @param respawnTicks             пауза перед новой колонией после гибели
 * @param respawnProtectTicks      вернувшаяся колония столько тактов под защитой новичка
 * @param tickTimeoutMillis        сколько миллисекунд есть у {@link Colony#onTick} на такт
 * @param extraOrdersPerTick       приказов за такт сверх одного на каждый свой юнит и базу; лишние отбрасываются
 * @param maxWorkers               больше стольких рабочих у колонии не бывает (лиги: {@code features().unitCaps()})
 * @param maxTanks                 больше стольких танков у колонии не бывает (лиги: {@code features().unitCaps()})
 * @param meleeDamage              урон удара рабочего вплотную (лиги: {@code features().melee()})
 * @param strikeRange              танк бьёт первого чужого на прямой не дальше стольких клеток
 *                                 (лиги: {@code features().tankStrike()})
 * @param strikeDamage             урон удара танка
 * @param homeRadius               у своей базы юнит не ранится: не дальше стольких шагов от неё
 *                                 (лиги 3+: {@code features().homeGuard()})
 * @param depotCost                цена склада (ДЗ «лестница возможностей»: {@code features().depots()})
 * @param maxDepots                больше стольких складов у колонии не бывает
 * @param depotVision              радиус обзора склада
 * @param rubbleDurability         прочность завала {@code %}: столько ударов киркой его разбирают
 *                                 ({@code features().dig()})
 * @param upgradeCost              цена улучшения рабочего ({@code features().upgrades()})
 * @param centerHarvestRate        арена: сколько энергии рабочий добывает за такт из жилы сердца; {@code 0} — как из обычной
 * @param rulesVersion             версия правил, например {@code league-3}, {@code season1-2a} или {@code season1-2b}
 * @param features                 какие механики сезона уже включены
 */
public record RuleSet(
        int maxTicks,
        int truceTicks,
        int startEnergy,
        int startWorkers,
        int workerCost,
        int workerHp,
        int workerCarry,
        int workerVision,
        int workerUpkeepEvery,
        int harvestRate,
        int homeHarvestRate,
        int richHarvestRate,
        int depositRegenEvery,
        int baseHp,
        int baseVision,
        int tankCost,
        int tankHp,
        int tankUpkeepEvery,
        int tankVision,
        int shellSpeed,
        int shellRange,
        int shellDamage,
        int tankCooldown,
        int baseFireCost,
        int baseFireRange,
        int baseFireDamage,
        int buildCost,
        int buildMinDistanceToCenter,
        int maxBases,
        int transferLossPercent,
        int lootMinColonyUnits,
        int centerRadius,
        int scoreEnergyDivisor,
        int raidFirstTick,
        int raidEvery,
        int raidSize,
        int eventEvery,
        int eventAnnounceTicks,
        int eventDepositAmount,
        int respawnTicks,
        int respawnProtectTicks,
        int tickTimeoutMillis,
        int extraOrdersPerTick,
        int maxWorkers,
        int maxTanks,
        int meleeDamage,
        int strikeRange,
        int strikeDamage,
        int homeRadius,
        int depotCost,
        int maxDepots,
        int depotVision,
        int rubbleDurability,
        int upgradeCost,
        int centerHarvestRate,
        String rulesVersion,
        Features features) {

    /**
     * Правила, которые видит колония ({@code view.rules()}): только то, чем пользуется её лига. Запас механик 2б
     * колонии не виден.
     */
    public Rules forColony() {
        return forColony(abilities());
    }

    /**
     * Правила для колонии, которой открыты возможности {@code open}: склад, завалы и улучшения видны, только если
     * они есть в мире и открыты ей. Остальное — как в {@link #forColony()}.
     */
    public Rules forColony(Set<Ability> open) {
        Features f = features;
        Optional<Rules.Melee> melee = f.melee()
                ? Optional.of(new Rules.Melee(meleeDamage, f.homeGuard() ? homeRadius : 0)) : Optional.empty();
        Optional<Rules.Centre> centre = f.center() || f.centerMajority() || f.centerByTanks()
                ? Optional.of(new Rules.Centre(centerRadius)) : Optional.empty();
        Optional<Rules.Tanks> tanks = f.tanks()
                ? Optional.of(new Rules.Tanks(tankCost, tankHp, tankVision, f.tankStrike() ? strikeRange : shellRange,
                        f.tankStrike() ? strikeDamage : shellDamage, tankCooldown, f.unitCaps() ? maxTanks : 0))
                : Optional.empty();
        Optional<Rules.Depot> depot = f.depots() && open.contains(Ability.DEPOT)
                ? Optional.of(new Rules.Depot(depotCost, maxDepots, depotVision)) : Optional.empty();
        Optional<Rules.Dig> dig = f.dig() && open.contains(Ability.DIG)
                ? Optional.of(new Rules.Dig(rubbleDurability)) : Optional.empty();
        Optional<Rules.Upgrades> upgrades = f.upgrades() && open.contains(Ability.UPGRADES)
                ? Optional.of(new Rules.Upgrades(upgradeCost)) : Optional.empty();
        return new Rules(RulesLoader.leagueOf(this), maxTicks, truceTicks, startEnergy, workerCost,
                f.unitCaps() ? maxWorkers : 0, workerHp, workerCarry, harvestRate, workerVision, baseVision,
                f.passableForeign(), melee, centre, tanks, tickTimeoutMillis, depot, dig, upgrades);
    }

    /** Какие возможности ДЗ есть в этом мире: склад, завалы, улучшения — по флагам {@link #features()}. */
    public Set<Ability> abilities() {
        Set<Ability> out = Ability.none();
        for (Ability a : Ability.values()) {
            if (features.offers(a)) {
                out.add(a);
            }
        }
        return out;
    }

    /**
     * Те же правила, но из возможностей ДЗ остаются только {@code open}: остальные флаги выключены. Так сервер
     * сообщает колонии её правила при входе в мир.
     */
    public RuleSet limitedTo(Set<Ability> open) {
        if (open.containsAll(abilities())) {
            return this;
        }
        ObjectNode json = RulesLoader.toJson(this);
        ObjectNode f = (ObjectNode) json.get("features");
        for (Ability a : Ability.values()) {
            if (!open.contains(a)) {
                f.put(a.flag(), false);
            }
        }
        return RulesLoader.fromJson(json);
    }

    /** Сколько рабочий несёт: {@code workerCarry}, с сумкой ({@link colony.api.Upgrade#BAG}) — вдвое больше. */
    public int carryOf(java.util.Set<colony.api.Upgrade> upgrades) {
        return upgrades.contains(colony.api.Upgrade.BAG) ? 2 * workerCarry : workerCarry;
    }

    /** Сколько энергии рабочий добывает за такт из залежи вида {@code kind}: домашняя, богатая, остальные. */
    public int rateOf(DepositKind kind) {
        if (kind == DepositKind.HOME) {
            return homeHarvestRate;
        }
        if (kind == DepositKind.RICH && richHarvestRate > 0) {
            return richHarvestRate;
        }
        if (kind == DepositKind.CENTER && centerHarvestRate > 0) {
            return centerHarvestRate;
        }
        return harvestRate;
    }

    /**
     * Полные правила матча по виду колонии — для встроенных ботов, которым нужен весь запас (боты ворот А на
     * правилах 2б).
     *
     * @throws IllegalArgumentException вид построен не движком
     */
    public static RuleSet of(ColonyView view) {
        if (view instanceof ViewSnapshot v) {
            return v.ruleSet();
        }
        throw new IllegalArgumentException("вид построен не движком: " + view);
    }

    /**
     * Механики сезона, которые включаются по одной.
     *
     * @param tanks      танки и стрельба
     * @param loot       трофеи с погибших юнитов
     * @param baseFire   выстрел базы
     * @param secondBase вторая база
     * @param center     удержание центра
     * @param raiders    налётчики
     * @param events     объявленные события
     * @param foreignTransfer передача энергии чужим юнитам с потерей {@code transferLossPercent}
     * @param shellsFirst     опыт: снаряды летят в начале такта, до хода юнитов
     * @param centerByTanks   опыт: центр держит колония, у которой в радиусе больше всех танков; рабочие не в счёт
     * @param scoreByIncome   опыт: счёт = такты центра + вся добытая за матч энергия / {@code scoreEnergyDivisor};
     *                        налётчики идут к лидеру по счёту
     * @param unitCaps        лиги: рабочих не больше {@code maxWorkers}, танков не больше {@code maxTanks}
     * @param passableForeign лиги 1–2: чужие юниты проходимы, колонии друг другу не мешают
     * @param melee           лиги 3+: рабочий бьёт соседнего чужого юнита ({@link Orders#attack})
     * @param dropCarry       лиги 3+: погибший юнит роняет груз на свою клетку, его может добыть любой рабочий
     * @param scoreDelivered  лиги: счёт = вся энергия, сданная на базу за матч (+ такты центра)
     * @param centerMajority  лиги 4+: центр держит колония, у которой в радиусе {@code centerRadius} больше всех
     *                        юнитов; поровну — ничей
     * @param tankStrike      лига 5: выстрел танка — мгновенный удар по первому чужому на прямой до
     *                        {@code strikeRange} клеток, без снаряда; свои не мешают
     * @param freeWorker      лиги 3+: колония без рабочих и без энергии на рабочего получает рабочего бесплатно
     * @param homeGuard       лиги 3+: юнит не дальше {@code homeRadius} шагов от своей базы не ранится
     * @param fog             шаг «Туман» ДЗ: колония видит только залежи в обзоре, места остальных ей не известны
     * @param softCollisions  ДЗ «лестница возможностей»: свои меняются местами; в клетку, куда идут несколько
     *                        своих, проходит меньший номер, остальные стоят. С чужими — как прежде
     * @param depots          склады: {@code build(worker, d, Building.DEPOT)}
     * @param dig             завалы разбираются киркой: {@code dig(worker, d)}
     * @param upgrades        улучшения рабочих у базы: {@code upgrade(worker, PICK | BAG)}
     * @param upkeepNoDeath   опыт экономики мира: нечем платить содержание — рабочий работает даром, здоровье не
     *                        теряет. Колония без энергии не вымирает
     * @param foreignHomeHidden опыт экономики мира: чужих домашних залежей нет в {@code view.deposits()} (добыть их
     *                        всё равно нельзя); {@code depositAt} их показывает — клетка остаётся непроходимой
     * @param endlessDeposits арена: залежи не иссякают — добыча не уменьшает запас
     * @param emptyHidden     опыт экономики мира: залежи (кроме домашних) с запасом меньше груза рабочего
     *                        ({@code workerCarry}) нет в {@code view.deposits()}; {@code depositAt} её показывает
     */
    public record Features(
            boolean tanks,
            boolean loot,
            boolean baseFire,
            boolean secondBase,
            boolean center,
            boolean raiders,
            boolean events,
            boolean foreignTransfer,
            boolean shellsFirst,
            boolean centerByTanks,
            boolean scoreByIncome,
            boolean unitCaps,
            boolean passableForeign,
            boolean melee,
            boolean dropCarry,
            boolean scoreDelivered,
            boolean centerMajority,
            boolean tankStrike,
            boolean freeWorker,
            boolean homeGuard,
            boolean fog,
            boolean softCollisions,
            boolean depots,
            boolean dig,
            boolean upgrades,
            boolean upkeepNoDeath,
            boolean foreignHomeHidden,
            boolean emptyHidden,
            boolean endlessDeposits) {

        /** Есть ли в мире возможность {@code a}. */
        public boolean offers(Ability a) {
            return switch (a) {
                case DEPOT -> depots;
                case DIG -> dig;
                case UPGRADES -> upgrades;
            };
        }
    }
}
