package colony.engine.world;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.SplittableRandom;

/**
 * Квартал: квадрат {@code P × P}, четыре сектора вокруг прииска в кратере. Строится сектор северо-запада, остальные —
 * его повороты на 90°, поэтому соседи по кварталу равны в точности. Квартал на два места — тот же квартал, где
 * секторы северо-востока и юго-запада пусты (дикие), а симметрия — поворот на 180°.
 *
 * <p>Прииск: площадка в кратере, восемь богатых жил в его стене лицом к площадке (у каждого сектора две свои), кольцо
 * скалы, ров, внешнее кольцо. Площадка общая: свои жилы ближе, до соседских — пара шагов. На каждой оси —
 * дверь: проход сквозь оба кольца, а во рву на оси — завал. Дверь на оси общая для двух соседних секторов: кто её
 * разберёт, откроет короткий путь и соседу. Открытый обход: щель во внешнем кольце у одного конца четверти рва и щель во
 * внутреннем у другого — четверть круга пешком.
 */
final class PodGen {

    /**
     * Параметры квартала, общие для мира: сторона, смещение выхода от угла, облик, мест (4 или 2), база сектора 0 и
     * направление от неё к домашней жиле (по диагонали), отражение (вертушка в другую сторону) — одно на мир, чтобы
     * выходы соседних кварталов сходились.
     */
    record Params(int size, int exit, Archetype arch, int seats, int bx, int by, int hdx, int hdy,
                  boolean mirror, int[] near) {

        /** Те же параметры, но ближняя жила и карман — как в {@code near} (скелет первого квартала мира). */
        Params withNear(int[] fixed, int seatsHere) {
            return new Params(size, exit, arch, seatsHere, bx, by, hdx, hdy, mirror, fixed);
        }
    }

    /**
     * Длины путей сектора, в шагах от клетки у базы (завалы закрыты, если не сказано иначе).
     *
     * @param near1     до места у ближней жилы
     * @param near2     до места у жилы в кармане
     * @param mineDig   до места у жилы прииска, если завалы разобраны
     * @param mineOpen  до места у жилы прииска в обход завалов
     * @param exit      до выхода из квартала на западной стороне (через площадку прииска)
     * @param plugs     полос завала в секторе (без дверей прииска)
     */
    record Metrics(int near1, int near2, int mineDig, int mineOpen, int exit, int plugs) {

        int[] vector() {
            return new int[] {near1, near2, mineDig, mineOpen, exit};
        }
    }

    /** Сектор готового квартала: база, домашняя, ближняя и жила в кармане — в координатах квартала. */
    record Sector(int index, int[] base, int[] home, int[] near1, int[] near2) {}

    /** Готовый квартал в своих координатах. */
    static final class Pod {
        final int size;
        final int seats;
        final Cells g;
        /** Занятые секторы по часовой стрелке с северо-запада; на два места — северо-запад и юго-восток. */
        final List<Sector> sectors;
        final Metrics m;
        final long seed;
        final boolean mirrored;
        /** Скелет ближних жил сектора 0: ближняя (x, y, маска мест), карман (x, y), выход кармана (dx, dy). */
        int[] near;

        Pod(int size, int seats, Cells g, List<Sector> sectors, Metrics m, long seed, boolean mirrored) {
            this.size = size;
            this.seats = seats;
            this.g = g;
            this.sectors = sectors;
            this.m = m;
            this.seed = seed;
            this.mirrored = mirrored;
        }
    }

    /** До прииска через дверь — шагов от клетки у базы. */
    static final int MINE_DIG_MIN = 12;
    static final int MINE_DIG_MAX = 22;
    /** Обход длиннее двери хотя бы на столько шагов и не длиннее предела. */
    static final int DETOUR_MIN = 7;
    static final int MINE_OPEN_MAX = 34;

    private final Params p;
    private final int n;
    private final int c;
    private final SplittableRandom r;
    private final Cells g;
    private final boolean[] lock;
    private int order = 4;

    // сектор 0 в каноническом виде
    private int bx;
    private int by;
    private int[] near1;
    private int[] near2;
    private int plugs;

    private PodGen(Params p, long seed) {
        this.p = p;
        this.n = p.size();
        this.c = n / 2;
        this.r = new SplittableRandom(seed);
        this.g = new Cells(n, n, Cells.FLOOR);
        this.lock = new boolean[n * n];
    }

    /** Квартал по зерну или {@code null}, если зерно не дало годного квартала. */
    static Pod build(Params p, long seed) {
        if (p.size() % 2 == 0) {
            throw new IllegalArgumentException("сторона квартала должна быть нечётной: " + p.size());
        }
        return new PodGen(p, seed).run(seed);
    }

    // ---- симметрия ----

    /** Поворот на 90° {@code k} раз: (x, y) → (n−1−y, x). */
    int[] rot(int x, int y, int k) {
        int ax = x;
        int ay = y;
        for (int i = 0; i < (k & 3); i++) {
            int t = n - 1 - ay;
            ay = ax;
            ax = t;
        }
        return new int[] {ax, ay};
    }

    /** Клетка сектора 0 в секторе {@code k} готового квартала (с отражением, если оно было). */
    private int[] place(int x, int y, int k, boolean mirror) {
        int[] q = mirror ? new int[] {y, x} : new int[] {x, y};
        return rot(q[0], q[1], k);
    }

    private void put(int x, int y, char ch) {
        for (int k = 0; k < 4; k += 4 / order) {
            int[] q = rot(x, y, k);
            g.set(q[0], q[1], ch);
        }
    }

    private void hold(int x, int y) {
        for (int k = 0; k < 4; k += 4 / order) {
            int[] q = rot(x, y, k);
            if (g.in(q[0], q[1])) {
                lock[g.idx(q[0], q[1])] = true;
            }
        }
    }

    private void putHold(int x, int y, char ch) {
        put(x, y, ch);
        hold(x, y);
    }

    private boolean locked(int x, int y) {
        return !g.in(x, y) || lock[g.idx(x, y)];
    }

    /** Представитель клетки в секторе 0 (северо-запад и западная полуось). */
    int[] rep(int x, int y) {
        int[] q = {x, y};
        for (int k = 0; k < 4; k++) {
            if (q[0] < c && q[1] <= c) {
                return q;
            }
            q = rot(q[0], q[1], 1);
        }
        return new int[] {c, c};
    }

    // ---- постройка ----

    /** Отладка: почему кварталы отбрасываются (включается {@code -Dworldgen.why=true}). */
    static final java.util.Map<String, Integer> WHY = new java.util.concurrent.ConcurrentHashMap<>();
    private static final boolean TRACE_WHY = Boolean.getBoolean("worldgen.why");
    private String lastWhy = "";

    private static Pod why(String reason) {
        if (TRACE_WHY) {
            String key = reason;
            WHY.merge(key, 1, Integer::sum);
        }
        return null;
    }

    private Pod run(long seed) {
        terrain();
        border();
        crater();
        exits();
        if (!base()) {
            return why("база");
        }
        if (p.near() != null ? !placeFixed(p.near()) : !nearDeposits()) {
            return why(p.near() != null ? "скелет" : near1 == null ? "ближняя" : "карман");
        }
        grow();
        rubble();
        cleanup();
        Metrics m = measure();
        if (m == null) {
            return why(lastWhy);
        }
        if (!acceptable(m)) {
            return why("длины " + java.util.Arrays.toString(m.vector()));
        }
        if (p.seats() == 2) {
            unseat();
            order = 2;
            cleanup();
            m = measure();
            if (m == null || !acceptable(m)) {
                return null;
            }
        }
        boolean mirror = p.mirror();
        Cells out = g;
        if (mirror) {
            out = new Cells(n, n, Cells.ROCK);
            for (int y = 0; y < n; y++) {
                for (int x = 0; x < n; x++) {
                    out.set(y, x, g.get(x, y));
                }
            }
        }
        int[] h0 = null;
        for (int[] d : Cells.RING8) {
            if (g.get(bx + d[0], by + d[1]) == 'H') {
                h0 = new int[] {bx + d[0], by + d[1]};
            }
        }
        List<Sector> sectors = new ArrayList<>();
        for (int k = 0; k < 4; k++) {
            if (p.seats() == 2 && (k & 1) == 1) {
                continue;
            }
            sectors.add(new Sector(k, place(bx, by, k, mirror), place(h0[0], h0[1], k, mirror),
                    place(near1[0], near1[1], k, mirror), place(near2[0], near2[1], k, mirror)));
        }
        // жадный шаг не симметричен поворотам (порядок осей и «С, В, Ю, З»): проверяем каждый сектор как он есть
        for (Sector s : sectors) {
            if (!greedyOk(out, s)) {
                return why("жадный шаг");
            }
        }
        Pod pod = new Pod(n, p.seats(), out, sectors, m, seed, mirror);
        pod.near = skeleton();
        return pod;
    }

    /** Скелет ближних жил этого квартала — чтобы остальные кварталы мира повторили его. */
    private int[] skeleton() {
        int mask = 0;
        for (int k = 0; k < 4; k++) {
            int[] dd = Cells.DIRS[k];
            if (Cells.walk(g.get(near1[0] + dd[0], near1[1] + dd[1]))) {
                mask |= 1 << k;
            }
        }
        return new int[] {near1[0], near1[1], mask, near2[0], near2[1], pocketDir[0], pocketDir[1]};
    }

    private int[] pocketDir;

    /** Ближняя жила и карман по скелету мира; вокруг них рельеф расчищается на две клетки. */
    private boolean placeFixed(int[] sk) {
        int[] q = {sk[0], sk[1]};
        int[] q2 = {sk[3], sk[4]};
        for (int[] at : new int[][] {q, q2}) {
            for (int y = at[1] - 1; y <= at[1] + 1; y++) {
                for (int x = at[0] - 1; x <= at[0] + 1; x++) {
                    if (!locked(x, y)) {
                        put(x, y, Cells.FLOOR);
                    }
                }
            }
        }
        if (locked(q[0], q[1])) {
            return false;
        }
        putHold(q[0], q[1], '*');
        for (int k = 0; k < 4; k++) {
            int x = q[0] + Cells.DIRS[k][0];
            int y = q[1] + Cells.DIRS[k][1];
            boolean keep = (sk[2] >> k & 1) == 1;
            if (locked(x, y) && Cells.walk(g.get(x, y)) != keep) {
                return false;
            }
            putHold(x, y, keep ? Cells.FLOOR : Cells.ROCK);
        }
        near1 = q;
        return pocket(q2[0], q2[1], new int[] {sk[5], sk[6]}, false);
    }

    /** Крупные формы рельефа сектора 0: {x, y, радиус} — для осыпей у столовых гор и кромок у провалов. */
    private final List<double[]> forms = new ArrayList<>();

    /**
     * Рельеф сектора по облику мира, затем повёрнут на четыре стороны. Формы крупные и узнаваемые: столовые горы на
     * плато, длинные гряды в ущельях, извилистые стены в лабиринте, круглые провалы. Мелочь потом убирается.
     */
    private void terrain() {
        boolean[] raw = new boolean[n * n];
        switch (p.arch()) {
            case PLATEAU -> {
                // плато: открыто, массив — один и не всегда
                int count = r.nextDouble() < 0.5 ? 1 : 0;
                for (int i = 0; i < count; i++) {
                    double rad = 1.8 + r.nextDouble() * 0.7;
                    double[] at = formSpot(rad);
                    if (at != null) {
                        blob(raw, at[0], at[1], rad);
                        forms.add(new double[] {at[0], at[1], rad});
                    }
                }
            }
            case SINKHOLES -> {
                // провалы: одна-две большие круглые ямы
                int count = 1 + r.nextInt(2);
                for (int i = 0; i < count; i++) {
                    double rad = 2.6 + r.nextDouble() * 0.6;
                    double[] at = formSpot(rad);
                    if (at != null) {
                        Terrain.disc(raw, n, n, at[0], at[1], rad);
                        forms.add(new double[] {at[0], at[1], rad});
                    }
                }
            }
            case CANYONS -> {
                // гряды вдоль одного направления в секторе: вдоль диагонали квартала или поперёк неё
                double ang = (r.nextBoolean() ? Math.PI / 4 : -Math.PI / 4) + (r.nextDouble() - 0.5) * 0.5;
                int count = 3 + r.nextInt(2);
                for (int i = 0; i < count; i++) {
                    double[] at = formSpot(1.0);
                    if (at != null) {
                        double a = ang + (r.nextBoolean() ? 0 : Math.PI);
                        Terrain.ridge(raw, n, n, at[0], at[1], a, 11 + r.nextInt(6), 0.12, true, r);
                    }
                }
            }
            case ROCK_MAZE -> {
                // лабиринт: много скал среднего размера
                double[] nz = Terrain.fractal(n, n, 2.2, 0.5, r);
                double t = Terrain.threshold(nz, 0.46);
                for (int i = 0; i < raw.length; i++) {
                    raw[i] = nz[i] > t;
                }
                raw = Terrain.smooth(raw, n, n, null);
            }
        }
        boolean[] rock = new boolean[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                int[] q = rep(x, y);
                rock[g.idx(x, y)] = raw[g.idx(q[0], q[1])];
            }
        }
        for (int i = 0; i < rock.length; i++) {
            g.a[i] = rock[i] ? Cells.ROCK : Cells.FLOOR;
        }
    }

    /** Середина крупной формы радиуса {@code rad} в свободной части сектора 0: не у базы, не у кратера, не у края. */
    private double[] formSpot(double rad) {
        for (int t = 0; t < 40; t++) {
            double x = 2 + r.nextDouble() * (c - 3);
            double y = 2 + r.nextDouble() * (c - 3);
            boolean nearBase = Math.max(Math.abs(x - p.bx()), Math.abs(y - p.by())) < 2.5 + rad;
            boolean nearCrater = Math.hypot(x - c, y - c) < 7.0 + rad * 0.6;
            boolean nearExit = x < 3 + rad && Math.abs(y - p.exit() - 0.5) < 2 + rad;
            boolean overlap = false;
            for (double[] f : forms) {
                if (Math.hypot(x - f[0], y - f[1]) < rad + f[2] + 2.5) {
                    overlap = true;
                }
            }
            if (!nearBase && !nearCrater && !nearExit && !overlap) {
                return new double[] {x, y};
            }
        }
        return null;
    }

    /** Неровный круг: край гуляет по шуму на полклетки. */
    private void blob(boolean[] raw, double cx, double cy, double rad) {
        int r0 = (int) Math.ceil(rad + 1);
        for (int dy = -r0; dy <= r0; dy++) {
            for (int dx = -r0; dx <= r0; dx++) {
                int x = (int) Math.round(cx) + dx;
                int y = (int) Math.round(cy) + dy;
                if (x < 0 || y < 0 || x >= n || y >= n) {
                    continue;
                }
                double d = Math.hypot(x - cx, y - cy);
                if (d <= rad + (r.nextDouble() - 0.5) * 1.1) {
                    raw[y * n + x] = true;
                }
            }
        }
    }

    /** Край квартала: ряд скалы и неровный наплыв в одну-две клетки внутрь (по шуму), чтобы край не был по линейке. */
    private void border() {
        double[] nz = Terrain.valueNoise(n, 2, 3.5, r);
        for (int i = 0; i < n; i++) {
            putHold(i, 0, Cells.ROCK);
            if (nz[i] > (p.arch() == Archetype.PLATEAU ? 0.62 : 0.42)) {
                put(i, 1, Cells.ROCK);
            }
            if (nz[i] > 0.7) {
                put(i, 2, Cells.ROCK);
            }
        }
    }

    /** Радиус площадки прииска: на ней жилы и места у них, сюда же сходятся выходы квартала. */
    static final double PLAZA = 4.5;
    private static final double TUNNEL_IN = 6.0;
    private static final double TUNNEL_OUT = 7.8;

    /**
     * Кратер — крепость квартала. Площадка радиусом 4,5 с четырьмя богатыми жилами (по одной на сектор, к каждой — 4
     * места). Вокруг — внутреннее кольцо скалы, под ним кольцевой ход шириной 2, внешнее кольцо с неровным краем.
     * Кольцевой ход разрезан стенами выходов на четыре четверти — у каждого сектора своя: вход снаружи у северного
     * конца четверти, выход на площадку — у западного. Это открытый обход. Короткий путь — дверь: две клетки завала
     * сквозь внешнее кольцо прямо к западному концу (8 ударов), без дуги. Из площадки к серединам сторон квартала идут четыре выхода шириной 2,
     * со стенами по бокам и без входов из секторов: наружу сектор попадает только через площадку.
     */
    private void crater() {
        double[] bump = Terrain.valueNoise(n, n, 3.0, r);
        // радиус колец гуляет по углу (период — четверть круга, чтобы повороты сходились); ход и кольца сдвигаются
        // вместе, ширина хода та же
        double amp = 0.5 + r.nextDouble() * 0.4;
        double ph1 = r.nextDouble() * 2 * Math.PI;
        double ph2 = r.nextDouble() * 2 * Math.PI;
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                int[] q = rep(x, y);
                if (q[0] != x || q[1] != y) {
                    continue;
                }
                double d = Math.hypot(x - c, y - c);
                double th = Math.atan2(y - c, x - c);
                double off = amp * (0.5 + 0.32 * Math.sin(4 * th + ph1) + 0.18 * Math.sin(8 * th + ph2));
                double ro = 8.6 + off + bump[g.idx(x, y)] * 0.9;
                char ch;
                if (d <= PLAZA + off) {
                    ch = Cells.FLOOR;
                } else if (d <= TUNNEL_IN + off) {
                    ch = Cells.ROCK;
                } else if (d <= TUNNEL_OUT + off) {
                    ch = Cells.FLOOR;
                } else if (d <= ro) {
                    ch = Cells.ROCK;
                } else {
                    continue;
                }
                putHold(x, y, ch);
            }
        }
        for (int[] m : mineCells()) {
            putHold(m[0], m[1], '$');
        }
        // выход на запад: ряды c и c+1 от края площадки до стены квартала, стены — ряды c−1 и c+2
        for (int x = 0; x <= c - 5; x++) {
            putHold(x, c, Cells.FLOOR);
            putHold(x, c + 1, Cells.FLOOR);
            if (x >= 1) {
                putHold(x, c - 1, Cells.ROCK);
                putHold(x, c + 2, Cells.ROCK);
            }
        }
        // четверть кольцевого хода сектора 0: от стены западного выхода (dy ≤ −2) до стены северного (dx ≤ −3)
        // вход снаружи у северного конца (две клетки шириной), выход на площадку у западного
        // вход — щель шириной 2 между скальной стенкой и стеной северного выхода, открытая только сверху: к входу
        // идут в обход стенки, вдоль края квартала
        for (int y = 1; y <= c - 7; y++) {
            putHold(c - 3, y, Cells.FLOOR);
            putHold(c - 4, y, Cells.FLOOR);
        }
        for (int y = 2; y <= c - 8; y++) {
            putHold(c - 5, y, Cells.ROCK);
        }
        putHold(c - 5, 1, Cells.FLOOR);
        putHold(c - 6, 1, Cells.FLOOR);
        putHold(c - 5, c - 2, Cells.FLOOR);
        putHold(c - 5, c - 3, Cells.FLOOR);
        putHold(c - 4, c - 3, Cells.FLOOR);
        // дверь: сквозь внешнее кольцо прямо к западному концу четверти, где выход на площадку, — срезка всей дуги
        putHold(c - 7, c - 3, Cells.RUBBLE);
        putHold(c - 8, c - 3, Cells.RUBBLE);
        putHold(c - 9, c - 3, Cells.FLOOR);
        putHold(c - 10, c - 3, Cells.FLOOR);
    }

    /** Выходы сектора больше не нужны: квартал выходит наружу только через площадку прииска. */
    private void exits() {
    }

    /** База и домашняя жила по диагонали от неё: у домашней ровно одно место, вплотную к базе. */
    private boolean base() {
        for (int attempt = 0; attempt < 1; attempt++) {
            int x = p.bx();
            int y = p.by();
            int dx = p.hdx();
            int dy = p.hdy();
            // домашняя жила — от края квартала
            if (x + 2 * dx < 2 || y + 2 * dy < 2) {
                continue;
            }
            boolean clash = false;
            for (int yy = y - 2; yy <= y + 2 && !clash; yy++) {
                for (int xx = x - 2; xx <= x + 2; xx++) {
                    if (locked(xx, yy) && g.get(xx, yy) != Cells.FLOOR) {
                        clash = true;
                        break;
                    }
                }
            }
            if (clash) {
                continue;
            }
            for (int yy = y - 2; yy <= y + 2; yy++) {
                for (int xx = x - 2; xx <= x + 2; xx++) {
                    if (!locked(xx, yy)) {
                        boolean inner = Math.max(Math.abs(xx - x), Math.abs(yy - y)) <= 1;
                        if (inner) {
                            putHold(xx, yy, Cells.FLOOR);
                        } else {
                            put(xx, yy, Cells.FLOOR);
                        }
                    }
                }
            }
            bx = x;
            by = y;
            putHold(x, y, '@');
            putHold(x + dx, y + dy, 'H');
            // у домашней одно место — ниша вплотную к базе, закрытая скалой: туда только появляются, мимо никто не
            // ходит. У базы ещё две свободные клетки, к середине квартала: туда сдают и там появляются. Без ниши
            // гружёный рабочий шагает в клетку добывающего у домашней (поиск пути юнитов не видит) и колония встаёт.
            putHold(x + dx, y, Cells.ROCK);
            putHold(x + 2 * dx, y + dy, Cells.ROCK);
            putHold(x + dx, y + 2 * dy, Cells.ROCK);
            putHold(x + 2 * dx, y + 2 * dy, Cells.ROCK);
            putHold(x, y + 2 * dy, Cells.ROCK);
            putHold(x - dx, y + dy, Cells.ROCK);
            return true;
        }
        return false;
    }

    /** Клетки у базы, откуда ходят: без ниши домашней жилы. */
    private List<int[]> baseCells() {
        return walkOut(g, bx, by);
    }

    /** Свободные клетки у базы {@code (x, y)}, кроме ниши у домашней жилы. */
    static List<int[]> walkOut(Cells cells, int x, int y) {
        List<int[]> out = new ArrayList<>();
        for (int[] s : cells.spots(x, y)) {
            boolean niche = false;
            for (int[] d : Cells.DIRS) {
                if (cells.get(s[0] + d[0], s[1] + d[1]) == 'H') {
                    niche = true;
                }
            }
            if (!niche) {
                out.add(s);
            }
        }
        return out;
    }

    /** Ближняя жила на виду (жадный шаг доходит) и жила в кармане за скалой (жадный шаг застревает). */
    private boolean nearDeposits() {
        int[] d0 = g.dist(baseCells(), false, 0);
        List<int[]> firsts = new ArrayList<>();
        for (int y = 1; y < c; y++) {
            for (int x = 1; x < c; x++) {
                int v = d0[g.idx(x, y)];
                if (v >= 4 && v <= 7 && !locked(x, y) && quietAround(x, y) && foreignFar(x, y)) {
                    firsts.add(new int[] {x, y});
                }
            }
        }
        shuffle(firsts);
        firsts.sort((a, b) -> rockSides(b) - rockSides(a));
        if (firsts.isEmpty() && TRACE_WHY) {
            int all = 0;
            int far = 0;
            for (int y = 1; y < c; y++) {
                for (int x = 1; x < c; x++) {
                    int v = d0[g.idx(x, y)];
                    if (v >= 4 && v <= 7 && !locked(x, y) && quietAround(x, y)) {
                        all++;
                        if (foreignFar(x, y)) {
                            far++;
                        }
                    }
                }
            }
            why("нет ближней: мест " + all + ", вдали от соседей " + far);
        }
        for (int k = 0; k < Math.min(6, firsts.size()); k++) {
            char[] save = g.a.clone();
            boolean[] saveLock = lock.clone();
            if (nearPair(firsts.get(k), d0)) {
                return true;
            }
            System.arraycopy(save, 0, g.a, 0, save.length);
            System.arraycopy(saveLock, 0, lock, 0, lock.length);
            near1 = null;
        }
        return false;
    }

    /** Ближняя жила в {@code q0} и карман к ней; {@code false} — карман не встал. */
    private boolean nearPair(int[] q0, int[] d) {
        // ближняя: два места, вплотную к скале
        List<int[]> cands = new ArrayList<>();
        cands.add(q0);
        int[] q = cands.get(0);
        putHold(q[0], q[1], '*');
        trimSpots(q, d, 2);
        near1 = q;
        // карман: жила, вокруг скала, вход — от базы в сторону
        d = g.dist(baseCells(), false, 0);
        cands.clear();
        for (int y = 2; y < c - 1; y++) {
            for (int x = 2; x < c - 1; x++) {
                int v = d[g.idx(x, y)];
                if (v >= 5 && v <= 12 && Math.abs(x - near1[0]) + Math.abs(y - near1[1]) >= 4) {
                    boolean free = true;
                    for (int yy = y - 1; yy <= y + 1 && free; yy++) {
                        for (int xx = x - 1; xx <= x + 1; xx++) {
                            if (locked(xx, yy)) {
                                free = false;
                                break;
                            }
                        }
                    }
                    if (free) {
                        cands.add(new int[] {x, y});
                    }
                }
            }
        }
        shuffle(cands);
        for (int[] cand : cands) {
            int x = cand[0];
            int y = cand[1];
            // выход кармана — в сторону от базы
            int[] o = null;
            int best = Integer.MIN_VALUE;
            for (int[] dir : Cells.DIRS) {
                int dot = dir[0] * (x - bx) + dir[1] * (y - by);
                if (dot > best) {
                    best = dot;
                    o = dir;
                }
            }
            if (pocket(x, y, o, true)) {
                return true;
            }
        }
        return false;
    }

    /** Сколько рабочих колония посылает к прииску в расчёте: столько мест у богатых жил должно быть ближе чужих жил. */
    static final int MINE_WORKERS = 2;
    /** Самый узкий проход между кварталами. */
    static final int SEAM_MIN = 5;

    /**
     * Ближняя жила в {@code (x, y)} не станет чужой приманкой: у соседей по кварталу (повороты) и у соседей через
     * гряду (тот же сектор соседнего квартала слева и сверху) её копия дальше от нашей базы по прямой
     * ({@code |dx| + |dy|}), чем {@link #MINE_WORKERS}-е место у богатых жил кратера. Колонии выбирают место по
     * прямой: иначе рабочий уходит к соседской жиле в обход на 40–60 шагов, вместо своего прииска.
     */
    private boolean foreignFar(int x, int y) {
        List<Integer> mine = new ArrayList<>();
        java.util.Set<Integer> seen = new java.util.HashSet<>();
        for (int k = 0; k < 4; k++) {
            for (int[] mc : mineCells()) {
                int[] q = rot(mc[0], mc[1], k);
                for (int[] d : Cells.DIRS) {
                    int sx = q[0] + d[0];
                    int sy = q[1] + d[1];
                    if (Math.hypot(sx - c, sy - c) <= PLAZA && seen.add(g.idx(sx, sy))) {
                        mine.add(Math.abs(sx - bx) + Math.abs(sy - by));
                    }
                }
            }
        }
        mine.sort(null);
        int thr = mine.get(Math.min(MINE_WORKERS, mine.size()) - 1);
        int[] r1 = rot(x, y, 1);
        int[] r3 = rot(x, y, 3);
        int shift = n + SEAM_MIN;
        int[][] copies = {r1, r3, {r1[0] - shift, r1[1]}, {r3[0], r3[1] - shift}};
        for (int[] q : copies) {
            if (Math.abs(q[0] - bx) + Math.abs(q[1] - by) - 1 <= thr) {
                return false;
            }
        }
        return true;
    }

    /**
     * Карман: жила {@code (x, y)} в скальном блоке 3×3 с прорезью в сторону {@code o}. Годится, если до места у жилы
     * 5–11 шагов, жадный шаг от базы туда не доходит, ближняя жила по-прежнему достижима. {@code strict} — не трогать
     * закреплённые клетки (поиск), иначе — ставить по скелету.
     */
    private boolean pocket(int x, int y, int[] o, boolean strict) {
        int[] pp = {o[1], o[0]};
        int mx = x + o[0];
        int my = y + o[1];
        int ox = x + 2 * o[0];
        int oy = y + 2 * o[1];
        if (!g.in(ox, oy) || strict && (locked(mx, my) || locked(ox, oy) || g.get(ox, oy) != Cells.FLOOR)) {
            return false;
        }
        for (int yy = y - 1; yy <= y + 1; yy++) {
            for (int xx = x - 1; xx <= x + 1; xx++) {
                if (locked(xx, yy) && !(xx == mx && yy == my) && g.get(xx, yy) != Cells.ROCK) {
                    return false;
                }
            }
        }
        char[] save = g.a.clone();
        boolean[] saveLock = lock.clone();
        for (int yy = y - 1; yy <= y + 1; yy++) {
            for (int xx = x - 1; xx <= x + 1; xx++) {
                putHold(xx, yy, Cells.ROCK);
            }
        }
        putHold(x + o[0] + pp[0], y + o[1] + pp[1], Cells.ROCK);
        putHold(x + o[0] - pp[0], y + o[1] - pp[1], Cells.ROCK);
        putHold(x, y, '*');
        putHold(mx, my, Cells.FLOOR);
        putHold(ox, oy, Cells.FLOOR);
        int[] d2 = g.dist(baseCells(), false, 0);
        int v = d2[g.idx(mx, my)];
        boolean trap = true;
        for (int[] s0 : baseCells()) {
            if (g.greedyReaches(s0[0], s0[1], mx, my)) {
                trap = false;
            }
        }
        if (v >= 5 && v <= 12 && trap && g.toSpots(d2, near1[0], near1[1]) >= 0) {
            near2 = new int[] {x, y};
            pocketDir = o;
            return true;
        }
        System.arraycopy(save, 0, g.a, 0, save.length);
        System.arraycopy(saveLock, 0, lock, 0, lock.length);
        return false;
    }

    /** Рядом с клеткой нет закреплённых жил, базы и завалов, чтобы жила не легла впритык к ним. */
    private boolean quietAround(int x, int y) {
        for (int yy = y - 1; yy <= y + 1; yy++) {
            for (int xx = x - 1; xx <= x + 1; xx++) {
                char ch = g.get(xx, yy);
                if (locked(xx, yy) && !(xx == x && yy == y) && ch != Cells.FLOOR && ch != Cells.ROCK) {
                    return false;
                }
            }
        }
        return g.get(x, y) == Cells.FLOOR;
    }

    private int rockSides(int[] q) {
        int k = 0;
        for (int[] d : Cells.DIRS) {
            if (g.get(q[0] + d[0], q[1] + d[1]) == Cells.ROCK) {
                k++;
            }
        }
        return k == 2 ? 3 : k == 1 ? 2 : k == 3 ? 1 : 0;
    }

    /** Оставить у жилы {@code keep} мест — ближайших к базе; остальные закрыть скалой. */
    private void trimSpots(int[] q, int[] d, int keep) {
        List<int[]> s = g.spots(q[0], q[1]);
        s.sort((a, b) -> Integer.compare(score(d, a), score(d, b)));
        for (int i = keep; i < s.size(); i++) {
            putHold(s.get(i)[0], s.get(i)[1], Cells.ROCK);
        }
        for (int i = 0; i < Math.min(keep, s.size()); i++) {
            hold(s.get(i)[0], s.get(i)[1]);
        }
    }

    private int score(int[] d, int[] cell) {
        int v = d[g.idx(cell[0], cell[1])];
        return v < 0 ? 999 : v;
    }

    /**
     * Скальные массивы нарастают на стены каркаса и формы облика по шуму: стены выхода, перегородка у входа в четверть
     * и край квартала тонут в неровной скале. Пути от базы к ключевым местам не зарастают (их потом расширяют до двух
     * клеток). Насколько густо — по облику: плато почти не зарастает, лабиринт — сильнее всех.
     */
    private void grow() {
        double t = switch (p.arch()) {
            case PLATEAU -> 0.92;
            case SINKHOLES -> 0.78;
            case CANYONS -> 0.72;
            case ROCK_MAZE -> 0.66;
        };
        boolean[] free = new boolean[n * n];
        int[][] targets = {{c - 3, c - 11}, {near1[0], near1[1]}, {c - 10, c - 3},
                {near2[0] + 2 * pocketDir[0], near2[1] + 2 * pocketDir[1]}};
        for (int[] tg : targets) {
            for (int[] cell : route(baseCells(), tg)) {
                free[g.idx(cell[0], cell[1])] = true;
            }
        }
        double[] nz = Terrain.valueNoise(n, n, 2.6, r);
        for (int it = 0; it < 2; it++) {
            List<int[]> add = new ArrayList<>();
            for (int y = 1; y <= c; y++) {
                for (int x = 1; x < c; x++) {
                    int[] q = rep(x, y);
                    if (q[0] != x || q[1] != y || locked(x, y) || free[g.idx(x, y)] || g.get(x, y) != Cells.FLOOR
                            || nz[g.idx(x, y)] <= t) {
                        continue;
                    }
                    for (int[] d : Cells.DIRS) {
                        if (g.get(x + d[0], y + d[1]) == Cells.ROCK) {
                            add.add(new int[] {x, y});
                            break;
                        }
                    }
                }
            }
            for (int[] a : add) {
                put(a[0], a[1], Cells.ROCK);
            }
        }
    }

    /** Завалы облика: пробки в узких местах, осыпи у подножий, обвалившиеся кромки провалов. */
    private void rubble() {
        int want = switch (p.arch()) {
            case CANYONS, ROCK_MAZE -> 2;
            case PLATEAU, SINKHOLES -> 1;
        };
        for (int i = 0; i < want; i++) {
            if (plug()) {
                plugs++;
            }
        }
        widenRoutes();
    }

    /**
     * Магистрали сектора не уже двух клеток: путь от базы ко входу в кратер и к ближней жиле. Где путь идёт щелью в
     * клетку, соседняя незакреплённая скала сбоку становится полом. Чужой юнит в щели шириной в клетку — вечная пробка.
     */
    private void widenRoutes() {
        int[][] targets = {{c - 3, c - 11}, {near1[0], near1[1]}};
        for (int[] t : targets) {
            List<int[]> path = route(baseCells(), t);
            for (int k = 1; k + 1 < path.size(); k++) {
                int[] cur = path.get(k);
                int[] nx = path.get(k + 1);
                int dx = nx[0] - cur[0];
                int dy = nx[1] - cur[1];
                int[] sideA = {cur[0] - dy, cur[1] + dx};
                int[] sideB = {cur[0] + dy, cur[1] - dx};
                boolean openA = Cells.walk(g.get(sideA[0], sideA[1]));
                boolean openB = Cells.walk(g.get(sideB[0], sideB[1]));
                if (openA || openB) {
                    continue;
                }
                for (int[] side : new int[][] {sideA, sideB}) {
                    if (g.get(side[0], side[1]) == Cells.ROCK && !locked(side[0], side[1])) {
                        put(side[0], side[1], Cells.FLOOR);
                        break;
                    }
                }
            }
        }
    }

    /** Кратчайший путь (клетки) от ближайшей из {@code from} до клетки {@code to} или вплотную к ней. */
    private List<int[]> route(List<int[]> from, int[] to) {
        int[] prev = new int[n * n];
        java.util.Arrays.fill(prev, -2);
        java.util.ArrayDeque<Integer> q = new java.util.ArrayDeque<>();
        for (int[] f : from) {
            prev[g.idx(f[0], f[1])] = -1;
            q.add(g.idx(f[0], f[1]));
        }
        int hit = -1;
        while (!q.isEmpty() && hit < 0) {
            int i = q.poll();
            int x = i % n;
            int y = i / n;
            if (Math.abs(x - to[0]) + Math.abs(y - to[1]) <= 1) {
                hit = i;
                break;
            }
            for (int[] d : Cells.DIRS) {
                int nx = x + d[0];
                int ny = y + d[1];
                if (g.walk(nx, ny, false) && prev[g.idx(nx, ny)] == -2) {
                    prev[g.idx(nx, ny)] = i;
                    q.add(g.idx(nx, ny));
                }
            }
        }
        List<int[]> out = new ArrayList<>();
        for (int i = hit; i >= 0; i = prev[i]) {
            out.add(0, new int[] {i % n, i / n});
        }
        return out;
    }

    /**
     * Осыпь у столовой горы или обвалившаяся кромка провала: дуга завала шириной в клетку вокруг формы {@code f}, в
     * сторону случайного направления, на угол {@code ±span} радиан. Остаётся, только если ключевые места достижимы.
     */
    private void skirt(double[] f, double span) {
        double dir = r.nextDouble() * 2 * Math.PI;
        char[] save = g.a.clone();
        boolean any = false;
        int r0 = (int) Math.ceil(f[2] + 2);
        for (int dy = -r0; dy <= r0; dy++) {
            for (int dx = -r0; dx <= r0; dx++) {
                int x = (int) Math.round(f[0]) + dx;
                int y = (int) Math.round(f[1]) + dy;
                if (!g.in(x, y) || locked(x, y) || g.get(x, y) != Cells.FLOOR) {
                    continue;
                }
                double d = Math.hypot(x - f[0], y - f[1]);
                double a = Math.atan2(y - f[1], x - f[0]);
                double off = Math.abs(Math.atan2(Math.sin(a - dir), Math.cos(a - dir)));
                if (d > f[2] + 0.3 && d <= f[2] + 1.5 && off <= span && touchesRock(x, y)) {
                    put(x, y, Cells.RUBBLE);
                    any = true;
                }
            }
        }
        if (any && !keyReachable()) {
            System.arraycopy(save, 0, g.a, 0, save.length);
        }
    }

    private boolean touchesRock(int x, int y) {
        for (int[] d : Cells.RING8) {
            if (g.get(x + d[0], y + d[1]) == Cells.ROCK || g.get(x + d[0], y + d[1]) == Cells.RUBBLE) {
                return true;
            }
        }
        return false;
    }

    /**
     * Полоса завала — срезка: клетки по обе стороны полосы связаны и без неё, но в обход хотя бы на 4 шага длиннее.
     * Завал, который ничего не сокращает, — шум, его не ставим.
     */
    private boolean shortcut(int[] cand) {
        int px = cand[3];
        int py = cand[2];
        int mx = cand[0] + cand[2] * (cand[4] / 2);
        int my = cand[1] + cand[3] * (cand[4] / 2);
        int[] a = {mx - px, my - py};
        int[] b = {mx + px, my + py};
        if (!Cells.walk(g.get(a[0], a[1])) || !Cells.walk(g.get(b[0], b[1]))) {
            return false;
        }
        int[] d = g.dist(List.of(a), false, 0);
        int around = d[g.idx(b[0], b[1])];
        return around >= 0 && around - 2 >= 4;
    }

    /** Полоса завала поперёк узкого прохода (1–3 клетки между скалами) в секторе 0. */
    private boolean plug() {
        List<int[]> cands = new ArrayList<>();
        for (int y = 1; y < c; y++) {
            for (int x = 1; x < c; x++) {
                for (int dir = 0; dir < 2; dir++) {
                    int ux = dir == 0 ? 1 : 0;
                    int uy = dir == 0 ? 0 : 1;
                    if (g.get(x - ux, y - uy) != Cells.ROCK) {
                        continue;
                    }
                    int len = 0;
                    boolean ok = true;
                    while (len < 4 && g.get(x + ux * len, y + uy * len) == Cells.FLOOR) {
                        if (locked(x + ux * len, y + uy * len)) {
                            ok = false;
                        }
                        len++;
                    }
                    if (ok && len >= 1 && len <= 3 && g.get(x + ux * len, y + uy * len) == Cells.ROCK
                            && Math.max(Math.abs(x - c), Math.abs(y - c)) > 8) {
                        cands.add(new int[] {x, y, ux, uy, len});
                    }
                }
            }
        }
        shuffle(cands);
        for (int[] cand : cands) {
            char[] save = g.a.clone();
            for (int k = 0; k < cand[4]; k++) {
                put(cand[0] + cand[2] * k, cand[1] + cand[3] * k, Cells.RUBBLE);
            }
            if (keyReachable() && shortcut(cand)) {
                for (int k = 0; k < cand[4]; k++) {
                    hold(cand[0] + cand[2] * k, cand[1] + cand[3] * k);
                }
                return true;
            }
            System.arraycopy(save, 0, g.a, 0, save.length);
        }
        return false;
    }

    /** Ключевые места сектора 0 достижимы при закрытых завалах. */
    private boolean keyReachable() {
        int[] d = g.dist(baseCells(), false, 0);
        return g.toSpots(d, near1[0], near1[1]) >= 0 && g.toSpots(d, near2[0], near2[1]) >= 0
                && g.toSpots(d, c - 2, c - 2) >= 0 && d[g.idx(1, c)] >= 0;
    }

    /** Убрать мелочь (камни по 1–2 клетки), залить или соединить отрезанные клочки пола. */
    private void cleanup() {
        for (int pass = 0; pass < 3; pass++) {
            List<Integer> sizes = new ArrayList<>();
            int[] comp = g.components(i -> g.a[i] == Cells.ROCK, true, sizes);
            for (int i = 0; i < comp.length; i++) {
                if (comp[i] >= 0 && sizes.get(comp[i]) <= 2 && !lock[i]) {
                    put(i % n, i / n, Cells.FLOOR);
                }
            }
            // пол, куда не дойти от базы даже с разобранными завалами
            int[] d = g.dist(baseCells(), true, 0);
            sizes.clear();
            int[] fc = g.components(i -> (Cells.walk(g.a[i]) || g.a[i] == Cells.RUBBLE) && d[i] < 0, false, sizes);
            boolean changed = false;
            for (int id = 0; id < sizes.size(); id++) {
                int first = -1;
                for (int i = 0; i < fc.length; i++) {
                    if (fc[i] == id) {
                        first = i;
                        break;
                    }
                }
                if (first < 0 || d[first] >= 0 || !canon(first)) {
                    continue;
                }
                if (sizes.get(id) <= 8) {
                    for (int i = 0; i < fc.length; i++) {
                        if (fc[i] == id && !lock[i]) {
                            put(i % n, i / n, Cells.ROCK);
                        }
                    }
                } else {
                    carve(first, d);
                }
                changed = true;
            }
            if (!changed && pass > 0) {
                break;
            }
        }
    }

    /** Клетка — наименьшая по номеру в своей орбите поворотов: так каждая орбита обрабатывается один раз. */
    private boolean canon(int i) {
        int x = i % n;
        int y = i / n;
        for (int k = 4 / order; k < 4; k += 4 / order) {
            int[] q = rot(x, y, k);
            if (g.idx(q[0], q[1]) < i) {
                return false;
            }
        }
        return true;
    }

    /** Прорубить ход от клетки {@code from} до ближайшей достижимой, только сквозь незакреплённую скалу. */
    private void carve(int from, int[] reach) {
        int[] prev = new int[n * n];
        Arrays.fill(prev, -2);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        prev[from] = -1;
        q.add(from);
        int hit = -1;
        while (!q.isEmpty() && hit < 0) {
            int i = q.poll();
            for (int[] d : Cells.DIRS) {
                int x = i % n + d[0];
                int y = i / n + d[1];
                if (!g.in(x, y)) {
                    continue;
                }
                int j = g.idx(x, y);
                if (prev[j] != -2) {
                    continue;
                }
                char ch = g.a[j];
                if (reach[j] >= 0 && (Cells.walk(ch) || ch == Cells.RUBBLE)) {
                    prev[j] = i;
                    hit = j;
                    break;
                }
                if (Cells.walk(ch) || ch == Cells.RUBBLE || ch == Cells.ROCK && !lock[j]) {
                    prev[j] = i;
                    q.add(j);
                }
            }
        }
        for (int i = hit; i >= 0; i = prev[i]) {
            if (g.a[i] == Cells.ROCK) {
                put(i % n, i / n, Cells.FLOOR);
            }
        }
    }

    /** Квартал на два места: базы, домашние и ближние жилы секторов 1 и 3 убираются, жилы прииска на северной и южной осях — тоже. */
    private void unseat() {
        order = 2;
        int[] b = rot(bx, by, 1);
        int[] h = null;
        for (int[] d : Cells.RING8) {
            if (g.get(b[0] + d[0], b[1] + d[1]) == 'H') {
                h = new int[] {b[0] + d[0], b[1] + d[1]};
            }
        }
        // на месте базы — скальный останец, ниша домашней тоже засыпана
        put(b[0], b[1], Cells.ROCK);
        int[] niche = rot(bx, by + p.hdy(), 1);
        put(niche[0], niche[1], Cells.ROCK);
        if (h != null) {
            put(h[0], h[1], Cells.ROCK);
        }
        for (int[] d : Cells.DIRS) {
            if (!locked(b[0] + d[0], b[1] + d[1]) || g.get(b[0] + d[0], b[1] + d[1]) == Cells.FLOOR) {
                // оставим пол: проходы вокруг не трогаем
            }
        }
        int[] a = rot(near1[0], near1[1], 1);
        put(a[0], a[1], Cells.ROCK);
        int[] k = rot(near2[0], near2[1], 1);
        put(k[0], k[1], Cells.ROCK);
        for (int[] mc : mineCells()) {
            int[] m = rot(mc[0], mc[1], 1);
            put(m[0], m[1], Cells.FLOOR);
        }
    }

    /** Богатая жила сектора 0 — посреди площадки, ближе к его углу; к ней четыре места. */
    private int[][] mineCells() {
        return new int[][] {{c - 2, c - 2}};
    }

    /** Все богатые жилы квартала (повороты жил сектора 0). */
    private List<int[]> allMine() {
        List<int[]> out = new ArrayList<>();
        for (int k = 0; k < 4; k++) {
            for (int[] mc : mineCells()) {
                out.add(rot(mc[0], mc[1], k));
            }
        }
        return out;
    }

    // ---- замер ----

    private Metrics measure() {
        List<int[]> src = baseCells();
        int[] d = g.dist(src, false, 0);
        int[] dd = g.dist(src, true, 0);
        int n1 = g.toSpots(d, near1[0], near1[1]);
        int n2 = g.toSpots(d, near2[0], near2[1]);
        int mineOpen = -1;
        int mineDig = -1;
        for (int[] q : allMine()) {
            if (g.get(q[0], q[1]) != '$') {
                continue;
            }
            int a = g.toSpots(d, q[0], q[1]);
            int b = g.toSpots(dd, q[0], q[1]);
            if (a >= 0 && (mineOpen < 0 || a < mineOpen)) {
                mineOpen = a;
            }
            if (b >= 0 && (mineDig < 0 || b < mineDig)) {
                mineDig = b;
            }
        }
        int ex = d[g.idx(1, c)];
        if (n1 < 0 || n2 < 0 || mineOpen < 0 || mineDig < 0 || ex < 0) {
            lastWhy = "недостижимо";
            return null;
        }
        if (!bypass(src, mineOpen, mineDig, ex)) {
            lastWhy = "обход занятых мест";
            return null;
        }
        return new Metrics(n1, n2, mineDig, mineOpen, ex, plugs);
    }

    /**
     * Рабочие у ближних жил не перекрывают дорогу: если на всех местах у ближней жилы и у кармана стоят, путь от базы
     * до прииска и до выхода длиннее не больше чем на шаг. Иначе гружёные с прииска упираются в добывающих.
     */
    private boolean bypass(List<int[]> src, int mineOpen, int mineDig, int ex) {
        List<int[]> blocked = new ArrayList<>();
        blocked.addAll(g.spots(near1[0], near1[1]));
        blocked.addAll(g.spots(near2[0], near2[1]));
        char[] save = g.a.clone();
        for (int[] b : blocked) {
            put(b[0], b[1], Cells.ROCK);
        }
        List<int[]> from = new ArrayList<>();
        for (int[] s0 : src) {
            if (Cells.walk(g.get(s0[0], s0[1]))) {
                from.add(s0);
            }
        }
        int[] d = g.dist(from, false, 0);
        int[] dd = g.dist(from, true, 0);
        int open = -1;
        int dig = -1;
        for (int[] q : allMine()) {
            if (g.get(q[0], q[1]) != '$') {
                continue;
            }
            int a = g.toSpots(d, q[0], q[1]);
            int b = g.toSpots(dd, q[0], q[1]);
            if (a >= 0 && (open < 0 || a < open)) {
                open = a;
            }
            if (b >= 0 && (dig < 0 || b < dig)) {
                dig = b;
            }
        }
        int e2 = d[g.idx(1, c)];
        System.arraycopy(save, 0, g.a, 0, save.length);
        return open >= 0 && dig >= 0 && e2 >= 0 && open <= mineOpen + 1 && dig <= mineDig + 1 && e2 <= ex + 1
                && from.size() == src.size();
    }

    /**
     * Жадный шаг ({@code Pathfinder.SIMPLE}) в секторе как он есть: от каждой клетки у базы доходит до ближней жилы и
     * от каждого места у неё — обратно к базе; до кармана не доходит ни от одной клетки у базы.
     */
    static boolean greedyOk(Cells out, Sector s) {
        // обратно к базе жадный шаг должен дойти от каждого места у ближней жилы
        for (int[] sp : out.spots(s.near1()[0], s.near1()[1])) {
            if (!out.greedyReaches(sp[0], sp[1], s.base()[0], s.base()[1])) {
                return false;
            }
        }
        for (int[] b : walkOut(out, s.base()[0], s.base()[1])) {
            boolean easy = false;
            for (int[] sp : out.spots(s.near1()[0], s.near1()[1])) {
                if (out.greedyReaches(b[0], b[1], sp[0], sp[1])) {
                    easy = true;
                }
            }
            if (!easy) {
                return false;
            }
            for (int[] sp : out.spots(s.near2()[0], s.near2()[1])) {
                if (out.greedyReaches(b[0], b[1], sp[0], sp[1])) {
                    return false;
                }
            }
        }
        return true;
    }

    static boolean acceptable(Metrics m) {
        return m.near1() >= 3 && m.near1() <= 6 && m.near2() >= 5 && m.near2() <= 12
                && m.mineDig() >= MINE_DIG_MIN && m.mineDig() <= MINE_DIG_MAX && m.mineOpen() - m.mineDig() >= DETOUR_MIN
                && m.mineOpen() <= MINE_OPEN_MAX
                && m.exit() >= 10 && m.exit() <= 45;
    }

    private <T> void shuffle(List<T> list) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            T t = list.get(i);
            list.set(i, list.get(j));
            list.set(j, t);
        }
    }
}
