package colony.engine;

import java.util.TreeMap;

/**
 * Номера чужих юнитов и баз, как их видит колония. Свой юнит колония знает по его номеру в колонии
 * («рабочий 5»); чужой получает номер в порядке, в котором колония его впервые увидела: 1, 2, 3… (в виде колонии —
 * со знаком минус, чтобы не путать со своими). Номер держится, пока юнит жив, и не выдаёт, сколько юнитов выпустил
 * сосед. Внутренние номера движка наружу не уходят.
 */
final class Sightings {

    /** Внутренний номер → номер встречи; юниты и базы — в одном счёте, как свои. */
    private static final class Seen {
        final TreeMap<Integer, Integer> numbers = new TreeMap<>();
    }

    private final TreeMap<Integer, Seen> byObserver = new TreeMap<>();

    /** Номер чужого юнита для колонии {@code observer}; при первой встрече — следующий по счёту. */
    synchronized int unit(int observer, int internalId) {
        TreeMap<Integer, Integer> seen = seen(observer).numbers;
        return seen.computeIfAbsent(internalId, k -> seen.size() + 1);
    }

    /** Номер чужой базы для колонии {@code observer}. */
    synchronized int base(int observer, int internalId) {
        return unit(observer, internalId);
    }

    /** Колония видела чужой юнит или базу под порядковым номером {@code number}: внутренний номер; иначе {@code -1}. */
    synchronized int byNumber(int observer, int number) {
        Seen s = byObserver.get(observer);
        if (s != null) {
            for (var e : s.numbers.entrySet()) {
                if (e.getValue() == number) {
                    return e.getKey();
                }
            }
        }
        return -1;
    }

    private Seen seen(int observer) {
        return byObserver.computeIfAbsent(observer, k -> new Seen());
    }
}
