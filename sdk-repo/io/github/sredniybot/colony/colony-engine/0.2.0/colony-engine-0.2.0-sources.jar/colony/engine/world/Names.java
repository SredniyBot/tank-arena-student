package colony.engine.world;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.SplittableRandom;

/**
 * Имена мест по роли: прииск, перевал, дикие земли. Прилагательное согласуется с родом существительного. В одном мире
 * ни прилагательное, ни сочетание не повторяются; стороны света — только если место одно на свою сторону.
 */
final class Names {

    enum Gender { M, F, N, PL }

    record Noun(String word, Gender g) {}

    /** Прилагательное в четырёх формах: м., ж., ср., мн. */
    record Adj(String m, String f, String n, String pl) {
        String form(Gender g) {
            return switch (g) {
                case M -> m;
                case F -> f;
                case N -> n;
                case PL -> pl;
            };
        }
    }

    static final List<Noun> MINE = List.of(new Noun("прииск", Gender.M), new Noun("копи", Gender.PL),
            new Noun("рудник", Gender.M), new Noun("жила", Gender.F), new Noun("россыпь", Gender.F),
            new Noun("шахты", Gender.PL));
    static final List<Noun> PASS = List.of(new Noun("перевал", Gender.M), new Noun("проход", Gender.M),
            new Noun("теснина", Gender.F), new Noun("седловина", Gender.F), new Noun("горло", Gender.N),
            new Noun("брод", Gender.M), new Noun("ворота", Gender.PL));
    static final List<Noun> WILD = List.of(new Noun("пустошь", Gender.F), new Noun("дебри", Gender.PL),
            new Noun("осыпь", Gender.F), new Noun("урочище", Gender.N), new Noun("кряж", Gender.M));

    static final List<Adj> ADJ = List.of(
            new Adj("Кривой", "Кривая", "Кривое", "Кривые"),
            new Adj("Медный", "Медная", "Медное", "Медные"),
            new Adj("Старый", "Старая", "Старое", "Старые"),
            new Adj("Глухой", "Глухая", "Глухое", "Глухие"),
            new Adj("Волчий", "Волчья", "Волчье", "Волчьи"),
            new Adj("Лисий", "Лисья", "Лисье", "Лисьи"),
            new Adj("Ржавый", "Ржавая", "Ржавое", "Ржавые"),
            new Adj("Сухой", "Сухая", "Сухое", "Сухие"),
            new Adj("Чёрный", "Чёрная", "Чёрное", "Чёрные"),
            new Adj("Белый", "Белая", "Белое", "Белые"),
            new Adj("Красный", "Красная", "Красное", "Красные"),
            new Adj("Тихий", "Тихая", "Тихое", "Тихие"),
            new Adj("Гремучий", "Гремучая", "Гремучее", "Гремучие"),
            new Adj("Каменный", "Каменная", "Каменное", "Каменные"),
            new Adj("Ветреный", "Ветреная", "Ветреное", "Ветреные"),
            new Adj("Козий", "Козья", "Козье", "Козьи"),
            new Adj("Горелый", "Горелая", "Горелое", "Горелые"),
            new Adj("Дальний", "Дальняя", "Дальнее", "Дальние"),
            new Adj("Синий", "Синяя", "Синее", "Синие"),
            new Adj("Ломаный", "Ломаная", "Ломаное", "Ломаные"),
            new Adj("Совиный", "Совиная", "Совиное", "Совиные"),
            new Adj("Железный", "Железная", "Железное", "Железные"),
            new Adj("Мшистый", "Мшистая", "Мшистое", "Мшистые"),
            new Adj("Острый", "Острая", "Острое", "Острые"),
            new Adj("Пыльный", "Пыльная", "Пыльное", "Пыльные"),
            new Adj("Сизый", "Сизая", "Сизое", "Сизые"),
            new Adj("Лунный", "Лунная", "Лунное", "Лунные"),
            new Adj("Рыжий", "Рыжая", "Рыжее", "Рыжие"),
            new Adj("Ясный", "Ясная", "Ясное", "Ясные"),
            new Adj("Гулкий", "Гулкая", "Гулкое", "Гулкие"));

    static final List<Adj> SIDES = List.of(
            new Adj("Северный", "Северная", "Северное", "Северные"),
            new Adj("Восточный", "Восточная", "Восточное", "Восточные"),
            new Adj("Южный", "Южная", "Южное", "Южные"),
            new Adj("Западный", "Западная", "Западное", "Западные"));

    private final SplittableRandom r;
    private final List<Adj> adjs;
    private final Set<String> used = new HashSet<>();
    private int next;

    Names(SplittableRandom r) {
        this.r = r;
        this.adjs = new ArrayList<>(ADJ);
        for (int i = adjs.size() - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            Adj t = adjs.get(i);
            adjs.set(i, adjs.get(j));
            adjs.set(j, t);
        }
    }

    /** Имя места с ролью {@code nouns}; {@code side} — сторона света (0 — север … 3 — запад) или {@code -1}. */
    String name(List<Noun> nouns, int side) {
        Noun noun = nouns.get(r.nextInt(nouns.size()));
        if (side >= 0) {
            String s = SIDES.get(side).form(noun.g()) + " " + noun.word();
            if (used.add(s)) {
                return s;
            }
        }
        for (int k = 0; k < adjs.size(); k++) {
            Adj a = adjs.get(next++ % adjs.size());
            String s = a.form(noun.g()) + " " + noun.word();
            if (used.add(s)) {
                return s;
            }
        }
        return noun.word();
    }
}
