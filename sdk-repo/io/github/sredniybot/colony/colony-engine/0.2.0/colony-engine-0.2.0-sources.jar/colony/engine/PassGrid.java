package colony.engine;

import colony.api.Pos;

/**
 * Какие клетки закрыты для шага: стена, база, залежь. Юниты не учитываются. Неизменяемый снимок; новая версия —
 * когда появляется или исчезает база или залежь (вторая база, разрушение, трофей, событие).
 *
 * @param version номер снимка; растёт с каждым изменением
 * @param blocked индекс {@code y * width + x} → клетка закрыта
 */
record PassGrid(int version, boolean[] blocked) {

    /** Снимок по одной карте: закрыто всё, что не пол и не логово. */
    static PassGrid of(GameMap map) {
        boolean[] b = new boolean[map.width() * map.height()];
        for (int y = 0; y < map.height(); y++) {
            for (int x = 0; x < map.width(); x++) {
                b[y * map.width() + x] = !map.passable(new Pos(x, y));
            }
        }
        return new PassGrid(0, b);
    }
}
