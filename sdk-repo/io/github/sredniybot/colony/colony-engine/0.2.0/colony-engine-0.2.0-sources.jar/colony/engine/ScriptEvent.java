package colony.engine;

import colony.api.Pos;
import java.util.Objects;

/**
 * Событие сценария карты — для шага «Устойчивость» домашнего задания: в такт {@code tick} мир меняется без приказа
 * колоний. Если сделать это в такт {@code tick} нельзя (в клетке стоит юнит), событие ждёт ближайшего такта, когда
 * можно.
 *
 * @param tick     такт, после которого событие случается
 * @param kind     что случается
 * @param pos      клетка: залежь для {@link Kind#DRY}, проход для {@link Kind#CLOSE}; для {@link Kind#VANISH} не нужна
 * @param colonyId колония для {@link Kind#VANISH}
 */
public record ScriptEvent(int tick, Kind kind, Pos pos, int colonyId) {

    /** Вид события. */
    public enum Kind {
        /** Залежь в клетке {@code pos} иссякает: запас становится 0. */
        DRY,
        /** Клетка {@code pos} становится стеной (обвал). */
        CLOSE,
        /** У колонии {@code colonyId} исчезает рабочий с самым большим грузом (при равенстве — с меньшим номером). */
        VANISH
    }

    public ScriptEvent {
        Objects.requireNonNull(kind, "kind");
        if (kind != Kind.VANISH) {
            Objects.requireNonNull(pos, "pos");
        }
    }
}
