package colony.engine;

import colony.engine.World.ColonyState;

/**
 * Счёт колонии — по флагам правил. Всегда плюс такты удержания центра.
 * <ul>
 *   <li>{@code scoreDelivered} (лиги): вся энергия, сданная на базу за матч; трата её не уменьшает;</li>
 *   <li>{@code scoreByIncome} (опыт 2б): вся добытая энергия / {@code scoreEnergyDivisor};</li>
 *   <li>иначе (2а, 2б): запас / {@code scoreEnergyDivisor}.</li>
 * </ul>
 */
final class Scoring {

    private Scoring() {}

    static int score(RuleSet rules, ColonyState c) {
        RuleSet.Features f = rules.features();
        int energy;
        if (f.scoreDelivered()) {
            energy = c.delivered;
        } else {
            energy = (f.scoreByIncome() ? c.gained : c.energy) / rules.scoreEnergyDivisor();
        }
        return c.centerTicks + energy;
    }
}
