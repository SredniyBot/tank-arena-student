package colony.engine;

import java.util.EnumSet;
import java.util.Set;

/**
 * Возможность колонии из ДЗ «лестница возможностей». Правила матча говорят, какие возможности есть в этом мире
 * ({@link RuleSet#abilities()}); колонии можно открыть только часть из них ({@link Match#unlock}). Без этого колонии
 * открыто всё, что есть в мире.
 */
public enum Ability {

    /** Склад: {@code build(worker, d, Building.DEPOT)}. */
    DEPOT("depots", "склад"),
    /** Разбор завалов: {@code dig(worker, d)}. */
    DIG("dig", "завалы"),
    /** Улучшения рабочих: {@code upgrade(worker, PICK | BAG)}. */
    UPGRADES("upgrades", "улучшения");

    private final String flag;
    private final String title;

    Ability(String flag, String title) {
        this.flag = flag;
        this.title = title;
    }

    /** «склад», «завалы», «улучшения» — для людей. */
    public String title() {
        return title;
    }

    /** «склад, завалы»; пустой набор — «только основа». */
    public static String titles(Set<Ability> set) {
        if (set.isEmpty()) {
            return "только основа";
        }
        return String.join(", ", EnumSet.copyOf(set).stream().map(Ability::title).toList());
    }

    /** Имя флага в {@code features} правил: {@code depots}, {@code dig}, {@code upgrades}. */
    public String flag() {
        return flag;
    }

    /** Пустой набор: колонии открыта только основа. */
    public static Set<Ability> none() {
        return EnumSet.noneOf(Ability.class);
    }
}
