package colony.engine;

import colony.api.Colony;
import colony.api.ColonyView;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.engine.OrderBook.Order;
import java.security.CodeSource;
import java.util.List;
import java.util.Objects;
import java.util.Optional;
import java.util.concurrent.Callable;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.RejectedExecutionException;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.concurrent.atomic.AtomicReference;
import java.util.function.Supplier;

/**
 * Запускает код одной колонии в её собственном потоке-демоне с таймаутом такта.
 *
 * <ul>
 *   <li>Приказы берутся только из вызова, который уложился во время.</li>
 *   <li>Не уложился — вызов брошен (его приказы выброшены), поток прерван; колония в этом такте стоит.</li>
 *   <li>Если прошлый вызов ещё идёт к следующему такту — колония снова стоит, новый вызов не начинается.</li>
 *   <li>Исключение — колония стоит; в отказе — класс исключения и строка кода колонии.</li>
 *   <li>Прерывание потока движка или {@link #close()} — не вина колонии: вызов отменяется и бросается
 *       {@link CancellationException}, отказ не пишется.</li>
 * </ul>
 */
final class ColonyRunner implements AutoCloseable {

    /** Итог такта: приказы или причина, по которой колония стоит. */
    /** Итог такта колонии; {@code marks} — пометки пути ({@link colony.api.Orders#mark}), номер юнита → клетки. */
    record Outcome(List<Order> orders, Rejection failure, long millis, int dropped,
                   java.util.Map<Integer, List<colony.api.Pos>> marks) {

        Outcome(List<Order> orders, Rejection failure, long millis, int dropped) {
            this(orders, failure, millis, dropped, java.util.Map.of());
        }
    }

    private static final class Call {
        volatile boolean started;
        volatile boolean finished;
        Future<?> future;
    }

    private static final long CREATE_TIMEOUT_MILLIS = 5000;

    private final ExecutorService executor;
    private final Colony colony;
    private final Rejection createFailure;
    private final Navigator navigator;
    private final ClassLoader loader;
    private volatile Call current;
    private final AtomicReference<Thread> thread = new AtomicReference<>();
    private volatile Throwable lastError;
    private volatile boolean closed;

    ColonyRunner(int colonyId, Supplier<Colony> factory, GameMap map, long tickTimeoutMillis) {
        this(colonyId, factory, () -> new Navigator(map), tickTimeoutMillis);
    }

    /** {@code navigators} создаёт навигатор для встроенного бота; вызывается, только если колония — такой бот. */
    ColonyRunner(int colonyId, Supplier<Colony> factory, Supplier<Navigator> navigators, long tickTimeoutMillis) {
        // Фабрика потока не должна ссылаться на этот объект: исполнитель JDK держит её из своего Cleaner'а,
        // и ссылка назад на runner навсегда удержала бы матч, мир и колонию в памяти.
        AtomicReference<Thread> holder = this.thread;
        this.executor = Executors.newSingleThreadExecutor(r -> {
            Thread t = new Thread(r, "colony-" + colonyId);
            t.setDaemon(true);
            holder.set(t);
            return t;
        });
        this.loader = factory.getClass().getClassLoader();
        Colony created = null;
        Rejection failure = null;
        Call call = new Call();
        Future<Object> f = executor.submit(tracked(call, () -> {
            try {
                return factory.get();
            } catch (Throwable t) {
                return failure(t, true);
            }
        }));
        call.future = f;
        current = call;
        long limit = Math.max(CREATE_TIMEOUT_MILLIS, tickTimeoutMillis);
        try {
            Object result = f.get(limit, TimeUnit.MILLISECONDS);
            if (result instanceof Failure fail) {
                lastError = fail.copy();
                failure = new Rejection(0, RejectCode.EXCEPTION, fail.text());
            } else if (result == null) {
                failure = new Rejection(0, RejectCode.EXCEPTION, Messages.factoryReturnedNull());
            } else {
                created = (Colony) result;
            }
        } catch (TimeoutException e) {
            f.cancel(true);
            failure = new Rejection(0, RejectCode.TIMEOUT, Messages.createTimeout(limit));
        } catch (ExecutionException e) {
            // сюда исключения колонии не доходят (их описывает её поток); только сбой самого описания
            failure = new Rejection(0, RejectCode.EXCEPTION, Messages.createFailed(name(e.getCause()), null, null));
        } catch (InterruptedException e) {
            f.cancel(true);
            close();
            Thread.currentThread().interrupt();
            throw new CancellationException(Messages.interrupted());
        }
        this.colony = failure == null ? created : null;
        this.createFailure = failure;
        this.navigator = colony instanceof InternalColony && trusted(colony.getClass()) ? navigators.get() : null;
    }

    /** Колонии из пакетов встроенных ботов получают навигатор. */
    static boolean trusted(Class<?> type) {
        String p = type.getPackageName();
        return p.equals("colony.bots") || p.startsWith("colony.bots.")
                || p.equals("colony.gatebots") || p.startsWith("colony.gatebots.");
    }

    /**
     * Имя класса колонии для повтора; пусто, если колония не создалась. У лямбды адрес скрытого класса
     * отбрасывается: он меняется от запуска к запуску и сломал бы побайтное совпадение повторов.
     */
    String botClass() {
        if (colony == null) {
            return "";
        }
        String name = colony.getClass().getName();
        int lambda = name.indexOf("$$Lambda");
        return lambda >= 0 ? name.substring(0, lambda + "$$Lambda".length()) : name;
    }

    Optional<Throwable> lastError() {
        return Optional.ofNullable(lastError);
    }

    /**
     * Один такт: вызвать {@code onTick} и дождаться не дольше {@code timeoutMillis}. Принимается не больше
     * {@code orderLimit} приказов; сколько отброшено сверх — в {@link Outcome#dropped()}.
     *
     * @throws CancellationException если поток движка прерван или исполнитель закрыт: колония не виновата
     */
    Outcome decide(ColonyView view, int tick, long timeoutMillis, int orderLimit) {
        if (closed) {
            throw new CancellationException(Messages.closed());
        }
        if (colony == null) {
            return new Outcome(null, createFailure, 0, 0);
        }
        if (busy()) {
            return new Outcome(null, new Rejection(0, RejectCode.TIMEOUT, Messages.stillRunning()), 0, 0);
        }
        OrderBook book = new OrderBook(tick, orderLimit);
        Call call = new Call();
        long start = System.nanoTime();
        Future<Object> f;
        try {
            f = executor.submit(tracked(call, () -> {
                try {
                    if (navigator != null) {
                        ((InternalColony) colony).onTick(view, book, navigator);
                    } else {
                        colony.onTick(view, book);
                    }
                    return null;
                } catch (Throwable t) {
                    return failure(t, false);
                }
            }));
        } catch (RejectedExecutionException e) {
            throw new CancellationException(Messages.closed());
        }
        call.future = f;
        current = call;
        Outcome outcome;
        try {
            Object result = f.get(timeoutMillis, TimeUnit.MILLISECONDS);
            if (result instanceof Failure fail) {
                book.close();
                if (!closed) {
                    lastError = fail.copy();
                }
                outcome = new Outcome(null, new Rejection(0, RejectCode.EXCEPTION, fail.text()), millis(start), 0);
            } else {
                List<Order> orders = book.close();
                outcome = new Outcome(orders, null, millis(start), book.dropped(), book.marks());
            }
        } catch (TimeoutException e) {
            f.cancel(true);
            book.close();
            outcome = new Outcome(null, new Rejection(0, RejectCode.TIMEOUT, Messages.timeout(timeoutMillis)),
                    millis(start), 0);
        } catch (ExecutionException e) {
            // сюда исключения колонии не доходят (их описывает её поток); только сбой самого описания
            book.close();
            outcome = new Outcome(null, new Rejection(0, RejectCode.EXCEPTION,
                    Messages.exception(name(e.getCause()), null, null)), millis(start), 0);
        } catch (CancellationException e) {
            book.close();
            throw new CancellationException(Messages.closed());
        } catch (InterruptedException e) {
            f.cancel(true);
            book.close();
            Thread.currentThread().interrupt();
            throw new CancellationException(Messages.interrupted());
        }
        if (closed) {
            throw new CancellationException(Messages.closed());
        }
        return outcome;
    }

    private boolean busy() {
        Call c = current;
        if (c == null || c.finished) {
            return false;
        }
        return c.started || !c.future.isCancelled();
    }

    private static <T> Callable<T> tracked(Call call, Callable<T> body) {
        return () -> {
            call.started = true;
            try {
                return body.call();
            } finally {
                call.finished = true;
            }
        };
    }

    private static long millis(long startNanos) {
        return (System.nanoTime() - startNanos) / 1_000_000;
    }

    /**
     * Исключение колонии, описанное в её потоке: текст отказа и копия для консоли локальной игры. Движку достаются
     * только они — методы самого исключения (код колонии) поток движка не вызывает.
     */
    private record Failure(String text, Throwable copy) {}

    /**
     * Описать исключение колонии. Вызывается в потоке колонии, в счёт её такта: {@code getMessage},
     * {@code getStackTrace}, {@code getCause} могут быть кодом студента — зависнуть, бросить, прервать поток.
     * Не вышло описать — только имя класса.
     */
    private Failure failure(Throwable t, boolean creation) {
        String type = name(t);
        try {
            String message = t.getMessage();
            if (message != null && message.length() > 2000) {
                message = message.substring(0, 2000);
            }
            StackTraceElement[] stack = t.getStackTrace().clone();
            String where = where(stack);
            String text = creation ? Messages.createFailed(type, message, where)
                    : Messages.exception(type, message, where);
            return new Failure(text, copy(t, message, stack, 0));
        } catch (Throwable e) {
            String text = creation ? Messages.createFailed(type, null, null) : Messages.exception(type, null, null);
            return new Failure(text, new ColonyError(t.getClass().getName(), null, new StackTraceElement[0], null));
        }
    }

    /** Короткое имя класса исключения; у анонимного — полное. {@code getClass} кода колонии не вызывает. */
    private static String name(Throwable t) {
        if (t == null) {
            return "Throwable";
        }
        String simple = t.getClass().getSimpleName();
        return simple.isEmpty() ? t.getClass().getName() : simple;
    }

    /** Копия исключения и его причин (до 5) — объекты движка; снимается в потоке колонии. */
    private static ColonyError copy(Throwable t, String message, StackTraceElement[] stack, int depth) {
        ColonyError cause = null;
        Throwable c = t.getCause();
        if (c != null && c != t && depth < 5) {
            String m = c.getMessage();
            cause = copy(c, m == null || m.length() <= 2000 ? m : m.substring(0, 2000), c.getStackTrace().clone(),
                    depth + 1);
        }
        return new ColonyError(t.getClass().getName(), message, stack, cause);
    }

    /** Копия исключения колонии: имя класса, сообщение, стек, причина. Её методы кода колонии не вызывают. */
    static final class ColonyError extends RuntimeException {
        private final String text;

        ColonyError(String className, String message, StackTraceElement[] stack, ColonyError cause) {
            super(message, cause, false, true);
            this.text = message == null ? className : className + ": " + message;
            setStackTrace(stack);
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /** Первая строка стека в коде колонии: не JDK, не движок и не API. Например {@code MyColony.java:42}. */
    String where(StackTraceElement[] stack) {
        CodeSource engine = codeSource(ColonyRunner.class);
        CodeSource api = codeSource(Colony.class);
        ClassLoader cl = colony != null ? colony.getClass().getClassLoader() : loader;
        for (StackTraceElement e : stack) {
            String cn = e.getClassName();
            if (e.getModuleName() != null || cn.startsWith("java.") || cn.startsWith("javax.") || cn.startsWith("jdk.")
                    || cn.startsWith("sun.") || cn.startsWith("com.sun.")) {
                continue;
            }
            CodeSource cs = null;
            try {
                cs = codeSource(Class.forName(cn, false, cl));
            } catch (ClassNotFoundException | LinkageError ignored) {
                // класс не нашёлся — считаем его кодом колонии
            }
            if (cs != null && (same(cs, engine) || same(cs, api))) {
                continue;
            }
            return e.getFileName() == null ? cn : e.getFileName() + ":" + e.getLineNumber();
        }
        return null;
    }

    private static CodeSource codeSource(Class<?> type) {
        return type.getProtectionDomain() == null ? null : type.getProtectionDomain().getCodeSource();
    }

    private static boolean same(CodeSource a, CodeSource b) {
        return b != null && Objects.equals(a.getLocation(), b.getLocation());
    }

    @Override
    public void close() {
        closed = true;
        Call c = current;
        if (c != null && c.future != null) {
            c.future.cancel(true);
        }
        executor.shutdownNow();
    }

    /**
     * После {@link #close()}: ждёт поток колонии не дольше {@code waitMillis}. Если он всё ещё жив (код колонии
     * не слышит прерывания), понижает его приоритет и возвращает {@code true}. Остановить такой поток в Java 21
     * нельзя; он демон и не держит процесс, а его виды и приказы уже не отвечают.
     */
    boolean stray(long waitMillis) {
        Thread t = thread.get();
        if (t == null || !t.isAlive()) {
            return false;
        }
        try {
            t.join(Math.max(1, waitMillis));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        if (t.isAlive()) {
            t.setPriority(Thread.MIN_PRIORITY);
            return true;
        }
        return false;
    }
}
