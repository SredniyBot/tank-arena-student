package colony.engine;

import colony.api.Deposit;
import colony.api.DepositKind;
import colony.api.EventKind;
import colony.api.GameEvent;
import colony.api.Pos;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.engine.World.ColonyState;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.concurrent.CancellationException;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Матч: мир, колонии и кадры. Шаг — {@link #step()}; кадр 0 — начало матча, кадр {@code t} — после такта {@code t}.
 *
 * <p>{@link #step()} вызывается из одного потока. {@link #frame()}, {@link #frames(int)}, {@link #finished()},
 * {@link #result()} и {@link #replayHeader()} можно читать из других потоков (например, сервера просмотра).
 */
public final class Match implements AutoCloseable {

    /** Участник в повторе. */
    public record ColonyInfo(int id, String name, String sign, String color, String bot) {}

    /**
     * Сколько колония добыла из одной залежи за матч (для разборов и проверок ворот А).
     *
     * @param kind вид залежи; жила события — {@link colony.api.DepositKind#RICH}, трофей — {@code LOOT}
     */
    public record HarvestStat(int colonyId, int depositId, colony.api.DepositKind kind, Pos pos, int amount) {}

    /** Ждать потоки колоний при закрытии, всего не дольше. */
    private static final long STRAY_WAIT_MILLIS = 200;

    /** События, которые видят все колонии. */
    private static final Set<EventKind> BROADCAST = EnumSet.of(EventKind.COLONY_DIED, EventKind.TRUCE_END,
            EventKind.ANNOUNCE, EventKind.RAID, EventKind.EVENT_STARTED);

    private final MatchConfig config;
    private final GameMap map;
    private final World world;
    private final List<ColonyRunner> runners;
    private final List<ColonyInfo> colonies;
    private final ObjectNode header;
    private final List<Frame> frames = new ArrayList<>();
    /** Сколько последних кадров держать; 0 — все с начала. Под {@code frames}. */
    private int keepFrames;
    private final Map<Integer, List<Rejection>> lastRejections = new HashMap<>();
    private final Map<Integer, List<GameEvent>> lastEvents = new HashMap<>();
    private volatile Frame last;
    private volatile MatchResult result;
    private volatile boolean finished;
    private volatile boolean closed;
    private final AtomicBoolean viewsClosed = new AtomicBoolean();
    private volatile int strayThreads;

    private Match(MatchConfig config, List<ColonySpec> specs) {
        this.config = config;
        this.map = config.map().forColonies(specs.size());
        List<String> names = specs.stream().map(ColonySpec::name).toList();
        List<Boolean> bots = specs.stream().map(ColonySpec::bot).toList();
        this.world = new World(config, map, names, bots);
        List<ColonyRunner> rs = new ArrayList<>();
        List<ColonyInfo> infos = new ArrayList<>();
        try {
            for (int i = 0; i < specs.size(); i++) {
                ColonySpec s = specs.get(i);
                ColonyRunner r = new ColonyRunner(i + 1, s.factory(), () -> new Navigator(map, world::grid),
                        config.tickTimeoutMillis());
                rs.add(r);
                infos.add(new ColonyInfo(i + 1, s.name(), Palette.sign(s.sign(), s.name()), Palette.color(i + 1),
                        r.botClass()));
            }
        } catch (RuntimeException e) {
            rs.forEach(ColonyRunner::close);
            throw e;
        }
        this.runners = List.copyOf(rs);
        this.colonies = List.copyOf(infos);
        this.header = buildHeader();
        record(List.of(), List.of(), Map.of(), Map.of(), false, Map.of());
    }

    /**
     * Новый матч. Колонии получают номера 1…N по порядку списка и места 1…N на карте; лишние места карты
     * пустеют (база и её домашняя залежь становятся полом).
     */
    public static Match create(MatchConfig cfg, List<ColonySpec> colonies) {
        Objects.requireNonNull(cfg, "cfg");
        if (colonies == null || colonies.isEmpty()) {
            throw new IllegalArgumentException("в матче нет колоний");
        }
        if (colonies.size() > cfg.map().players()) {
            throw new IllegalArgumentException("на карте «" + cfg.map().name() + "» мест " + cfg.map().players()
                    + ", а колоний " + colonies.size());
        }
        return new Match(cfg, List.copyOf(colonies));
    }

    /**
     * Сыграть один такт.
     *
     * @throws IllegalStateException матч окончен или закрыт
     * @throws java.util.concurrent.CancellationException поток прерван или матч закрыт во время такта; такт не
     *                                                    записан, колонии ни в чём не обвинены, матч закрыт
     */
    public void step() {
        if (finished) {
            throw new IllegalStateException("матч окончен");
        }
        if (closed) {
            throw new IllegalStateException(Messages.closed());
        }
        if (Thread.currentThread().isInterrupted()) {
            close();
            throw new CancellationException(Messages.interrupted());
        }
        int t = world.tick;
        Map<Integer, List<Rejection>> rejections = new TreeMap<>();
        Map<Integer, Long> millis = new TreeMap<>();
        Map<Integer, List<OrderBook.Order>> orders = new TreeMap<>();
        Map<Integer, ViewSnapshot> views = new TreeMap<>();
        Map<Integer, List<Pos>> paths = new TreeMap<>();
        try {
            for (ColonyState c : world.colonies) {
                if (!c.alive) {
                    continue;
                }
                ViewSnapshot view = ViewSnapshot.of(world, c.id, config.maxTicks(),
                        lastRejections.getOrDefault(c.id, List.of()), lastEvents.getOrDefault(c.id, List.of()),
                        viewsClosed);
                views.put(c.id, view);
                int limit = view.myUnits().size() + view.myBases().size() + config.rules().extraOrdersPerTick();
                ColonyRunner.Outcome o = runners.get(c.id - 1).decide(view, t, config.tickTimeoutMillis(), limit);
                millis.put(c.id, o.millis());
                if (o.failure() != null) {
                    rejections.computeIfAbsent(c.id, k -> new ArrayList<>()).add(o.failure());
                    if (o.failure().code() == RejectCode.EXCEPTION) {
                        c.exceptions++;
                    } else {
                        c.timeouts++;
                    }
                } else {
                    orders.put(c.id, o.orders());
                    o.marks().forEach((number, cells) -> {
                        World.UnitEntity u = world.ownUnit(c.id, number);
                        if (u != null) {
                            paths.put(u.id, cells);
                        }
                    });
                    if (o.dropped() > 0) {
                        rejections.computeIfAbsent(c.id, k -> new ArrayList<>()).add(new Rejection(0,
                                RejectCode.TOO_MANY_ORDERS, Messages.tooManyOrders(o.orders().size(), o.dropped())));
                        c.rejections++;
                    }
                }
            }
        } catch (CancellationException e) {
            close();
            throw e;
        }
        List<Frame.Event> events = new ArrayList<>();
        List<Frame.Shot> shots = new ArrayList<>();
        TickResolver.resolve(world, orders, views, rejections, events, shots);
        rejections.values().forEach(list -> list.sort(Comparator.comparingInt(Rejection::unitId)));
        boolean waiting = world.respawn && world.colonies.stream().anyMatch(c -> c.respawnAt >= 0);
        boolean done = world.tick >= config.maxTicks()
                || (world.colonies.stream().noneMatch(c -> c.alive) && !waiting);
        record(events, shots, rejections, millis, done, paths);
        remember(events, rejections);
        if (done) {
            finished = true;
            close();
        }
    }

    /** Играть до конца. */
    public void run() {
        while (!finished) {
            step();
        }
    }

    public boolean finished() {
        return finished;
    }

    /** Сыгранных тактов. */
    public int tick() {
        return last.t();
    }

    public MatchConfig config() {
        return config;
    }

    /** Карта матча: места без колоний уже убраны. */
    public GameMap map() {
        return map;
    }

    public List<ColonyInfo> colonies() {
        return colonies;
    }

    /** Последний кадр. */
    public Frame frame() {
        return last;
    }

    /** Все кадры в памяти: с начала или, с {@link #keepLastFrames}, последние. */
    public List<Frame> frames() {
        return frames(0);
    }

    /** Кадры с такта {@code from}; если такие уже выброшены ({@link #keepLastFrames}) — с самого раннего в памяти. */
    public List<Frame> frames(int from) {
        synchronized (frames) {
            int first = frames.isEmpty() ? 0 : frames.get(0).t();
            int start = Math.max(0, Math.min(from - first, frames.size()));
            return List.copyOf(frames.subList(start, frames.size()));
        }
    }

    /**
     * Держать в памяти только последние {@code n} кадров (от {@code n} до {@code 2n}), а не все с начала: мир без
     * конца иначе съест память — кадр общего мира на 28 колоний весит около 80 КБ. Повтор такого матча начинается
     * не с нулевого такта. {@code 0} — все кадры.
     */
    public void keepLastFrames(int n) {
        if (n < 0) {
            throw new IllegalArgumentException("кадров должно быть не меньше нуля, а не " + n);
        }
        synchronized (frames) {
            keepFrames = n;
            trimFrames();
        }
    }

    /** Под {@code frames}. */
    private void trimFrames() {
        if (keepFrames > 0 && frames.size() >= 2 * keepFrames) {
            frames.subList(0, frames.size() - keepFrames).clear();
        }
    }

    /** Итог; до конца матча — положение на последний такт. */
    public MatchResult result() {
        return result;
    }

    /** Последнее исключение из кода колонии, чтобы показать стек целиком. */
    public Optional<Throwable> lastError(int colonyId) {
        return runners.get(colonyId - 1).lastError();
    }

    /**
     * Обзор колонии на начало следующего такта — тот же, что её {@code onTick} получит в {@link #step()}. Для
     * сервера мира: обзор уходит по сети до такта. Вызывать из того же потока, что и {@code step()}.
     */
    public colony.api.ColonyView nextView(int colonyId) {
        return ViewSnapshot.of(world, colonyId, config.maxTicks(), lastRejections.getOrDefault(colonyId, List.of()),
                lastEvents.getOrDefault(colonyId, List.of()));
    }

    /**
     * Клетки, закрытые сценарием карты (обвалом) к такту обзора {@code view}: на исходной карте это пол. Для обзора не
     * из движка — пусто. Нужно серверу: рельеф уходит клиенту один раз при входе, а обвалы — с каждым обзором.
     */
    public static Set<Pos> closedCells(colony.api.ColonyView view) {
        return view instanceof ViewSnapshot s ? s.walls() : Set.of();
    }

    /**
     * Открыть колонии {@code colonyId} только возможности {@code open} — из тех, что есть в мире
     * ({@link RuleSet#abilities()}). Закрытую возможность её {@code view.rules()} не показывает, а приказ отклоняется:
     * «рабочий 1: склад ещё не открыт». Без вызова колонии открыто всё, что есть в мире. Можно звать из любого
     * потока и посреди матча: сервер открывает возможности, когда студент входит в мир.
     */
    public void unlock(int colonyId, Set<Ability> open) {
        unlock(colonyId, open, null);
    }

    /**
     * То же; {@code hint} говорит, как открыть закрытую возможность, — его текст дописывается в отказ: «рабочий 1:
     * склад ещё не открыт — сдай шаг 3 «Склад»». {@code null} или пустой текст — без подсказки.
     */
    public void unlock(int colonyId, Set<Ability> open, java.util.function.Function<Ability, String> hint) {
        if (colonyId < 1 || colonyId > world.colonies.size()) {
            throw new IllegalArgumentException("нет колонии " + colonyId);
        }
        world.unlock(colonyId, Objects.requireNonNull(open, "open"), hint);
    }

    /** Что открыто колонии {@code colonyId}: возможности мира, оставшиеся после {@link #unlock}. */
    public Set<Ability> unlocked(int colonyId) {
        return world.colony(colonyId).unlocked.abilities();
    }

    /**
     * Навигатор по миру матча — тот же, что движок даёт встроенным ботам. Для сервера мира: за отсутствующего студента
     * он сам зовёт бота с обзором {@link #nextView}. Вызывать из того же потока, что и {@code step()}.
     */
    public Navigator navigator() {
        return new Navigator(map, world::grid);
    }

    /** Заголовок повтора: всё, кроме {@code frames} и {@code result}. Копия. */
    public ObjectNode replayHeader() {
        return header.deepCopy();
    }

    /** Мир для тестов движка. */
    World world() {
        return world;
    }

    /** Сколько энергии колония {@code colonyId} сдала на базу и склады за сыгранные такты. */
    public int delivered(int colonyId) {
        synchronized (frames) {
            return world.colony(colonyId).delivered;
        }
    }

    /** Добыча по колониям и залежам за сыгранные такты; по возрастанию колонии и залежи. */
    public List<HarvestStat> harvestStats() {
        synchronized (frames) {
            List<HarvestStat> out = new ArrayList<>();
            world.harvested.forEach((colony, byDeposit) -> byDeposit.forEach((id, amount) -> {
                World.DepositEntity d = world.everDeposit.get(id);
                out.add(new HarvestStat(colony, id, d.kind, d.pos, amount));
            }));
            return out;
        }
    }

    /**
     * Сколько потоков колоний пережили {@link #close()}: их код не слышит прерывания. Такой поток — демон с
     * наименьшим приоритетом; его виды и приказы бросают исключение. Остановить его совсем может только выход
     * из процесса (прогон преподавателя так и делает).
     */
    public int strayThreads() {
        return strayThreads;
    }

    @Override
    public synchronized void close() {
        if (!closed) {
            closed = true;
            viewsClosed.set(true);
            runners.forEach(ColonyRunner::close);
            long deadline = System.nanoTime() + STRAY_WAIT_MILLIS * 1_000_000;
            int stray = 0;
            for (ColonyRunner r : runners) {
                long left = Math.max(1, (deadline - System.nanoTime()) / 1_000_000);
                if (r.stray(left)) {
                    stray++;
                }
            }
            strayThreads = stray;
        }
    }

    // ---- внутреннее ----

    private void record(List<Frame.Event> events, List<Frame.Shot> shots, Map<Integer, List<Rejection>> rejections,
                        Map<Integer, Long> millis, boolean done, Map<Integer, List<Pos>> paths) {
        List<Frame.ColonyState> cs = new ArrayList<>();
        for (ColonyState c : world.colonies) {
            int units = (int) world.units.values().stream().filter(u -> u.colonyId == c.id).count();
            cs.add(new Frame.ColonyState(c.id, c.energy, world.score(c), c.alive, c.centerTicks, units));
        }
        List<Deposit> deposits = new ArrayList<>();
        for (World.DepositEntity d : world.deposits.values()) {
            deposits.add(new Deposit(d.id, d.pos, d.kind, d.kind == DepositKind.HOME ? -1 : d.amount, true,
                    config.rules().rateOf(d.kind)));
        }
        Map<Integer, Integer> numbers = new TreeMap<>();
        world.units.values().forEach(u -> numbers.put(u.id, u.number));
        world.bases.values().forEach(b -> numbers.put(b.id, b.number));
        List<Frame.Rubble> rubble = new ArrayList<>();
        for (Pos p : world.rubbleCells) {
            rubble.add(new Frame.Rubble(p, world.rubbleAt(p)));
        }
        Frame f = new Frame(world.tick, cs,
                world.bases.values().stream().map(World.BaseEntity::snapshot).toList(),
                world.units.values().stream().map(World.UnitEntity::snapshot).toList(),
                deposits, shots, events, rejections, millis, numbers, world.centerHolder, world.closedCells, rubble,
                world.structures.values().stream().map(World.StructureEntity::snapshot).toList(), paths);
        synchronized (frames) {
            frames.add(f);
            trimFrames();
        }
        last = f;
        result = standings(done);
    }

    private void remember(List<Frame.Event> events, Map<Integer, List<Rejection>> rejections) {
        lastRejections.clear();
        lastRejections.putAll(rejections);
        lastEvents.clear();
        for (ColonyState c : world.colonies) {
            List<GameEvent> mine = new ArrayList<>();
            for (Frame.Event e : events) {
                if (e.colonyId() == c.id) {
                    mine.add(new GameEvent(e.tick(), e.kind(), e.message(), e.pos()));
                } else if (e.colonyId() == 0 || BROADCAST.contains(e.kind())) {
                    mine.add(new GameEvent(e.tick(), e.kind(), e.text(), e.pos()));
                }
            }
            lastEvents.put(c.id, mine);
        }
    }

    private MatchResult standings(boolean done) {
        List<ColonyState> order = new ArrayList<>(world.colonies);
        order.sort(Comparator.<ColonyState, Boolean>comparing(c -> !c.alive)
                .thenComparing(c -> c.alive ? 0 : -c.deathTick)
                .thenComparing(c -> -world.score(c))
                .thenComparingInt(c -> c.id));
        List<MatchResult.Placement> ranking = new ArrayList<>();
        int place = 0;
        ColonyState prev = null;
        for (int i = 0; i < order.size(); i++) {
            ColonyState c = order.get(i);
            boolean tie = prev != null && prev.alive == c.alive && world.score(prev) == world.score(c)
                    && (c.alive || prev.deathTick == c.deathTick);
            if (!tie) {
                place = i + 1;
            }
            ranking.add(new MatchResult.Placement(c.id, c.name, place, world.score(c), c.energy, c.alive,
                    c.exceptions, c.timeouts, c.rejections, c.delivered));
            prev = c;
        }
        return new MatchResult(world.tick, done, ranking);
    }

    private ObjectNode buildHeader() {
        ObjectNode h = Json.MAPPER.createObjectNode();
        h.put("format", "colony-replay");
        h.put("version", 1);
        h.put("sdkVersion", Version.get());
        h.put("rulesVersion", config.rules().rulesVersion());
        h.put("seed", config.seed());
        h.set("rules", RulesLoader.toJson(config.rules()));
        ObjectNode m = h.putObject("map");
        m.put("name", map.name());
        m.put("width", map.width());
        m.put("height", map.height());
        ArrayNode rows = m.putArray("rows");
        map.rows().forEach(rows::add);
        ArrayNode regions = m.putArray("regions");
        for (GameMap.Region r : map.regions()) {
            regions.addObject().put("name", r.name()).put("x", r.x()).put("y", r.y());
        }
        putPos(m, "center", map.center());
        putPos(m, "lair", map.lair().orElse(null));
        // клетки зоны центра — ровно те, что считает движок: просмотр рисует их, а не догадывается
        RuleSet.Features f = config.rules().features();
        if (f.center() || f.centerMajority() || f.centerByTanks()) {
            ArrayNode zone = m.putArray("centerZone");
            for (int y = 0; y < map.height(); y++) {
                for (int x = 0; x < map.width(); x++) {
                    Pos p = new Pos(x, y);
                    if (world.inCentre(p) && map.terrain(p) != colony.api.Terrain.WALL) {
                        zone.addArray().add(x).add(y);
                    }
                }
            }
        }
        ArrayNode cs = h.putArray("colonies");
        for (ColonyInfo c : colonies) {
            cs.addObject().put("id", c.id()).put("name", c.name()).put("sign", c.sign()).put("color", c.color())
                    .put("bot", c.bot());
        }
        return h;
    }

    private static void putPos(ObjectNode o, String key, Pos p) {
        if (p == null) {
            o.putNull(key);
        } else {
            o.putObject(key).put("x", p.x()).put("y", p.y());
        }
    }
}
