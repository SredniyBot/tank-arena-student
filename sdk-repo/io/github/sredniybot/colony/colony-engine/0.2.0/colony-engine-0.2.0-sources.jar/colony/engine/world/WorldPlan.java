package colony.engine.world;

import colony.api.Pos;
import colony.engine.GameMap;
import java.util.List;
import java.util.Map;

/**
 * Мир с пояснениями: карта и то, из чего она собрана, — для просмотра, проверок и замеров. Серверу хватает
 * {@link #map()}.
 *
 * @param map        карта мира
 * @param archetype  облик местности
 * @param asked      сколько мест просили
 * @param pods       кварталы
 * @param seats      места в порядке номеров (место 1 — первое)
 * @param passes     ничейные жилы в проходах между кварталами
 * @param heart      середина сердца мира или {@code null}, если мир из одного квартала
 * @param lair       логово или {@code null}
 * @param report     проверки и замеры путей
 * @param candidates сколько миров-кандидатов собрано, из них выбран лучший по оценке интереса
 * @param millis     время сборки, мс
 */
public record WorldPlan(GameMap map, Archetype archetype, int asked, List<PodInfo> pods, List<Seat> seats,
                        List<Pass> passes, Pos heart, Pos lair, Report report, int candidates, long millis) {

    /** Места для «бронзы»: номера после {@link #asked()} до числа мест на карте. */
    public List<Integer> bots() {
        return java.util.stream.IntStream.rangeClosed(asked + 1, map.players()).boxed().toList();
    }

    /**
     * Квартал.
     *
     * @param index    номер с 0
     * @param x0       левый верхний угол на карте
     * @param size     сторона
     * @param seats    мест: 4 или 2
     * @param seed     зерно квартала
     * @param mirrored отражён (вертушка в другую сторону)
     * @param mine     середина прииска
     * @param name     имя прииска
     */
    public record PodInfo(int index, int col, int row, int x0, int y0, int size, int seats, long seed,
                          boolean mirrored, Pos mine, String name) {}

    /** Место колонии: база, домашняя, ближние жилы; квартал и сектор в нём (0 — северо-запад, по часовой). */
    public record Seat(int seat, int pod, int sector, Pos base, Pos home, Pos near1, Pos near2) {}

    /**
     * Проход между кварталами с ничейными жилами.
     *
     * @param deposits жилы прохода
     * @param owners   места, чьи выходы ведут в проход (1 или 2)
     * @param name     имя или {@code null}, если проход не подписан
     */
    public record Pass(List<Pos> deposits, List<Integer> owners, String name) {}

    /**
     * Длины путей места в шагах от клетки у базы до места у жилы; {@code -1} — не дойти.
     *
     * @param mineDig   до прииска с разобранными завалами
     * @param mineOpen  до прииска в обход завалов
     * @param pass      до ближайшей ничейной жилы в проходе
     * @param heart     до сердца мира (кольцо завала сплошное: с разобранными завалами)
     * @param trap      жадный шаг не доходит до жилы в кармане
     */
    public record Paths(int seat, int near1, int near2, int mineDig, int mineOpen, int pass, int heart,
                        boolean trap) {}

    /**
     * Итог проверок.
     *
     * @param failures что не прошло; пусто — карта годна
     * @param paths    пути каждого места
     * @param score    оценка интереса (больше — лучше)
     * @param parts    слагаемые оценки
     */
    public record Report(List<String> failures, List<Paths> paths, double score, Map<String, Double> parts) {
        public boolean ok() {
            return failures.isEmpty();
        }
    }
}
