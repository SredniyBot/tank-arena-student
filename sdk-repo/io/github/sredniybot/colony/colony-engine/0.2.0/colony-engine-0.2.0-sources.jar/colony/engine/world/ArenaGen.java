package colony.engine.world;

import colony.api.DepositKind;
import colony.api.Pos;
import colony.engine.GameMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.PriorityQueue;
import java.util.SplittableRandom;

/**
 * Карта общей арены: мир с поворотной симметрией четвёртого порядка, в котором у кода колонии много мест для выбора.
 *
 * <p>Базы стоят на ромбе {@code |dx| + |dy| = R}, а не на круге: рабочие ходят по четырём сторонам, и только на ромбе
 * до середины всем одинаково по клеткам (на круге с диагонали на 41 % дальше, чем с оси). Всё по слоям — тоже ромбы.
 * От края к середине:
 * <ol>
 *     <li><b>Горы</b> по краю, острия ромба срезаны.</li>
 *     <li><b>Своё</b> у базы: домашняя в нише (одно место, вплотную к базе), <b>карман</b> — обычная жила в выемке
 *     скалы с одним местом в 3–5 шагах, и <b>развилка</b> — две обычные жилы в стене за базой с выемкой между ними:
 *     три места, и клетка перед выемкой касается всех трёх (склад там — ни шага от жилы до сдачи).</li>
 *     <li><b>Общий прииск</b> с соседом — богатая жила в кольце скал: со стороны баз завал (дверь на двоих), с другой
 *     стороны — проход, без прокопа в обход. У пары через угол ромба базы подходят с двух сторон — там две двери.</li>
 *     <li><b>Дикие земли</b> — каменистый пояс, восемь диких приисков. Каждый — <b>россыпь</b> (четыре богатые жилы
 *     квадратом: центральная клетка касается четырёх мест, соседние — трёх) и <b>ущелье</b> (три богатые жилы вдоль
 *     хода в одну клетку: свой рабочий у входа запирает своих дальше). К середине ведут каньоны с завалами.</li>
 *     <li><b>Сердце</b> — четыре самые быстрые жилы под завалом посреди поляны; до него всем одинаково далеко.</li>
 * </ol>
 *
 * <p>Как и в {@link QuarterGen}, рельеф — поле по четырём поворотам, всё поверх пишется в четыре копии. Равенство
 * классов одной четверти: по ромбу — само, где рельеф мешает — прорубкой ({@link #equalize}); проверяется замерами
 * путей ({@link #check}), в том числе для простого кода: 12 ближайших по прямой мест у жил.
 */
final class ArenaGen {

    /** Меньше мест — арена не строится (в середине не хватает места), берётся крепость. */
    static final int MIN_SEATS = 12;
    /** Общих приисков у каждого места. */
    static final int MINES_PER_SEAT = 2;
    /** Обход к общему прииску длиннее двери хотя бы на столько шагов. */
    static final int DOOR_GAIN_MIN = 6;
    /** Диких приисков в четверти. */
    static final int WILD_PER_QUARTER = 2;
    /**
     * Карман и развилка «свои»: любая чужая база по прямой дальше своей хотя бы на столько. Иначе простой код соседа
     * берёт их как свои ближние, а у мест у углов ромба соседей меньше — выходит нечестно.
     */
    static final int OWN_MARGIN = 4;
    /** До кармана — столько шагов, ±1. */
    static final int POCKET_STEPS = 4;
    /** До развилки (до ближайшего из трёх мест) — столько шагов, ±1. */
    static final int FORK_STEPS = 6;
    /** Попыток собрать годный мир (каждая — своё зерно). */
    static final int ATTEMPTS = 48;

    /**
     * Радиус ромба баз в шагах: {@code |dx| + |dy|} от середины. Ходят по четырём сторонам, поэтому «круг», где до
     * сердца всем поровну, — ромб. На стороне ромба базы через {@link #spacing} по обходу (у углов — шире, см.
     * {@link #cornerGap}); не меньше 36, чтобы в середине поместились дикие земли.
     */
    static int radius(int seats) {
        int k = seats / 4;
        double r = k > 2 ? ((k - 2) * spacing(seats) + CORNER) / 2 : 0;
        return (int) Math.ceil(Math.max(36, r));
    }

    /**
     * Шаг между соседними базами по обходу ромба ({@code |dx| + |dy|}): 11,5, на 30 местах и больше — 10,5. По
     * клеткам это около 8 — соседи на проекторе не слипаются, а общий прииск помещается между ними.
     */
    static double spacing(int seats) {
        return seats >= 30 ? 10.5 : 11.5;
    }

    /**
     * Сумма половины разрыва у угла и половины шага: столько по обходу от угла ромба до первого общего прииска на
     * стороне, плюс 7. Иначе прииск в углу (у пары через угол) и соседний сходятся ближе 7,5 клетки.
     */
    static final double CORNER = 35.5;

    /** От ромба баз до гор: развилка за базой. */
    static int margin(int seats) {
        return seats >= 30 ? 6 : 7;
    }

    /** Сторона мира, нечётная: в середине клетка сердца. */
    static int side(int seats) {
        return 2 * (radius(seats) + margin(seats)) + 1;
    }

    /**
     * Разрыв по обходу между крайними базами соседних сторон (через угол) и шаг на стороне — {gap, step}: базы стоят
     * через {@code step}, у угла — через {@code gap}. Если места много — поровну.
     */
    static double[] cornerGap(int seats, int r1) {
        int k = seats / 4;
        double even = 2.0 * r1 / k;
        if (k <= 2 || even >= CORNER / 2) {
            return new double[] {even, even};
        }
        double step = (2.0 * r1 - CORNER) / (k - 2);
        return new double[] {CORNER - step, step};
    }

    /** Ромб диких приисков: середина каменистого пояса, чётный (у приисков на сторонах ромба — целая половина). */
    static int wildRadius(int r1) {
        int w = (8 + r1 - 15) / 2;
        return Math.max(12, w - (w & 1));
    }

    /** Шагов от середины мира до клетки (как по клеткам). */
    private int m(int x, int y) {
        return Math.abs(x - c) + Math.abs(y - c);
    }

    /**
     * Лучший мир из {@link #ATTEMPTS} попыток: первый, прошедший проверки, или (если ни один) — с наименьшим числом
     * замечаний. Ищется до {@code want} годных; число попыток не зависит от скорости машины — одно зерно, одна
     * карта.
     */
    static WorldPlan plan(int asked, int seats, long seed, int want) {
        WorldPlan best = null;
        int ok = 0;
        int built = 0;
        for (int t = 0; t < ATTEMPTS && ok < Math.max(1, want); t++) {
            WorldPlan p = new ArenaGen(asked, seats, seed, t).build();
            if (p == null) {
                continue;
            }
            built++;
            if (p.report().ok()) {
                ok++;
            }
            if (best == null || better(p, best)) {
                best = p;
            }
        }
        if (best == null) {
            return null;
        }
        return new WorldPlan(best.map(), best.archetype(), asked, best.pods(), best.seats(), best.passes(),
                best.heart(), best.lair(), best.report(), built, 0);
    }

    private static boolean better(WorldPlan a, WorldPlan b) {
        int fa = a.report().failures().size();
        int fb = b.report().failures().size();
        if (fa != fb) {
            return fa < fb;
        }
        return a.report().score() > b.report().score();
    }

    /** Одна попытка как есть (и непрошедшая) — для отладки и замеров. */
    static WorldPlan attempt(int asked, int seats, long seed, int t) {
        return new ArenaGen(asked, seats, seed, t).build();
    }

    /** Отладка: последняя причина отказа по каждой попытке ({@code -Dworldgen.why=true}). */
    static final Map<String, Integer> WHY = new java.util.concurrent.ConcurrentHashMap<>();
    private static final boolean TRACE = Boolean.getBoolean("worldgen.why");

    private WorldPlan why(String reason) {
        if (TRACE) {
            WHY.merge(reason, 1, Integer::sum);
        }
        return null;
    }

    private final int asked;
    private final int seats;
    private final long seed;
    private final int k;
    private final int n;
    private final int c;
    /** Радиус ромба баз. */
    private final int rho;
    /** Радиус ромба диких приисков. */
    private final int rw;
    /** Цена прорубки по клеткам: где шум выше, скала «твёрже» — прорубленный ход петляет, а не идёт по линейке. */
    private int[] hardness;
    /** Дикие земли: вес пояса в клетке (0 — не пояс, каньон или поляна) и мелкая рябь скал. */
    private double[] bandW;
    private double[] roughF;
    private final SplittableRandom r;
    private final Archetype arch;
    private final Cells g;
    private final boolean[] lock;
    private final int[][] base;
    private final int[][] home;
    /** Развилка класса: {fx, fy, ox, oy, tx, ty} — выемка, наружу, вдоль стены. */
    private final int[][] fork;
    /** Карман класса: клетка жилы. */
    private final int[][] pocket;
    private final List<int[]> mines = new ArrayList<>();
    /** Дикие прииски четверти 0: {sx, sy, gx, gy} — середина площадки и ось к сердцу. */
    private final List<int[]> sites = new ArrayList<>();

    private ArenaGen(int asked, int seats, long seed, int attempt) {
        this.asked = asked;
        this.seats = seats;
        this.seed = seed;
        this.k = seats / 4;
        this.n = side(seats);
        this.c = n / 2;
        this.rho = radius(seats);
        this.rw = wildRadius(rho);
        this.r = new SplittableRandom(WorldGen.mix(seed * 0x9E3779B97F4A7C15L + attempt * 7_919L + seats * 31L + 5));
        this.arch = WorldGen.archetypeOf(seed);
        this.g = new Cells(n, n, Cells.ROCK);
        this.lock = new boolean[n * n];
        this.base = new int[k][];
        this.home = new int[k][];
        this.fork = new int[k][];
        this.pocket = new int[k][];
    }

    // ---- симметрия ----

    /** Поворот на 90° {@code t} раз: (x, y) → (n−1−y, x). */
    int[] rot(int x, int y, int t) {
        int ax = x;
        int ay = y;
        for (int i = 0; i < (t & 3); i++) {
            int nx = n - 1 - ay;
            ay = ax;
            ax = nx;
        }
        return new int[] {ax, ay};
    }

    private int[] copy(int cls, int t) {
        return rot(base[cls][0], base[cls][1], t);
    }

    private void put(int x, int y, char ch) {
        for (int t = 0; t < 4; t++) {
            int[] q = rot(x, y, t);
            if (g.in(q[0], q[1])) {
                g.set(q[0], q[1], ch);
            }
        }
    }

    private void hold(int x, int y) {
        for (int t = 0; t < 4; t++) {
            int[] q = rot(x, y, t);
            if (g.in(q[0], q[1])) {
                lock[g.idx(q[0], q[1])] = true;
            }
        }
    }

    private void putHold(int x, int y, char ch) {
        put(x, y, ch);
        hold(x, y);
    }

    private boolean locked(int x, int y) {
        return !g.in(x, y) || lock[g.idx(x, y)];
    }

    // ---- сборка ----

    private WorldPlan build() {
        bases();
        sites();
        field();
        heart();
        for (int i = 0; i < k; i++) {
            placeBase(i);
        }
        for (int[] s : sites) {
            stampSite(s);
        }
        plugs();
        connect();
        List<int[]> pairs = pairs();
        if (pairs == null) {
            return why("нет пар соседей с равными путями");
        }
        for (int[] e : pairs) {
            if (!mine(e)) {
                return why("кольцо прииска не встало");
            }
        }
        connect();
        boolean whole = own();
        if (!whole) {
            why("развилка или карман");
        }
        equalize();
        widen();
        cleanup();
        equalize();
        cleanup();
        return finish();
    }

    // ---- базы ----

    /**
     * {@code k} баз четверти на стороне ромба от западного угла к северному: у углов разрыв шире, на стороне —
     * поровну; сдвиг на долю клетки — по зерну. У каждой базы {@code |dx| + |dy|} ровно {@link #radius}: до сердца
     * всем поровну.
     */
    private void bases() {
        double[] gs = cornerGap(seats, rho);
        for (int i = 0; i < k; i++) {
            double u = gs[0] / 2 + i * gs[1] + (r.nextDouble() - 0.5) * 0.6;
            int b = (int) Math.round(u / 2);
            b = Math.max(0, Math.min(rho, b));
            base[i] = new int[] {c - (rho - b), c - b};
        }
    }



    /**
     * Дикие прииски четверти 0: в западном углу ромба {@link #rw} и посередине северо-западной стороны. До россыпи
     * каждого — {@code rw + 4} шагов от середины; у любой базы хотя бы один лежит «по пути» к сердцу, поэтому до
     * ближайшего всем поровну. Ось площадки — к сердцу: у углового по оси, у бокового — на восток.
     */
    private void sites() {
        sites.add(new int[] {c - rw, c, 1, 0});
        sites.add(new int[] {c - rw / 2, c - rw / 2, 1, 0});
    }

    // ---- рельеф ----

    private void field() {
        double[] f = noise();
        boolean max = arch == Archetype.CANYONS || arch == Archetype.SINKHOLES;
        // мелкая рябь: и фактура, и одинаковых значений нет (иначе ранг зависит от номера клетки и симметрия рвётся)
        double[] fine = symmetric(Terrain.valueNoise(n, n, 2.6, r));
        double[] sum = new double[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                double s = max ? -1e9 : 0;
                for (int t = 0; t < 4; t++) {
                    int[] q = rot(x, y, t);
                    double v = f[q[1] * n + q[0]];
                    s = max ? Math.max(s, v) : s + v;
                }
                sum[y * n + x] = s + (max ? 0.18 : 0.5) * fine[y * n + x];
            }
        }
        double share = switch (arch) {
            case PLATEAU -> 0.26;
            case CANYONS -> 0.32;
            case SINKHOLES -> 0.30;
            case ROCK_MAZE -> 0.40;
        };
        Integer[] order = new Integer[n * n];
        for (int i = 0; i < order.length; i++) {
            order[i] = i;
        }
        Arrays.sort(order, (p, q) -> Double.compare(sum[p], sum[q]));
        double[] rank = new double[n * n];
        for (int i = 0; i < order.length; i++) {
            rank[order[i]] = (double) i / (order.length - 1);
        }
        double[] valley = valleys();
        boolean[] rock = new boolean[n * n];
        for (int i = 0; i < rock.length; i++) {
            int x = i % n;
            int y = i / n;
            rock[i] = rank[i] > 1 - share + valley[i] || x == 0 || y == 0 || x == n - 1 || y == n - 1;
            if (bandW[i] > 0.5) {
                // дикие земли: около половины — скалы, мелкими кусками; крупный облик мира — четвертью веса
                rock[i] = 0.75 * (1 - roughF[i]) + 0.25 * rank[i] > 0.52;
            }
        }
        int smooth = switch (arch) {
            case PLATEAU -> 3;
            case CANYONS -> 1;
            case SINKHOLES -> 1;
            case ROCK_MAZE -> 2;
        };
        for (int s = 0; s < smooth; s++) {
            rock = Terrain.smooth(rock, n, n, null);
        }
        for (int i = 0; i < rock.length; i++) {
            g.a[i] = rock[i] ? Cells.ROCK : Cells.FLOOR;
            int x = i % n;
            int y = i / n;
            if (x == 0 || y == 0 || x == n - 1 || y == n - 1) {
                g.a[i] = Cells.ROCK;
                lock[i] = true;
            }
        }
    }

    /** Шум, усреднённый по четырём поворотам. */
    private double[] symmetric(double[] v) {
        double[] out = new double[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                double s = 0;
                for (int t = 0; t < 4; t++) {
                    int[] q = rot(x, y, t);
                    s += v[q[1] * n + q[0]];
                }
                out[y * n + x] = s / 4;
            }
        }
        return out;
    }

    /**
     * Долины и горы — всё по шагам от середины ({@code m = |dx| + |dy|}): горы за ромбом баз, долина вдоль ромба
     * баз, от каждой базы — короткая долина сквозь гряду приисков к внутренней долине; дальше — каменистый пояс диких
     * земель, каньоны к сердцу между дикими приисками и поляны вокруг приисков.
     */
    private double[] valleys() {
        double[] wob = symmetric(Terrain.valueNoise(n, n, 5.0, r));
        // дикие земли — мелкие скалы и проходы между ними (не сплошная стена, а «бездорожье»)
        double[] rough = symmetric(Terrain.fractal(n, n, 4.2, 0.45, r));
        stretch(rough);
        roughF = rough;
        bandW = new double[n * n];
        double[] edge = symmetric(Terrain.valueNoise(n, n, 7.0, r));
        double[] edge2 = symmetric(Terrain.valueNoise(n, n, 2.5, r));
        List<double[]> spokes = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                int[] q = copy(i, t);
                spokes.add(new double[] {q[0] - c, q[1] - c});
            }
        }
        // каньон к сердцу — по одному в четверти, между дикими приисками (на 247,5° в четверти 0), с завалом
        List<double[]> canyons = new ArrayList<>();
        for (int j = 0; j < 4; j++) {
            double a = Math.PI + 3 * Math.PI / 8 + j * Math.PI / 2;
            canyons.add(new double[] {Math.cos(a), Math.sin(a), 1});
        }
        List<double[]> clear = new ArrayList<>();
        for (int[] s : sites) {
            for (int t = 0; t < 4; t++) {
                int[] q = rot(s[0] - 3 * s[2], s[1] - 3 * s[3], t);
                clear.add(new double[] {q[0], q[1]});
            }
        }
        double inR = rho - 13;
        double out = rho + margin(seats) - 1.0;
        double[] v = new double[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                double dx = x - c;
                double dy = y - c;
                double mm = Math.abs(dx) + Math.abs(dy);
                double w = 0.7 + 0.6 * wob[y * n + x];
                double ring = Math.exp(-Math.pow((mm - rho) / (3.6 * w), 2));
                double spoke = 0;
                for (double[] b : spokes) {
                    double bl = Math.hypot(b[0], b[1]);
                    double along = (dx * b[0] + dy * b[1]) / bl;
                    if (along < bl - 15 || along > bl) {
                        continue;
                    }
                    double across = Math.abs(dx * b[1] - dy * b[0]) / bl;
                    spoke = Math.max(spoke, Math.exp(-Math.pow(across / (1.7 * w), 2)));
                }
                double wall = Math.exp(-Math.pow((mm - (rho - 7)) / (2.6 * w), 2));
                double inner = Math.exp(-Math.pow((mm - inR) / (1.8 * w), 2));
                double canyon = 0;
                for (double[] cy : canyons) {
                    double along = dx * cy[0] + dy * cy[1];
                    if (along < 5 || along > inR) {
                        continue;
                    }
                    double across = dx * cy[1] - dy * cy[0];
                    double bend = 1.4 * Math.sin(along / 3.3 + cy[2] * 1.7);
                    canyon = Math.max(canyon, Math.exp(-Math.pow((across - bend) / (1.4 * w), 2)));
                }
                double glade = 0;
                for (double[] s : clear) {
                    double d = Math.hypot(x - s[0], y - s[1]);
                    glade = Math.max(glade, Math.exp(-Math.pow(d / 4.5, 4)));
                }
                double band = mm > 8 && mm < inR - 2 ? 1 : 0;
                double open = Math.max(Math.max(0.8 * ring, 0.6 * spoke), Math.max(0.4 * inner,
                        Math.max(0.6 * canyon, 0.75 * glade)));
                bandW[y * n + x] = band * (1 - Math.max(canyon, glade));
                double val = open - 1.4 * wall * (1 - spoke);
                double jag = 6.0 * (edge[y * n + x] - 0.5) + 2.5 * (edge2[y * n + x] - 0.5);
                // острия ромба срезаны: у угла баз нет, там горы
                double tip = Math.max(Math.abs(dx), Math.abs(dy)) - (rho - 1);
                double mountains = Math.max(mm - (out + jag), tip - jag / 2);
                if (mountains > 0) {
                    val -= 3;
                }
                v[y * n + x] = val;
            }
        }
        return v;
    }

    /** Растянуть значения в 0…1 по рангу (у суммы четырёх поворотов разброс уже, чем у шума). */
    private static void stretch(double[] v) {
        Integer[] order = new Integer[v.length];
        for (int i = 0; i < order.length; i++) {
            order[i] = i;
        }
        Arrays.sort(order, (p, q) -> Double.compare(v[p], v[q]));
        double[] out = new double[v.length];
        int i = 0;
        while (i < order.length) {
            int j = i;
            while (j + 1 < order.length && v[order[j + 1]] == v[order[i]]) {
                j++;
            }
            double rank = (i + j) / 2.0 / (order.length - 1);
            for (int t = i; t <= j; t++) {
                out[order[t]] = rank;
            }
            i = j + 1;
        }
        System.arraycopy(out, 0, v, 0, v.length);
    }

    /** Шум облика (как в {@link QuarterGen}). */
    private double[] noise() {
        return switch (arch) {
            case PLATEAU -> Terrain.fractal(n, n, n / 5.5, 0.35, r);
            case ROCK_MAZE -> Terrain.fractal(n, n, 3.4, 0.6, r);
            case CANYONS -> {
                double[] b = Terrain.fractal(n, n, n / 6.0, 0.25, r);
                for (int i = 0; i < b.length; i++) {
                    b[i] = 1 - Math.abs(2 * b[i] - 1);
                }
                yield b;
            }
            case SINKHOLES -> {
                double[] b = new double[n * n];
                double[] wob = Terrain.valueNoise(n, n, 2.5, r);
                int count = Math.max(3, (int) Math.round(n * n * 0.075 / (Math.PI * 3.6 * 3.6)));
                for (int m = 0; m < count; m++) {
                    double rad = 2.6 + r.nextDouble() * 2.2;
                    double cx = 2 + r.nextDouble() * (n - 4);
                    double cy = 2 + r.nextDouble() * (n - 4);
                    int r0 = (int) Math.ceil(rad * 1.3) + 1;
                    for (int dy = -r0; dy <= r0; dy++) {
                        for (int dx = -r0; dx <= r0; dx++) {
                            int x = (int) Math.round(cx) + dx;
                            int y = (int) Math.round(cy) + dy;
                            if (x < 0 || y < 0 || x >= n || y >= n) {
                                continue;
                            }
                            double d = Math.hypot(x - cx, y - cy);
                            double v = 1 - d / (rad * (0.85 + 0.3 * wob[y * n + x]));
                            b[y * n + x] = Math.max(b[y * n + x], v);
                        }
                    }
                }
                yield b;
            }
        };
    }

    /** Сердце: столп, четыре жилы на осях под завалом, поляна вокруг. */
    private void heart() {
        for (int y = c - 9; y <= c + 9; y++) {
            for (int x = c - 9; x <= c + 9; x++) {
                double d = Math.hypot(x - c, y - c);
                char ch;
                if (d <= 1.0) {
                    ch = Cells.ROCK;
                } else if (d <= 3.9) {
                    ch = Cells.RUBBLE;
                } else if (d <= 6.5) {
                    ch = Cells.FLOOR;
                } else {
                    continue;
                }
                g.set(x, y, ch);
                lock[g.idx(x, y)] = true;
            }
        }
        putHold(c, c - 2, 'C');
    }

    /** Площадка 5×5, база, домашняя по диагонали наружу в нише: туда только появляются. */
    private void placeBase(int i) {
        int x = base[i][0];
        int y = base[i][1];
        int dx = -1;
        int dy = y < c ? -1 : 1;
        for (int yy = y - 2; yy <= y + 2; yy++) {
            for (int xx = x - 2; xx <= x + 2; xx++) {
                if (!locked(xx, yy)) {
                    if (Math.max(Math.abs(xx - x), Math.abs(yy - y)) <= 1) {
                        putHold(xx, yy, Cells.FLOOR);
                    } else {
                        put(xx, yy, Cells.FLOOR);
                    }
                }
            }
        }
        putHold(x, y, '@');
        putHold(x + dx, y + dy, 'H');
        home[i] = new int[] {x + dx, y + dy};
        putHold(x + dx, y, Cells.ROCK);
        putHold(x + 2 * dx, y + dy, Cells.ROCK);
        putHold(x + dx, y + 2 * dy, Cells.ROCK);
        putHold(x + 2 * dx, y + 2 * dy, Cells.ROCK);
        putHold(x, y + 2 * dy, Cells.ROCK);
        putHold(x - dx, y + dy, Cells.ROCK);
    }

    // ---- дикие прииски ----

    /**
     * Дикий прииск в координатах площадки: {@code a} — к сердцу, {@code b} — поперёк. Снаружи (a от −7 до −1) —
     * поляна с россыпью: четыре богатые жилы в углах квадрата 3×3 около (−4, 0). Внутри (a от 1 до 7) — скала с
     * ущельем: ход в одну клетку a = 1…4, жилы (2, 1), (3, −1) и в торце (5, 0). Между ними — двор (a = −1…0).
     */
    private void stampSite(int[] s) {
        int sx = s[0];
        int sy = s[1];
        int gx = s[2];
        int gy = s[3];
        int hx = -gy;
        int hy = gx;
        // скальный выступ с ущельем: эллипс
        for (int a = 0; a <= 7; a++) {
            for (int b = -3; b <= 3; b++) {
                double e = Math.pow((a - 3.3) / 3.4, 2) + Math.pow(b / 2.6, 2);
                if (e <= 1) {
                    putHold(sx + a * gx + b * hx, sy + a * gy + b * hy, Cells.ROCK);
                }
            }
        }
        for (int a = 1; a <= 4; a++) {
            putHold(sx + a * gx, sy + a * gy, Cells.FLOOR);
        }
        putHold(sx + 2 * gx + hx, sy + 2 * gy + hy, '$');
        putHold(sx + 3 * gx - hx, sy + 3 * gy - hy, '$');
        putHold(sx + 5 * gx, sy + 5 * gy, '$');
        // двор
        for (int a = -1; a <= 0; a++) {
            for (int b = -2; b <= 2; b++) {
                putHold(sx + a * gx + b * hx, sy + a * gy + b * hy, Cells.FLOOR);
            }
        }
        // россыпь: квадрат 5×5 вокруг (−4, 0), жилы в углах внутреннего 3×3
        for (int a = -6; a <= -2; a++) {
            for (int b = -2; b <= 2; b++) {
                boolean dep = (a == -5 || a == -3) && Math.abs(b) == 1;
                putHold(sx + a * gx + b * hx, sy + a * gy + b * hy, dep ? '$' : Cells.FLOOR);
            }
        }
        // поляна вокруг россыпи (не закреплена — рельеф может подойти ближе)
        for (int a = -7; a <= -1; a++) {
            for (int b = -4; b <= 4; b++) {
                int x = sx + a * gx + b * hx;
                int y = sy + a * gy + b * hy;
                if (!locked(x, y) && Math.hypot(a + 4, b) <= 4.2) {
                    put(x, y, Cells.FLOOR);
                }
            }
        }
    }

    /** Клетки жил дикого прииска {@code s} (четверть 0): сначала россыпь, затем ущелье. */
    private List<int[]> siteDeposits(int[] s) {
        int gx = s[2];
        int gy = s[3];
        int hx = -gy;
        int hy = gx;
        List<int[]> out = new ArrayList<>();
        for (int a : new int[] {-5, -3}) {
            for (int b : new int[] {-1, 1}) {
                out.add(new int[] {s[0] + a * gx + b * hx, s[1] + a * gy + b * hy});
            }
        }
        out.add(new int[] {s[0] + 2 * gx + hx, s[1] + 2 * gy + hy});
        out.add(new int[] {s[0] + 3 * gx - hx, s[1] + 3 * gy - hy});
        out.add(new int[] {s[0] + 5 * gx, s[1] + 5 * gy});
        return out;
    }

    /** Середина россыпи (клетка, что касается четырёх мест). */
    private int[] siteCentre(int[] s) {
        return new int[] {s[0] - 4 * s[2], s[1] - 4 * s[3]};
    }

    /**
     * Завалы в каньонах: в каждой четверти каньон на 247,5° перегорожен завалом в две клетки — короткий путь к
     * сердцу для того, кто разберёт (и для всех после него); каньон на 202,5° открыт.
     */
    private void plugs() {
        double a = Math.PI + Math.PI / 8 + Math.PI / 4;
        double ux = Math.cos(a);
        double uy = Math.sin(a);
        double rr = (rw + rho - 13) / 2.0 / (Math.abs(ux) + Math.abs(uy));
        double bend = 1.4 * Math.sin(rr / 3.3 + 1.7);
        double px = c + rr * ux + bend * uy;
        double py = c + rr * uy - bend * ux;
        for (int y = (int) py - 4; y <= (int) py + 4; y++) {
            for (int x = (int) px - 4; x <= (int) px + 4; x++) {
                if (!g.in(x, y) || locked(x, y)) {
                    continue;
                }
                double along = (x - px) * ux + (y - py) * uy;
                double across = -(x - px) * uy + (y - py) * ux;
                if (Math.abs(along) <= 1.0 && Math.abs(across) <= 3.5 && g.get(x, y) == Cells.FLOOR) {
                    putHold(x, y, Cells.RUBBLE);
                }
            }
        }
    }

    // ---- связность ----

    private List<int[]> out(int[] b) {
        return PodGen.walkOut(g, b[0], b[1]);
    }

    private List<int[]> allOut() {
        List<int[]> src = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                src.addAll(out(copy(i, t)));
            }
        }
        return src;
    }

    /** Весь пол связан с базой 0 (завалы закрыты): мелкие клочки — в скалу, крупные — ходом к ближайшему. */
    private void connect() {
        for (int pass = 0; pass < 80; pass++) {
            int[] d = g.dist(out(copy(0, 0)), false, 0);
            List<Integer> sizes = new ArrayList<>();
            int[] comp = g.components(i -> Cells.walk(g.a[i]) && d[i] < 0 && !niche(i), false, sizes);
            int pick = -1;
            for (int i = 0; i < comp.length && pick < 0; i++) {
                if (comp[i] >= 0) {
                    pick = i;
                }
            }
            if (pick < 0) {
                return;
            }
            int id = comp[pick];
            boolean held = false;
            for (int i = 0; i < comp.length; i++) {
                if (comp[i] == id && lock[i]) {
                    held = true;
                    break;
                }
            }
            if (sizes.get(id) <= 12 && !held) {
                for (int i = 0; i < comp.length; i++) {
                    if (comp[i] == id) {
                        put(i % n, i / n, Cells.ROCK);
                    }
                }
            } else {
                carve(pick, d);
            }
        }
    }

    private boolean niche(int i) {
        int x = i % n;
        int y = i / n;
        for (int[] d : Cells.DIRS) {
            if (g.get(x + d[0], y + d[1]) == 'H') {
                return true;
            }
        }
        return false;
    }

    /** Ход от клетки {@code from} до ближайшей достижимой — сквозь незакреплённую скалу, в четыре поворота. */
    private void carve(int from, int[] reach) {
        int[] prev = new int[n * n];
        Arrays.fill(prev, -2);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        prev[from] = -1;
        q.add(from);
        int hit = -1;
        while (!q.isEmpty() && hit < 0) {
            int i = q.poll();
            for (int[] dd : Cells.DIRS) {
                int x = i % n + dd[0];
                int y = i / n + dd[1];
                if (!g.in(x, y)) {
                    continue;
                }
                int j = g.idx(x, y);
                if (prev[j] != -2) {
                    continue;
                }
                char ch = g.a[j];
                if (reach[j] >= 0 && Cells.walk(ch)) {
                    prev[j] = i;
                    hit = j;
                    break;
                }
                if (Cells.walk(ch) || ch == Cells.ROCK && !lock[j]) {
                    prev[j] = i;
                    q.add(j);
                }
            }
        }
        for (int i = hit; i >= 0; i = prev[i]) {
            if (g.a[i] == Cells.ROCK && !lock[i]) {
                put(i % n, i / n, Cells.FLOOR);
            }
        }
    }

    // ---- общие прииски (как в QuarterGen) ----

    /** Пары соседей по ромбу: {a, b, копия b}; у класса два соседа — два прииска. */
    private List<int[]> pairs() {
        List<int[]> want = new ArrayList<>();
        for (int i = 0; i + 1 < k; i++) {
            want.add(new int[] {i, i + 1, 0});
        }
        want.add(k == 1 ? new int[] {0, 0, 1} : new int[] {0, k - 1, 3});
        return want;
    }

    /** Место базы класса {@code i}, копии {@code t} на обходе ромба: от западного угла по часовой, 0…8·rho. */
    private double around(int i, int t) {
        return 2.0 * (c - base[i][1]) + 2.0 * rho * t;
    }

    /**
     * Точка ромба радиуса {@code rr} на обходе {@code u} (0…8·rr от западного угла по часовой) и наружу оттуда:
     * {x, y, nx, ny}.
     */
    private double[] onDiamond(double rr, double u) {
        double per = 8 * rr;
        u = ((u % per) + per) % per;
        int q = (int) Math.floor(u / (2 * rr));
        double w = u - 2 * rr * q;
        double bb = w / 2;
        double aa = rr - bb;
        double x = c - aa;
        double y = c - bb;
        double nx = bb < 1.5 ? -1 : aa < 1.5 ? 0 : -Math.sqrt(0.5);
        double ny = bb < 1.5 ? 0 : aa < 1.5 ? -1 : -Math.sqrt(0.5);
        // поворот на q четвертей: (x, y) → (n−1−y, x), вектор (vx, vy) → (−vy, vx)
        for (int j = 0; j < q; j++) {
            double tx = n - 1 - y;
            y = x;
            x = tx;
            double tn = -ny;
            ny = nx;
            nx = tn;
        }
        return new double[] {x, y, nx, ny};
    }

    /**
     * Общий прииск пары: на ромбе {@code rho − depth} напротив середины между базами по ромбу (проекция поперёк
     * стороны: у обеих баз прииск «по пути» к сердцу, до него обеим ровно {@code depth} шагов); у угла — в угол
     * внутреннего ромба. Дверь — наружу, к базам.
     */
    private boolean mine(int[] e) {
        double ua = around(e[0], 0);
        double ub = around(e[1], e[2]);
        double per = 8.0 * rho;
        if (Math.abs(ua - ub) > per / 2) {
            if (ua < ub) {
                ua += per;
            } else {
                ub += per;
            }
        }
        double mid = ((ua + ub) / 2 % per + per) % per;
        int q = (int) Math.floor(mid / (2.0 * rho));
        double local = mid - 2.0 * rho * q;
        if (local < 7 || local > 2 * rho - 7) {
            // пара через угол: базы подходят с двух сторон — у прииска две двери, к каждой базе своя, проход — к
            // острию; со стороны сердца — скала
            int qq = local < 7 ? q : (q + 1) & 3;
            for (double depth : new double[] {5.0, 4.0, 6.0}) {
                double[] p = onDiamond(rho - depth, 2 * (rho - depth) * qq);
                int px = (int) Math.round(p[0]);
                int py = (int) Math.round(p[1]);
                if (fits(px, py)) {
                    cornerRing(px, py, p[2], p[3]);
                    mines.add(new int[] {px, py, e[0], e[1], e[2]});
                    return true;
                }
            }
            return false;
        }
        for (double depth : new double[] {6.0, 7.0, 5.0}) {
            double rr = rho - depth;
            double ul = Math.max(0, Math.min(2 * rr, local - depth));
            double[] p = onDiamond(rr, 2 * rr * q + ul);
            int px = (int) Math.round(p[0]);
            int py = (int) Math.round(p[1]);
            if (fits(px, py)) {
                ring(px, py, p[2], p[3]);
                mines.add(new int[] {px, py, e[0], e[1], e[2]});
                return true;
            }
        }
        return false;
    }

    private boolean fits(int px, int py) {
        for (int y = py - 6; y <= py + 6; y++) {
            for (int x = px - 6; x <= px + 6; x++) {
                if (Math.hypot(x - px, y - py) > 2.7) {
                    continue;
                }
                if (x < 2 || y < 2 || x > n - 3 || y > n - 3 || lock[g.idx(x, y)]) {
                    why("прииск: занято " + g.get(x, y));
                    return false;
                }
            }
        }
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                int[] q = copy(i, t);
                if (Math.hypot(q[0] - px, q[1] - py) < 5.5) {
                    why("прииск: база рядом");
                    return false;
                }
            }
        }
        int[] q = rot(px, py, 1);
        if (Math.hypot(q[0] - px, q[1] - py) <= 8) {
            why("прииск: сам с собой");
        }
        return Math.hypot(q[0] - px, q[1] - py) > 8;
    }

    /**
     * Кольцо прииска у угла ромба: {@code (ox, oy)} — наружу, к острию. Двери-завалы — поперёк, к обеим базам; проход —
     * к острию (без кирки — в обход кольца); к сердцу — скала.
     */
    private void cornerRing(int px, int py, double ox, double oy) {
        double sx = -oy;
        double sy = ox;
        for (int y = py - 5; y <= py + 5; y++) {
            for (int x = px - 5; x <= px + 5; x++) {
                double d = Math.hypot(x - px, y - py);
                if (d > 3.9) {
                    continue;
                }
                double cs = d == 0 ? 0 : ((x - px) * sx + (y - py) * sy) / d;
                double co = d == 0 ? 0 : ((x - px) * ox + (y - py) * oy) / d;
                char ch;
                if (d <= 1.5) {
                    ch = Cells.FLOOR;
                } else if (d <= 2.6) {
                    ch = Math.abs(cs) >= 0.86 ? Cells.RUBBLE : co >= 0.86 ? Cells.FLOOR : Cells.ROCK;
                } else if (Math.abs(cs) >= 0.6 || co >= 0.6) {
                    ch = Cells.FLOOR;
                } else if (co <= -0.6) {
                    ch = Cells.ROCK;
                } else {
                    continue;
                }
                putHold(x, y, ch);
            }
        }
        putHold(px, py, '$');
    }

    /** Кольцо прииска: дверь-завал в сторону {@code (dx, dy)} (к кругу баз), проход напротив. */
    private void ring(int px, int py, double dx, double dy) {
        for (int y = py - 6; y <= py + 6; y++) {
            for (int x = px - 6; x <= px + 6; x++) {
                double d = Math.hypot(x - px, y - py);
                double cos = d == 0 ? 0 : ((x - px) * dx + (y - py) * dy) / d;
                // кольцо — стена в одну клетку; перед дверью и за проходом — пол; с боков решает рельеф, чтобы между
                // соседними приисками оставался проход
                boolean front = d > 2.6 && d <= 3.6 && Math.abs(cos) >= 0.6;
                boolean apron = d > 2.6 && d <= 5.0 && cos <= -0.75 && !locked(x, y);
                if (d > 2.6 && !front && !apron) {
                    continue;
                }
                char ch;
                if (d <= 1.5) {
                    ch = Cells.FLOOR;
                } else if (d <= 2.6) {
                    ch = cos >= 0.86 ? Cells.RUBBLE : cos <= -0.86 ? Cells.FLOOR : Cells.ROCK;
                } else {
                    ch = Cells.FLOOR;
                }
                if (apron && !front) {
                    put(x, y, ch);
                } else {
                    putHold(x, y, ch);
                }
            }
        }
        putHold(px, py, '$');
    }

    // ---- до сердца поровну ----

    /**
     * До сердца и до ближайшей россыпи всем почти поровну. По ромбу до них всем одинаково, но скалы заставляют
     * обходить: классу, которому дальше всех (больше минимума на 3), прорубается ход — путь, где скала стоит 4 шага,
     * пол — 1; так рубится немного и там, где ход почти есть. До 14 раз.
     */
    private void equalize() {
        int stuck = 0;
        for (int pass = 0; pass < 30 && stuck < 3; pass++) {
            int[] hd = new int[k];
            int[] wd = new int[k];
            for (int i = 0; i < k; i++) {
                hd[i] = heartDist(g.dist(out(copy(i, 0)), true, 0));
                wd[i] = wildDist(g.dist(out(copy(i, 0)), false, 0));
                hd[i] = hd[i] < 0 ? 9999 : hd[i];
                wd[i] = wd[i] < 0 ? 9999 : wd[i];
            }
            int hw = 0;
            int ww = 0;
            for (int i = 1; i < k; i++) {
                hw = hd[i] > hd[hw] ? i : hw;
                ww = wd[i] > wd[ww] ? i : ww;
            }
            int hs = hd[hw] - Arrays.stream(hd).min().getAsInt();
            int ws = wd[ww] - Arrays.stream(wd).min().getAsInt();
            // никому не дойти — тоже неравенство: рубить до худшего
            if (hd[hw] == 9999) {
                hs = 999;
            }
            if (wd[ww] == 9999) {
                ws = 999;
            }
            if (hs <= 2 && ws <= 2) {
                return;
            }
            if (hardness == null) {
                double[] hn = symmetric(Terrain.valueNoise(n, n, 3.0, r));
                stretch(hn);
                hardness = new int[n * n];
                for (int i = 0; i < hardness.length; i++) {
                    hardness[i] = (int) Math.round(4 * hn[i]);
                }
            }
            int cost = 2 + Math.min(1, stuck) * -1;
            int carved;
            if (hs >= ws) {
                carved = carveToward(out(copy(hw, 0)), Math.max(1, cost), true,
                        i -> Math.hypot(i % n - c, i / n - c) <= 6.5 && g.a[i] == Cells.FLOOR);
            } else {
                boolean[] arm = new boolean[n * n];
                for (int[] a2 : wildArms()) {
                    arm[g.idx(a2[0], a2[1])] = true;
                }
                carved = carveToward(out(copy(ww, 0)), Math.max(1, cost), false, i -> arm[i]);
            }
            stuck = carved == 0 ? stuck + 1 : 0;
        }
    }

    /** Клетки, что касаются середины россыпи (по две жилы у каждой), у всех диких приисков. */
    private List<int[]> wildArms() {
        List<int[]> outList = new ArrayList<>();
        for (int[] s : sites) {
            int[] sc = siteCentre(s);
            for (int t = 0; t < 4; t++) {
                for (int[] d : Cells.DIRS) {
                    outList.add(rot(sc[0] + d[0], sc[1] + d[1], t));
                }
            }
        }
        return outList;
    }

    /** Шагов до ближайшей россыпи (до клетки, что касается двух её жил); {@code -1} — не дойти. */
    private int wildDist(int[] d) {
        int best = -1;
        for (int[] a2 : wildArms()) {
            int v = d[g.idx(a2[0], a2[1])];
            if (v >= 0 && (best < 0 || v < best)) {
                best = v;
            }
        }
        return best;
    }

    /**
     * Взвешенный путь от {@code from} до клетки, где {@code target}; скала по пути — в пол (в четыре поворота).
     * {@code rubbleOpen} — завал проходим (как разобранный).
     */
    private int carveToward(List<int[]> from, int rockCost, boolean rubbleOpen, java.util.function.IntPredicate target) {
        int[] dist = new int[n * n];
        int[] prev = new int[n * n];
        Arrays.fill(dist, Integer.MAX_VALUE);
        Arrays.fill(prev, -1);
        PriorityQueue<int[]> pq = new PriorityQueue<>((p, q) -> Integer.compare(p[0], q[0]));
        for (int[] f : from) {
            int i = g.idx(f[0], f[1]);
            dist[i] = 0;
            pq.add(new int[] {0, i});
        }
        int hit = -1;
        while (!pq.isEmpty()) {
            int[] e = pq.poll();
            int i = e[1];
            if (e[0] > dist[i]) {
                continue;
            }
            if (target.test(i)) {
                hit = i;
                break;
            }
            int x = i % n;
            int y = i / n;
            for (int[] dd : Cells.DIRS) {
                int nx = x + dd[0];
                int ny = y + dd[1];
                if (!g.in(nx, ny)) {
                    continue;
                }
                int j = g.idx(nx, ny);
                char ch = g.a[j];
                int cost;
                if (Cells.walk(ch) || rubbleOpen && ch == Cells.RUBBLE) {
                    cost = 1;
                } else if (ch == Cells.ROCK && !lock[j]) {
                    cost = rockCost + (hardness == null || rockCost <= 1 ? 0 : hardness[j]);
                } else {
                    continue;
                }
                if (dist[i] + cost < dist[j]) {
                    dist[j] = dist[i] + cost;
                    prev[j] = i;
                    pq.add(new int[] {dist[j], j});
                }
            }
        }
        int carved = 0;
        for (int i = hit; i >= 0; i = prev[i]) {
            if (g.a[i] == Cells.ROCK && !lock[i]) {
                put(i % n, i / n, Cells.FLOOR);
                carved++;
            }
        }
        return carved;
    }

    // ---- своё у базы ----

    /** Развилка и карман у каждого класса; классы — в допуске (развилка ±1, карман ±1). */
    private boolean own() {
        int tp = -1;
        boolean all = true;
        for (int i = 0; i < k; i++) {
            int got = placeFork(i, FORK_STEPS);
            if (got < 0) {
                why("развилка класса " + i);
                // нет развилки — на её месте база (замер покажет отказ)
                fork[i] = new int[] {base[i][0], base[i][1], 0, 0, 0, 0};
                all = false;
            }
            got = placePocket(i, tp);
            if (got < 0) {
                why("карман класса " + i);
                pocket[i] = new int[] {base[i][0], base[i][1]};
                all = false;
                continue;
            }
            if (tp < 0) {
                tp = got;
            }
        }
        return all;
    }

    /**
     * Развилка: выемка F в стене, жилы F ± t, за ними скала; перед выемкой — клетка D (склад там касается трёх мест:
     * F, F ± t − o). {@code o} — наружу (от сердца). Путь до ближайшего места 5–9 шагов; {@code target ≥ 0} — ±1 от
     * него. Возвращает путь или −1.
     */
    private int placeFork(int i, int target) {
        int bx = base[i][0];
        int by = base[i][1];
        int[] d0 = g.dist(out(copy(i, 0)), false, 0);
        List<int[]> cands = new ArrayList<>();
        for (int y = by - 10; y <= by + 10; y++) {
            for (int x = bx - 10; x <= bx + 10; x++) {
                if (!g.in(x, y) || x < 3 || y < 3 || x > n - 4 || y > n - 4) {
                    continue;
                }
                for (int[] o : Cells.DIRS) {
                    // наружу: от сердца
                    if (o[0] * (x - c) + o[1] * (y - c) <= 0) {
                        continue;
                    }
                    cands.add(new int[] {x, y, o[0], o[1]});
                }
            }
        }
        shuffle(cands);
        // сначала те, где до клетки D примерно нужное число шагов; при равенстве — ближе к горам (выемка в стене)
        int[] est = new int[cands.size()];
        for (int ci = 0; ci < cands.size(); ci++) {
            int[] cd = cands.get(ci);
            int dx = cd[0] - cd[2];
            int dy = cd[1] - cd[3];
            int v = g.in(dx, dy) ? d0[g.idx(dx, dy)] : -1;
            if (v < 0 && g.in(dx - cd[2], dy - cd[3])) {
                int v2 = d0[g.idx(dx - cd[2], dy - cd[3])];
                v = v2 < 0 ? -1 : v2 + 1;
            }
            est[ci] = v < 0 ? 99 : Math.abs(v - FORK_STEPS);
            cd = java.util.Arrays.copyOf(cd, 5);
            cd[4] = est[ci];
            cands.set(ci, cd);
        }
        cands.sort((p, q) -> p[4] != q[4] ? Integer.compare(p[4], q[4]) : Integer.compare(m(q[0], q[1]), m(p[0], p[1])));
        int tries = 0;
        for (int[] cd : cands) {
            int fx = cd[0];
            int fy = cd[1];
            int ox = cd[2];
            int oy = cd[3];
            int tx = -oy;
            int ty = ox;
            // клетки рисунка: {x, y, знак}; знак '?' — пол, если надо, но не трогать закреплённое
            int[][] floor = {{fx, fy}, {fx - ox, fy - oy}, {fx + tx - ox, fy + ty - oy}, {fx - tx - ox, fy - ty - oy}};
            int[][] dep = {{fx + tx, fy + ty}, {fx - tx, fy - ty}};
            int[][] rock = {{fx + ox, fy + oy}, {fx + tx + ox, fy + ty + oy}, {fx - tx + ox, fy - ty + oy},
                    {fx + 2 * tx, fy + 2 * ty}, {fx - 2 * tx, fy - 2 * ty}, {fx + 2 * tx + ox, fy + 2 * ty + oy},
                    {fx - 2 * tx + ox, fy - 2 * ty + oy}};
            boolean ok = true;
            for (int[] p : floor) {
                ok &= g.in(p[0], p[1]) && (!locked(p[0], p[1]) || g.get(p[0], p[1]) == Cells.FLOOR);
            }
            for (int[] p : dep) {
                ok &= !locked(p[0], p[1]);
            }
            for (int[] p : rock) {
                ok &= g.in(p[0], p[1]) && (!locked(p[0], p[1]) || g.get(p[0], p[1]) == Cells.ROCK);
            }
            // свои: чужие базы дальше хотя бы на 2; до приисков не ближе 5,5, до диких — 10
            ok = ok && own(fx, fy, i, OWN_MARGIN) && farFromMines(fx, fy) && farFromSites(fx, fy)
                    && m(fx, fy) > rho + 1;
            // рисунок касается того, куда уже можно дойти: клетка D или перед ней
            int di = g.idx(fx - ox, fy - oy);
            int dj = g.idx(fx - 2 * ox, fy - 2 * oy);
            if (!ok || d0[di] < 0 && (!g.in(fx - 2 * ox, fy - 2 * oy) || d0[dj] < 0)) {
                continue;
            }
            if (TRACE) {
                WHY.merge("развилка: кандидат", 1, Integer::sum);
            }
            if (++tries > 60) {
                break;
            }
            char[] save = g.a.clone();
            boolean[] saveLock = lock.clone();
            for (int[] p : floor) {
                if (!locked(p[0], p[1])) {
                    putHold(p[0], p[1], Cells.FLOOR);
                }
            }
            for (int[] p : rock) {
                if (!locked(p[0], p[1])) {
                    putHold(p[0], p[1], Cells.ROCK);
                }
            }
            for (int[] p : dep) {
                putHold(p[0], p[1], '*');
            }
            int[] dd = g.dist(out(copy(i, 0)), false, 0);
            int v = g.toSpots(dd, fx + tx, fy + ty);
            int v2 = g.toSpots(dd, fx - tx, fy - ty);
            int spots = g.spots(fx + tx, fy + ty).size() + g.spots(fx - tx, fy - ty).size();
            boolean good = v2 >= 0 && Math.abs(v - v2) <= 2 && spots <= 5 && Math.abs(v - target) <= 1
                    && pocketsStillOk(i, dd)
                    && !crumbAround(new int[] {fx + tx, fy + ty}) && !crumbAround(new int[] {fx - tx, fy - ty});
            if (good) {
                fork[i] = new int[] {fx, fy, ox, oy, tx, ty};
                return v;
            }
            if (TRACE) {
                WHY.merge("развилка: путь " + v + "/" + v2 + " мест " + spots, 1, Integer::sum);
            }
            System.arraycopy(save, 0, g.a, 0, save.length);
            System.arraycopy(saveLock, 0, lock, 0, lock.length);
        }
        return -1;
    }

    /** Ранее поставленные классы не потеряли путь до своих жил (рисунок мог перекрыть проход). */
    private boolean pocketsStillOk(int upTo, int[] ignored) {
        for (int j = 0; j < upTo; j++) {
            int[] dj = g.dist(out(copy(j, 0)), false, 0);
            if (fork[j] != null && g.toSpots(dj, fork[j][0] + fork[j][4], fork[j][1] + fork[j][5]) < 0) {
                return false;
            }
            if (pocket[j] != null && g.toSpots(dj, pocket[j][0], pocket[j][1]) < 0) {
                return false;
            }
        }
        return true;
    }

    /** Сторона света от {@code (x, y)} больше всего к {@code (tx, ty)}. */
    private static int[] toward(int x, int y, int tx, int ty) {
        int[] o = null;
        int best = Integer.MIN_VALUE;
        for (int[] dir : Cells.DIRS) {
            int dot = dir[0] * (tx - x) + dir[1] * (ty - y);
            if (dot > best) {
                best = dot;
                o = dir;
            }
        }
        return o;
    }

    /**
     * Карман: обычная жила в выемке скалы — у клетки ровно одна открытая сторона, до неё 3–5 шагов. Сначала ищется
     * готовая выемка (жила ставится в скалу и ничего не перекрывает); нет такой — скальный блок 3×3 с прорезью.
     */
    private int placePocket(int i, int target) {
        int got = notchPocket(i);
        if (got < 0) {
            got = spurPocket(i);
        }
        return got >= 0 ? got : blockPocket(i, target);
    }

    /** Карман в готовой выемке скалы; −1 — выемки нет. */
    private int notchPocket(int i) {
        int bx = base[i][0];
        int by = base[i][1];
        int[] d = g.dist(out(copy(i, 0)), false, 0);
        List<int[]> cands = new ArrayList<>();
        for (int y = by - 7; y <= by + 7; y++) {
            for (int x = bx - 7; x <= bx + 7; x++) {
                // карман — не ближе к сердцу, чем база: в проходах между приисками ему не место
                if (x < 3 || y < 3 || x > n - 4 || y > n - 4 || g.get(x, y) != Cells.ROCK || locked(x, y)
                        || m(x, y) < rho - 1) {
                    continue;
                }
                int open = 0;
                int[] spot = null;
                boolean rockElse = true;
                for (int[] dd : Cells.DIRS) {
                    char ch = g.get(x + dd[0], y + dd[1]);
                    if (Cells.walk(ch)) {
                        open++;
                        spot = new int[] {x + dd[0], y + dd[1]};
                    } else if (ch != Cells.ROCK) {
                        rockElse = false;
                    }
                }
                if (open != 1 || !rockElse || locked(spot[0], spot[1]) && g.get(spot[0], spot[1]) != Cells.FLOOR) {
                    continue;
                }
                int v = d[g.idx(spot[0], spot[1])];
                if (v < 0 || Math.abs(v - POCKET_STEPS) > 1 || !own(x, y, i, OWN_MARGIN) || !farFromMines(x, y, 3.5)
                        || Math.abs(x - fork[i][0]) + Math.abs(y - fork[i][1]) < 3 || crumbAround(new int[] {x, y})) {
                    continue;
                }
                // скала вокруг не крошка: хотя бы 4 камня из 8 соседей
                if (g.count8(x, y, Cells.ROCK) < 4) {
                    continue;
                }
                cands.add(new int[] {x, y, Math.abs(v - POCKET_STEPS), v});
            }
        }
        if (cands.isEmpty()) {
            return -1;
        }
        shuffle(cands);
        cands.sort((p, q) -> Integer.compare(p[2], q[2]));
        int[] cd = cands.get(0);
        putHold(cd[0], cd[1], '*');
        for (int[] dd : Cells.DIRS) {
            if (g.get(cd[0] + dd[0], cd[1] + dd[1]) == Cells.ROCK) {
                hold(cd[0] + dd[0], cd[1] + dd[1]);
            } else {
                hold(cd[0] + dd[0], cd[1] + dd[1]);
            }
        }
        pocket[i] = new int[] {cd[0], cd[1]};
        return cd[3];
    }

    /**
     * Карман-отрог: жила и три камня вокруг неё (открыта одна сторона — к базе), если готовой выемки нет; −1 — не
     * встал.
     */
    private int spurPocket(int i) {
        int bx = base[i][0];
        int by = base[i][1];
        int[] d = g.dist(out(copy(i, 0)), false, 0);
        int f0 = g.toSpots(d, fork[i][0] + fork[i][4], fork[i][1] + fork[i][5]);
        List<int[]> cands = new ArrayList<>();
        for (int y = by - 7; y <= by + 7; y++) {
            for (int x = bx - 7; x <= bx + 7; x++) {
                if (x < 3 || y < 3 || x > n - 4 || y > n - 4 || locked(x, y) || m(x, y) < rho - 1) {
                    continue;
                }
                for (int[] o : Cells.DIRS) {
                    int mx = x + o[0];
                    int my = y + o[1];
                    if (locked(mx, my) && g.get(mx, my) != Cells.FLOOR || !Cells.walk(g.get(mx, my))) {
                        continue;
                    }
                    int v = d[g.idx(mx, my)];
                    if (v < 0 || Math.abs(v - POCKET_STEPS) > 1) {
                        continue;
                    }
                    boolean free = true;
                    for (int[] dd : Cells.DIRS) {
                        if (dd != o && locked(x + dd[0], y + dd[1]) && g.get(x + dd[0], y + dd[1]) != Cells.ROCK) {
                            free = false;
                        }
                    }
                    if (free && own(x, y, i, OWN_MARGIN) && farFromMines(x, y, 3.5)
                            && Math.abs(x - fork[i][0]) + Math.abs(y - fork[i][1]) >= 3) {
                        cands.add(new int[] {x, y, o[0], o[1], Math.abs(v - POCKET_STEPS), g.count8(x, y, Cells.ROCK)});
                    }
                }
            }
        }
        shuffle(cands);
        // ближе к нужному числу шагов, затем — где скалы рядом уже больше (отрог прирастает к скале)
        cands.sort((p, q) -> p[4] != q[4] ? Integer.compare(p[4], q[4]) : Integer.compare(q[5], p[5]));
        int tries = 0;
        for (int[] cd : cands) {
            if (++tries > 30) {
                break;
            }
            char[] save = g.a.clone();
            boolean[] saveLock = lock.clone();
            int x = cd[0];
            int y = cd[1];
            for (int[] dd : Cells.DIRS) {
                if (dd[0] == cd[2] && dd[1] == cd[3]) {
                    continue;
                }
                putHold(x + dd[0], y + dd[1], Cells.ROCK);
            }
            putHold(x, y, '*');
            hold(x + cd[2], y + cd[3]);
            int[] d2 = g.dist(out(copy(i, 0)), false, 0);
            int v = g.toSpots(d2, x, y);
            int f2 = g.toSpots(d2, fork[i][0] + fork[i][4], fork[i][1] + fork[i][5]);
            pocket[i] = new int[] {x, y};
            boolean ok = Math.abs(v - POCKET_STEPS) <= 1 && g.spots(x, y).size() == 1 && f2 >= 0
                    && Math.abs(f2 - f0) <= 1 && pocketsStillOk(i, d2) && !crumbAround(new int[] {x, y});
            if (ok) {
                return v;
            }
            pocket[i] = null;
            System.arraycopy(save, 0, g.a, 0, save.length);
            System.arraycopy(saveLock, 0, lock, 0, lock.length);
        }
        return -1;
    }

    /** Карман в скальном блоке 3×3 с прорезью к базе; −1 — не встал. */
    private int blockPocket(int i, int target) {
        int bx = base[i][0];
        int by = base[i][1];
        List<int[]> cands = new ArrayList<>();
        int[] d = g.dist(out(copy(i, 0)), false, 0);
        for (int y = by - 7; y <= by + 7; y++) {
            for (int x = bx - 7; x <= bx + 7; x++) {
                if (x < 3 || y < 3 || x > n - 4 || y > n - 4) {
                    continue;
                }
                if (!own(x, y, i, OWN_MARGIN) || !farFromMines(x, y) || Math.abs(x - fork[i][0]) + Math.abs(y - fork[i][1]) < 4
                        || m(x, y) < rho - 1) {
                    continue;
                }
                boolean free = true;
                for (int yy = y - 1; yy <= y + 1 && free; yy++) {
                    for (int xx = x - 1; xx <= x + 1; xx++) {
                        if (locked(xx, yy)) {
                            free = false;
                            break;
                        }
                    }
                }
                if (free) {
                    cands.add(new int[] {x, y});
                }
            }
        }
        shuffle(cands);
        // сначала те, где до прорези примерно 3 шага
        for (int ci = 0; ci < cands.size(); ci++) {
            int[] cd = cands.get(ci);
            int[] o = toward(cd[0], cd[1], bx, by);
            int ox = cd[0] + 2 * o[0];
            int oy = cd[1] + 2 * o[1];
            int v = g.in(ox, oy) ? d[g.idx(ox, oy)] : -1;
            cands.set(ci, new int[] {cd[0], cd[1], v < 0 ? 99 : Math.abs(v + 1 - POCKET_STEPS)});
        }
        cands.sort((p, q) -> Integer.compare(p[2], q[2]));
        if (TRACE) {
            WHY.merge("карман " + i + ": кандидатов " + cands.size() + " годных " + cands.stream().filter(cd -> cd[2] <= 2).count(), 1, Integer::sum);
        }
        int tries = 0;
        for (int[] cand : cands) {
            if (++tries > 40 || cand[2] > 2) {
                break;
            }
            int x = cand[0];
            int y = cand[1];
            int[] o = null;
            int best = Integer.MIN_VALUE;
            for (int[] dir : Cells.DIRS) {
                int dot = dir[0] * (bx - x) + dir[1] * (by - y);
                if (dot > best) {
                    best = dot;
                    o = dir;
                }
            }
            int mx = x + o[0];
            int my = y + o[1];
            int ox = x + 2 * o[0];
            int oy = y + 2 * o[1];
            if (!g.in(ox, oy) || locked(ox, oy) && g.get(ox, oy) != Cells.FLOOR || d[g.idx(ox, oy)] < 0) {
                continue;
            }
            char[] save = g.a.clone();
            boolean[] saveLock = lock.clone();
            int[] pp = {o[1], o[0]};
            for (int yy = y - 1; yy <= y + 1; yy++) {
                for (int xx = x - 1; xx <= x + 1; xx++) {
                    putHold(xx, yy, Cells.ROCK);
                }
            }
            if (!locked(mx + pp[0], my + pp[1])) {
                putHold(mx + pp[0], my + pp[1], Cells.ROCK);
            }
            if (!locked(mx - pp[0], my - pp[1])) {
                putHold(mx - pp[0], my - pp[1], Cells.ROCK);
            }
            putHold(x, y, '*');
            putHold(mx, my, Cells.FLOOR);
            if (!locked(ox, oy)) {
                putHold(ox, oy, Cells.FLOOR);
            }
            int[] d2 = g.dist(out(copy(i, 0)), false, 0);
            int v = g.toSpots(d2, x, y);
            pocket[i] = new int[] {x, y};
            int f2 = g.toSpots(d2, fork[i][0] + fork[i][4], fork[i][1] + fork[i][5]);
            boolean ok = Math.abs(v - POCKET_STEPS) <= 1 && g.spots(x, y).size() == 1
                    && f2 >= 0 && Math.abs(f2 - FORK_STEPS) <= 1 && pocketsStillOk(i, d2);
            if (ok) {
                return v;
            }
            if (TRACE) {
                WHY.merge("карман " + i + ": путь " + v + " мест " + g.spots(x, y).size() + " развилка " + f2
                        + " прежние " + pocketsStillOk(i, d2), 1, Integer::sum);
            }
            pocket[i] = null;
            System.arraycopy(save, 0, g.a, 0, save.length);
            System.arraycopy(saveLock, 0, lock, 0, lock.length);
        }
        return -1;
    }

    /** Закрытые места у жилы не остались отдельными камнями в 1–2 клетки. */
    private boolean crumbAround(int[] q) {
        for (int[] d : Cells.DIRS) {
            int x = q[0] + d[0];
            int y = q[1] + d[1];
            if (g.get(x, y) != Cells.ROCK) {
                continue;
            }
            int rock = 0;
            for (int[] e : Cells.RING8) {
                if (g.get(x + e[0], y + e[1]) == Cells.ROCK) {
                    rock++;
                }
            }
            if (rock == 0) {
                return true;
            }
        }
        return false;
    }

    /** Клетка своя: по прямой любая чужая база хотя бы на 3 дальше своей. */
    private boolean own(int x, int y, int i) {
        return own(x, y, i, 3);
    }

    /** Клетка своя: по прямой любая чужая база хотя бы на {@code margin} дальше своей. */
    private boolean own(int x, int y, int i, int margin) {
        int mine = Math.abs(x - base[i][0]) + Math.abs(y - base[i][1]);
        for (int j = 0; j < k; j++) {
            for (int t = 0; t < 4; t++) {
                if (j == i && t == 0) {
                    continue;
                }
                int[] q = copy(j, t);
                if (Math.abs(x - q[0]) + Math.abs(y - q[1]) < mine + margin) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean farFromMines(int x, int y) {
        return farFromMines(x, y, 5.5);
    }

    private boolean farFromMines(int x, int y, double min) {
        for (int[] m : mines) {
            for (int t = 0; t < 4; t++) {
                int[] q = rot(m[0], m[1], t);
                if (Math.hypot(q[0] - x, q[1] - y) < min) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean farFromSites(int x, int y) {
        for (int[] s : sites) {
            for (int t = 0; t < 4; t++) {
                int[] q = rot(s[0], s[1], t);
                if (Math.hypot(q[0] - x, q[1] - y) < 10) {
                    return false;
                }
            }
        }
        return true;
    }

    // ---- магистрали и чистка ----

    /** Пути от базы к развилке, карману, приискам и сердцу — не уже двух клеток. */
    private void widen() {
        List<int[]> ms = new ArrayList<>();
        for (int[] m : mines) {
            for (int t = 0; t < 4; t++) {
                ms.add(rot(m[0], m[1], t));
            }
        }
        for (int i = 0; i < k; i++) {
            int[] b = copy(i, 0);
            int[] dAll = g.dist(out(b), false, 0);
            List<int[]> sorted = new ArrayList<>(ms);
            sorted.sort((p, q) -> Integer.compare(spotsOrFar(dAll, p), spotsOrFar(dAll, q)));
            List<int[]> use = new ArrayList<>(sorted.subList(0, Math.min(sorted.size(), MINES_PER_SEAT)));
            use.add(new int[] {fork[i][0], fork[i][1]});
            use.add(pocket[i]);
            for (int[] t : use) {
                List<int[]> path = route(out(b), t);
                for (int p = 1; p + 1 < path.size(); p++) {
                    int[] cur = path.get(p);
                    int[] nx = path.get(p + 1);
                    int dx = nx[0] - cur[0];
                    int dy = nx[1] - cur[1];
                    int[] sa = {cur[0] - dy, cur[1] + dx};
                    int[] sb = {cur[0] + dy, cur[1] - dx};
                    if (Cells.walk(g.get(sa[0], sa[1])) || Cells.walk(g.get(sb[0], sb[1]))) {
                        continue;
                    }
                    for (int[] side : new int[][] {sa, sb}) {
                        if (g.in(side[0], side[1]) && g.get(side[0], side[1]) == Cells.ROCK
                                && !locked(side[0], side[1])) {
                            put(side[0], side[1], Cells.FLOOR);
                            break;
                        }
                    }
                }
            }
        }
    }

    private int spotsOrFar(int[] d, int[] cell) {
        int v = g.toSpots(d, cell[0], cell[1]);
        return v < 0 ? 9999 : v;
    }

    private List<int[]> route(List<int[]> from, int[] to) {
        int[] prev = new int[n * n];
        Arrays.fill(prev, -2);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        for (int[] f : from) {
            prev[g.idx(f[0], f[1])] = -1;
            q.add(g.idx(f[0], f[1]));
        }
        int hit = -1;
        while (!q.isEmpty() && hit < 0) {
            int i = q.poll();
            int x = i % n;
            int y = i / n;
            if (Math.abs(x - to[0]) + Math.abs(y - to[1]) <= 1) {
                hit = i;
                break;
            }
            for (int[] d : Cells.DIRS) {
                int nx = x + d[0];
                int ny = y + d[1];
                if (g.walk(nx, ny, false) && prev[g.idx(nx, ny)] == -2) {
                    prev[g.idx(nx, ny)] = i;
                    q.add(g.idx(nx, ny));
                }
            }
        }
        List<int[]> outPath = new ArrayList<>();
        for (int i = hit; i >= 0; i = prev[i]) {
            outPath.add(0, new int[] {i % n, i / n});
        }
        return outPath;
    }

    /** Камни в 1–2 клетки — в пол; отрезанный пол — залить или соединить. */
    private void cleanup() {
        for (int pass = 0; pass < 3; pass++) {
            List<Integer> sizes = new ArrayList<>();
            int[] comp = g.components(i -> g.a[i] == Cells.ROCK, true, sizes);
            boolean any = false;
            for (int i = 0; i < comp.length; i++) {
                if (comp[i] >= 0 && sizes.get(comp[i]) <= 2 && !lock[i]) {
                    put(i % n, i / n, Cells.FLOOR);
                    any = true;
                }
            }
            connect();
            if (!any) {
                break;
            }
        }
    }

    // ---- итог ----

    private WorldPlan finish() {
        int[][] number = new int[k][4];
        int bots = seats - asked;
        List<Integer> quarters = new ArrayList<>(List.of(0, 1, 2, 3));
        int botNo = asked;
        for (int b = 0; b < bots; b++) {
            int t = quarters.remove(r.nextInt(quarters.size()));
            number[r.nextInt(k)][t] = ++botNo;
        }
        int no = 0;
        for (int t = 0; t < 4; t++) {
            for (int i = 0; i < k; i++) {
                if (number[i][t] == 0) {
                    number[i][t] = ++no;
                }
            }
        }
        WorldPlan.Seat[] bySeat = new WorldPlan.Seat[seats];
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                int[] b = copy(i, t);
                int[] h = rot(home[i][0], home[i][1], t);
                int[] a = rot(fork[i][0] + fork[i][4], fork[i][1] + fork[i][5], t);
                int[] p = rot(pocket[i][0], pocket[i][1], t);
                int s = number[i][t];
                bySeat[s - 1] = new WorldPlan.Seat(s, t, i, new Pos(b[0], b[1]), new Pos(h[0], h[1]),
                        new Pos(a[0], a[1]), new Pos(p[0], p[1]));
            }
        }
        List<WorldPlan.Seat> seatList = List.of(bySeat);
        for (WorldPlan.Seat s : seatList) {
            g.set(s.base().x(), s.base().y(), GameMap.BASE_MARKS.charAt(s.seat() - 1));
        }
        WorldPlan.Report report = check(seatList);
        Names names = new Names(r);
        List<GameMap.Region> regions = new ArrayList<>();
        regions.add(new GameMap.Region("Сердце", c, Math.min(n - 2, c + 9)));
        List<WorldPlan.Pass> shared = new ArrayList<>();
        for (int[] m : mines) {
            for (int t = 0; t < 4; t++) {
                int[] q = rot(m[0], m[1], t);
                List<Integer> owners = List.of(number[m[2]][t], number[m[3]][(m[4] + t) & 3]);
                shared.add(new WorldPlan.Pass(List.of(new Pos(q[0], q[1])), owners, null));
            }
        }
        for (int[] s : sites) {
            for (int t = 0; t < 4; t++) {
                String nm = names.name(Names.MINE, -1);
                List<Pos> deps = new ArrayList<>();
                for (int[] d : siteDeposits(s)) {
                    int[] q = rot(d[0], d[1], t);
                    deps.add(new Pos(q[0], q[1]));
                }
                // подпись — снаружи от площадки, на поляне
                int[] lab = rot(s[0] - 9 * s[2], s[1] - 9 * s[3], t);
                regions.add(new GameMap.Region(nm, Math.max(1, Math.min(n - 2, lab[0])),
                        Math.max(1, Math.min(n - 2, lab[1]))));
                shared.add(new WorldPlan.Pass(List.copyOf(deps), List.of(), nm));
            }
        }
        Map<DepositKind, Integer> amounts = new EnumMap<>(DepositKind.class);
        amounts.put(DepositKind.NORMAL, WorldGen.NORMAL);
        amounts.put(DepositKind.RICH, WorldGen.RICH);
        amounts.put(DepositKind.CENTER, WorldGen.CENTER);
        GameMap map = GameMap.of("arena-" + seats + "-" + seed, seats, g.rows(), amounts, regions);
        return new WorldPlan(map, arch, asked, List.of(), seatList, List.copyOf(shared), new Pos(c, c), null,
                report, 1, 0);
    }

    /**
     * Проверки. Жёсткие: нет мелочи, всё связно, у жил (кроме сердца) нет мест, куда без кирки не дойти; карман —
     * одно место в 3–5 шагах, развилка — 5–9; два общих прииска, обход длиннее двери хотя бы на
     * {@link #DOOR_GAIN_MIN}. Между классами: развилка и карман ±1, прииски ±2, дикий прииск и сердце ±3.
     */
    private WorldPlan.Report check(List<WorldPlan.Seat> seatList) {
        List<String> fail = new ArrayList<>();
        List<Integer> sizes = new ArrayList<>();
        g.components(i -> g.a[i] == Cells.ROCK, true, sizes);
        long crumbs = sizes.stream().filter(s -> s <= 2).count();
        if (crumbs > 0) {
            fail.add("скал из 1–2 клеток: " + crumbs);
        }
        List<int[]> all = allOut();
        List<int[]> withNiche = new ArrayList<>();
        for (WorldPlan.Seat st : seatList) {
            withNiche.addAll(g.spots(st.base().x(), st.base().y()));
        }
        int[] open = g.dist(withNiche, true, 0);
        int[] closed = g.dist(all, false, 0);
        int lost = 0;
        int hidden = 0;
        for (int i = 0; i < g.a.length; i++) {
            if ((Cells.walk(g.a[i]) || g.a[i] == Cells.RUBBLE) && open[i] < 0) {
                lost++;
            }
            char ch = g.a[i];
            if (Cells.deposit(ch) && ch != 'H' && ch != 'C') {
                for (int[] sp : g.spots(i % n, i / n)) {
                    if (closed[g.idx(sp[0], sp[1])] < 0) {
                        hidden++;
                    }
                }
            }
        }
        if (lost > 0) {
            fail.add("недостижимых клеток: " + lost);
        }
        if (hidden > 0) {
            fail.add("мест у жил за завалом без обхода: " + hidden);
        }
        List<int[]> mineCells = new ArrayList<>();
        for (int[] m : mines) {
            for (int t = 0; t < 4; t++) {
                mineCells.add(rot(m[0], m[1], t));
            }
        }
        int[][] per = new int[k][];
        WorldPlan.Paths[] paths = new WorldPlan.Paths[seats];
        double gainSum = 0;
        int gainN = 0;
        for (int i = 0; i < k; i++) {
            int[] b = copy(i, 0);
            int[] dc = g.dist(out(b), false, 0);
            int[] dd = g.dist(out(b), true, 0);
            int n1 = g.toSpots(dc, fork[i][0] + fork[i][4], fork[i][1] + fork[i][5]);
            int n2 = g.toSpots(dc, pocket[i][0], pocket[i][1]);
            int heartD = heartDist(dd);
            int[][] m = new int[mineCells.size()][];
            for (int j = 0; j < m.length; j++) {
                int[] mc = mineCells.get(j);
                m[j] = new int[] {g.toSpots(dd, mc[0], mc[1]), g.toSpots(dc, mc[0], mc[1])};
            }
            Arrays.sort(m, (p, q) -> Integer.compare(p[0] < 0 ? 9999 : p[0], q[0] < 0 ? 9999 : q[0]));
            int wild = wildDist(dc);
            int rich = richAccess(g.dist(out(b), true, RUBBLE_COST));
            int[] near = nearSpots(b, g.dist(out(b), true, RUBBLE_COST));
            String who = "класс " + (i + 1) + ": ";
            if (Math.abs(n1 - FORK_STEPS) > 1) {
                fail.add(who + "развилка в " + n1 + " шагах");
            }
            if (Math.abs(n2 - POCKET_STEPS) > 1) {
                fail.add(who + "карман в " + n2 + " шагах");
            }
            if (m.length < MINES_PER_SEAT || heartD < 0 || wild < 0) {
                fail.add(who + "приисков " + m.length + ", сердце " + heartD + ", дикий " + wild);
                per[i] = new int[] {n1, n2, -1, -1, heartD, wild, -1, -1, rich, near[0], near[1]};
                continue;
            }
            // дверь короче обхода: у каждого прииска хотя бы на 4 (у прииска в углу ромба базы подходят сбоку), у
            // одного из двух — хотя бы на DOOR_GAIN_MIN
            int bestGain = 0;
            for (int j = 0; j < MINES_PER_SEAT; j++) {
                int gain = m[j][1] - m[j][0];
                if (m[j][0] < 0 || m[j][1] < 0 || gain < 4) {
                    fail.add(who + "прииск " + (j + 1) + ": дверь " + m[j][0] + ", обход " + m[j][1]);
                } else {
                    bestGain = Math.max(bestGain, gain);
                    gainSum += gain;
                    gainN++;
                }
            }
            if (bestGain < DOOR_GAIN_MIN) {
                fail.add(who + "дверь короче обхода только на " + bestGain);
            }
            per[i] = new int[] {n1, n2, m[0][0], m[1][0], heartD, wild, m[0][1], m[1][1], rich, near[0], near[1]};
        }
        List<int[]> digFrom = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                digFrom.add(g.dist(out(copy(i, t)), true, 0));
            }
        }
        for (int[] mc : mineCells) {
            List<Integer> ds = new ArrayList<>();
            for (int[] dd : digFrom) {
                ds.add(g.toSpots(dd, mc[0], mc[1]));
            }
            ds.removeIf(v -> v < 0);
            ds.sort(null);
            if (ds.size() >= 2 && ds.get(1) - ds.get(0) > 2) {
                fail.add("прииск (" + mc[0] + ", " + mc[1] + "): хозяевам " + ds.get(0) + " и " + ds.get(1));
                break;
            }
        }
        int[] tol = {2, 2, 2, 2, 3, 3};
        String[] what = {"развилка", "карман", "первый прииск", "второй прииск", "сердце", "дикий прииск"};
        double spreadSum = 0;
        for (int f = 0; f < tol.length; f++) {
            int lo = Integer.MAX_VALUE;
            int hi = Integer.MIN_VALUE;
            for (int[] p : per) {
                lo = Math.min(lo, p[f]);
                hi = Math.max(hi, p[f]);
            }
            if (hi - lo > tol[f]) {
                fail.add(what[f] + ": между классами " + lo + "–" + hi);
            }
            spreadSum += (double) (hi - lo) / tol[f];
        }
        // доступ к богатым жилам: сумма путей до RICH_SPOTS ближайших мест у богатых жил — между классами не больше
        // ±10 % от среднего (замер ботами ArenaEcon: доход мест расходится в основном на богатых жилах)
        double richMean = Arrays.stream(per).mapToInt(p -> p[8]).average().orElse(0);
        int richLo = Arrays.stream(per).mapToInt(p -> p[8]).min().orElse(0);
        int richHi = Arrays.stream(per).mapToInt(p -> p[8]).max().orElse(0);
        if (richMean <= 0 || richHi - richLo > 0.2 * richMean) {
            fail.add("путь к богатым жилам: между классами " + richLo + "–" + richHi);
        }
        spreadSum += richMean <= 0 ? 10 : (richHi - richLo) / (0.2 * richMean);
        // простой код (эталон шага 5): рабочих — на ближайшие по прямой места, склад — если место дальше 8. У всех
        // мест одинаково таких дальних среди 12 ближайших, а доход с них — в пределах ±5 %
        int farLo = Arrays.stream(per).mapToInt(p -> p[10]).min().orElse(0);
        int farHi = Arrays.stream(per).mapToInt(p -> p[10]).max().orElse(0);
        double nearMean = Arrays.stream(per).mapToInt(p -> p[9]).average().orElse(0);
        int nearLo = Arrays.stream(per).mapToInt(p -> p[9]).min().orElse(0);
        int nearHi = Arrays.stream(per).mapToInt(p -> p[9]).max().orElse(0);
        if (farLo != farHi || nearHi - nearLo > 0.1 * nearMean) {
            fail.add("12 ближайших мест у жил: доход " + nearLo + "–" + nearHi + ", дальше 8 — " + farLo + "–"
                    + farHi);
        }
        spreadSum += (farHi - farLo) + (nearMean <= 0 ? 10 : (nearHi - nearLo) / (0.1 * nearMean));
        for (WorldPlan.Seat s : seatList) {
            int[] p = per[s.sector()];
            paths[s.seat() - 1] = new WorldPlan.Paths(s.seat(), p[0], p[1], p[2], p[6], p[5], p[4], true);
        }
        Map<String, Double> parts = new LinkedHashMap<>();
        parts.put("fair", -spreadSum);
        parts.put("door", gainN == 0 ? 0 : Math.min(12, gainSum / gainN) / 6);
        int rock = 0;
        for (char ch : g.a) {
            if (ch == Cells.ROCK) {
                rock++;
            }
        }
        parts.put("rock", (double) rock / g.a.length);
        double score = parts.get("fair") + parts.get("door");
        return new WorldPlan.Report(fail, List.of(paths), score, parts);
    }

    /** Цена клетки завала в пути: шаг и удары (прочность завала на арене — 10). */
    static final int RUBBLE_COST = 10;
    /** Сколько ближайших мест у богатых жил считать в доступе: столько рабочих у колонии. */
    static final int RICH_SPOTS = 12;

    /**
     * 12 ближайших к базе {@code b} по прямой ({@code |dx| + |dy|}) мест у жил, которые можно добывать (обычных,
     * богатых, своей домашней) — их и берёт простой код: {доход простой колонии с них за 100 тактов, сколько из них
     * дальше 8 по прямой}. Доход — по правилам арены (обычная 2 за такт, богатая 3, кирка и сумка у всех): груз 40 /
     * (добыча + путь по {@code d} туда и обратно + сдача); путь до своей домашней — 0.
     */
    private int[] nearSpots(int[] b, int[] d) {
        List<int[]> ds = new ArrayList<>();
        for (int i = 0; i < g.a.length; i++) {
            char ch = g.a[i];
            int x = i % n;
            int y = i / n;
            boolean ownHome = ch == 'H' && Math.max(Math.abs(x - b[0]), Math.abs(y - b[1])) <= 1;
            if (ch != '*' && ch != '$' && !ownHome) {
                continue;
            }
            for (int[] sp : g.spots(x, y)) {
                int path = ownHome ? 0 : d[g.idx(sp[0], sp[1])];
                ds.add(new int[] {Math.abs(sp[0] - b[0]) + Math.abs(sp[1] - b[1]), path < 0 ? 999 : path,
                        ch == '$' ? 3 : 2});
            }
        }
        ds.sort((p, q) -> p[0] != q[0] ? Integer.compare(p[0], q[0]) : Integer.compare(p[1], q[1]));
        double income = 0;
        int far = 0;
        for (int j = 0; j < Math.min(12, ds.size()); j++) {
            int rate = 2 * ds.get(j)[2];
            income += 40.0 / ((40 + rate - 1) / rate + 2 * ds.get(j)[1] + 1);
            far += ds.get(j)[0] > 8 ? 1 : 0;
        }
        return new int[] {(int) Math.round(income * 100), far};
    }

    /** Сумма путей до {@link #RICH_SPOTS} ближайших мест у богатых жил ({@code -1} в {@code d} — не дойти). */
    private int richAccess(int[] d) {
        List<Integer> best = new ArrayList<>();
        for (int i = 0; i < g.a.length; i++) {
            if (g.a[i] != '$') {
                continue;
            }
            for (int[] sp : g.spots(i % n, i / n)) {
                int v = d[g.idx(sp[0], sp[1])];
                if (v >= 0) {
                    best.add(v);
                }
            }
        }
        best.sort(null);
        int sum = 0;
        for (int j = 0; j < Math.min(RICH_SPOTS, best.size()); j++) {
            sum += best.get(j);
        }
        return best.size() < RICH_SPOTS ? sum + 999 * (RICH_SPOTS - best.size()) : sum;
    }

    /** До клетки вплотную к жиле сердца (она засыпана: путь — с разобранными завалами). */
    private int heartDist(int[] dd) {
        int best = -1;
        for (int[] d : Cells.DIRS) {
            int v = dd[g.idx(c + d[0], c - 2 + d[1])];
            if (v >= 0 && (best < 0 || v < best)) {
                best = v;
            }
        }
        return best;
    }

    private <T> void shuffle(List<T> list) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            T t = list.get(i);
            list.set(i, list.get(j));
            list.set(j, t);
        }
    }
}
