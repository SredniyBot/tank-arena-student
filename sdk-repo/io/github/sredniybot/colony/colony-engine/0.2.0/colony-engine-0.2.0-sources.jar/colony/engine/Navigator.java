package colony.engine;

import colony.api.Direction;
import colony.api.Pos;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Поиск пути для встроенных ботов: карта расстояний поиском в ширину до цели по проходимым клеткам.
 * Стены, базы и залежи (в том числе трофеи) путь закрывают, юниты — нет. Цель может быть закрытой клеткой
 * (залежь, база): тогда путь ведёт к соседней клетке, и последний шаг — «смотреть на цель».
 * Карты расстояний кэшируются по клетке цели; когда в мире появляется или исчезает база или залежь, кэш
 * сбрасывается.
 */
public final class Navigator {

    private static final int CACHE = 512;

    private final int width;
    private final int height;
    private final Supplier<PassGrid> source;
    private int version = Integer.MIN_VALUE;
    private boolean[] blocked;
    private final Map<Integer, int[]> cache = new LinkedHashMap<>(64, 0.75f, true) {
        @Override
        protected boolean removeEldestEntry(Map.Entry<Integer, int[]> eldest) {
            return size() > CACHE;
        }
    };

    /** Навигатор по неизменной карте. */
    Navigator(GameMap map) {
        this(map, constant(PassGrid.of(map)));
    }

    /** Навигатор по миру матча: закрытые клетки берёт из {@code source} на каждый запрос. */
    Navigator(GameMap map, Supplier<PassGrid> source) {
        this.width = map.width();
        this.height = map.height();
        this.source = source;
    }

    private static Supplier<PassGrid> constant(PassGrid g) {
        return () -> g;
    }

    /**
     * Шагов от {@code from} до {@code to}; для закрытой цели — до соседней клетки плюс один.
     * {@code 0} — уже на месте, {@code -1} — недостижимо.
     */
    public synchronized int distance(Pos from, Pos to) {
        if (!inside(from) || !inside(to)) {
            return -1;
        }
        return field(to)[index(from)];
    }

    /**
     * Первый шаг кратчайшего пути. Если {@code from} рядом с {@code to} — направление на цель (для добычи и передачи).
     * Пусто, если уже на месте или пути нет. При равенстве — порядок N, E, S, W.
     */
    public synchronized Optional<Direction> next(Pos from, Pos to) {
        int d = distance(from, to);
        if (d <= 0) {
            return Optional.empty();
        }
        int[] f = field(to);
        for (Direction dir : Direction.values()) {
            Pos n = from.step(dir);
            if (!inside(n)) {
                continue;
            }
            if (n.equals(to) || (!blocked[index(n)] && f[index(n)] == d - 1)) {
                return Optional.of(dir);
            }
        }
        return Optional.empty();
    }

    /** Копия карты расстояний до {@code to}: индекс {@code y * width + x}, {@code -1} — недостижимо. */
    public synchronized int[] distanceMap(Pos to) {
        return field(to).clone();
    }

    /** Клетку можно занять: внутри карты, не стена, не база, не залежь. */
    public synchronized boolean passable(Pos p) {
        refresh();
        return inside(p) && !blocked[index(p)];
    }

    private boolean inside(Pos p) {
        return p.x() >= 0 && p.y() >= 0 && p.x() < width && p.y() < height;
    }

    private int index(Pos p) {
        return p.y() * width + p.x();
    }

    private void refresh() {
        PassGrid g = source.get();
        if (g.version() != version) {
            version = g.version();
            blocked = g.blocked();
            cache.clear();
        }
    }

    private int[] field(Pos to) {
        refresh();
        return cache.computeIfAbsent(index(to), k -> bfs(to));
    }

    private int[] bfs(Pos to) {
        return bfs(blocked, width, height, new int[] {index(to)});
    }

    /** Расстояния от ближайшего из {@code sources} по незакрытым клеткам; сами источники могут быть закрыты. */
    static int[] bfs(boolean[] blocked, int width, int height, int[] sources) {
        int n = width * height;
        int[] dist = new int[n];
        Arrays.fill(dist, -1);
        int[] queue = new int[n];
        int head = 0;
        int tail = 0;
        for (int s : sources) {
            if (dist[s] < 0) {
                dist[s] = 0;
                queue[tail++] = s;
            }
        }
        while (head < tail) {
            int c = queue[head++];
            int x = c % width;
            int y = c / width;
            int d = dist[c] + 1;
            if (y > 0 && !blocked[c - width] && dist[c - width] < 0) {
                dist[c - width] = d;
                queue[tail++] = c - width;
            }
            if (x < width - 1 && !blocked[c + 1] && dist[c + 1] < 0) {
                dist[c + 1] = d;
                queue[tail++] = c + 1;
            }
            if (y < height - 1 && !blocked[c + width] && dist[c + width] < 0) {
                dist[c + width] = d;
                queue[tail++] = c + width;
            }
            if (x > 0 && !blocked[c - 1] && dist[c - 1] < 0) {
                dist[c - 1] = d;
                queue[tail++] = c - 1;
            }
        }
        return dist;
    }
}
