package colony.engine;

import colony.api.Pos;
import colony.api.UnitType;
import java.util.List;
import java.util.Objects;

/**
 * Параметры матча.
 *
 * @param rules             правила
 * @param map               карта; мест на ней не меньше, чем колоний в матче
 * @param seed              зерно случайности движка
 * @param maxTicks          длина матча в тактах
 * @param tickTimeoutMillis сколько миллисекунд у колонии на такт; обычно {@code rules.tickTimeoutMillis()}
 * @param respawn           мир на занятие: погибшая колония через {@code respawnTicks} возвращается со стартовым
 *                          набором на своё место и {@code respawnProtectTicks} тактов под защитой новичка
 * @param units             дополнительные юниты в начале — для сценариев боя и тестов
 * @param script            события сценария карты (шаг «Устойчивость» ДЗ); обычно пусто
 */
public record MatchConfig(RuleSet rules, GameMap map, long seed, int maxTicks, int tickTimeoutMillis, boolean respawn,
                          List<StartUnit> units, List<ScriptEvent> script) {

    /**
     * Юнит, который стоит на карте с начала матча.
     *
     * @param colonyId колония; {@code 0} — налётчик
     */
    public record StartUnit(int colonyId, UnitType type, Pos pos) {
        public StartUnit {
            Objects.requireNonNull(type, "type");
            Objects.requireNonNull(pos, "pos");
        }
    }

    public MatchConfig {
        Objects.requireNonNull(rules, "rules");
        Objects.requireNonNull(map, "map");
        if (maxTicks < 1) {
            throw new IllegalArgumentException("длина матча должна быть больше нуля, а не " + maxTicks);
        }
        if (tickTimeoutMillis < 1) {
            throw new IllegalArgumentException("время на такт должно быть больше нуля, а не " + tickTimeoutMillis);
        }
        units = List.copyOf(units);
        script = script == null ? List.of() : List.copyOf(script);
    }

    public MatchConfig(RuleSet rules, GameMap map, long seed, int maxTicks, int tickTimeoutMillis, boolean respawn,
                       List<StartUnit> units) {
        this(rules, map, seed, maxTicks, tickTimeoutMillis, respawn, units, List.of());
    }

    public MatchConfig(RuleSet rules, GameMap map, long seed, int maxTicks, int tickTimeoutMillis) {
        this(rules, map, seed, maxTicks, tickTimeoutMillis, false, List.of());
    }

    /** Время на такт — из правил. */
    public MatchConfig(RuleSet rules, GameMap map, long seed, int maxTicks) {
        this(rules, map, seed, maxTicks, rules.tickTimeoutMillis());
    }

    /** Длина матча и время на такт — из правил. */
    public static MatchConfig of(RuleSet rules, GameMap map, long seed) {
        return new MatchConfig(rules, map, seed, rules.maxTicks());
    }

    public MatchConfig withTickTimeoutMillis(int millis) {
        return new MatchConfig(rules, map, seed, maxTicks, millis, respawn, units, script);
    }

    public MatchConfig withMaxTicks(int ticks) {
        return new MatchConfig(rules, map, seed, ticks, tickTimeoutMillis, respawn, units, script);
    }

    public MatchConfig withRespawn(boolean on) {
        return new MatchConfig(rules, map, seed, maxTicks, tickTimeoutMillis, on, units, script);
    }

    public MatchConfig withUnits(List<StartUnit> start) {
        return new MatchConfig(rules, map, seed, maxTicks, tickTimeoutMillis, respawn, start, script);
    }

    public MatchConfig withScript(List<ScriptEvent> events) {
        return new MatchConfig(rules, map, seed, maxTicks, tickTimeoutMillis, respawn, units, events);
    }
}
