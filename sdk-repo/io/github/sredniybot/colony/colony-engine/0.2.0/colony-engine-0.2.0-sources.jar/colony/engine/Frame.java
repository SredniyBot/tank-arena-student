package colony.engine;

import colony.api.Base;
import colony.api.Deposit;
import colony.api.EventKind;
import colony.api.Pos;
import colony.api.Rejection;
import colony.api.Structure;
import colony.api.Unit;
import colony.api.Upgrade;
import colony.api.UnitType;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;

/**
 * Кадр повтора: полное состояние мира после такта {@code t} (кадр 0 — начало матча), всё видно.
 * Неизменяемый; в JSON — {@link #toJson(boolean)} в формате {@code colony-replay} v1.
 *
 * @param t            номер такта
 * @param colonies     колонии по id
 * @param bases        базы по id
 * @param units        юниты по id
 * @param deposits     залежи по id; запас настоящий, у домашней {@code -1}
 * @param shots        выстрелы такта (шаг 2б): путь снаряда за такт, у выстрела базы — от базы до клетки цели
 * @param events       события такта
 * @param rejections   отказы такта: id колонии → отказы; только колонии с отказами
 * @param decideMillis сколько миллисекунд думала каждая колония
 * @param numbers      номер в колонии у юнитов и баз: внутренний номер → «рабочий 5»; в повторе — поле {@code n}
 * @param centerHolder кто держит центр после такта: номер колонии, {@code 0} — никто
 * @param closed       клетки, закрытые сценарием карты (обвал) к концу такта; в повторе — поле {@code closed}
 * @param rubble       клетки, где в начале матча был завал, с остатком прочности ({@code 0} — разобран); в повторе —
 *                     поле {@code rubble}: {@code [[x, y, left], …]}, только на картах с завалами
 * @param structures   постройки (склады); в повторе — поле {@code structures}, только если они есть
 * @param paths        пометки пути колоний ({@link colony.api.Orders#mark}): внутренний номер юнита → клетки; в повторе
 *                     — поле {@code paths}, только если они есть
 */
public record Frame(
        int t,
        List<ColonyState> colonies,
        List<Base> bases,
        List<Unit> units,
        List<Deposit> deposits,
        List<Shot> shots,
        List<Event> events,
        Map<Integer, List<Rejection>> rejections,
        Map<Integer, Long> decideMillis,
        Map<Integer, Integer> numbers,
        int centerHolder,
        List<Pos> closed,
        List<Rubble> rubble,
        List<Structure> structures,
        Map<Integer, List<Pos>> paths) {

    /** Завал в кадре: клетка и сколько ударов осталось; {@code 0} — разобран, клетка — пол. */
    public record Rubble(Pos pos, int left) {}

    /** Колония в кадре. {@code units} — число её юнитов. */
    public record ColonyState(int id, int energy, int score, boolean alive, int centerTicks, int units) {}

    /**
     * Выстрел или удар: кто ({@code 0} — налётчики), откуда, куда за этот такт, в кого попал ({@code 0} — ещё летит
     * или мимо).
     *
     * @param kind {@code shell} — снаряд (2б), {@code base} — выстрел базы, {@code strike} — удар танка по прямой,
     *             {@code melee} — удар рабочего вплотную
     */
    public record Shot(int colonyId, Pos from, Pos to, int hit, String kind) {
        public static final String SHELL = "shell";
        public static final String BASE = "base";
        public static final String STRIKE = "strike";
        public static final String MELEE = "melee";

        /** Снаряд. */
        public Shot(int colonyId, Pos from, Pos to, int hit) {
            this(colonyId, from, to, hit, SHELL);
        }
    }

    /**
     * Событие такта.
     *
     * @param tick     такт, в котором событие случилось ({@code view.tick()} того такта); лежит в кадре {@code tick + 1}
     * @param colonyId колония; {@code 0} — объявление для всех
     * @param message  текст для колонии-хозяина: «новый рабочий 5»
     * @param text     текст для всех, с именем колонии: «Вы: новый рабочий 5»
     * @param pos      клетка; может быть {@code null}
     */
    public record Event(int tick, int colonyId, EventKind kind, String message, String text, Pos pos) {}

    public Frame {
        colonies = List.copyOf(colonies);
        bases = List.copyOf(bases);
        units = List.copyOf(units);
        deposits = List.copyOf(deposits);
        shots = List.copyOf(shots);
        events = List.copyOf(events);
        TreeMap<Integer, List<Rejection>> r = new TreeMap<>();
        rejections.forEach((k, v) -> r.put(k, List.copyOf(v)));
        rejections = Collections.unmodifiableMap(r);
        decideMillis = Collections.unmodifiableMap(new TreeMap<>(decideMillis));
        numbers = Collections.unmodifiableMap(new TreeMap<>(numbers));
        closed = closed == null ? List.of() : List.copyOf(closed);
        rubble = rubble == null ? List.of() : List.copyOf(rubble);
        structures = structures == null ? List.of() : List.copyOf(structures);
        paths = paths == null ? Map.of() : Collections.unmodifiableMap(new TreeMap<>(paths));
    }

    /** Кадр без пометок пути. */
    public Frame(int t, List<ColonyState> colonies, List<Base> bases, List<Unit> units, List<Deposit> deposits,
                 List<Shot> shots, List<Event> events, Map<Integer, List<Rejection>> rejections,
                 Map<Integer, Long> decideMillis, Map<Integer, Integer> numbers, int centerHolder, List<Pos> closed,
                 List<Rubble> rubble, List<Structure> structures) {
        this(t, colonies, bases, units, deposits, shots, events, rejections, decideMillis, numbers, centerHolder,
                closed, rubble, structures, Map.of());
    }

    /** Кадр без завалов и построек — как до ДЗ «лестница возможностей». */
    public Frame(int t, List<ColonyState> colonies, List<Base> bases, List<Unit> units, List<Deposit> deposits,
                 List<Shot> shots, List<Event> events, Map<Integer, List<Rejection>> rejections,
                 Map<Integer, Long> decideMillis, Map<Integer, Integer> numbers, int centerHolder, List<Pos> closed) {
        this(t, colonies, bases, units, deposits, shots, events, rejections, decideMillis, numbers, centerHolder,
                closed, List.of(), List.of(), Map.of());
    }

    /** Кадр без закрытых сценарием клеток — как до шагов ДЗ. */
    public Frame(int t, List<ColonyState> colonies, List<Base> bases, List<Unit> units, List<Deposit> deposits,
                 List<Shot> shots, List<Event> events, Map<Integer, List<Rejection>> rejections,
                 Map<Integer, Long> decideMillis, Map<Integer, Integer> numbers, int centerHolder) {
        this(t, colonies, bases, units, deposits, shots, events, rejections, decideMillis, numbers, centerHolder,
                List.of());
    }

    /** Кадр без номеров в колонии и без центра — как до лиг. */
    public Frame(int t, List<ColonyState> colonies, List<Base> bases, List<Unit> units, List<Deposit> deposits,
                 List<Shot> shots, List<Event> events, Map<Integer, List<Rejection>> rejections,
                 Map<Integer, Long> decideMillis) {
        this(t, colonies, bases, units, deposits, shots, events, rejections, decideMillis, Map.of(), 0);
    }

    /** Номер юнита или базы в колонии ({@code рабочий 5}) по внутреннему номеру; нет в кадре — {@code 0}. */
    public int number(int id) {
        return numbers.getOrDefault(id, 0);
    }

    /** Колония по id. */
    public ColonyState colony(int id) {
        return colonies.stream().filter(c -> c.id() == id).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("нет колонии " + id));
    }

    /** Юнит по id, если жив. */
    public Optional<Unit> unit(int id) {
        return units.stream().filter(u -> u.id() == id).findFirst();
    }

    /** Кадр в JSON формата {@code colony-replay} v1. */
    public ObjectNode toJson(boolean includeTimings) {
        JsonNodeFactory f = JsonNodeFactory.instance;
        ObjectNode o = f.objectNode();
        o.put("t", t);
        ArrayNode cs = o.putArray("colonies");
        for (ColonyState c : colonies) {
            cs.addObject().put("id", c.id()).put("energy", c.energy()).put("score", c.score()).put("alive", c.alive())
                    .put("centerTicks", c.centerTicks()).put("units", c.units());
        }
        ArrayNode bs = o.putArray("bases");
        for (Base b : bases) {
            bs.addObject().put("id", b.id()).put("n", numbers.getOrDefault(b.id(), b.id())).put("c", b.colonyId()).put("x", b.pos().x())
                    .put("y", b.pos().y()).put("hp", b.hp());
        }
        ArrayNode us = o.putArray("units");
        for (Unit u : units) {
            ObjectNode un = us.addObject().put("id", u.id()).put("n", numbers.getOrDefault(u.id(), u.id()))
                    .put("c", u.colonyId())
                    .put("k", u.colonyId() == 0 ? "R" : u.type() == UnitType.TANK ? "T" : "W")
                    .put("x", u.pos().x()).put("y", u.pos().y()).put("hp", u.hp()).put("carry", u.carry());
            if (!u.upgrades().isEmpty()) {
                ArrayNode up = un.putArray("up");
                for (Upgrade g : u.upgrades()) {
                    up.add(g.name());
                }
            }
        }
        ArrayNode ds = o.putArray("deposits");
        for (Deposit d : deposits) {
            ds.addObject().put("id", d.id()).put("x", d.pos().x()).put("y", d.pos().y()).put("kind", d.kind().name())
                    .put("amount", d.amount());
        }
        ArrayNode ss = o.putArray("shots");
        for (Shot s : shots) {
            ss.addObject().put("c", s.colonyId()).put("fx", s.from().x()).put("fy", s.from().y())
                    .put("tx", s.to().x()).put("ty", s.to().y()).put("hit", s.hit()).put("kind", s.kind());
        }
        ArrayNode es = o.putArray("events");
        for (Event e : events) {
            ObjectNode n = es.addObject().put("kind", e.kind().name()).put("c", e.colonyId()).put("text", e.text());
            if (e.pos() != null) {
                n.put("x", e.pos().x()).put("y", e.pos().y());
            } else {
                n.putNull("x").putNull("y");
            }
        }
        if (centerHolder > 0) {
            o.put("holder", centerHolder);
        }
        if (!closed.isEmpty()) {
            ArrayNode cl = o.putArray("closed");
            for (Pos p : closed) {
                cl.addArray().add(p.x()).add(p.y());
            }
        }
        if (!rubble.isEmpty()) {
            ArrayNode rb = o.putArray("rubble");
            for (Rubble r : rubble) {
                rb.addArray().add(r.pos().x()).add(r.pos().y()).add(r.left());
            }
        }
        if (!paths.isEmpty()) {
            ObjectNode ps = o.putObject("paths");
            paths.forEach((id, cells) -> {
                ArrayNode a = ps.putArray(Integer.toString(id));
                for (Pos p : cells) {
                    a.addArray().add(p.x()).add(p.y());
                }
            });
        }
        if (!structures.isEmpty()) {
            ArrayNode st = o.putArray("structures");
            for (Structure x : structures) {
                st.addObject().put("n", x.id()).put("c", x.colonyId()).put("kind", x.type().name())
                        .put("x", x.pos().x()).put("y", x.pos().y());
            }
        }
        ObjectNode rs = o.putObject("rejections");
        rejections.forEach((c, list) -> {
            ArrayNode a = rs.putArray(Integer.toString(c));
            for (Rejection r : list) {
                a.addObject().put("unit", r.unitId()).put("code", r.code().name()).put("text", r.message());
            }
        });
        if (includeTimings) {
            ObjectNode ms = o.putObject("decideMillis");
            decideMillis.forEach((c, v) -> ms.put(Integer.toString(c), v));
        }
        return o;
    }
}
