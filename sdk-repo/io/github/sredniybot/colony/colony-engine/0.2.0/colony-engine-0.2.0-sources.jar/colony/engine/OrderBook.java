package colony.engine;

import colony.api.Building;
import colony.api.Direction;
import colony.api.Orders;
import colony.api.Pos;
import colony.api.UnitType;
import colony.api.Upgrade;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.TreeMap;

/**
 * Приказы колонии на один такт в порядке вызова. Проверяются движком после {@code onTick}.
 * Хранится не больше {@code limit} приказов, остальные только считаются. После {@link #close()} приказы
 * не принимаются: вызов бросает {@link IllegalStateException}. Блокировка — закрытая: код колонии,
 * который синхронизируется на объекте {@code Orders}, движок не задерживает.
 */
final class OrderBook implements Orders {

    enum Kind { MOVE, HARVEST, TRANSFER, PRODUCE, FIRE, BASE_FIRE, BUILD, ATTACK, CONSTRUCT, DIG, UPGRADE }

    /**
     * Приказ. {@code building} — у {@link Kind#CONSTRUCT}, {@code upgrade} — у {@link Kind#UPGRADE}, иначе
     * {@code null}.
     */
    record Order(Kind kind, int id, Direction dir, int amount, UnitType type, Pos target, Building building,
                 Upgrade upgrade) {

        Order(Kind kind, int id, Direction dir, int amount, UnitType type, Pos target) {
            this(kind, id, dir, amount, type, target, null, null);
        }
    }

    private final Object lock = new Object();
    private final int tick;
    private final int limit;
    private final List<Order> orders = new ArrayList<>();
    /** Пометки пути: номер юнита в колонии → клетки. */
    private final Map<Integer, List<Pos>> marks = new TreeMap<>();
    private int dropped;
    private boolean closed;

    OrderBook(int tick, int limit) {
        this.tick = tick;
        this.limit = limit;
    }

    private void add(Order o) {
        synchronized (lock) {
            if (closed) {
                throw new IllegalStateException(Messages.ordersClosed(tick));
            }
            if (orders.size() < limit) {
                orders.add(o);
            } else {
                dropped++;
            }
        }
    }

    /** Закрывает книгу и возвращает принятые приказы в порядке вызова. */
    List<Order> close() {
        synchronized (lock) {
            closed = true;
            return List.copyOf(orders);
        }
    }

    /** Пометки пути после закрытия: номер юнита в колонии → клетки. */
    Map<Integer, List<Pos>> marks() {
        synchronized (lock) {
            return Map.copyOf(marks);
        }
    }

    /** Сколько приказов сверх предела отброшено. */
    int dropped() {
        synchronized (lock) {
            return dropped;
        }
    }

    @Override
    public void move(int unitId, Direction d) {
        Objects.requireNonNull(d, Messages.nullDirection());
        add(new Order(Kind.MOVE, unitId, d, 0, null, null));
    }

    @Override
    public void harvest(int workerId, Direction d) {
        Objects.requireNonNull(d, Messages.nullDirection());
        add(new Order(Kind.HARVEST, workerId, d, 0, null, null));
    }

    @Override
    public void transfer(int unitId, Direction d, int amount) {
        Objects.requireNonNull(d, Messages.nullDirection());
        add(new Order(Kind.TRANSFER, unitId, d, amount, null, null));
    }

    @Override
    public void produce(int baseId, UnitType type) {
        Objects.requireNonNull(type, Messages.nullType());
        add(new Order(Kind.PRODUCE, baseId, null, 0, type, null));
    }

    @Override
    public void fire(int tankId, Direction d) {
        Objects.requireNonNull(d, Messages.nullDirection());
        add(new Order(Kind.FIRE, tankId, d, 0, null, null));
    }

    @Override
    public void baseFire(int baseId, Pos target) {
        Objects.requireNonNull(target, Messages.nullTarget());
        add(new Order(Kind.BASE_FIRE, baseId, null, 0, null, target));
    }

    @Override
    public void build(int workerId, Direction d) {
        Objects.requireNonNull(d, Messages.nullDirection());
        add(new Order(Kind.BUILD, workerId, d, 0, null, null));
    }

    @Override
    public void attack(int workerId, Direction d) {
        Objects.requireNonNull(d, Messages.nullDirection());
        add(new Order(Kind.ATTACK, workerId, d, 0, null, null));
    }

    @Override
    public void build(int workerId, Direction d, Building type) {
        Objects.requireNonNull(d, Messages.nullDirection());
        Objects.requireNonNull(type, "постройка не задана (null)");
        add(new Order(Kind.CONSTRUCT, workerId, d, 0, null, null, type, null));
    }

    @Override
    public void dig(int workerId, Direction d) {
        Objects.requireNonNull(d, Messages.nullDirection());
        add(new Order(Kind.DIG, workerId, d, 0, null, null));
    }

    @Override
    public void upgrade(int workerId, Upgrade upgrade) {
        Objects.requireNonNull(upgrade, "улучшение не задано (null)");
        add(new Order(Kind.UPGRADE, workerId, null, 0, null, null, null, upgrade));
    }

    @Override
    public void mark(int unitId, List<Pos> path) {
        if (path == null) {
            return;
        }
        List<Pos> cells = new ArrayList<>();
        for (Pos p : path) {
            if (p != null && cells.size() < 64) {
                cells.add(p);
            }
        }
        synchronized (lock) {
            if (closed) {
                throw new IllegalStateException(Messages.ordersClosed(tick));
            }
            marks.put(unitId, List.copyOf(cells));
        }
    }

    @Override
    public String toString() {
        return "Orders[такт " + tick + "]";
    }
}
