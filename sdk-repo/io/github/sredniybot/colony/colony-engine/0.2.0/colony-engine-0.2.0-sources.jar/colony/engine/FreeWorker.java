package colony.engine;

import colony.api.EventKind;
import colony.api.Pos;
import colony.api.UnitType;
import colony.engine.World.BaseEntity;
import colony.engine.World.ColonyState;
import colony.engine.World.UnitEntity;
import java.util.List;

/**
 * Флаг {@code freeWorker} (лиги 3+): колония в лигах не погибает, но без рабочих и без энергии на рабочего она бы
 * застряла до конца матча (танки не добывают). Такой колонии база выпускает рабочего бесплатно — на первую свободную клетку, как обычно.
 */
final class FreeWorker {

    private FreeWorker() {}

    static void apply(World w, TickLog log) {
        if (!w.rules.features().freeWorker()) {
            return;
        }
        int[] workers = new int[w.colonies.size() + 1];
        for (UnitEntity u : w.units.values()) {
            if (u.type == UnitType.WORKER) {
                workers[u.colonyId]++;
            }
        }
        List<UnitEntity>[] cells = null;
        for (ColonyState c : w.colonies) {
            if (!c.alive || workers[c.id] > 0 || c.energy >= w.rules.workerCost()) {
                continue;
            }
            if (cells == null) {
                cells = w.occupancy();
            }
            BaseEntity base = w.bases.values().stream().filter(b -> b.colonyId == c.id).findFirst().orElse(null);
            if (base == null) {
                continue;
            }
            for (Pos p : w.spawnOrder(base.pos)) {
                if (w.free(p) && cells[w.index(p)] == null) {
                    // ни один танк не добывает: без рабочих колония застряла бы
                    UnitEntity u = w.addUnit(c.id, UnitType.WORKER, p);
                    log.event(c.id, EventKind.PRODUCED, Messages.freeWorker(u.number), p);
                    break;
                }
            }
        }
    }
}
