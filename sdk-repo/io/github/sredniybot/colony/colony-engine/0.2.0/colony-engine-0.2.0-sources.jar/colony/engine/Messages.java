package colony.engine;

import colony.api.Building;
import colony.api.UnitType;
import colony.api.Upgrade;

/**
 * Все тексты отказов и событий — в одном месте. Короткие, по-русски, с номером юнита в начале:
 * «рабочий 7: залежь пуста». Номер — номер юнита в его колонии; внутренние номера движка в тексты не попадают.
 * Чужой юнит в отказе — без номера: «столкновение с чужим рабочим». Имена колоний — имена студентов, род у них
 * неизвестен, поэтому тексты обходятся без глаголов прошедшего времени при имени.
 */
final class Messages {

    private Messages() {}

    // ---- имена ----

    static String unit(UnitType type, int id) {
        return (type == UnitType.TANK ? "танк " : "рабочий ") + id;
    }

    /** «база» — первая база колонии (номер {@code 0}); «база 7» — построенная позже. */
    static String base(int id) {
        return id == 0 ? "база" : "база " + id;
    }

    /** «юнит 5», «юнит −3» (чужой — с настоящим минусом). */
    static String anyUnit(int id) {
        return "юнит " + (id < 0 ? "−" + (-id) : String.valueOf(id));
    }

    /** «с рабочим 5», «с танком 5»; номер {@code 0} — чужой: «с чужим рабочим». */
    private static String with(UnitType type, int id) {
        String name = type == UnitType.TANK ? "танком" : "рабочим";
        return id == 0 ? "чужим " + name : name + " " + id;
    }

    /** «у рабочего 5», «у танка 5»; номер {@code 0} — «у чужого рабочего». */
    private static String at(UnitType type, int id) {
        String name = type == UnitType.TANK ? "танка" : "рабочего";
        return id == 0 ? "чужого " + name : name + " " + id;
    }

    // ---- проверка приказа ----

    static String unknown(int id) {
        return anyUnit(id) + ": такого нет";
    }

    static String notYours(int id) {
        return anyUnit(id) + ": чужой";
    }

    static String duplicate(String who) {
        return who + ": второй приказ за такт, выполняется первый";
    }

    static String baseCannotMove(String who) {
        return who + ": база не ходит";
    }

    static String onlyWorkerHarvests(String who) {
        return who + ": добывает только рабочий";
    }

    static String baseCannotTransfer(String who) {
        return who + ": база не передаёт энергию";
    }

    static String onlyBaseProduces(String who) {
        return who + ": юнитов выпускает только база";
    }

    static String onlyTankFires(String who) {
        return who + ": стреляет только танк";
    }

    static String onlyBaseFiresAtCell(String who) {
        return who + ": по клетке стреляет только база";
    }

    static String onlyWorkerBuilds(String who) {
        return who + ": строит только рабочий";
    }

    // ---- откроется позже ----

    static String tanksLater(String who) {
        return who + ": танки пока недоступны";
    }

    static String fireLater(String who) {
        return who + ": стрельба пока недоступна";
    }

    static String baseFireLater(String who) {
        return who + ": выстрел базы пока недоступен";
    }

    static String buildLater(String who) {
        return who + ": вторая база пока недоступна";
    }

    static String foreignTransferLater(String who) {
        return who + ": передача чужим пока недоступна";
    }

    // ---- движение ----

    static String edge(String who) {
        return who + ": край карты";
    }

    static String wall(String who) {
        return who + ": впереди стена";
    }

    static String baseAhead(String who) {
        return who + ": там база";
    }

    static String depositAhead(String who) {
        return who + ": там залежь";
    }

    static String occupied(String who) {
        return who + ": клетка занята";
    }

    static String collision(String who, UnitType otherType, int otherId) {
        return who + ": столкновение с " + with(otherType, otherId);
    }

    static String swap(String who, UnitType otherType, int otherId) {
        return who + ": обмен местами с " + with(otherType, otherId) + " — столкновение";
    }

    // ---- производство ----

    static String notEnoughEnergy(String who, int need, int have) {
        return who + ": не хватает энергии (нужно " + need + ", есть " + have + ")";
    }

    static String spawnBlocked(String who) {
        return who + ": рядом нет свободной клетки, энергия не списана";
    }

    // ---- добыча и передача ----

    static String noDeposit(String who) {
        return who + ": там нет залежи";
    }

    static String foreignHome(String who) {
        return who + ": это домашняя залежь чужой колонии";
    }

    static String depositEmpty(String who) {
        return who + ": залежь пуста";
    }

    static String carryFull(String who, int carry) {
        return who + ": груз полон (" + carry + ")";
    }

    static String badAmount(String who, int amount) {
        return who + ": передать можно только больше нуля, а не " + amount;
    }

    static String emptyCarry(String who) {
        return who + ": груз пуст";
    }

    static String noReceiver(String who) {
        return who + ": там некому передать";
    }

    static String receiverFull(String who, UnitType type, int id) {
        return who + ": " + "у " + at(type, id) + " полон груз";
    }

    // ---- код колонии ----

    /**
     * Короткое описание исключения: «NullPointerException в MyColony.java:42 — направление не задано (null)». Из уже
     * снятых строк: объект исключения — код колонии, движок его методов не вызывает.
     */
    private static String describe(String type, String message, String where) {
        String text = type + (where == null ? "" : " в " + where);
        if (message != null && !message.isBlank() && message.length() <= 120 && message.lines().count() == 1) {
            text += " — " + message;
        }
        return text;
    }

    static String exception(String type, String message, String where) {
        return "код колонии упал: " + describe(type, message, where) + "; в этот такт колония стоит";
    }

    static String createFailed(String type, String message, String where) {
        return "код колонии не создался: " + describe(type, message, where) + "; колония стоит";
    }

    static String factoryReturnedNull() {
        return "фабрика колонии вернула null; колония стоит";
    }

    static String tooManyOrders(int accepted, int dropped) {
        return "слишком много приказов: принято " + accepted + ", отброшено " + dropped;
    }

    static String interrupted() {
        return "матч прерван";
    }

    static String closed() {
        return "матч закрыт";
    }

    static String createTimeout(long millis) {
        return "код колонии не создался за " + millis + " мс; колония стоит";
    }

    static String timeout(long millis) {
        return "код колонии не уложился в " + millis + " мс; в этот такт колония стоит";
    }

    static String stillRunning() {
        return "прошлый такт ещё считается; в этот такт колония стоит";
    }

    static String ordersClosed(int tick) {
        return "приказы такта " + tick + " уже приняты: Orders действует только внутри onTick";
    }

    static String nullDirection() {
        return "направление не задано (null)";
    }

    static String nullType() {
        return "тип юнита не задан (null)";
    }

    static String nullTarget() {
        return "клетка цели не задана (null)";
    }

    // ---- события ----

    static String produced(UnitType type, int id) {
        return "новый " + unit(type, id);
    }

    static String upkeepUnpaid(String who) {
        return who + ": нет энергии на содержание, −1 здоровья";
    }

    static String diedUpkeep(String who) {
        return who + " погиб: не хватило энергии на содержание";
    }

    static String died(String who) {
        return who + " погиб";
    }

    static String baseDestroyed(int id) {
        return base(id) + " разрушена";
    }

    static String colonyDied() {
        return "колония погибла";
    }

    static String truceEnded() {
        return "перемирие окончилось: чужие юниты больше не проходимы";
    }

    // ---- шаг 2б ----

    /** «1 такт», «2 такта», «5 тактов». */
    static String plural(int n, String one, String few, String many) {
        int m100 = Math.abs(n) % 100;
        int m10 = m100 % 10;
        String word = m100 >= 11 && m100 <= 14 ? many : m10 == 1 ? one : m10 >= 2 && m10 <= 4 ? few : many;
        return n + " " + word;
    }

    static String raider(int id) {
        return "налётчик " + id;
    }

    static String truceNoFire(String who) {
        return who + ": идёт перемирие, оружие не стреляет";
    }

    static String cooldown(String who, int left) {
        return who + ": перезарядка, ещё " + plural(left, "такт", "такта", "тактов");
    }

    static String offMap(String who) {
        return who + ": клетка за краем карты";
    }

    static String notAtSelf(String who) {
        return who + ": по своей клетке не стреляет";
    }

    static String outOfRange(String who, int range) {
        int m100 = range % 100;
        String cells = range % 10 == 1 && m100 != 11 ? " клетки" : " клеток";
        return who + ": цель дальше " + range + cells;
    }


    /** Для всех: кто кого ранил — «Вера ▸ Глеб: рабочий 4, −1 (осталось 2)»; гибель — отдельным событием. */
    static String struck(String attacker, String victim, String who, int damage, int left) {
        return attacker + " ▸ " + victim + ": " + who + ", −" + damage + (left > 0 ? " (осталось " + left + ")" : "");
    }

    /** Хозяину: «рабочий 3 ранен: −1, осталось 2»; добит — «рабочий 3 ранен: −1». */
    static String wounded(String who, int damage, int left) {
        return who + " ранен: −" + damage + (left > 0 ? ", осталось " + left : "");
    }

    static String baseHit(int id, int damage) {
        return base(id) + ": попадание, −" + damage + " прочности";
    }

    /** «попадание в своего рабочего 3», «попадание в свой танк 3». */
    static String friendlyFire(UnitType type, int id) {
        return "попадание в " + (type == UnitType.TANK ? "свой танк " : "своего рабочего ") + id;
    }

    static String friendlyFireBase(int id) {
        return "попадание в свою " + base(id);
    }

    // ---- лиги ----

    /** «база: уже 8 рабочих из 8», «база: уже 4 танка из 4». */
    static String unitLimit(String who, UnitType type, int have, int max) {
        String n = type == UnitType.TANK ? plural(have, "танк", "танка", "танков")
                : plural(have, "рабочий", "рабочих", "рабочих");
        return who + ": уже " + n + " из " + max;
    }

    static String meleeLater(String who) {
        return who + ": драться пока нельзя";
    }

    static String onlyWorkerAttacks(String who) {
        return who + ": вплотную бьёт только рабочий";
    }

    static String truceNoMelee(String who) {
        return who + ": идёт перемирие, драться нельзя";
    }

    static String nobodyNear(String who) {
        return who + ": в этой стороне рядом никого";
    }

    static String ownThere(String who) {
        return who + ": там свой";
    }

    static String baseUnhurt(String who) {
        return who + ": базу удар не ранит";
    }

    static String guardedTarget(String who) {
        return who + ": цель у своей базы, там не ранить";
    }

    static String strikeNoTarget(String who, int range) {
        return who + ": на прямой до " + range + (range % 10 == 1 && range % 100 != 11 ? " клетки" : " клеток")
                + " никого";
    }


    static String freeWorker(int id) {
        return "новый " + unit(UnitType.WORKER, id) + " — бесплатно: юнитов нет, энергии мало";
    }

    static String raiderDown(int id) {
        return raider(id) + " уничтожен";
    }

    static String buildWall(String who) {
        return who + ": там стена";
    }

    static String buildTaken(String who) {
        return who + ": там база или залежь";
    }

    static String buildNearCentre(String who, int min) {
        return who + ": здесь строить нельзя — до центра ближе " + min + (min % 10 == 1 && min % 100 != 11
                ? " клетки" : " клеток");
    }

    static String tooManyBases(String who, int max) {
        return who + ": у колонии уже " + plural(max, "база", "базы", "баз") + ", больше нельзя";
    }

    static String built(int id) {
        return "построена " + base(id);
    }

    static String guardedLoot(String who) {
        return who + ": колония под защитой новичка, трофеи подбирать нельзя";
    }

    static String guardedTrade(String who) {
        return who + ": колония под защитой новичка, передавать чужим нельзя";
    }

    static String foreignBase(String who) {
        return who + ": чужой базе передать нельзя, только юниту";
    }

    static String raiderTakesNothing(String who) {
        return who + ": налётчику передать нельзя";
    }

    /** «налёт: 3 налётчика идут к колонии «Вы»». */
    static String raid(int n, String colony) {
        String verb = n % 10 == 1 && n % 100 != 11 ? " идёт" : " идут";
        return "налёт: " + plural(n, "налётчик", "налётчика", "налётчиков") + verb + " к колонии «" + colony + "»";
    }

    /** «через 5 минут откроется жила в квадрате К-4»; не кратно минуте — в тактах. */
    static String announce(int ticks, String square) {
        String when = ticks > 0 && ticks % 60 == 0 ? plural(ticks / 60, "минуту", "минуты", "минут")
                : plural(ticks, "такт", "такта", "тактов");
        return "через " + when + " откроется жила в квадрате " + square;
    }

    static String eventStarted(String square) {
        return "открылась жила в квадрате " + square;
    }

    private static final String COLUMNS = "АБВГДЕЖЗИКЛМНОПРСТУФХЦЧШЩЭЮЯ";

    /** Квадрат 8×8 клеток: столбец — буква, строка — число с 1. Клетка (72, 24) — «К-4». */
    static String square(colony.api.Pos p) {
        int col = p.x() / 8;
        String letter = col < COLUMNS.length() ? String.valueOf(COLUMNS.charAt(col))
                : COLUMNS.charAt(col % COLUMNS.length()) + Integer.toString(col / COLUMNS.length());
        return letter + "-" + (p.y() / 8 + 1);
    }

    static String returned() {
        return "колония вернулась";
    }

    // ---- лестница возможностей: склады, завалы, улучшения ----

    /** «склад 1». */
    static String structure(Building type, int number) {
        return switch (type) {
            case DEPOT -> "склад " + number;
        };
    }

    static String rubbleAhead(String who) {
        return who + ": впереди завал";
    }

    static String structureAhead(String who) {
        return who + ": там постройка";
    }

    static String buildingLater(String who, Building type) {
        return who + ": " + switch (type) {
            case DEPOT -> "склад";
        } + " на этой карте не построить";
    }

    static String buildRubble(String who) {
        return who + ": там завал";
    }

    static String buildOccupied(String who) {
        return who + ": там база, постройка или залежь";
    }

    static String tooManyDepots(String who, int max) {
        return who + ": у колонии уже " + plural(max, "склад", "склада", "складов") + ", больше нельзя";
    }

    static String builtStructure(Building type, int number) {
        return "построен " + structure(type, number);
    }

    static String onlyWorkerDigs(String who) {
        return who + ": копает только рабочий";
    }

    /** «рабочий 1: склад ещё не открыт — сдай шаг 3 «Склад»»: возможность есть в мире, но колонии не открыта. */
    static String locked(String who, Ability a, String hint) {
        String what = switch (a) {
            case DEPOT -> "склад ещё не открыт";
            case DIG -> "разбор завалов ещё не открыт";
            case UPGRADES -> "улучшения ещё не открыты";
        };
        return who + ": " + what + (hint == null || hint.isBlank() ? "" : " — " + hint);
    }

    static String digLater(String who) {
        return who + ": копать на этой карте нельзя";
    }

    static String noRubble(String who) {
        return who + ": там нет завала";
    }

    static String onlyWorkerUpgrades(String who) {
        return who + ": улучшить можно только рабочего";
    }

    static String upgradeLater(String who) {
        return who + ": улучшения на этой карте недоступны";
    }

    static String noBaseNear(String who) {
        return who + ": рядом нет своей базы";
    }

    static String upgradeName(Upgrade u) {
        return switch (u) {
            case PICK -> "кирка";
            case BAG -> "сумка";
        };
    }

    static String alreadyUpgraded(String who, Upgrade u) {
        return who + ": " + upgradeName(u) + " уже есть";
    }
}
