package colony.engine;

import colony.api.UnitType;
import colony.engine.World.UnitEntity;
import java.util.function.Predicate;

/**
 * Кто держит центр после такта — по флагам правил:
 * <ul>
 *   <li>{@code centerMajority} (лиги 4+): больше всех юнитов в радиусе; поровну — ничей;</li>
 *   <li>{@code centerByTanks} (опыт 2б): больше всех танков в радиусе;</li>
 *   <li>{@code center} (2б): в радиусе юниты только одной колонии.</li>
 * </ul>
 * Колонии под защитой новичка не держат и не оспаривают центр. Держатель получает такт центра.
 */
final class Centre {

    private Centre() {}

    /** Держатель после такта: номер колонии, {@code 0} — никто или механика выключена. */
    static int holder(World w, boolean[] guarded) {
        RuleSet.Features f = w.rules.features();
        Predicate<UnitEntity> counts = u -> w.inCentre(u.pos) && !(u.colonyId > 0 && guarded[u.colonyId]);
        if (f.centerMajority()) {
            return majority(w, counts);
        }
        if (!f.center()) {
            return 0;
        }
        if (f.centerByTanks()) {
            return majority(w, counts.and(u -> u.type == UnitType.TANK));
        }
        return sole(w, counts);
    }

    /** Колония, у которой таких юнитов больше всех; поровну или налётчики — никто. */
    private static int majority(World w, Predicate<UnitEntity> counts) {
        int[] count = new int[w.colonies.size() + 1];
        for (UnitEntity u : w.units.values()) {
            if (counts.test(u)) {
                count[u.colonyId]++;
            }
        }
        int best = 0;
        int holder = 0;
        boolean tie = false;
        for (int c = 0; c < count.length; c++) {
            if (count[c] > best) {
                best = count[c];
                holder = c;
                tie = false;
            } else if (count[c] == best && best > 0) {
                tie = true;
            }
        }
        return tie ? 0 : holder;
    }

    /** Единственная колония в радиусе; две и больше (или налётчики) — никто. */
    private static int sole(World w, Predicate<UnitEntity> counts) {
        int holder = -1;
        for (UnitEntity u : w.units.values()) {
            if (!counts.test(u)) {
                continue;
            }
            if (holder == -1) {
                holder = u.colonyId;
            } else if (holder != u.colonyId) {
                return 0;
            }
        }
        return Math.max(holder, 0);
    }
}
