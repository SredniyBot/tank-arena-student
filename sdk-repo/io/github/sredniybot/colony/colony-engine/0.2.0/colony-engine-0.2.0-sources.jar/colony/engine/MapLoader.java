package colony.engine;

import colony.api.DepositKind;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Set;

/**
 * Загрузка карт из JSON: встроенных (из ресурсов движка) и преподавательских (из любого каталога).
 *
 * <pre>{ "name": "steps-4", "players": 4, "rows": ["####", "#1H*", ...],
 *   "amounts": { "NORMAL": 400, "RICH": 1000 },
 *   "regions": [ { "name": "Жила", "x": 20, "y": 14 } ] }</pre>
 */
public final class MapLoader {

    /** Встроенные карты: сезон 1 и лиги (у каждой лиги — три дуэли и мир класса на 12). */
    public static final List<String> BUILTIN = builtinNames();

    private static List<String> builtinNames() {
        List<String> names = new ArrayList<>(List.of("training-2", "steps-4", "world-12"));
        for (int n = 1; n <= RulesLoader.LEAGUES; n++) {
            names.addAll(leagueDuels(n));
            names.add(leagueWorld(n));
        }
        return List.copyOf(names);
    }

    /** Три дуэли лиги {@code n}: первая — тренировочная, все три — проверка босса. */
    public static List<String> leagueDuels(int n) {
        return List.of("league-" + n + "-duel-a", "league-" + n + "-duel-b", "league-" + n + "-duel-c");
    }

    /** Мир класса лиги {@code n}: 12 равных мест. */
    public static String leagueWorld(int n) {
        return "league-" + n + "-world";
    }

    private static final Set<String> KEYS = Set.of("name", "players", "rows", "amounts", "regions", "description");

    private MapLoader() {}

    /** Встроенная карта по имени из {@link #BUILTIN}. */
    public static GameMap builtin(String name) {
        String resource = "/colony/maps/" + name + ".json";
        if (!BUILTIN.contains(name)) {
            throw new IllegalArgumentException("нет встроенной карты «" + name + "»; есть: training-2, steps-4, world-12 и "
                    + "карты лиг league-N-duel-a|b|c, league-N-world (N = 1…" + RulesLoader.LEAGUES + ")");
        }
        try (InputStream in = MapLoader.class.getResourceAsStream(resource)) {
            if (in == null) {
                throw new IllegalStateException("нет ресурса " + resource);
            }
            return fromJson(Json.MAPPER.readTree(in), name);
        } catch (IOException e) {
            throw new UncheckedIOException("не удалось прочитать карту " + resource, e);
        }
    }

    /** Карта из файла. */
    public static GameMap load(Path path) {
        try {
            return fromJson(Json.MAPPER.readTree(Files.readAllBytes(path)), path.toString());
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("карта " + path + ": " + e.getOriginalMessage(), e);
        } catch (IOException e) {
            throw new UncheckedIOException("не удалось прочитать карту " + path, e);
        }
    }

    /** Встроенная карта, если имя встроенное, иначе файл по пути. */
    public static GameMap resolve(String nameOrPath) {
        return BUILTIN.contains(nameOrPath) ? builtin(nameOrPath) : load(Path.of(nameOrPath));
    }

    /** Карта из строки JSON. */
    public static GameMap parse(String json) {
        try {
            return fromJson(Json.MAPPER.readTree(json), "JSON");
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("карта: " + e.getOriginalMessage(), e);
        }
    }

    /** Карта из дерева JSON; {@code source} попадает в текст ошибки. */
    public static GameMap fromJson(JsonNode node, String source) {
        String where = "карта " + source;
        if (node == null || !node.isObject()) {
            throw new IllegalArgumentException(where + ": ожидался объект JSON");
        }
        for (Iterator<String> it = node.fieldNames(); it.hasNext(); ) {
            String key = it.next();
            if (!KEYS.contains(key)) {
                throw new IllegalArgumentException(where + ": лишний ключ «" + key + "»");
            }
        }
        String name = text(node, "name", where);
        JsonNode players = node.get("players");
        if (players == null || !players.isInt()) {
            throw new IllegalArgumentException(where + ": нет целого «players»");
        }
        JsonNode rowsNode = node.get("rows");
        if (rowsNode == null || !rowsNode.isArray()) {
            throw new IllegalArgumentException(where + ": нет массива «rows»");
        }
        List<String> rows = new ArrayList<>();
        for (JsonNode r : rowsNode) {
            if (!r.isTextual()) {
                throw new IllegalArgumentException(where + ": в «rows» не строка: " + r);
            }
            rows.add(r.asText());
        }
        Map<DepositKind, Integer> amounts = new EnumMap<>(DepositKind.class);
        JsonNode amountsNode = node.get("amounts");
        if (amountsNode != null) {
            if (!amountsNode.isObject()) {
                throw new IllegalArgumentException(where + ": «amounts» должен быть объектом");
            }
            for (Iterator<Map.Entry<String, JsonNode>> it = amountsNode.fields(); it.hasNext(); ) {
                Map.Entry<String, JsonNode> e = it.next();
                DepositKind kind;
                try {
                    kind = DepositKind.valueOf(e.getKey());
                } catch (IllegalArgumentException ex) {
                    throw new IllegalArgumentException(where + ": в «amounts» неизвестный вид «" + e.getKey() + "»");
                }
                if (!e.getValue().isInt()) {
                    throw new IllegalArgumentException(where + ": запас " + kind + " должен быть целым");
                }
                amounts.put(kind, e.getValue().asInt());
            }
        }
        List<GameMap.Region> regions = new ArrayList<>();
        JsonNode regionsNode = node.get("regions");
        if (regionsNode != null) {
            if (!regionsNode.isArray()) {
                throw new IllegalArgumentException(where + ": «regions» должен быть массивом");
            }
            for (JsonNode r : regionsNode) {
                JsonNode x = r.get("x");
                JsonNode y = r.get("y");
                if (x == null || y == null || !x.isInt() || !y.isInt()) {
                    throw new IllegalArgumentException(where + ": у области нужны целые x и y: " + r);
                }
                regions.add(new GameMap.Region(text(r, "name", where), x.asInt(), y.asInt()));
            }
        }
        return GameMap.of(name, players.asInt(), rows, amounts, regions);
    }

    /** Карта в формате файла карты. */
    public static ObjectNode toJson(GameMap map) {
        ObjectNode root = Json.MAPPER.createObjectNode();
        root.put("name", map.name());
        root.put("players", map.players());
        ArrayNode rows = root.putArray("rows");
        map.rows().forEach(rows::add);
        ObjectNode amounts = root.putObject("amounts");
        map.amounts().forEach((k, v) -> amounts.put(k.name(), v));
        ArrayNode regions = root.putArray("regions");
        for (GameMap.Region r : map.regions()) {
            regions.addObject().put("name", r.name()).put("x", r.x()).put("y", r.y());
        }
        return root;
    }

    private static String text(JsonNode node, String key, String where) {
        JsonNode v = node.get(key);
        if (v == null || !v.isTextual()) {
            throw new IllegalArgumentException(where + ": нет строки «" + key + "»");
        }
        return v.asText();
    }
}
