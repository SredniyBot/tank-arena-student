package colony.engine;

import java.io.IOException;
import java.io.InputStream;
import java.util.Properties;

/** Версия движка и SDK из сборки Maven. */
public final class Version {

    private static final String VERSION = load();

    private Version() {}

    /** Например {@code 0.1.0}; при запуске без сборки — {@code dev}. */
    public static String get() {
        return VERSION;
    }

    private static String load() {
        try (InputStream in = Version.class.getResourceAsStream("/colony/engine/version.properties")) {
            if (in == null) {
                return "dev";
            }
            Properties p = new Properties();
            p.load(in);
            String v = p.getProperty("version", "dev");
            return v.contains("${") ? "dev" : v;
        } catch (IOException e) {
            return "dev";
        }
    }
}
