package colony.engine.world;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;

/**
 * Изменяемая сетка знаков карты и поиски по ней: пути в ширину, жадный шаг {@code Pathfinder.SIMPLE}, связные
 * куски. Знаки — легенда {@link colony.engine.GameMap}. За краем — стена.
 */
final class Cells {

    static final char ROCK = '#';
    static final char FLOOR = '.';
    static final char RUBBLE = '%';

    final int w;
    final int h;
    final char[] a;

    Cells(int w, int h, char fill) {
        this.w = w;
        this.h = h;
        this.a = new char[w * h];
        Arrays.fill(a, fill);
    }

    Cells(Cells o) {
        this.w = o.w;
        this.h = o.h;
        this.a = o.a.clone();
    }

    boolean in(int x, int y) {
        return x >= 0 && y >= 0 && x < w && y < h;
    }

    int idx(int x, int y) {
        return y * w + x;
    }

    char get(int x, int y) {
        return in(x, y) ? a[y * w + x] : ROCK;
    }

    void set(int x, int y, char c) {
        if (in(x, y)) {
            a[y * w + x] = c;
        }
    }

    /** Клетку можно занять юнитом: пол или логово. */
    static boolean walk(char c) {
        return c == FLOOR || c == 'L';
    }

    static boolean deposit(char c) {
        return c == 'H' || c == '*' || c == '$' || c == 'C';
    }

    boolean walk(int x, int y, boolean rubbleOpen) {
        char c = get(x, y);
        return walk(c) || rubbleOpen && c == RUBBLE;
    }

    /** Свободные клетки вплотную к клетке {@code (x, y)} — места у жилы или у базы. */
    List<int[]> spots(int x, int y) {
        List<int[]> out = new ArrayList<>(4);
        for (int[] d : DIRS) {
            if (walk(get(x + d[0], y + d[1]))) {
                out.add(new int[] {x + d[0], y + d[1]});
            }
        }
        return out;
    }

    /** Север, восток, юг, запад — порядок {@code colony.api.Direction}. */
    static final int[][] DIRS = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
    static final int[][] RING8 = {{-1, -1}, {0, -1}, {1, -1}, {1, 0}, {1, 1}, {0, 1}, {-1, 1}, {-1, 0}};

    /**
     * Шагов от источников по проходимым клеткам; {@code -1} — не дойти. Завал проходим, если {@code rubbleOpen}:
     * тогда каждая клетка завала стоит {@code 1 + rubbleCost} (шаг и удары), поиск — Дейкстра на малых весах.
     */
    int[] dist(List<int[]> sources, boolean rubbleOpen, int rubbleCost) {
        int[] d = new int[w * h];
        Arrays.fill(d, -1);
        if (!rubbleOpen || rubbleCost == 0) {
            ArrayDeque<Integer> q = new ArrayDeque<>();
            for (int[] s : sources) {
                if (in(s[0], s[1]) && d[idx(s[0], s[1])] < 0) {
                    d[idx(s[0], s[1])] = 0;
                    q.add(idx(s[0], s[1]));
                }
            }
            while (!q.isEmpty()) {
                int i = q.poll();
                int x = i % w;
                int y = i / w;
                for (int[] dd : DIRS) {
                    int nx = x + dd[0];
                    int ny = y + dd[1];
                    if (walk(nx, ny, rubbleOpen) && d[idx(nx, ny)] < 0) {
                        d[idx(nx, ny)] = d[i] + 1;
                        q.add(idx(nx, ny));
                    }
                }
            }
            return d;
        }
        // веса 1 и 1 + rubbleCost: корзины по расстоянию
        int maxW = 1 + rubbleCost;
        List<ArrayDeque<Integer>> buckets = new ArrayList<>();
        for (int i = 0; i <= maxW; i++) {
            buckets.add(new ArrayDeque<>());
        }
        for (int[] s : sources) {
            if (in(s[0], s[1]) && d[idx(s[0], s[1])] < 0) {
                d[idx(s[0], s[1])] = 0;
                buckets.get(0).add(idx(s[0], s[1]));
            }
        }
        int cur = 0;
        int empty = 0;
        while (empty <= maxW) {
            ArrayDeque<Integer> b = buckets.get(cur % (maxW + 1));
            if (b.isEmpty()) {
                empty++;
                cur++;
                continue;
            }
            empty = 0;
            while (!b.isEmpty()) {
                int i = b.poll();
                if (d[i] != cur) {
                    continue;
                }
                int x = i % w;
                int y = i / w;
                for (int[] dd : DIRS) {
                    int nx = x + dd[0];
                    int ny = y + dd[1];
                    if (!walk(nx, ny, true)) {
                        continue;
                    }
                    int cost = get(nx, ny) == RUBBLE ? 1 + rubbleCost : 1;
                    int j = idx(nx, ny);
                    if (d[j] < 0 || d[j] > cur + cost) {
                        d[j] = cur + cost;
                        buckets.get((cur + cost) % (maxW + 1)).add(j);
                    }
                }
            }
            cur++;
        }
        return d;
    }

    /** Ближайшее из расстояний {@code d} до свободных клеток у {@code (x, y)}; {@code -1} — не дойти. */
    int toSpots(int[] d, int x, int y) {
        int best = -1;
        for (int[] s : spots(x, y)) {
            int v = d[idx(s[0], s[1])];
            if (v >= 0 && (best < 0 || v < best)) {
                best = v;
            }
        }
        return best;
    }

    /**
     * Жадный шаг {@code Pathfinder.SIMPLE}: по оси, где до цели дальше; закрыто — по другой; закрыто и там — первая
     * открытая соседняя в порядке С, В, Ю, З. Доходит ли он от {@code (sx, sy)} до клетки {@code (tx, ty)}
     * (или вплотную к ней, если она непроходима).
     */
    boolean greedyReaches(int sx, int sy, int tx, int ty) {
        int x = sx;
        int y = sy;
        boolean[] seen = new boolean[w * h];
        for (int step = 0; step < w * h; step++) {
            if (x == tx && y == ty) {
                return true;
            }
            int man = Math.abs(tx - x) + Math.abs(ty - y);
            if (man == 1 && !walk(get(tx, ty))) {
                return true;
            }
            if (seen[idx(x, y)]) {
                return false;
            }
            seen[idx(x, y)] = true;
            int dx = tx - x;
            int dy = ty - y;
            int[] alongX = dx > 0 ? DIRS[1] : DIRS[3];
            int[] alongY = dy > 0 ? DIRS[2] : DIRS[0];
            List<int[]> tries = new ArrayList<>(6);
            if (Math.abs(dx) >= Math.abs(dy)) {
                if (dx != 0) {
                    tries.add(alongX);
                }
                if (dy != 0) {
                    tries.add(alongY);
                }
            } else {
                tries.add(alongY);
                if (dx != 0) {
                    tries.add(alongX);
                }
            }
            tries.addAll(List.of(DIRS));
            int[] go = null;
            for (int[] d : tries) {
                if (walk(get(x + d[0], y + d[1]))) {
                    go = d;
                    break;
                }
            }
            if (go == null) {
                return false;
            }
            x += go[0];
            y += go[1];
        }
        return false;
    }

    /**
     * Связные куски клеток, где {@code member} истинно; соседство по 8 ({@code eight}) или по 4. Возвращает номер
     * куска для каждой клетки ({@code -1} — не член) и размеры кусков в {@code sizes}.
     */
    int[] components(java.util.function.IntPredicate member, boolean eight, List<Integer> sizes) {
        int[] comp = new int[w * h];
        Arrays.fill(comp, -1);
        int[][] nb = eight ? RING8 : DIRS;
        ArrayDeque<Integer> q = new ArrayDeque<>();
        for (int i = 0; i < w * h; i++) {
            if (comp[i] >= 0 || !member.test(i)) {
                continue;
            }
            int id = sizes.size();
            int size = 0;
            comp[i] = id;
            q.add(i);
            while (!q.isEmpty()) {
                int j = q.poll();
                size++;
                int x = j % w;
                int y = j / w;
                for (int[] d : nb) {
                    int nx = x + d[0];
                    int ny = y + d[1];
                    if (in(nx, ny)) {
                        int k = idx(nx, ny);
                        if (comp[k] < 0 && member.test(k)) {
                            comp[k] = id;
                            q.add(k);
                        }
                    }
                }
            }
            sizes.add(size);
        }
        return comp;
    }

    int count8(int x, int y, char c) {
        int n = 0;
        for (int[] d : RING8) {
            if (get(x + d[0], y + d[1]) == c) {
                n++;
            }
        }
        return n;
    }

    List<String> rows() {
        List<String> out = new ArrayList<>(h);
        for (int y = 0; y < h; y++) {
            out.add(new String(a, y * w, w));
        }
        return out;
    }

    @Override
    public String toString() {
        return String.join("\n", rows());
    }
}
