package colony.engine;

import colony.api.DepositKind;
import colony.api.Pos;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

/**
 * Симметричная карта с «лесенкой жил» у каждой базы: домашняя вплотную, обычная по прямой,
 * за поворотом и за стеной. Одно зерно — одна и та же карта.
 *
 * <p>Устройство: у каждой базы — блок 10×10 с лесенкой (повёрнутый случайно, но одинаково для всех баз),
 * блоки ставятся в половину или четверть карты, вне блоков — случайные стены и залежи не ближе 8 шагов
 * к базам, затем половина отражается. Места колоний нумеруются через четверти: 1 — северо-запад,
 * 2 — северо-восток, 3 — юго-восток, 4 — юго-запад, затем вторые блоки четвертей и т. д.
 *
 * <p>Больше 12 колоний: в четверти сетка блоков (по одному на четыре места), между блоками — стенки с проходами,
 * у середины четверти — прииск: богатые жилы за кольцом завала. Без кирки к ним не подойти, без склада они далеко.
 */
public final class MapGenerator {

    /** Блок базы: {@code @} — база. Края блока пустые. */
    static final String[] BLOCK = {
            "..........",
            "....*.....",
            "..........",
            ".......#..",
            ".......#..",
            "....@..#*.",
            ".....H.#..",
            "..........",
            ".......*..",
            "..........",
    };
    private static final int B = 10;
    private static final int NORMAL = 400;
    private static final int RICH = 1000;
    private static final int CENTER = 3000;
    private static final int KEEP_AWAY = 8;

    private MapGenerator() {}

    /** {@code mine} — центр прииска в четверти ({@code null} — прииска нет). */
    private record Layout(boolean quarters, int qw, int qh, int[][] blocks, int[][] walls, char middle, int[] mine) {}

    /** Наибольшее число колоний на карте генератора. */
    public static final int MAX_PLAYERS = 32;
    private static final int PITCH = B + 1;

    /** Карта на {@code players} колоний (1–{@value #MAX_PLAYERS}) по зерну {@code seed}. */
    public static GameMap generate(int players, long seed) {
        if (players < 1 || players > MAX_PLAYERS) {
            throw new IllegalArgumentException("игроков должно быть от 1 до " + MAX_PLAYERS + ", а не " + players);
        }
        Layout layout = layout(players);
        SplittableRandom rnd = new SplittableRandom(seed);
        String name = "gen-" + players + "-" + seed;
        int first = rnd.nextInt(8);
        char[][] block = null;
        for (int k = 0; k < 8 && block == null; k++) {
            char[][] candidate = transform((first + k) % 8);
            if (!spawnTies(mirror(layout, quarter(layout, candidate, null), name))) {
                block = candidate;
            }
        }
        if (block == null) {
            throw new IllegalStateException("нет поворота блока без равных клеток появления: " + name);
        }
        for (int attempt = 0; attempt <= 50; attempt++) {
            char[][] q = quarter(layout, block, attempt < 50 ? rnd : null);
            GameMap full = mirror(layout, q, name);
            if (connected(full)) {
                return full.forColonies(players);
            }
        }
        throw new IllegalStateException("не удалось построить связную карту: " + name);
    }

    /**
     * У какой-то базы две свободные соседние клетки на равном расстоянии от центра карты: тогда порядок появления
     * решает N, E, S, W, а он у отражённых баз разный.
     */
    private static boolean spawnTies(GameMap map) {
        for (Pos b : map.bases()) {
            List<Long> seen = new ArrayList<>();
            for (Pos n : b.neighbours()) {
                if (!map.passable(n)) {
                    continue;
                }
                long dx = 2L * n.x() - (map.width() - 1);
                long dy = 2L * n.y() - (map.height() - 1);
                long d = dx * dx + dy * dy;
                if (seen.contains(d)) {
                    return true;
                }
                seen.add(d);
            }
        }
        return false;
    }

    private static Layout layout(int players) {
        if (players <= 2) {
            return new Layout(false, 16, 20, new int[][] {{1, 5}}, new int[0][], '$', null);
        }
        if (players <= 4) {
            return new Layout(true, 20, 14, new int[][] {{1, 2}}, new int[0][], '$', null);
        }
        if (players <= 8) {
            return new Layout(true, 26, 14, new int[][] {{1, 2}, {14, 2}},
                    new int[][] {{12, 1, 12, 9}}, '$', null);
        }
        if (players <= 12) {
            return new Layout(true, 32, 20, new int[][] {{1, 1}, {12, 1}, {1, 10}},
                    new int[][] {{11, 1, 11, 9}, {1, 10, 7, 10}, {1, 19, 20, 19}, {31, 4, 31, 15}}, 'C', null);
        }
        return grid((players + 3) / 4);
    }

    /**
     * Четверть с сеткой из {@code k} блоков: по строкам слева направо, шаг 11 клеток. Справа и снизу от сетки —
     * свободная полоса шириной 10 к середине карты, в ней прииск. Стенки между блоками оставляют проходы.
     */
    private static Layout grid(int k) {
        int rows = Math.max(1, (int) Math.round(Math.sqrt(k / 1.6)));   // экран проектора шире, чем выше
        int cols = (k + rows - 1) / rows;
        int qw = 1 + cols * PITCH + 10;
        int qh = 1 + rows * PITCH + 10;
        int[][] blocks = new int[k][];
        for (int i = 0; i < k; i++) {
            blocks[i] = new int[] {1 + (i % cols) * PITCH, 1 + (i / cols) * PITCH};
        }
        List<int[]> walls = new ArrayList<>();
        for (int j = 0; j < rows; j++) {
            for (int i = 0; i + 1 < cols; i++) {
                int x = PITCH * (i + 1);
                walls.add(new int[] {x, 1 + j * PITCH, x, j * PITCH + 7});
            }
        }
        for (int j = 0; j + 1 < rows; j++) {
            for (int i = 0; i < cols; i++) {
                int y = PITCH * (j + 1);
                walls.add(new int[] {1 + i * PITCH, y, i * PITCH + 6, y});
            }
        }
        walls.add(new int[] {1, qh - 1, qw * 2 / 3, qh - 1});
        walls.add(new int[] {qw - 1, qh / 5, qw - 1, qh * 3 / 4});
        return new Layout(true, qw, qh, blocks, walls.toArray(new int[0][]), 'C', new int[] {qw - 7, qh - 7});
    }

    /** Один из восьми поворотов и отражений блока. */
    private static char[][] transform(int t) {
        char[][] out = new char[B][B];
        for (int y = 0; y < B; y++) {
            for (int x = 0; x < B; x++) {
                int sx = (t & 4) != 0 ? B - 1 - x : x;
                int sy = y;
                for (int r = 0; r < (t & 3); r++) {
                    int nx = B - 1 - sy;
                    sy = sx;
                    sx = nx;
                }
                out[y][x] = BLOCK[sy].charAt(sx);
            }
        }
        return out;
    }

    private static char[][] quarter(Layout l, char[][] block, SplittableRandom rnd) {
        char[][] q = new char[l.qh()][l.qw()];
        for (char[] row : q) {
            Arrays.fill(row, '.');
        }
        for (int x = 0; x < l.qw(); x++) {
            q[0][x] = '#';
        }
        if (!l.quarters()) {
            for (int x = 0; x < l.qw(); x++) {
                q[l.qh() - 1][x] = '#';
            }
        }
        for (int y = 0; y < l.qh(); y++) {
            q[y][0] = '#';
        }
        boolean[][] reserved = new boolean[l.qh()][l.qw()];
        List<Pos> rings = new ArrayList<>();
        for (int[] o : l.blocks()) {
            for (int y = 0; y < B; y++) {
                for (int x = 0; x < B; x++) {
                    q[o[1] + y][o[0] + x] = block[y][x];
                    if (block[y][x] == '@') {
                        rings.addAll(new Pos(o[0] + x, o[1] + y).neighbours());
                    }
                }
            }
            for (int y = o[1] - 1; y <= o[1] + B; y++) {
                for (int x = o[0] - 1; x <= o[0] + B; x++) {
                    if (y >= 0 && x >= 0 && y < l.qh() && x < l.qw()) {
                        reserved[y][x] = true;
                    }
                }
            }
        }
        for (int[] w : l.walls()) {
            for (int y = w[1]; y <= w[3]; y++) {
                for (int x = w[0]; x <= w[2]; x++) {
                    q[y][x] = '#';
                }
            }
        }
        int mx = l.qw() - 1;
        int my = l.qh() - 1;
        if (l.quarters()) {
            q[my][mx] = l.middle();
        } else {
            q[l.qh() / 2 - 1][mx] = l.middle();
            q[l.qh() / 2][mx] = l.middle();
        }
        reserved[my][mx] = true;
        if (l.mine() != null) {
            mine(q, reserved, l.mine()[0], l.mine()[1]);
        }
        if (rnd == null) {
            return q;
        }
        int[] dist = distances(q, rings);
        int cells = l.qw() * l.qh();
        int walls = cells / 70 + rnd.nextInt(3);
        int deposits = cells / 90 + rnd.nextInt(2);
        for (int i = 0; i < walls; i++) {
            int len = 2 + rnd.nextInt(3);
            boolean across = rnd.nextBoolean();
            int x0 = 1 + rnd.nextInt(l.qw() - 1);
            int y0 = 1 + rnd.nextInt(l.qh() - 1);
            List<int[]> seg = new ArrayList<>();
            for (int k = 0; k < len; k++) {
                int x = across ? x0 + k : x0;
                int y = across ? y0 : y0 + k;
                if (x >= l.qw() || y >= l.qh() || reserved[y][x] || q[y][x] != '.') {
                    seg.clear();
                    break;
                }
                seg.add(new int[] {x, y});
            }
            char wall = l.mine() != null && rnd.nextInt(3) == 0 ? '%' : '#';
            for (int[] c : seg) {
                q[c[1]][c[0]] = wall;
            }
        }
        for (int i = 0; i < deposits; i++) {
            int x = 1 + rnd.nextInt(l.qw() - 1);
            int y = 1 + rnd.nextInt(l.qh() - 1);
            int d = dist[y * l.qw() + x];
            if (!reserved[y][x] && q[y][x] == '.' && d >= KEEP_AWAY) {
                q[y][x] = rnd.nextInt(5) == 0 ? '$' : '*';
            }
        }
        return q;
    }

    /** Прииск: кольцо завала 5×5, внутри две богатые жилы. Клетки вокруг заняты, случайное туда не ляжет. */
    private static void mine(char[][] q, boolean[][] reserved, int cx, int cy) {
        for (int y = cy - 3; y <= cy + 3; y++) {
            for (int x = cx - 3; x <= cx + 3; x++) {
                boolean ring = Math.max(Math.abs(x - cx), Math.abs(y - cy)) == 2;
                boolean inside = Math.max(Math.abs(x - cx), Math.abs(y - cy)) < 2;
                if (ring) {
                    q[y][x] = '%';
                } else if (inside) {
                    q[y][x] = (y == cy && (x == cx || x == cx - 1)) ? '$' : '.';
                }
                reserved[y][x] = true;
            }
        }
    }

    private static int[] distances(char[][] q, List<Pos> sources) {
        int h = q.length;
        int w = q[0].length;
        int[] dist = new int[w * h];
        Arrays.fill(dist, Integer.MAX_VALUE);
        ArrayDeque<Pos> queue = new ArrayDeque<>();
        for (Pos s : sources) {
            if (s.x() >= 0 && s.y() >= 0 && s.x() < w && s.y() < h && q[s.y()][s.x()] == '.') {
                dist[s.y() * w + s.x()] = 0;
                queue.add(s);
            }
        }
        while (!queue.isEmpty()) {
            Pos p = queue.poll();
            for (Pos n : p.neighbours()) {
                if (n.x() >= 0 && n.y() >= 0 && n.x() < w && n.y() < h && q[n.y()][n.x()] == '.'
                        && dist[n.y() * w + n.x()] == Integer.MAX_VALUE) {
                    dist[n.y() * w + n.x()] = dist[p.y() * w + p.x()] + 1;
                    queue.add(n);
                }
            }
        }
        return dist;
    }

    private static GameMap mirror(Layout l, char[][] q, String name) {
        int w = l.qw() * 2;
        int h = l.quarters() ? l.qh() * 2 : l.qh();
        char[][] g = new char[h][w];
        List<List<Pos>> slots = new ArrayList<>();
        for (int i = 0; i < l.blocks().length; i++) {
            slots.add(new ArrayList<>());
        }
        int quarters = l.quarters() ? 4 : 2;
        for (int y = 0; y < l.qh(); y++) {
            for (int x = 0; x < l.qw(); x++) {
                char c = q[y][x];
                Pos[] images = l.quarters()
                        ? new Pos[] {new Pos(x, y), new Pos(w - 1 - x, y), new Pos(w - 1 - x, h - 1 - y), new Pos(x, h - 1 - y)}
                        : new Pos[] {new Pos(x, y), new Pos(w - 1 - x, y)};
                for (Pos p : images) {
                    g[p.y()][p.x()] = c == '@' ? '.' : c;
                }
                if (c == '@') {
                    int block = blockIndex(l, x, y);
                    slots.get(block).addAll(Arrays.asList(images));
                }
            }
        }
        int slot = 0;
        for (List<Pos> perBlock : slots) {
            for (int k = 0; k < quarters; k++) {
                Pos p = perBlock.get(k);
                g[p.y()][p.x()] = GameMap.BASE_MARKS.charAt(slot++);
            }
        }
        List<String> rows = new ArrayList<>();
        for (char[] row : g) {
            rows.add(new String(row));
        }
        Map<DepositKind, Integer> amounts = new EnumMap<>(DepositKind.class);
        amounts.put(DepositKind.NORMAL, NORMAL);
        amounts.put(DepositKind.RICH, RICH);
        if (l.middle() == 'C') {
            amounts.put(DepositKind.CENTER, CENTER);
        }
        List<GameMap.Region> regions = List.of(new GameMap.Region(l.middle() == 'C' ? "Центр" : "Жила", w / 2, h / 2));
        return GameMap.of(name, slot, rows, amounts, regions);
    }

    private static int blockIndex(Layout l, int x, int y) {
        for (int i = 0; i < l.blocks().length; i++) {
            int[] o = l.blocks()[i];
            if (x >= o[0] && x < o[0] + B && y >= o[1] && y < o[1] + B) {
                return i;
            }
        }
        throw new IllegalStateException("база вне блока");
    }

    /** Все базы связаны проходимыми клетками. */
    private static boolean connected(GameMap map) {
        int w = map.width();
        boolean[] seen = new boolean[w * map.height()];
        ArrayDeque<Pos> queue = new ArrayDeque<>();
        Pos start = map.base(1).neighbours().stream().filter(map::passable).findFirst().orElseThrow();
        seen[start.y() * w + start.x()] = true;
        queue.add(start);
        while (!queue.isEmpty()) {
            Pos p = queue.poll();
            for (Pos n : p.neighbours()) {
                if (map.passable(n) && !seen[n.y() * w + n.x()]) {
                    seen[n.y() * w + n.x()] = true;
                    queue.add(n);
                }
            }
        }
        for (Pos b : map.bases()) {
            boolean reached = false;
            for (Pos n : b.neighbours()) {
                reached |= map.passable(n) && seen[n.y() * w + n.x()];
            }
            if (!reached) {
                return false;
            }
        }
        return true;
    }
}
