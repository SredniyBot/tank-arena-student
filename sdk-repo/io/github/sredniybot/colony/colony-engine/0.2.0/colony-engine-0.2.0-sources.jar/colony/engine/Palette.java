package colony.engine;

import java.util.List;
import java.util.Locale;

/**
 * Цвета и знаки колоний. Двадцать четыре цвета без красного и янтарного: красный в просмотре — ошибки и урон,
 * янтарный — энергия. Знак из двух букв дублирует цвет для тех, кто плохо различает цвета.
 */
public final class Palette {

    private static final List<String> COLORS = List.of(
            "#2F6FDB", "#E3762C", "#13998A", "#8A5CD8",
            "#3E9A3E", "#CC4A9C", "#3CA6DA", "#8C6239",
            "#263F8C", "#8DB032", "#5E6E80", "#6B3F86",
            "#7A7A1F", "#0E6E8C", "#E07AA8", "#5BC8A0",
            "#4B3FC8", "#1F6B3A", "#B89B6A", "#8DA2BC",
            "#B07AE0", "#3A3A3A", "#9C8AA5", "#D18FD1");

    private Palette() {}

    /** Цвет колонии {@code colonyId} (1–24; дальше по кругу). */
    public static String color(int colonyId) {
        return COLORS.get(Math.floorMod(colonyId - 1, COLORS.size()));
    }

    /** Знак из двух букв: заданный или первые буквы имени, заглавные. */
    public static String sign(String sign, String name) {
        String s = sign == null || sign.isBlank() ? name.replaceAll("[^\\p{L}\\p{N}]", "") : sign.strip();
        if (s.isEmpty()) {
            s = "??";
        }
        s = s.toUpperCase(Locale.ROOT);
        int end = s.offsetByCodePoints(0, Math.min(2, s.codePointCount(0, s.length())));
        return s.substring(0, end);
    }
}
