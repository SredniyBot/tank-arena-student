package colony.engine;

import colony.api.Base;
import colony.api.ColonyView;
import colony.api.Deposit;
import colony.api.DepositKind;
import colony.api.GameEvent;
import colony.api.Pos;
import colony.api.Rejection;
import colony.api.Structure;
import colony.api.Terrain;
import colony.api.Unit;
import colony.api.UnitType;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Неизменяемый взгляд колонии на мир на начало такта. Номера — как их знает колония: свои юниты и базы — по номеру
 * в колонии, чужие — в порядке, в котором колония их увидела ({@link Sightings}). Строится движком; код колонии может хранить его
 * сколько угодно — мир он больше не отражает.
 */
final class ViewSnapshot implements ColonyView {

    private final int tick;
    private final int maxTicks;
    private final int myId;
    private final int energy;
    private final RuleSet rules;
    /** Колония этого обзора: что ей открыто, читается при вызове {@link #rules()} (сервер открывает при входе). */
    private final World.ColonyState colony;
    private final GameMap map;
    private final boolean truce;
    private final boolean[] visible;
    private final List<Unit> myUnits;
    private final List<Base> myBases;
    private final List<Unit> enemies;
    private final List<Base> enemyBases;
    private final List<Deposit> deposits;
    private final Map<Integer, Unit> unitCell;
    private final Map<Integer, Base> baseCell;
    private final Map<Integer, Deposit> depositCell;
    private final List<Rejection> lastRejections;
    private final List<GameEvent> events;
    private final AtomicBoolean closed;
    /** Клетки, закрытые сценарием карты к началу такта. */
    private final Set<Pos> walls;
    /** Свои постройки по номеру. */
    private final List<Structure> myStructures;
    /** Постройки в клетках: свои и чужие в обзоре. */
    private final Map<Integer, Structure> structureCell;
    /** Прочность завалов по клеткам на начало такта; {@code null} — завалов на карте не было. */
    private final int[] rubble;

    private ViewSnapshot(World w, int colonyId, int maxTicks, List<Rejection> lastRejections, List<GameEvent> events,
                         AtomicBoolean closed) {
        this.closed = closed;
        this.tick = w.tick;
        this.maxTicks = maxTicks;
        this.myId = colonyId;
        this.energy = w.colony(colonyId).energy;
        this.rules = w.rules;
        this.colony = w.colony(colonyId);
        this.map = w.map;
        this.truce = w.truce();
        this.visible = new boolean[map.width() * map.height()];
        this.lastRejections = List.copyOf(lastRejections);
        this.events = List.copyOf(events);

        List<Unit> mine = new ArrayList<>();
        List<Base> myB = new ArrayList<>();
        for (World.BaseEntity b : w.bases.values()) {
            if (b.colonyId == colonyId) {
                myB.add(b.snapshot(b.number));
                see(b.pos, rules.baseVision());
            }
        }
        for (World.UnitEntity u : w.units.values()) {
            if (u.colonyId == colonyId) {
                mine.add(u.snapshot(u.number));
                see(u.pos, u.type == UnitType.TANK ? rules.tankVision() : rules.workerVision());
            }
        }
        List<Structure> myS = new ArrayList<>();
        for (World.StructureEntity st : w.structures.values()) {
            if (st.colonyId == colonyId) {
                myS.add(st.snapshot());
                see(st.pos, rules.depotVision());
            }
        }
        Map<Integer, Structure> structuresAt = new HashMap<>();
        for (World.StructureEntity st : w.structures.values()) {
            if (st.colonyId == colonyId || visible[w.index(st.pos)]) {
                structuresAt.put(w.index(st.pos), st.snapshot());
            }
        }
        this.myStructures = List.copyOf(myS);
        this.structureCell = structuresAt;
        this.rubble = w.rubbleCopy();
        List<Unit> foe = new ArrayList<>();
        List<Base> foeB = new ArrayList<>();
        Map<Integer, Unit> units = new HashMap<>();
        Map<Integer, Base> basesAt = new HashMap<>();
        for (Unit u : mine) {
            units.putIfAbsent(w.index(u.pos()), u);
        }
        for (World.UnitEntity u : w.units.values()) {
            if (u.colonyId != colonyId && visible[w.index(u.pos)]) {
                Unit s = u.snapshot(w.shownId(colonyId, u));
                foe.add(s);
                units.putIfAbsent(w.index(u.pos), s);
            }
        }
        for (Base b : myB) {
            basesAt.put(w.index(b.pos()), b);
        }
        for (World.BaseEntity b : w.bases.values()) {
            if (b.colonyId != colonyId && visible[w.index(b.pos)]) {
                Base s = b.snapshot(w.shownId(colonyId, b));
                foeB.add(s);
                basesAt.put(w.index(b.pos), s);
            }
        }
        List<Deposit> deps = new ArrayList<>();
        Map<Integer, Deposit> depsAt = new HashMap<>();
        boolean fog = rules.features().fog();
        boolean hideForeignHome = rules.features().foreignHomeHidden();
        boolean hideEmpty = rules.features().emptyHidden();
        for (World.DepositEntity d : w.deposits.values()) {
            boolean seen = visible[w.index(d.pos)];
            if ((d.kind == DepositKind.LOOT || fog) && !seen) {
                continue;
            }
            int amount = seen && d.kind != DepositKind.HOME ? d.amount : -1;
            Deposit s = new Deposit(d.id, d.pos, d.kind, amount, seen, rules.rateOf(d.kind));
            // опыт экономики мира: чужую домашнюю не добыть — в списке её нет, но клетка по-прежнему занята
            boolean foreignHome = hideForeignHome && d.kind == DepositKind.HOME && d.homeOwner != colonyId;
            // опыт экономики мира: почти пустой залежи нет в списке, клетка по-прежнему занята
            boolean empty = hideEmpty && d.kind != DepositKind.HOME && d.amount < rules.workerCarry();
            if (!foreignHome && !empty) {
                deps.add(s);
            }
            depsAt.put(w.index(d.pos), s);
        }
        this.myUnits = List.copyOf(mine);
        this.myBases = List.copyOf(myB);
        foe.sort(java.util.Comparator.comparingInt(u -> -u.id()));
        foeB.sort(java.util.Comparator.comparingInt(b -> -b.id()));
        this.enemies = List.copyOf(foe);
        this.enemyBases = List.copyOf(foeB);
        this.deposits = List.copyOf(deps);
        this.unitCell = units;
        this.baseCell = basesAt;
        this.depositCell = depsAt;
        this.walls = Set.copyOf(w.closedCells);
    }

    /** Клетки, закрытые сценарием карты к началу такта. */
    Set<Pos> walls() {
        return walls;
    }

    static ViewSnapshot of(World w, int colonyId, int maxTicks, List<Rejection> lastRejections,
                           List<GameEvent> events) {
        return of(w, colonyId, maxTicks, lastRejections, events, new AtomicBoolean());
    }

    /** {@code closed} — флаг матча: после его закрытия вид не отвечает, чтобы зависший код колонии упал. */
    static ViewSnapshot of(World w, int colonyId, int maxTicks, List<Rejection> lastRejections,
                           List<GameEvent> events, AtomicBoolean closed) {
        return new ViewSnapshot(w, colonyId, maxTicks, lastRejections, events, closed);
    }

    /** Клетка в обзоре — для движка, без проверки закрытия. */
    boolean seen(Pos p) {
        return p != null && map.inside(p) && visible[index(p)];
    }

    private void open() {
        if (closed.get()) {
            throw new IllegalStateException(Messages.closed());
        }
    }

    private void see(Pos from, int r) {
        int r2 = r * r;
        for (int dy = -r; dy <= r; dy++) {
            for (int dx = -r; dx <= r; dx++) {
                if (dx * dx + dy * dy > r2) {
                    continue;
                }
                int x = from.x() + dx;
                int y = from.y() + dy;
                if (x >= 0 && y >= 0 && x < map.width() && y < map.height()) {
                    visible[y * map.width() + x] = true;
                }
            }
        }
    }

    private int index(Pos p) {
        return p.y() * map.width() + p.x();
    }

    @Override
    public int tick() {
        open();
        return tick;
    }

    @Override
    public int maxTicks() {
        open();
        return maxTicks;
    }

    @Override
    public int myId() {
        open();
        return myId;
    }

    @Override
    public int energy() {
        open();
        return energy;
    }

    @Override
    public colony.api.Rules rules() {
        open();
        return colony.unlocked.rules();
    }

    /** Полные правила — для {@link RuleSet#of}. */
    RuleSet ruleSet() {
        open();
        return rules;
    }

    @Override
    public int width() {
        open();
        return map.width();
    }

    @Override
    public int height() {
        open();
        return map.height();
    }

    @Override
    public boolean inside(Pos p) {
        open();
        return p != null && map.inside(p);
    }

    @Override
    public Terrain terrain(Pos p) {
        open();
        if (p == null || walls.contains(p)) {
            return Terrain.WALL;
        }
        Terrain t = map.terrain(p);
        // разобранный завал — пол
        return t == Terrain.RUBBLE && rubbleLeft(p) == 0 ? Terrain.FLOOR : t;
    }

    private int rubbleLeft(Pos p) {
        return rubble == null || !map.inside(p) ? 0 : rubble[index(p)];
    }

    @Override
    public int rubble(Pos p) {
        open();
        return p == null ? 0 : rubbleLeft(p);
    }

    @Override
    public List<Structure> myStructures() {
        open();
        return myStructures;
    }

    @Override
    public Optional<Structure> structureAt(Pos p) {
        open();
        return inside(p) ? Optional.ofNullable(structureCell.get(index(p))) : Optional.empty();
    }

    @Override
    public boolean isVisible(Pos p) {
        open();
        return inside(p) && visible[index(p)];
    }

    @Override
    public boolean truce() {
        open();
        return truce;
    }

    @Override
    public List<Unit> myUnits() {
        open();
        return myUnits;
    }

    @Override
    public List<Base> myBases() {
        open();
        return myBases;
    }

    @Override
    public List<Unit> visibleEnemies() {
        open();
        return enemies;
    }

    @Override
    public List<Base> visibleEnemyBases() {
        open();
        return enemyBases;
    }

    @Override
    public List<Deposit> deposits() {
        open();
        return deposits;
    }

    @Override
    public Optional<Unit> unitAt(Pos p) {
        open();
        return inside(p) ? Optional.ofNullable(unitCell.get(index(p))) : Optional.empty();
    }

    @Override
    public Optional<Base> baseAt(Pos p) {
        open();
        return inside(p) ? Optional.ofNullable(baseCell.get(index(p))) : Optional.empty();
    }

    @Override
    public Optional<Deposit> depositAt(Pos p) {
        open();
        return inside(p) ? Optional.ofNullable(depositCell.get(index(p))) : Optional.empty();
    }

    @Override
    public List<Rejection> lastRejections() {
        open();
        return lastRejections;
    }

    @Override
    public List<GameEvent> events() {
        open();
        return events;
    }

    @Override
    public String toString() {
        return "ColonyView[колония " + myId + ", такт " + tick + ", энергия " + energy + ", юнитов " + myUnits.size() + "]";
    }
}
