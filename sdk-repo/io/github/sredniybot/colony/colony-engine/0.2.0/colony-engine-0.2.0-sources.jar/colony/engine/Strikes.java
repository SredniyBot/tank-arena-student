package colony.engine;

import colony.api.Direction;
import colony.api.Pos;
import colony.api.RejectCode;
import colony.api.Terrain;
import colony.engine.World.Cause;
import colony.engine.World.UnitEntity;
import java.util.List;

/**
 * Мгновенные удары лиг, до хода юнитов: удар рабочего вплотную (флаг {@code melee}) и удар танка по прямой (флаг
 * {@code tankStrike}). Цель — тот, кто стоял в клетке в начале такта; ушедший в этом такте всё равно ранен.
 * Свои юниты не ранятся и удару танка не мешают; стены и базы его останавливают. Баз удары не ранят. Юнит у своей
 * базы (флаг {@code homeGuard}) не ранится: удар по нему — отказ, перезарядка цела.
 */
final class Strikes {

    /** Удар, о котором попросила колония. */
    record Request(int colonyId, UnitEntity unit, Direction dir) {}

    private final World w;
    private final RuleSet rules;
    private final TickLog log;
    private final boolean truce;
    private final int t;
    /** Юниты в клетках на начало такта. */
    private final List<UnitEntity>[] cells;

    Strikes(World w, TickLog log, List<UnitEntity>[] cellsAtStart) {
        this.w = w;
        this.rules = w.rules;
        this.log = log;
        this.truce = w.truce();
        this.t = w.tick;
        this.cells = cellsAtStart;
    }

    /** Удары рабочих вплотную. */
    void melee(List<Request> requests) {
        for (Request r : requests) {
            UnitEntity u = r.unit();
            String who = u.label();
            if (truce) {
                log.reject(r.colonyId(), u.number, RejectCode.TRUCE, Messages.truceNoMelee(who));
                continue;
            }
            Pos at = u.pos.step(r.dir());
            UnitEntity target = foreignAt(at, u.colonyId);
            if (target == null) {
                String why = w.map.inside(at) && cells[w.index(at)] != null ? Messages.ownThere(who)
                        : w.baseAt(at) != null ? Messages.baseUnhurt(who) : Messages.nobodyNear(who);
                log.reject(r.colonyId(), u.number, RejectCode.NO_TARGET, why);
                continue;
            }
            if (w.homeGuarded(target)) {
                log.reject(r.colonyId(), u.number, RejectCode.GUARDED, Messages.guardedTarget(who));
                continue;
            }
            log.hit(target, u.colonyId, Cause.MELEE, rules.meleeDamage());
            log.shot(new Frame.Shot(u.colonyId, u.pos, at, target.id, Frame.Shot.MELEE));
        }
    }

    /** Удары танков по прямой: первый чужой не дальше {@code strikeRange}; без цели — отказ, перезарядка цела. */
    void tanks(List<Request> requests) {
        for (Request r : requests) {
            UnitEntity u = r.unit();
            String who = u.label();
            if (truce) {
                log.reject(r.colonyId(), u.number, RejectCode.TRUCE, Messages.truceNoFire(who));
                continue;
            }
            if (t < u.readyAt) {
                log.reject(r.colonyId(), u.number, RejectCode.COOLDOWN, Messages.cooldown(who, u.readyAt - t));
                continue;
            }
            Pos p = u.pos;
            UnitEntity target = null;
            for (int k = 1; k <= rules.strikeRange() && target == null; k++) {
                p = p.step(r.dir());
                if (!w.map.inside(p) || w.map.terrain(p) == Terrain.WALL || w.baseAt(p) != null) {
                    break;
                }
                target = foreignAt(p, u.colonyId);
            }
            if (target == null) {
                log.reject(r.colonyId(), u.number, RejectCode.NO_TARGET, Messages.strikeNoTarget(who,
                        rules.strikeRange()));
                continue;
            }
            if (w.homeGuarded(target)) {
                log.reject(r.colonyId(), u.number, RejectCode.GUARDED, Messages.guardedTarget(who));
                continue;
            }
            u.readyAt = t + rules.tankCooldown();
            log.hit(target, u.colonyId, Cause.STRIKE, rules.strikeDamage());
            log.shot(new Frame.Shot(u.colonyId, u.pos, target.pos, target.id, Frame.Shot.STRIKE));
        }
    }

    /** Первый по номеру чужой юнит в клетке на начало такта. */
    private UnitEntity foreignAt(Pos p, int colonyId) {
        if (!w.map.inside(p) || cells[w.index(p)] == null) {
            return null;
        }
        for (UnitEntity v : cells[w.index(p)]) {
            if (v.colonyId != colonyId) {
                return v;
            }
        }
        return null;
    }
}
