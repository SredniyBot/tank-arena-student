package colony.engine;

import colony.api.EventKind;
import colony.api.Pos;
import colony.api.RejectCode;
import colony.engine.World.Cause;
import colony.engine.World.UnitEntity;

/**
 * Что правило-механика может записать в такт: отказ, событие, след удара, урон. Механики лиг ({@link Strikes},
 * {@link Centre}, {@link FreeWorker}, {@link Loot}) получают этот интерфейс, а не весь {@link TickResolver}.
 */
interface TickLog {

    /** Отказ колонии; {@code number} — номер юнита или базы в колонии. */
    void reject(int colonyId, int number, RejectCode code, String message);

    /** Событие колонии ({@code 0} — для всех); текст для всех — с именем колонии. */
    void event(int colonyId, EventKind kind, String message, Pos pos);

    /** След выстрела или удара для просмотра. */
    void shot(Frame.Shot shot);

    /** Урон юниту: здоровье, событие для хозяина и для всех, кто добил. */
    void hit(UnitEntity victim, int attackerColony, Cause cause, int damage);
}
