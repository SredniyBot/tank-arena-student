package colony.engine;

import java.util.List;

/**
 * Итог матча или положение на текущий такт.
 *
 * @param ticks    сколько тактов сыграно
 * @param finished матч окончен
 * @param ranking  места: живые по убыванию счёта, затем погибшие (позже погибшая — выше); равный счёт — равное место
 */
public record MatchResult(int ticks, boolean finished, List<Placement> ranking) {

    /**
     * Место колонии.
     *
     * @param id         номер колонии
     * @param name       имя
     * @param place      место, с 1
     * @param score      счёт: такты удержания центра + энергия / {@code scoreEnergyDivisor}
     * @param energy     запас энергии
     * @param alive      колония жива
     * @param exceptions тактов, когда код колонии бросил исключение
     * @param timeouts   тактов, когда код колонии не уложился во время
     * @param rejections отказов в приказах за матч
     * @param delivered  энергии сдано на базы за матч
     */
    public record Placement(int id, String name, int place, int score, int energy, boolean alive, int exceptions,
                            int timeouts, int rejections, int delivered) {}

    public MatchResult {
        ranking = List.copyOf(ranking);
    }

    /** Место колонии {@code colonyId}. */
    public Placement of(int colonyId) {
        return ranking.stream().filter(p -> p.id() == colonyId).findFirst()
                .orElseThrow(() -> new IllegalArgumentException("нет колонии " + colonyId));
    }
}
