package colony.engine;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.List;
import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;

/**
 * Загрузка правил сезона из JSON. Все числа правил живут в файле, код их не дублирует.
 * Лишний или пропущенный ключ — ошибка с понятным текстом.
 */
public final class RulesLoader {

    /**
     * Встроенные правила: {@code league-1} … {@code league-5} — лиги; {@code season1} — шаг 2а, все механики 2б
     * выключены; {@code season1-2b} — те же числа, все механики 2б включены (запас для лиг 6 и дальше).
     */
    public static final List<String> BUILTIN = List.of("league-1", "league-2", "league-3", "league-4", "league-5",
            "season1", "season1-2b", "arena");

    /** Сколько лиг. */
    public static final int LEAGUES = 5;

    /**
     * Ключи, которые появились с лигами. В правилах, записанных раньше (файлы, повторы), их нет — тогда они равны нулю
     * и выключены. Остальные ключи по-прежнему обязательны.
     */
    private static final List<String> LEAGUE_NUMBERS = List.of("maxWorkers", "maxTanks", "meleeDamage", "strikeRange",
            "strikeDamage", "homeRadius", "richHarvestRate", "depotCost", "maxDepots", "depotVision",
            "rubbleDurability", "upgradeCost", "centerHarvestRate");
    private static final List<String> LEAGUE_FLAGS = List.of("unitCaps", "passableForeign", "melee", "dropCarry",
            "scoreDelivered", "centerMajority", "tankStrike", "freeWorker", "homeGuard", "fog", "softCollisions",
            "depots", "dig", "upgrades", "upkeepNoDeath", "foreignHomeHidden", "emptyHidden",
            "endlessDeposits");

    private static final Map<String, RuleSet> CACHE = new ConcurrentHashMap<>();

    private RulesLoader() {}

    /** Правила сезона 1 из ресурсов движка (шаг 2а). */
    public static RuleSet season1() {
        return builtin("season1");
    }

    /** Правила лиги {@code n} (1…{@link #LEAGUES}). */
    public static RuleSet league(int n) {
        if (n < 1 || n > LEAGUES) {
            throw new IllegalArgumentException("лиги " + n + " нет; есть 1–" + LEAGUES);
        }
        return builtin("league-" + n);
    }

    /** Номер лиги по версии правил ({@code league-3} → 3); не лига — {@code 0}. */
    public static int leagueOf(RuleSet rules) {
        String v = rules.rulesVersion();
        if (v != null && v.startsWith("league-")) {
            try {
                return Integer.parseInt(v.substring("league-".length()));
            } catch (NumberFormatException e) {
                return 0;
            }
        }
        return 0;
    }

    /** Встроенные правила по имени из {@link #BUILTIN}. */
    public static RuleSet builtin(String name) {
        if (!BUILTIN.contains(name)) {
            throw new IllegalArgumentException("нет встроенных правил «" + name + "»; есть: " + String.join(", ", BUILTIN));
        }
        return CACHE.computeIfAbsent(name, n -> {
            String resource = "/colony/rules/" + n + ".json";
            try (InputStream in = RulesLoader.class.getResourceAsStream(resource)) {
                if (in == null) {
                    throw new IllegalStateException("нет ресурса " + resource);
                }
                return read(Json.MAPPER.readTree(in), resource);
            } catch (IOException e) {
                throw new UncheckedIOException("не удалось прочитать " + resource, e);
            }
        });
    }

    /** Правила из файла. */
    public static RuleSet load(Path path) {
        try {
            return read(Json.MAPPER.readTree(Files.readAllBytes(path)), path.toString());
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("правила " + path + ": " + e.getOriginalMessage(), e);
        } catch (IOException e) {
            throw new UncheckedIOException("не удалось прочитать правила " + path, e);
        }
    }

    /** Правила из строки JSON. */
    public static RuleSet parse(String json) {
        try {
            return read(Json.MAPPER.readTree(json), "JSON");
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("правила: " + e.getOriginalMessage(), e);
        }
    }

    /** Правила из дерева JSON. */
    public static RuleSet fromJson(JsonNode node) {
        return read(node, "JSON");
    }

    /** Правила в виде JSON — для повтора и проверок. Ключи — как в файле правил. */
    public static ObjectNode toJson(RuleSet rules) {
        return Json.MAPPER.valueToTree(rules);
    }

    private static RuleSet read(JsonNode node, String source) {
        try {
            return Json.MAPPER.treeToValue(withLeagueDefaults(node), RuleSet.class);
        } catch (JsonProcessingException e) {
            throw new IllegalArgumentException("правила " + source + ": " + e.getOriginalMessage(), e);
        }
    }

    /** Копия с ключами лиг, если их нет: старые правила и повторы читаются как раньше. */
    private static JsonNode withLeagueDefaults(JsonNode node) {
        if (node == null || !node.isObject()) {
            return node;
        }
        ObjectNode copy = ((ObjectNode) node).deepCopy();
        LEAGUE_NUMBERS.forEach(k -> {
            if (!copy.has(k)) {
                copy.put(k, 0);
            }
        });
        if (copy.get("features") instanceof ObjectNode f) {
            LEAGUE_FLAGS.forEach(k -> {
                if (!f.has(k)) {
                    f.put(k, false);
                }
            });
        }
        return copy;
    }
}
