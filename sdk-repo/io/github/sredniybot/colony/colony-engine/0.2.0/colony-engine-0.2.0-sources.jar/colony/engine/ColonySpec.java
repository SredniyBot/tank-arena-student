package colony.engine;

import colony.api.Colony;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Участник матча. Номер колонии — место в списке, с 1.
 *
 * @param name    имя для людей: «Вы», «бронза»
 * @param sign    знак из двух букв на карте; {@code null} — первые две буквы имени
 * @param factory создаёт колонию; вызывается один раз, в потоке колонии
 * @param bot     колония-бот (встроенный соперник): с её юнитов не падают трофеи, «фармить» ботов невыгодно
 */
public record ColonySpec(String name, String sign, Supplier<Colony> factory, boolean bot) {

    public ColonySpec {
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("у колонии нет имени");
        }
        Objects.requireNonNull(factory, "factory");
    }

    public ColonySpec(String name, String sign, Supplier<Colony> factory) {
        this(name, sign, factory, false);
    }

    public ColonySpec(String name, Supplier<Colony> factory) {
        this(name, null, factory, false);
    }

    /** Та же колония, помеченная как бот. */
    public ColonySpec asBot() {
        return new ColonySpec(name, sign, factory, true);
    }
}
