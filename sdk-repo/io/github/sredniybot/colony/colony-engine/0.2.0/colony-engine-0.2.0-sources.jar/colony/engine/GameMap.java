package colony.engine;

import colony.api.DepositKind;
import colony.api.Pos;
import colony.api.Terrain;
import java.util.ArrayList;
import java.util.Collections;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Неизменяемая карта: рельеф, места баз и залежей, области с именами.
 *
 * <p>Легенда строк: {@code #} — стена, {@code .} — пол, {@code 1}–{@code 9}, {@code a}–{@code z} — база
 * колонии 1–35, {@code H} — домашняя залежь, {@code *} — обычная, {@code $} — богатая,
 * {@code C} — центральная, {@code L} — логово налётчиков (проходимо), {@code %} — завал (непроходим, пока его не
 * разберут киркой).
 * Ось {@code y} растёт на юг.
 */
public final class GameMap {

    /** Область с именем, чтобы о ней говорить: «Перевал», «Жила». */
    public record Region(String name, int x, int y) {
        public Pos pos() {
            return new Pos(x, y);
        }
    }

    /**
     * Залежь в начале матча.
     *
     * @param amount начальный запас; {@code -1} у домашней — не иссякает
     */
    public record DepositSpot(int id, Pos pos, DepositKind kind, int amount) {}

    /** Знаки баз колоний 1–35: цифры, затем строчные латинские буквы. */
    public static final String BASE_MARKS = "123456789abcdefghijklmnopqrstuvwxyz";
    private static final String LEGEND = "#." + BASE_MARKS + "H*$CL%";

    private final String name;
    private final int players;
    private final List<String> rows;
    private final Map<DepositKind, Integer> amounts;
    private final List<Region> regions;
    private final int width;
    private final int height;
    private final List<Pos> bases;
    private final List<DepositSpot> deposits;
    private final List<Pos> centerCells;
    private final Pos lair;

    private GameMap(String name, int players, List<String> rows, Map<DepositKind, Integer> amounts,
                    List<Region> regions) {
        this.name = name;
        this.players = players;
        this.rows = List.copyOf(rows);
        EnumMap<DepositKind, Integer> a = new EnumMap<>(DepositKind.class);
        a.putAll(amounts);
        this.amounts = Collections.unmodifiableMap(a);
        this.regions = List.copyOf(regions);
        this.height = rows.size();
        this.width = rows.get(0).length();

        Pos[] baseAt = new Pos[BASE_MARKS.length()];
        List<DepositSpot> deps = new ArrayList<>();
        List<Pos> centers = new ArrayList<>();
        Pos lairAt = null;
        for (int y = 0; y < height; y++) {
            String row = rows.get(y);
            for (int x = 0; x < width; x++) {
                char c = row.charAt(x);
                Pos p = new Pos(x, y);
                int mark = BASE_MARKS.indexOf(c);
                if (mark >= 0) {
                    baseAt[mark] = p;
                }
                DepositKind kind = kindOf(c);
                if (kind != null) {
                    int amount = kind == DepositKind.HOME ? -1 : this.amounts.get(kind);
                    deps.add(new DepositSpot(deps.size() + 1, p, kind, amount));
                    if (kind == DepositKind.CENTER) {
                        centers.add(p);
                    }
                }
                if (c == 'L' && lairAt == null) {
                    lairAt = p;
                }
            }
        }
        List<Pos> b = new ArrayList<>();
        for (int i = 0; i < players; i++) {
            b.add(baseAt[i]);
        }
        this.bases = List.copyOf(b);
        this.deposits = List.copyOf(deps);
        this.centerCells = List.copyOf(centers);
        this.lair = lairAt;
    }

    /**
     * Проверяет и собирает карту.
     *
     * @throws IllegalArgumentException если карта нарушает формат; текст называет место ошибки
     */
    public static GameMap of(String name, int players, List<String> rows, Map<DepositKind, Integer> amounts,
                             List<Region> regions) {
        String where = "карта «" + name + "»";
        if (name == null || name.isBlank()) {
            throw new IllegalArgumentException("у карты нет имени");
        }
        if (rows == null || rows.isEmpty()) {
            throw new IllegalArgumentException(where + ": нет строк");
        }
        if (players < 1 || players > BASE_MARKS.length()) {
            throw new IllegalArgumentException(where + ": игроков должно быть от 1 до " + BASE_MARKS.length()
                    + ", а не " + players);
        }
        int width = rows.get(0).length();
        if (width == 0) {
            throw new IllegalArgumentException(where + ": пустая строка 0");
        }
        int[] baseCount = new int[BASE_MARKS.length()];
        boolean[] needs = new boolean[DepositKind.values().length];
        for (int y = 0; y < rows.size(); y++) {
            String row = rows.get(y);
            if (row.length() != width) {
                throw new IllegalArgumentException(where + ": строка " + y + " длиной " + row.length()
                        + ", а первая — " + width);
            }
            for (int x = 0; x < width; x++) {
                char c = row.charAt(x);
                if (LEGEND.indexOf(c) < 0) {
                    throw new IllegalArgumentException(where + ": строка " + y + ", столбец " + x
                            + ": неизвестный знак «" + c + "»");
                }
                int mark = BASE_MARKS.indexOf(c);
                if (mark >= 0) {
                    baseCount[mark]++;
                }
                DepositKind kind = kindOf(c);
                if (kind != null) {
                    needs[kind.ordinal()] = true;
                }
            }
        }
        for (int i = 0; i < BASE_MARKS.length(); i++) {
            char mark = BASE_MARKS.charAt(i);
            if (i < players && baseCount[i] != 1) {
                throw new IllegalArgumentException(where + ": база «" + mark + "» должна быть ровно одна, а их "
                        + baseCount[i]);
            }
            if (i >= players && baseCount[i] > 0) {
                throw new IllegalArgumentException(where + ": игроков " + players + ", но есть база «" + mark + "»");
            }
        }
        Map<DepositKind, Integer> a = amounts == null ? Map.of() : amounts;
        for (DepositKind kind : DepositKind.values()) {
            Integer amount = a.get(kind);
            if (amount != null && (kind == DepositKind.HOME || kind == DepositKind.LOOT)) {
                throw new IllegalArgumentException(where + ": запас " + kind + " не задаётся картой");
            }
            if (needs[kind.ordinal()] && kind != DepositKind.HOME && (amount == null || amount <= 0)) {
                throw new IllegalArgumentException(where + ": в amounts нет запаса " + kind);
            }
        }
        List<Region> r = regions == null ? List.of() : regions;
        for (Region region : r) {
            if (region.name() == null || region.name().isBlank()) {
                throw new IllegalArgumentException(where + ": у области нет имени");
            }
            if (region.x() < 0 || region.y() < 0 || region.x() >= width || region.y() >= rows.size()) {
                throw new IllegalArgumentException(where + ": область «" + region.name() + "» за краем карты");
            }
        }
        return new GameMap(name, players, rows, a, r);
    }

    private static DepositKind kindOf(char c) {
        return switch (c) {
            case 'H' -> DepositKind.HOME;
            case '*' -> DepositKind.NORMAL;
            case '$' -> DepositKind.RICH;
            case 'C' -> DepositKind.CENTER;
            default -> null;
        };
    }

    public String name() {
        return name;
    }

    /** Число мест для колоний. */
    public int players() {
        return players;
    }

    public int width() {
        return width;
    }

    public int height() {
        return height;
    }

    /** Строки карты в исходной легенде. */
    public List<String> rows() {
        return rows;
    }

    /** Начальный запас по видам залежей. */
    public Map<DepositKind, Integer> amounts() {
        return amounts;
    }

    public List<Region> regions() {
        return regions;
    }

    public boolean inside(Pos p) {
        return p.x() >= 0 && p.y() >= 0 && p.x() < width && p.y() < height;
    }

    /** Знак клетки; за краем карты — {@code #}. */
    public char cell(Pos p) {
        return inside(p) ? rows.get(p.y()).charAt(p.x()) : '#';
    }

    /** Рельеф в начале матча; за краем карты — стена. Разобранный завал здесь остаётся завалом: это знает мир. */
    public Terrain terrain(Pos p) {
        char c = cell(p);
        return c == '#' ? Terrain.WALL : c == '%' ? Terrain.RUBBLE : Terrain.FLOOR;
    }

    /** Есть ли на карте завалы {@code %}: без них разбирать нечего. */
    public boolean hasRubble() {
        return rows.stream().anyMatch(r -> r.indexOf('%') >= 0);
    }

    /** Клетку можно занять юнитом: пол или логово, без базы и залежи. */
    public boolean passable(Pos p) {
        char c = cell(p);
        return c == '.' || c == 'L';
    }

    /** База колонии {@code colonyId} (1…players). */
    public Pos base(int colonyId) {
        if (colonyId < 1 || colonyId > players) {
            throw new IllegalArgumentException("на карте «" + name + "» нет базы " + colonyId);
        }
        return bases.get(colonyId - 1);
    }

    /** Базы в порядке номеров колоний. */
    public List<Pos> bases() {
        return bases;
    }

    /** Залежи в порядке строк; {@code id} — с 1. */
    public List<DepositSpot> deposits() {
        return deposits;
    }

    /** Клетки центральных залежей. */
    public List<Pos> centerCells() {
        return centerCells;
    }

    /**
     * Центр карты, он есть у каждой карты: клетка ({@code width / 2}, {@code height / 2}). Если на карте есть
     * центральные залежи {@code C} — ближайшая из них к этой клетке (при равенстве — первая по строкам).
     * В повторе пишется в {@code map.center}.
     */
    public Pos center() {
        Pos middle = new Pos(width / 2, height / 2);
        Pos best = middle;
        int bestD = Integer.MAX_VALUE;
        for (Pos p : centerCells) {
            int d = p.manhattan(middle);
            if (d < bestD) {
                bestD = d;
                best = p;
            }
        }
        return best;
    }

    /** Логово налётчиков: первая клетка {@code L} по строкам. */
    public Optional<Pos> lair() {
        return Optional.ofNullable(lair);
    }

    /**
     * Карта для {@code colonies} колоний: базы с большими номерами и их домашние залежи становятся полом.
     * Домашняя залежь принадлежит базе вплотную к ней (по 8 соседям), иначе ближайшей.
     */
    public GameMap forColonies(int colonies) {
        if (colonies < 1 || colonies > players) {
            throw new IllegalArgumentException("на карте «" + name + "» мест для колоний " + players
                    + ", а нужно " + colonies);
        }
        if (colonies == players) {
            return this;
        }
        char[][] grid = new char[height][];
        for (int y = 0; y < height; y++) {
            grid[y] = rows.get(y).toCharArray();
        }
        for (DepositSpot d : deposits) {
            if (d.kind() == DepositKind.HOME && homeOwner(d.pos()) > colonies) {
                grid[d.pos().y()][d.pos().x()] = '.';
            }
        }
        for (int c = colonies + 1; c <= players; c++) {
            Pos b = base(c);
            grid[b.y()][b.x()] = '.';
        }
        List<String> out = new ArrayList<>();
        for (char[] row : grid) {
            out.add(new String(row));
        }
        return new GameMap(name, colonies, out, amounts, regions);
    }

    /** Номер колонии, которой принадлежит домашняя залежь в клетке {@code p}. */
    int homeOwner(Pos p) {
        int best = 0;
        int bestD = Integer.MAX_VALUE;
        for (int c = 1; c <= players; c++) {
            Pos b = bases.get(c - 1);
            int cheb = Math.max(Math.abs(b.x() - p.x()), Math.abs(b.y() - p.y()));
            int d = cheb <= 1 ? 0 : b.manhattan(p);
            if (d < bestD) {
                bestD = d;
                best = c;
            }
        }
        return best;
    }

    @Override
    public boolean equals(Object o) {
        return o instanceof GameMap m && players == m.players && name.equals(m.name) && rows.equals(m.rows)
                && amounts.equals(m.amounts) && regions.equals(m.regions);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name, players, rows, amounts, regions);
    }

    @Override
    public String toString() {
        return "GameMap[" + name + ", " + width + "x" + height + ", игроков " + players + "]";
    }
}
