package colony.engine;

import colony.api.DepositKind;
import colony.api.Pos;
import colony.engine.World.Cause;
import colony.engine.World.DepositEntity;
import colony.engine.World.UnitEntity;

/**
 * Что остаётся от погибшего юнита — по флагам правил:
 * <ul>
 *   <li>{@code dropCarry} (лиги 3+): ровно его груз, от любой гибели;</li>
 *   <li>{@code loot} (2б): груз и половина цены, только от снаряда колонии, не с ботов и не с колоний меньше
 *       {@code lootMinColonyUnits} юнитов.</li>
 * </ul>
 * Остаток — залежь-трофей на клетке юнита; на трофей поверх ложится в ту же залежь.
 */
final class Loot {

    private Loot() {}

    /** {@code unitsAtStart} — юнитов у колонии на начало такта, по номеру колонии. */
    static void drop(World w, UnitEntity u, int[] unitsAtStart) {
        int amount = amount(w, u, unitsAtStart);
        if (amount <= 0) {
            return;
        }
        Pos at = u.pos;
        DepositEntity d = w.depositAt(at);
        if (d != null && d.kind == DepositKind.LOOT) {
            d.amount += amount;
        } else if (d == null && w.baseAt(at) == null) {
            w.addDeposit(DepositKind.LOOT, at, amount);
        }
    }

    private static int amount(World w, UnitEntity u, int[] unitsAtStart) {
        var f = w.rules.features();
        if (f.dropCarry()) {
            return u.carry;
        }
        if (!f.loot() || u.killedBy != Cause.SHELL) {
            return 0;
        }
        World.ColonyState c = w.colony(u.colonyId);
        if (c.bot || unitsAtStart[u.colonyId] < w.rules.lootMinColonyUnits()) {
            return 0;
        }
        return u.carry + w.cost(u.type) / 2;
    }
}
