package colony.engine;

import colony.api.UnitType;
import colony.engine.World.UnitEntity;

/** Флаг {@code unitCaps} (лиги): рабочих не больше {@code maxWorkers}, танков не больше {@code maxTanks}. */
final class UnitCaps {

    private UnitCaps() {}

    /** Почему колонии нельзя ещё юнита этого типа; {@code null} — можно. */
    static String refusal(World w, int colonyId, UnitType type, String who) {
        RuleSet r = w.rules;
        if (!r.features().unitCaps()) {
            return null;
        }
        int max = type == UnitType.TANK ? r.maxTanks() : r.maxWorkers();
        int have = 0;
        for (UnitEntity u : w.units.values()) {
            if (u.colonyId == colonyId && u.type == type) {
                have++;
            }
        }
        return have >= max ? Messages.unitLimit(who, type, have, max) : null;
    }
}
