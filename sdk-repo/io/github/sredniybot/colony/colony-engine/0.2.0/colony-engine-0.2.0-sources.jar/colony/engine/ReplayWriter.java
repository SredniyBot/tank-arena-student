package colony.engine;

import com.fasterxml.jackson.core.JsonEncoding;
import com.fasterxml.jackson.core.JsonGenerator;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Iterator;
import java.util.Map;
import java.util.zip.GZIPOutputStream;

/**
 * Запись повтора {@code colony-replay} v1: заголовок, все кадры, итог. Путь на {@code .gz} — сжатый файл.
 * Время решения колоний ({@code decideMillis}) зависит от машины и пишется только по просьбе:
 * без него одинаковые матчи дают побайтно одинаковый повтор.
 */
public final class ReplayWriter {

    private ReplayWriter() {}

    /** Повтор без времени решения. */
    public static void write(Match match, Path path) {
        write(match, path, false);
    }

    public static void write(Match match, Path path, boolean includeTimings) {
        try {
            Path parent = path.toAbsolutePath().getParent();
            if (parent != null) {
                Files.createDirectories(parent);
            }
            try (OutputStream file = new BufferedOutputStream(Files.newOutputStream(path))) {
                if (path.getFileName().toString().endsWith(".gz")) {
                    try (GZIPOutputStream gz = new GZIPOutputStream(file, 1 << 16)) {
                        write(match, gz, includeTimings);
                    }
                } else {
                    write(match, file, includeTimings);
                }
            }
        } catch (IOException e) {
            throw new UncheckedIOException("не удалось записать повтор " + path, e);
        }
    }

    /** Повтор в поток; поток не закрывается. */
    public static void write(Match match, OutputStream out, boolean includeTimings) throws IOException {
        try (JsonGenerator g = Json.MAPPER.getFactory().createGenerator(out, JsonEncoding.UTF8)) {
            g.disable(JsonGenerator.Feature.AUTO_CLOSE_TARGET);
            g.writeStartObject();
            ObjectNode header = match.replayHeader();
            for (Iterator<Map.Entry<String, JsonNode>> it = header.fields(); it.hasNext(); ) {
                Map.Entry<String, JsonNode> e = it.next();
                g.writeFieldName(e.getKey());
                Json.MAPPER.writeTree(g, e.getValue());
            }
            g.writeArrayFieldStart("frames");
            for (Frame f : match.frames()) {
                Json.MAPPER.writeTree(g, f.toJson(includeTimings));
            }
            g.writeEndArray();
            g.writeFieldName("result");
            Json.MAPPER.writeTree(g, resultJson(match.result()));
            g.writeEndObject();
        }
    }

    /** Итог в формате повтора: {@code { "ticks", "ranking": [ { "id", "name", "place", "score", "alive" } ] }}. */
    public static ObjectNode resultJson(MatchResult r) {
        ObjectNode o = Json.MAPPER.createObjectNode();
        o.put("ticks", r.ticks());
        ArrayNode ranking = o.putArray("ranking");
        for (MatchResult.Placement p : r.ranking()) {
            ranking.addObject().put("id", p.id()).put("name", p.name()).put("place", p.place()).put("score", p.score())
                    .put("alive", p.alive());
        }
        return o;
    }
}
