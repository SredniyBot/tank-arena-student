package colony.engine;

import colony.api.Base;
import colony.api.Building;
import colony.api.DepositKind;
import colony.api.Direction;
import colony.api.Pos;
import colony.api.Terrain;
import colony.api.Structure;
import colony.api.Unit;
import colony.api.UnitType;
import colony.api.Upgrade;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.EnumSet;
import java.util.List;
import java.util.Set;
import java.util.SplittableRandom;
import java.util.TreeMap;
import java.util.function.Function;

/**
 * Изменяемое состояние матча. Только для движка; наружу уходят неизменяемые снимки.
 * Коллекции юнитов, баз и залежей — {@link TreeMap}: обход всегда по возрастанию id.
 *
 * <p>Номера: базы и стартовые юниты — подряд, как на шаге 2а. Всё, что колония получает потом, берёт номера
 * из своего диапазона в {@value #ID_BLOCK}: по своим новым номерам нельзя понять, сколько выпустили соседи.
 * Первый диапазон — у колонии с наибольшим номером, последний — у налётчиков.
 */
final class World {

    /** Номеров в диапазоне одной колонии. */
    static final int ID_BLOCK = 10_000;

    /** Отчего юнит потерял последние очки здоровья. */
    enum Cause { SHELL, RAIDER, BASE_FIRE, MELEE, STRIKE }

    static final class ColonyState {
        final int id;
        final String name;
        final boolean bot;
        int energy;
        boolean alive = true;
        int centerTicks;
        int deathTick = -1;
        int exceptions;
        int timeouts;
        int rejections;
        int delivered;
        /** Такт возвращения после гибели; {@code -1} — не ждёт. */
        int respawnAt = -1;
        /** Под защитой новичка, пока такт меньше этого числа. */
        int protectedUntil;
        /** Сколько номеров колония уже взяла из своего диапазона. */
        int serial;
        /** Добыто за матч (из залежей и трофеев) — для счёта по добытому. */
        int gained;
        /** Последний выданный номер юнита или новой базы; первая база — {@code 0}. */
        int unitSerial;
        /** Последний выданный номер постройки (склада): «склад 1». */
        int structureSerial;
        /** Что открыто колонии; меняется из другого потока ({@link Match#unlock}), поэтому {@code volatile}. */
        volatile Unlocked unlocked;

        ColonyState(int id, String name, boolean bot, int energy) {
            this.id = id;
            this.name = name;
            this.bot = bot;
            this.energy = energy;
        }
    }

    static final class UnitEntity {
        /** Внутренний номер движка: порядок обхода и повтор. Колониям не показывается. */
        final int id;
        final int colonyId;
        final UnitType type;
        /** Номер в колонии с 1 — его видит хозяин и все тексты: «рабочий 5». У налётчиков — номер налётчика. */
        int number;
        Pos pos;
        int hp;
        int carry;
        String deathCause;
        /** Танк может стрелять с этого такта. */
        int readyAt;
        /** Налётчик: колония-цель; {@code 0} — выбрать. */
        int target;
        /** Отчего упало здоровье до нуля; {@code null} — не от оружия. */
        Cause killedBy;
        /** Колония, чей выстрел добил налётчика. */
        int killer;
        /** Купленные улучшения ({@link colony.api.Orders#upgrade}). */
        final EnumSet<Upgrade> upgrades = EnumSet.noneOf(Upgrade.class);

        UnitEntity(int id, int colonyId, UnitType type, Pos pos, int hp) {
            this.id = id;
            this.colonyId = colonyId;
            this.type = type;
            this.pos = pos;
            this.hp = hp;
        }

        /** Снимок с внутренним номером — для кадра повтора. */
        Unit snapshot() {
            return snapshot(id);
        }

        /** Снимок под номером {@code shownId} — так юнит видит колония. */
        Unit snapshot(int shownId) {
            return new Unit(shownId, colonyId, type, pos, hp, carry, upgrades);
        }

        String label() {
            return colonyId == 0 ? Messages.raider(number) : Messages.unit(type, number);
        }
    }

    static final class BaseEntity {
        final int id;
        final int colonyId;
        final Pos pos;
        int hp;
        /** Номер базы в колонии: первая — {@code 0}, следующие — из счёта юнитов колонии. */
        int number;

        BaseEntity(int id, int colonyId, Pos pos, int hp) {
            this.id = id;
            this.colonyId = colonyId;
            this.pos = pos;
            this.hp = hp;
        }

        Base snapshot() {
            return snapshot(id);
        }

        Base snapshot(int shownId) {
            return new Base(shownId, colonyId, pos, hp);
        }

        String label() {
            return Messages.base(number);
        }
    }

    /** Постройка: склад. Не ранится, содержания не требует. */
    static final class StructureEntity {
        final int id;
        final int colonyId;
        final Building type;
        final Pos pos;
        /** Номер постройки в колонии, с 1. */
        final int number;

        StructureEntity(int id, int colonyId, Building type, Pos pos, int number) {
            this.id = id;
            this.colonyId = colonyId;
            this.type = type;
            this.pos = pos;
            this.number = number;
        }

        /** Снимок с номером в колонии — так постройку видят колонии и повтор. */
        Structure snapshot() {
            return new Structure(number, colonyId, type, pos);
        }

        String label() {
            return Messages.structure(type, number);
        }
    }

    static final class DepositEntity {
        final int id;
        final Pos pos;
        final DepositKind kind;
        final int initial;
        final int homeOwner;
        /** Восстанавливается: обычные, богатые и центральная с карты; трофеи и жилы событий — нет. */
        final boolean renewable;
        int amount;

        DepositEntity(int id, Pos pos, DepositKind kind, int amount, int homeOwner, boolean renewable) {
            this.id = id;
            this.pos = pos;
            this.kind = kind;
            this.initial = amount;
            this.amount = amount;
            this.homeOwner = homeOwner;
            this.renewable = renewable;
        }
    }

    /** Снаряд в полёте. */
    static final class Shell {
        final int colonyId;
        final Direction dir;
        Pos pos;
        Pos from;
        int left;
        int hit;
        boolean done;
        /** Выпущен в этом такте: в клетке, где он стоит, ещё никого не задел. */
        boolean fresh = true;

        Shell(int colonyId, Pos pos, Direction dir, int left) {
            this.colonyId = colonyId;
            this.pos = pos;
            this.from = pos;
            this.dir = dir;
            this.left = left;
        }
    }

    /** Сколько колония добыла из залежи. */
    record Harvest(int colonyId, int depositId, DepositKind kind, Pos pos) {}

    /**
     * Что открыто колонии.
     *
     * @param abilities открытые возможности, только из тех, что есть в мире
     * @param hint      как открыть закрытую возможность — хвост отказа; вернула {@code null} — без подсказки
     * @param rules     правила, которые видит колония
     */
    record Unlocked(Set<Ability> abilities, Function<Ability, String> hint, colony.api.Rules rules) {}

    final RuleSet rules;
    /** Что открыто колонии, пока ей ничего не ограничили: все возможности мира. */
    private final Unlocked everything;
    final GameMap map;
    final SplittableRandom random;
    final int maxTicks;
    final boolean respawn;
    final List<ColonyState> colonies = new ArrayList<>();
    final TreeMap<Integer, UnitEntity> units = new TreeMap<>();
    final TreeMap<Integer, BaseEntity> bases = new TreeMap<>();
    final TreeMap<Integer, DepositEntity> deposits = new TreeMap<>();
    /** Постройки (склады) по внутреннему номеру. */
    final TreeMap<Integer, StructureEntity> structures = new TreeMap<>();
    final List<Shell> shells = new ArrayList<>();
    /** Такт открытия жилы события → её клетка (выбрана при объявлении). */
    final TreeMap<Integer, Pos> eventSpots = new TreeMap<>();
    /** Добыча: колония → залежь → сколько. */
    final TreeMap<Integer, TreeMap<Integer, Integer>> harvested = new TreeMap<>();
    /** Все залежи, что были в матче: id → вид и клетка (трофеи исчезают, а добыча из них считается). */
    final TreeMap<Integer, DepositEntity> everDeposit = new TreeMap<>();
    /** Номера чужих юнитов и баз в глазах каждой колонии. */
    final Sightings sightings = new Sightings();
    private final BaseEntity[] baseCell;
    private final DepositEntity[] depositCell;
    private final StructureEntity[] structureCell;
    /** Прочность завала в клетке; {@code 0} — завала нет (или разобран). */
    private final int[] rubble;
    /** Клетки, где в начале матча был завал, — для кадров повтора. */
    final List<Pos> rubbleCells = new ArrayList<>();
    private int nextStructureId = 1;
    /** Клетки, закрытые сценарием карты (обвал): стена, которой нет в карте. */
    private final boolean[] closedCell;
    /** Закрытые сценарием клетки в порядке обвала — для кадров повтора. */
    final List<Pos> closedCells = new ArrayList<>();
    /** События сценария карты, которые ещё не случились, по такту. */
    final List<ScriptEvent> script = new ArrayList<>();
    private final List<Pos> centreSources;
    private final boolean[] centreZone;
    private volatile PassGrid grid;
    private int gridVersion;
    private int[] raiderField;
    private int raiderFieldColony = -1;
    private int raiderFieldVersion = -1;
    int tick;
    /** Кто держит центр после последнего такта; {@code 0} — никто. */
    int centerHolder;
    private int nextId = 1;
    private int idBase;
    private int raiderSerial;
    private int raiderNumbers;
    private int overflow;
    private int nextDepositId = 1;

    World(MatchConfig cfg, GameMap map, List<String> names, List<Boolean> bots) {
        this.rules = cfg.rules();
        this.everything = new Unlocked(Set.copyOf(rules.abilities()), a -> null, rules.forColony());
        this.map = map;
        this.random = new SplittableRandom(cfg.seed());
        this.maxTicks = cfg.maxTicks();
        this.respawn = cfg.respawn();
        this.baseCell = new BaseEntity[map.width() * map.height()];
        this.depositCell = new DepositEntity[map.width() * map.height()];
        this.closedCell = new boolean[map.width() * map.height()];
        this.structureCell = new StructureEntity[map.width() * map.height()];
        this.rubble = new int[map.width() * map.height()];
        for (int y = 0; y < map.height(); y++) {
            for (int x = 0; x < map.width(); x++) {
                Pos p = new Pos(x, y);
                if (map.terrain(p) == Terrain.RUBBLE) {
                    rubble[index(p)] = Math.max(1, rules.rubbleDurability());
                    rubbleCells.add(p);
                }
            }
        }
        this.script.addAll(cfg.script());
        this.script.sort(Comparator.comparingInt(ScriptEvent::tick));
        for (GameMap.DepositSpot d : map.deposits()) {
            int owner = d.kind() == DepositKind.HOME ? map.homeOwner(d.pos()) : 0;
            DepositEntity e = new DepositEntity(d.id(), d.pos(), d.kind(), d.amount(), owner,
                    d.kind() != DepositKind.HOME);
            putDeposit(e);
            nextDepositId = Math.max(nextDepositId, d.id() + 1);
        }
        for (int c = 1; c <= names.size(); c++) {
            boolean bot = c - 1 < bots.size() && bots.get(c - 1);
            ColonyState state = new ColonyState(c, names.get(c - 1), bot, rules.startEnergy());
            state.unlocked = everything;
            colonies.add(state);
            BaseEntity b = new BaseEntity(nextId++, c, map.base(c), rules.baseHp());
            b.number = 0;
            bases.put(b.id, b);
            baseCell[index(b.pos)] = b;
        }
        for (int c = 1; c <= names.size(); c++) {
            for (Pos p : startCells(c, rules.startWorkers())) {
                putUnit(numbered(new UnitEntity(nextId++, c, UnitType.WORKER, p, rules.workerHp())));
            }
        }
        List<UnitEntity>[] taken = occupancy();
        for (MatchConfig.StartUnit s : cfg.units()) {
            if (s.colonyId() < 0 || s.colonyId() > names.size()) {
                throw new IllegalArgumentException("юнит в начале: нет колонии " + s.colonyId());
            }
            if (!free(s.pos()) || taken[index(s.pos())] != null) {
                throw new IllegalArgumentException("юнит в начале: клетка " + s.pos() + " занята или закрыта");
            }
            UnitEntity u = numbered(new UnitEntity(nextId++, s.colonyId(), s.type(), s.pos(), hp(s.type())));
            putUnit(u);
            taken[index(u.pos)] = List.of(u);
        }
        this.idBase = nextId;
        this.centreSources = map.centerCells().isEmpty() ? List.of(map.center()) : map.centerCells();
        this.centreZone = new boolean[map.width() * map.height()];
        int r2 = rules.centerRadius() * rules.centerRadius();
        boolean steps = rules.features().centerMajority();
        for (int y = 0; y < map.height(); y++) {
            for (int x = 0; x < map.width(); x++) {
                Pos p = new Pos(x, y);
                centreZone[index(p)] = steps ? centreSteps(p) <= rules.centerRadius() : centreDistance2(p) <= r2;
            }
        }
        refreshGrid();
    }

    int index(Pos p) {
        return p.y() * map.width() + p.x();
    }

    ColonyState colony(int id) {
        return colonies.get(id - 1);
    }

    /**
     * Открыть колонии {@code colonyId} только возможности {@code open} (из тех, что есть в мире). Закрытую
     * возможность её приказы не получат: отказ «склад ещё не открыт — {@code hint}».
     */
    void unlock(int colonyId, Set<Ability> open, Function<Ability, String> hint) {
        Set<Ability> allowed = Ability.none();
        allowed.addAll(open);
        allowed.retainAll(everything.abilities());
        colony(colonyId).unlocked = new Unlocked(Set.copyOf(allowed), hint == null ? a -> null : hint,
                rules.forColony(allowed));
    }

    boolean truce() {
        return tick < rules.truceTicks();
    }

    /** Юнит у своей базы, где он не ранится (флаг {@code homeGuard}): не дальше {@code homeRadius} шагов от неё. */
    boolean homeGuarded(UnitEntity u) {
        if (!rules.features().homeGuard() || u.colonyId <= 0) {
            return false;
        }
        for (BaseEntity b : bases.values()) {
            if (b.colonyId == u.colonyId && b.pos.manhattan(u.pos) <= rules.homeRadius()) {
                return true;
            }
        }
        return false;
    }

    /** Колония под защитой новичка в такте {@code t}. Налётчики (0) — никогда. */
    boolean protectedAt(int colonyId, int t) {
        return colonyId > 0 && t < colony(colonyId).protectedUntil;
    }

    BaseEntity baseAt(Pos p) {
        return map.inside(p) ? baseCell[index(p)] : null;
    }

    DepositEntity depositAt(Pos p) {
        return map.inside(p) ? depositCell[index(p)] : null;
    }

    StructureEntity structureAt(Pos p) {
        return map.inside(p) ? structureCell[index(p)] : null;
    }

    /** Клетку можно занять: внутри, не стена и не завал, без базы, постройки и залежи. Юниты не учитываются. */
    boolean free(Pos p) {
        return map.inside(p) && !wall(p) && baseAt(p) == null && depositAt(p) == null && structureAt(p) == null;
    }

    /** Стена: в карте, закрыта сценарием или завалена (пока завал не разобран). За краем карты — тоже. */
    boolean wall(Pos p) {
        return !map.inside(p) || map.terrain(p) == Terrain.WALL || closedCell[index(p)] || rubble[index(p)] > 0;
    }

    /** Прочность завала в клетке; {@code 0} — завала нет. */
    int rubbleAt(Pos p) {
        return map.inside(p) ? rubble[index(p)] : 0;
    }

    /** Копия прочности завалов по клеткам — для снимка колонии; {@code null}, если завалов на карте не было. */
    int[] rubbleCopy() {
        return rubbleCells.isEmpty() ? null : rubble.clone();
    }

    /**
     * Удар киркой по завалу: прочность на единицу меньше; на нуле клетка становится полом навсегда.
     *
     * @return клетка открылась этим ударом
     */
    boolean dig(Pos p) {
        int i = index(p);
        if (rubble[i] <= 0) {
            return false;
        }
        rubble[i]--;
        if (rubble[i] == 0) {
            refreshGrid();
            return true;
        }
        return false;
    }

    /** Новая постройка колонии в клетке {@code p}. */
    StructureEntity addStructure(int colonyId, Building type, Pos p) {
        StructureEntity s = new StructureEntity(nextStructureId++, colonyId, type, p,
                ++colony(colonyId).structureSerial);
        structures.put(s.id, s);
        structureCell[index(p)] = s;
        refreshGrid();
        return s;
    }

    /** Построек вида {@code type} у колонии. */
    int structureCount(int colonyId, Building type) {
        int n = 0;
        for (StructureEntity s : structures.values()) {
            if (s.colonyId == colonyId && s.type == type) {
                n++;
            }
        }
        return n;
    }

    /** Сколько несёт юнит: рабочий — {@code workerCarry}, с сумкой вдвое больше; танк — ничего. */
    int carryOf(UnitEntity u) {
        return u.type == UnitType.WORKER ? rules.carryOf(u.upgrades) : 0;
    }

    /** Закрыть клетку сценарием (обвал). */
    void close(Pos p) {
        if (!closedCell[index(p)]) {
            closedCell[index(p)] = true;
            closedCells.add(p);
            refreshGrid();
        }
    }

    /** Юниты {@code a} и {@code b} мешают друг другу: свои — всегда, чужие — кроме перемирия и лиг 1–2. */
    boolean conflict(int colonyA, int colonyB) {
        return colonyA == colonyB || !(truce() || rules.features().passableForeign());
    }

    /** Юниты в клетках: индекс клетки → юниты по возрастанию id. */
    List<UnitEntity>[] occupancy() {
        @SuppressWarnings("unchecked")
        List<UnitEntity>[] cells = new List[map.width() * map.height()];
        for (UnitEntity u : units.values()) {
            int i = index(u.pos);
            if (cells[i] == null) {
                cells[i] = new ArrayList<>(2);
            }
            cells[i].add(u);
        }
        return cells;
    }

    int hp(UnitType type) {
        return type == UnitType.TANK ? rules.tankHp() : rules.workerHp();
    }

    int cost(UnitType type) {
        return type == UnitType.TANK ? rules.tankCost() : rules.workerCost();
    }

    /** Новый номер из диапазона колонии ({@code 0} — налётчики). */
    int newId(int colonyId) {
        int n = colonies.size();
        int block = colonyId == 0 ? n : n - colonyId;
        int serial = colonyId == 0 ? raiderSerial++ : colony(colonyId).serial++;
        if (serial < ID_BLOCK) {
            return idBase + block * ID_BLOCK + serial;
        }
        return idBase + (n + 1) * ID_BLOCK + overflow++;
    }

    UnitEntity addUnit(int colonyId, UnitType type, Pos p) {
        UnitEntity u = numbered(new UnitEntity(newId(colonyId), colonyId, type, p, hp(type)));
        putUnit(u);
        return u;
    }

    /** Номер в колонии: следующий по счёту; у налётчиков — общий счёт налётчиков. */
    private UnitEntity numbered(UnitEntity u) {
        u.number = u.colonyId == 0 ? ++raiderNumbers : ++colony(u.colonyId).unitSerial;
        return u;
    }

    /** Свой юнит колонии по номеру в колонии; {@code null} — нет такого. */
    UnitEntity ownUnit(int colonyId, int number) {
        for (UnitEntity u : units.values()) {
            if (u.colonyId == colonyId && u.number == number) {
                return u;
            }
        }
        return null;
    }

    /** Своя база колонии по номеру в колонии; {@code null} — нет такой. */
    BaseEntity ownBase(int colonyId, int number) {
        for (BaseEntity b : bases.values()) {
            if (b.colonyId == colonyId && b.number == number) {
                return b;
            }
        }
        return null;
    }

    /** Под каким номером колония {@code observer} знает юнит: свой — номер в колонии, чужой — минус порядок встречи. */
    int shownId(int observer, UnitEntity u) {
        return u.colonyId == observer ? u.number : -sightings.unit(observer, u.id);
    }

    /** Под каким номером колония {@code observer} знает базу: своя — номер в колонии, чужая — минус порядок встречи. */
    int shownId(int observer, BaseEntity b) {
        return b.colonyId == observer ? b.number : -sightings.base(observer, b.id);
    }

    private void putUnit(UnitEntity u) {
        units.put(u.id, u);
    }

    BaseEntity addBase(int colonyId, Pos p) {
        BaseEntity b = new BaseEntity(newId(colonyId), colonyId, p, rules.baseHp());
        b.number = ownBase(colonyId, 0) == null && p.equals(map.base(colonyId)) ? 0 : ++colony(colonyId).unitSerial;
        bases.put(b.id, b);
        baseCell[index(p)] = b;
        refreshGrid();
        return b;
    }

    /**
     * Повреждает базу. Разрушение и гибель колонии — в фазе гибели ближайшего такта.
     */
    void damageBase(int baseId, int amount) {
        BaseEntity b = bases.get(baseId);
        if (b == null) {
            throw new IllegalArgumentException("нет базы " + baseId);
        }
        b.hp -= amount;
    }

    void removeBase(BaseEntity b) {
        bases.remove(b.id);
        baseCell[index(b.pos)] = null;
        refreshGrid();
    }

    /** Новая залежь, которая не восстанавливается: трофей или жила события. */
    DepositEntity addDeposit(DepositKind kind, Pos p, int amount) {
        DepositEntity d = new DepositEntity(nextDepositId++, p, kind, amount, 0, false);
        putDeposit(d);
        refreshGrid();
        return d;
    }

    private void putDeposit(DepositEntity d) {
        deposits.put(d.id, d);
        everDeposit.put(d.id, d);
        depositCell[index(d.pos)] = d;
    }

    void removeDeposit(DepositEntity d) {
        deposits.remove(d.id);
        depositCell[index(d.pos)] = null;
        refreshGrid();
    }

    void recordHarvest(int colonyId, DepositEntity d, int amount) {
        harvested.computeIfAbsent(colonyId, k -> new TreeMap<>()).merge(d.id, amount, Integer::sum);
        colony(colonyId).gained += amount;
    }

    /** Баз у колонии сейчас. */
    int baseCount(int colonyId) {
        int n = 0;
        for (BaseEntity b : bases.values()) {
            if (b.colonyId == colonyId) {
                n++;
            }
        }
        return n;
    }

    /** Снимок закрытых клеток для навигатора; потокобезопасен. */
    PassGrid grid() {
        return grid;
    }

    private void refreshGrid() {
        boolean[] b = new boolean[map.width() * map.height()];
        for (int y = 0; y < map.height(); y++) {
            for (int x = 0; x < map.width(); x++) {
                Pos p = new Pos(x, y);
                b[index(p)] = !free(p);
            }
        }
        grid = new PassGrid(++gridVersion, b);
    }

    /** Квадрат расстояния до ближайшей клетки центра. */
    int centreDistance2(Pos p) {
        int best = Integer.MAX_VALUE;
        for (Pos c : centreSources) {
            int dx = p.x() - c.x();
            int dy = p.y() - c.y();
            best = Math.min(best, dx * dx + dy * dy);
        }
        return best;
    }

    /** Шагов по прямой (|dx| + |dy|) до ближайшей клетки центра — радиус центра в лигах. */
    int centreSteps(Pos p) {
        int best = Integer.MAX_VALUE;
        for (Pos c : centreSources) {
            best = Math.min(best, p.manhattan(c));
        }
        return best;
    }

    /** Клетка в зоне центра: в лигах — не дальше {@code centerRadius} шагов, в 2б — по кругу. */
    boolean inCentre(Pos p) {
        return centreZone[index(p)];
    }

    /** Вся энергия колонии: запас и грузы её юнитов. */
    int totalEnergy(ColonyState c) {
        int sum = c.energy;
        for (UnitEntity u : units.values()) {
            if (u.colonyId == c.id) {
                sum += u.carry;
            }
        }
        return sum;
    }

    /**
     * Цель налёта: живая колония не под защитой с наибольшей энергией (запас и грузы), а с флагом
     * {@code scoreByIncome} — с наибольшим счётом; при равенстве — меньший номер.
     */
    ColonyState raidTarget() {
        ColonyState best = null;
        int bestEnergy = Integer.MIN_VALUE;
        for (ColonyState c : colonies) {
            if (!c.alive || protectedAt(c.id, tick)) {
                continue;
            }
            int e = rules.features().scoreByIncome() ? score(c) : totalEnergy(c);
            if (e > bestEnergy) {
                bestEnergy = e;
                best = c;
            }
        }
        return best;
    }

    /** Карта шагов до ближайшей базы колонии; кэш до изменения закрытых клеток. */
    int[] distanceToBases(int colonyId) {
        PassGrid g = grid;
        if (raiderField == null || raiderFieldColony != colonyId || raiderFieldVersion != g.version()) {
            int[] sources = bases.values().stream().filter(b -> b.colonyId == colonyId).mapToInt(b -> index(b.pos))
                    .toArray();
            raiderField = Navigator.bfs(g.blocked(), map.width(), map.height(), sources);
            raiderFieldColony = colonyId;
            raiderFieldVersion = g.version();
        }
        return raiderField;
    }

    /**
     * Место для жилы события: свободная клетка (не логово), дальняя от баз — не ближе медианы расстояний до
     * ближайшей базы. Выбор — случайностью движка.
     */
    Pos chooseEventSpot() {
        List<Pos> cells = new ArrayList<>();
        List<Integer> far = new ArrayList<>();
        for (int y = 0; y < map.height(); y++) {
            for (int x = 0; x < map.width(); x++) {
                Pos p = new Pos(x, y);
                if (!free(p) || map.cell(p) == 'L') {
                    continue;
                }
                int best = Integer.MAX_VALUE;
                for (Pos b : map.bases()) {
                    int dx = p.x() - b.x();
                    int dy = p.y() - b.y();
                    best = Math.min(best, dx * dx + dy * dy);
                }
                cells.add(p);
                far.add(best);
            }
        }
        if (cells.isEmpty()) {
            return map.center();
        }
        int[] sorted = far.stream().mapToInt(Integer::intValue).sorted().toArray();
        int median = sorted[sorted.length / 2];
        List<Pos> candidates = new ArrayList<>();
        for (int i = 0; i < cells.size(); i++) {
            if (far.get(i) >= median) {
                candidates.add(cells.get(i));
            }
        }
        return candidates.get(random.nextInt(candidates.size()));
    }

    /** Ближайшая к {@code p} свободная клетка без юнитов (поиском в ширину); {@code null} — нет такой. */
    Pos nearestOpen(Pos p) {
        List<UnitEntity>[] taken = occupancy();
        boolean[] seen = new boolean[map.width() * map.height()];
        ArrayDeque<Pos> queue = new ArrayDeque<>();
        queue.add(p);
        seen[index(p)] = true;
        while (!queue.isEmpty()) {
            Pos c = queue.poll();
            if (free(c) && taken[index(c)] == null) {
                return c;
            }
            for (Direction d : Direction.values()) {
                Pos n = c.step(d);
                if (map.inside(n) && !seen[index(n)] && !wall(n)) {
                    seen[index(n)] = true;
                    queue.add(n);
                }
            }
        }
        return null;
    }

    /**
     * Возвращает погибшую колонию на её место со стартовым набором. Клетка базы занята — не сейчас.
     *
     * @return вернулась ли
     */
    boolean respawn(ColonyState c, int t) {
        Pos at = map.base(c.id);
        List<UnitEntity>[] taken = occupancy();
        if (!free(at) || taken[index(at)] != null) {
            return false;
        }
        addBase(c.id, at);
        c.alive = true;
        c.deathTick = -1;
        c.respawnAt = -1;
        c.energy = rules.startEnergy();
        c.protectedUntil = t + 1 + rules.respawnProtectTicks();
        for (Pos p : startCells(c.id, rules.startWorkers())) {
            addUnit(c.id, UnitType.WORKER, p);
        }
        return true;
    }

    /**
     * Соседи клетки в порядке появления юнитов: ближе к геометрическому центру карты — раньше, при равенстве
     * N, E, S, W. Порядок не зависит от того, в какой четверти отражённой карты стоит база.
     */
    List<Pos> spawnOrder(Pos p) {
        List<Pos> out = new ArrayList<>(p.neighbours());
        out.sort(Comparator.comparingLong(this::centreDistance));
        return out;
    }

    /** Квадрат удвоенного расстояния до геометрического центра карты — целое число, без дробей. */
    long centreDistance(Pos p) {
        long dx = 2L * p.x() - (map.width() - 1);
        long dy = 2L * p.y() - (map.height() - 1);
        return dx * dx + dy * dy;
    }

    /**
     * Стартовые клетки рабочих: сначала соседи базы рядом с её домашней залежью, затем остальные соседи —
     * оба раза в порядке {@link #spawnOrder}, затем дальше поиском в ширину. Занятые клетки пропускаются.
     */
    private List<Pos> startCells(int colonyId, int count) {
        Pos base = map.base(colonyId);
        List<Pos> ring = new ArrayList<>();
        for (Pos n : spawnOrder(base)) {
            if (free(n) && nearOwnHome(n, colonyId)) {
                ring.add(n);
            }
        }
        for (Pos n : spawnOrder(base)) {
            if (free(n) && !ring.contains(n)) {
                ring.add(n);
            }
        }
        boolean[] seen = new boolean[map.width() * map.height()];
        ArrayDeque<Pos> queue = new ArrayDeque<>();
        for (Pos p : ring) {
            seen[index(p)] = true;
            queue.add(p);
        }
        List<Pos> out = new ArrayList<>();
        List<UnitEntity>[] taken = occupancy();
        while (!queue.isEmpty() && out.size() < count) {
            Pos p = queue.poll();
            if (taken[index(p)] == null) {
                out.add(p);
            }
            for (Direction d : Direction.values()) {
                Pos n = p.step(d);
                if (free(n) && !seen[index(n)]) {
                    seen[index(n)] = true;
                    queue.add(n);
                }
            }
        }
        return out;
    }

    private boolean nearOwnHome(Pos p, int colonyId) {
        for (Pos n : p.neighbours()) {
            DepositEntity d = depositAt(n);
            if (d != null && d.kind == DepositKind.HOME && d.homeOwner == colonyId) {
                return true;
            }
        }
        return false;
    }

    /** Счёт колонии — {@link Scoring}. */
    int score(ColonyState c) {
        return Scoring.score(rules, c);
    }

    @Override
    public String toString() {
        return "World[такт " + tick + ", юнитов " + units.size() + ", баз " + bases.size() + "]";
    }
}
