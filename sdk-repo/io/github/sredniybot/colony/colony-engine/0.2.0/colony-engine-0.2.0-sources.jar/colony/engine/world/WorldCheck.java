package colony.engine.world;

import colony.api.Pos;
import colony.engine.GameMap;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Проверки готовой карты и оценка интереса. Жёсткие проверки (провал — карта отбрасывается):
 * <ul>
 *     <li>всё связно: с разобранными завалами из любой свободной клетки дойти до любой;</li>
 *     <li>каждому месту при закрытых завалах доступны домашняя, ближние жилы, прииск и перевалы; сердце — с киркой;</li>
 *     <li>длины путей в коридорах: прииск через дверь 12–22 шагов, обход длиннее хотя бы на 7, но не дальше 34;
 *     ближняя 3–6, в кармане 5–12, жадный шаг до кармана не доходит;</li>
 *     <li>нет мелочи: скал из одной-двух клеток;</li>
 *     <li>нет ловушек: каждое свободное место у жилы достижимо без кирки (жилы сердца засыпаны целиком);</li>
 *     <li>проходы не тупиковые: от площадки перевала вне кварталов дойти до выходов хотя бы двух кварталов.</li>
 * </ul>
 */
final class WorldCheck {

    private WorldCheck() {}

    static WorldPlan.Report check(GameMap map, List<WorldPlan.Seat> seats, List<WorldPlan.Pass> passes, Pos heart,
                                  List<WorldPlan.PodInfo> pods) {
        Cells g = new Cells(map.width(), map.height(), Cells.ROCK);
        for (int y = 0; y < map.height(); y++) {
            String row = map.rows().get(y);
            for (int x = 0; x < map.width(); x++) {
                g.set(x, y, row.charAt(x));
            }
        }
        List<String> fail = new ArrayList<>();
        // мелочь
        List<Integer> sizes = new ArrayList<>();
        int[] comp = g.components(i -> g.a[i] == Cells.ROCK, true, sizes);
        int crumbs = 0;
        for (int s : sizes) {
            if (s <= 2) {
                crumbs++;
            }
        }
        if (crumbs > 0) {
            fail.add("скал из 1–2 клеток: " + crumbs);
        }
        // связность
        List<int[]> all = new ArrayList<>();
        for (WorldPlan.Seat s : seats) {
            all.addAll(g.spots(s.base().x(), s.base().y()));
        }
        int[] open = g.dist(all, true, 0);
        int lost = 0;
        for (int i = 0; i < g.a.length; i++) {
            if ((Cells.walk(g.a[i]) || g.a[i] == Cells.RUBBLE) && open[i] < 0) {
                lost++;
            }
        }
        if (lost > 0) {
            fail.add("недостижимых клеток: " + lost);
        }
        // место у жилы, до которого без кирки не дойти, — ловушка: колония выберет его и встанет навсегда
        int[] closed = g.dist(all, false, 0);
        int hidden = 0;
        for (int y = 0; y < g.h; y++) {
            for (int x = 0; x < g.w; x++) {
                if (!Cells.deposit(g.get(x, y))) {
                    continue;
                }
                for (int[] sp : g.spots(x, y)) {
                    // ниша домашней жилы — вплотную к базе: туда появляются, а не приходят
                    boolean niche = g.get(x, y) == 'H';
                    if (closed[g.idx(sp[0], sp[1])] < 0 && !niche) {
                        hidden++;
                    }
                }
            }
        }
        if (hidden > 0) {
            fail.add("мест у жил за завалом без обхода: " + hidden);
        }
        // пути мест
        List<WorldPlan.Paths> paths = new ArrayList<>();
        for (WorldPlan.Seat s : seats) {
            List<int[]> src = PodGen.walkOut(g, s.base().x(), s.base().y());
            int[] d = g.dist(src, false, 0);
            int[] dd = g.dist(src, true, 0);
            int n1 = g.toSpots(d, s.near1().x(), s.near1().y());
            int n2 = g.toSpots(d, s.near2().x(), s.near2().y());
            int home = g.spots(s.home().x(), s.home().y()).isEmpty() ? -1 : 0;
            WorldPlan.PodInfo pod = pods.get(s.pod());
            int mineDig = -1;
            int mineOpen = -1;
            for (int y = pod.mine().y() - 3; y <= pod.mine().y() + 3; y++) {
                for (int x = pod.mine().x() - 3; x <= pod.mine().x() + 3; x++) {
                    if (g.get(x, y) != '$') {
                        continue;
                    }
                    mineOpen = minPos(mineOpen, g.toSpots(d, x, y));
                    mineDig = minPos(mineDig, g.toSpots(dd, x, y));
                }
            }
            int pass = -1;
            for (WorldPlan.Pass p : passes) {
                for (Pos q : p.deposits()) {
                    // жила перевала под обвалом: путь — до соседней клетки завала
                    for (int[] n : Cells.DIRS) {
                        if (g.walk(q.x() + n[0], q.y() + n[1], true)) {
                            pass = minPos(pass, dd[g.idx(q.x() + n[0], q.y() + n[1])]);
                        }
                    }
                }
            }
            int hd = -1;
            if (heart != null) {
                int[][] ha = {{-2, 0}, {2, 0}, {0, -2}, {0, 2}};
                for (int[] a : ha) {
                    // жилы сердца засыпаны: путь — до соседней клетки завала, его прокапывают
                    for (int[] n : Cells.DIRS) {
                        int x = heart.x() + a[0] + n[0];
                        int y = heart.y() + a[1] + n[1];
                        if (g.walk(x, y, true)) {
                            hd = minPos(hd, dd[g.idx(x, y)]);
                        }
                    }
                }
            }
            boolean trap = true;
            for (int[] b : src) {
                for (int[] sp : g.spots(s.near2().x(), s.near2().y())) {
                    if (g.greedyReaches(b[0], b[1], sp[0], sp[1])) {
                        trap = false;
                    }
                }
            }
            paths.add(new WorldPlan.Paths(s.seat(), n1, n2, mineDig, mineOpen, pass, hd, trap));
            String who = "место " + s.seat() + ": ";
            if (home < 0) {
                fail.add(who + "домашняя жила недоступна");
            }
            if (n1 < 3 || n1 > 6) {
                fail.add(who + "ближняя жила в " + n1 + " шагах");
            }
            if (n2 < 5 || n2 > 12 || !trap) {
                fail.add(who + "жила в кармане в " + n2 + " шагах" + (trap ? "" : ", жадный шаг доходит"));
            }
            if (mineDig < PodGen.MINE_DIG_MIN || mineDig > PodGen.MINE_DIG_MAX) {
                fail.add(who + "прииск через дверь в " + mineDig + " шагах");
            }
            if (mineOpen < 0 || mineOpen - mineDig < PodGen.DETOUR_MIN || mineOpen > PodGen.MINE_OPEN_MAX) {
                fail.add(who + "обход к прииску " + mineOpen + " шагов при двери " + mineDig);
            }
            if (pass < 0 && !passes.isEmpty()) {
                fail.add(who + "ни одной ничейной жилы не достать");
            }
            if (heart != null && hd < 0) {
                fail.add(who + "сердце мира не достать");
            }
        }
        // проходы не тупиковые
        boolean[] inPod = new boolean[g.a.length];
        for (WorldPlan.PodInfo p : pods) {
            for (int y = p.y0(); y < p.y0() + p.size(); y++) {
                for (int x = p.x0(); x < p.x0() + p.size(); x++) {
                    inPod[g.idx(x, y)] = true;
                }
            }
        }
        int deadPasses = 0;
        for (WorldPlan.Pass p : passes) {
            // площадка перевала вокруг жилы (сама жила под обвалом)
            List<int[]> src = new ArrayList<>();
            for (Pos q : p.deposits()) {
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dx = -2; dx <= 2; dx++) {
                        if (g.walk(q.x() + dx, q.y() + dy, false)) {
                            src.add(new int[] {q.x() + dx, q.y() + dy});
                        }
                    }
                }
            }
            int[] d = outside(g, inPod, src);
            int exits = 0;
            for (WorldPlan.PodInfo pod : pods) {
                for (int k = 0; k < pod.size(); k++) {
                    int[][] edge = {{pod.x0() + k, pod.y0()}, {pod.x0() + k, pod.y0() + pod.size() - 1},
                            {pod.x0(), pod.y0() + k}, {pod.x0() + pod.size() - 1, pod.y0() + k}};
                    for (int[] e : edge) {
                        if (Cells.walk(g.get(e[0], e[1]))) {
                            for (int[] dir : Cells.DIRS) {
                                int nx = e[0] + dir[0];
                                int ny = e[1] + dir[1];
                                if (g.in(nx, ny) && !inPod[g.idx(nx, ny)] && d[g.idx(nx, ny)] >= 0) {
                                    exits++;
                                }
                            }
                        }
                    }
                }
            }
            if (exits < 2 * 2) {
                deadPasses++;
            }
        }
        if (deadPasses > 0) {
            fail.add("тупиковых проходов: " + deadPasses);
        }
        Map<String, Double> parts = score(g, paths, inPod);
        double total = 0;
        for (double v : parts.values()) {
            total += v;
        }
        return new WorldPlan.Report(List.copyOf(fail), List.copyOf(paths), total, parts);
    }

    /** Поиск в ширину только вне кварталов (завалы закрыты). */
    private static int[] outside(Cells g, boolean[] inPod, List<int[]> src) {
        int[] d = new int[g.a.length];
        java.util.Arrays.fill(d, -1);
        java.util.ArrayDeque<Integer> q = new java.util.ArrayDeque<>();
        for (int[] s : src) {
            int i = g.idx(s[0], s[1]);
            if (!inPod[i] && d[i] < 0) {
                d[i] = 0;
                q.add(i);
            }
        }
        while (!q.isEmpty()) {
            int i = q.poll();
            int x = i % g.w;
            int y = i / g.w;
            for (int[] dir : Cells.DIRS) {
                int nx = x + dir[0];
                int ny = y + dir[1];
                if (g.walk(nx, ny, false) && !inPod[g.idx(nx, ny)] && d[g.idx(nx, ny)] < 0) {
                    d[g.idx(nx, ny)] = d[i] + 1;
                    q.add(g.idx(nx, ny));
                }
            }
        }
        return d;
    }

    private static int minPos(int a, int b) {
        if (b < 0) {
            return a;
        }
        return a < 0 ? b : Math.min(a, b);
    }

    /**
     * Оценка интереса, по слагаемым:
     * <ul>
     *     <li>{@code choice} — выбор «копать или обходить»: средний выигрыш двери над обходом, до 12 шагов — 1;</li>
     *     <li>{@code fair} — минус разброс между местами пути до ничейной жилы и до сердца (это не равенство по
     *     построению, его даёт расстановка кварталов);</li>
     *     <li>{@code relief} — доля скалы в проходах и диких землях около трети и нет пустых площадей больше 9×9;</li>
     *     <li>{@code dead} — минус тупики: клетки пола с одним выходом вне кварталов.</li>
     * </ul>
     */
    private static Map<String, Double> score(Cells g, List<WorldPlan.Paths> paths, boolean[] inPod) {
        Map<String, Double> parts = new LinkedHashMap<>();
        double choice = 0;
        int passMin = Integer.MAX_VALUE;
        int passMax = 0;
        int heartMin = Integer.MAX_VALUE;
        int heartMax = 0;
        for (WorldPlan.Paths p : paths) {
            choice += Math.min(1.0, (p.mineOpen() - p.mineDig()) / 12.0);
            passMin = Math.min(passMin, p.pass());
            passMax = Math.max(passMax, p.pass());
            if (p.heart() >= 0) {
                heartMin = Math.min(heartMin, p.heart());
                heartMax = Math.max(heartMax, p.heart());
            }
        }
        parts.put("choice", paths.isEmpty() ? 0 : choice / paths.size());
        double spread = (passMax - passMin) / 6.0 + (heartMax >= heartMin ? (heartMax - heartMin) / 60.0 : 0);
        parts.put("fair", -spread);
        int outsideCells = 0;
        int rock = 0;
        for (int i = 0; i < g.a.length; i++) {
            if (!inPod[i]) {
                outsideCells++;
                if (g.a[i] == Cells.ROCK) {
                    rock++;
                }
            }
        }
        double share = outsideCells == 0 ? 0.33 : (double) rock / outsideCells;
        double relief = 1 - Math.min(1, Math.abs(share - 0.33) / 0.2);
        // пустые площади: наибольший квадрат пола вне кварталов
        int[] sq = new int[g.a.length];
        int big = 0;
        for (int y = 0; y < g.h; y++) {
            for (int x = 0; x < g.w; x++) {
                int i = g.idx(x, y);
                if (inPod[i] || g.a[i] != Cells.FLOOR) {
                    continue;
                }
                int v = 1;
                if (x > 0 && y > 0) {
                    v = 1 + Math.min(sq[i - 1], Math.min(sq[i - g.w], sq[i - g.w - 1]));
                }
                sq[i] = v;
                big = Math.max(big, v);
            }
        }
        if (big > 9) {
            relief -= (big - 9) * 0.1;
        }
        parts.put("relief", relief * 0.5);
        int dead = 0;
        for (int y = 1; y < g.h - 1; y++) {
            for (int x = 1; x < g.w - 1; x++) {
                int i = g.idx(x, y);
                if (inPod[i] || !Cells.walk(g.a[i])) {
                    continue;
                }
                int open = 0;
                for (int[] d : Cells.DIRS) {
                    char c = g.get(x + d[0], y + d[1]);
                    if (Cells.walk(c) || c == Cells.RUBBLE || Cells.deposit(c)) {
                        open++;
                    }
                }
                if (open <= 1) {
                    dead++;
                }
            }
        }
        parts.put("dead", -dead * 0.01);
        return parts;
    }
}
