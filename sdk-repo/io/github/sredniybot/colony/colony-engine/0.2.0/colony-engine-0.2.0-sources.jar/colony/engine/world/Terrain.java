package colony.engine.world;

import java.util.SplittableRandom;

/**
 * Скалы по облику местности: шум значений, гряды, провалы и клеточный автомат «4–5», который сглаживает их в цельные
 * массивы. Работает на прямоугольнике {@code w × h}; симметрию квартала обеспечивает вызывающий.
 */
final class Terrain {

    private Terrain() {}

    /** Гладкий шум значений в [0, 1] с шагом решётки {@code cell} клеток. */
    static double[] valueNoise(int w, int h, double cell, SplittableRandom r) {
        int gw = (int) Math.ceil(w / cell) + 2;
        int gh = (int) Math.ceil(h / cell) + 2;
        double[] lat = new double[gw * gh];
        for (int i = 0; i < lat.length; i++) {
            lat[i] = r.nextDouble();
        }
        double ox = r.nextDouble() * cell;
        double oy = r.nextDouble() * cell;
        double[] out = new double[w * h];
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                double fx = (x + ox) / cell;
                double fy = (y + oy) / cell;
                int ix = (int) fx;
                int iy = (int) fy;
                double tx = smooth(fx - ix);
                double ty = smooth(fy - iy);
                double a = lat[iy * gw + ix];
                double b = lat[iy * gw + ix + 1];
                double c = lat[(iy + 1) * gw + ix];
                double d = lat[(iy + 1) * gw + ix + 1];
                out[y * w + x] = (a + (b - a) * tx) * (1 - ty) + (c + (d - c) * tx) * ty;
            }
        }
        return out;
    }

    private static double smooth(double t) {
        return t * t * (3 - 2 * t);
    }

    /** Два слоя шума: крупный и мелкий, вес мелкого {@code detail}. */
    static double[] fractal(int w, int h, double cell, double detail, SplittableRandom r) {
        double[] a = valueNoise(w, h, cell, r);
        double[] b = valueNoise(w, h, Math.max(1.5, cell / 2.5), r);
        for (int i = 0; i < a.length; i++) {
            a[i] = (a[i] + detail * b[i]) / (1 + detail);
        }
        return a;
    }

    /** Порог, при котором доля клеток выше него — {@code share}. */
    static double threshold(double[] v, double share) {
        double[] s = v.clone();
        java.util.Arrays.sort(s);
        int k = (int) Math.round((1 - share) * (s.length - 1));
        return s[Math.max(0, Math.min(s.length - 1, k))];
    }

    /**
     * Гряда: путь с инерцией из {@code (x, y)} под углом {@code angle} (радианы), длиной {@code len}, толщиной 1–2.
     * Пишет {@code true} в {@code rock}.
     */
    static void ridge(boolean[] rock, int w, int h, double x, double y, double angle, int len, double wobble,
                      boolean thick, SplittableRandom r) {
        double a = angle;
        for (int i = 0; i < len; i++) {
            int ix = (int) Math.round(x);
            int iy = (int) Math.round(y);
            mark(rock, w, h, ix, iy);
            if (thick) {
                // толщина поперёк направления
                int px = (int) Math.round(x - Math.sin(a) * 0.9);
                int py = (int) Math.round(y + Math.cos(a) * 0.9);
                mark(rock, w, h, px, py);
            }
            a += (r.nextDouble() - 0.5) * wobble;
            x += Math.cos(a);
            y += Math.sin(a);
        }
    }

    /** Круг радиуса {@code rad} с центром {@code (cx, cy)}. */
    static void disc(boolean[] rock, int w, int h, double cx, double cy, double rad) {
        int r0 = (int) Math.ceil(rad);
        for (int dy = -r0; dy <= r0; dy++) {
            for (int dx = -r0; dx <= r0; dx++) {
                if (dx * dx + dy * dy <= rad * rad) {
                    mark(rock, w, h, (int) Math.round(cx) + dx, (int) Math.round(cy) + dy);
                }
            }
        }
    }

    private static void mark(boolean[] rock, int w, int h, int x, int y) {
        if (x >= 0 && y >= 0 && x < w && y < h) {
            rock[y * w + x] = true;
        }
    }

    /**
     * Шаг клеточного автомата «4–5»: камень, если вокруг не меньше 5 камней, или он уже камень и вокруг не меньше 4.
     * За краем — камень. Клетки {@code lock} не меняются.
     */
    static boolean[] smooth(boolean[] rock, int w, int h, boolean[] lock) {
        boolean[] out = rock.clone();
        for (int y = 0; y < h; y++) {
            for (int x = 0; x < w; x++) {
                int i = y * w + x;
                if (lock != null && lock[i]) {
                    continue;
                }
                int n = 0;
                for (int[] d : Cells.RING8) {
                    int nx = x + d[0];
                    int ny = y + d[1];
                    if (nx < 0 || ny < 0 || nx >= w || ny >= h || rock[ny * w + nx]) {
                        n++;
                    }
                }
                out[i] = n >= 5 || rock[i] && n >= 4;
            }
        }
        return out;
    }

    /** Скалы облика {@code a} на прямоугольнике; доля камня — около {@code density}. */
    static boolean[] rocks(Archetype a, int w, int h, double density, SplittableRandom r) {
        boolean[] rock = new boolean[w * h];
        switch (a) {
            case PLATEAU -> {
                double[] n = fractal(w, h, 7.5, 0.35, r);
                double t = threshold(n, density * 1.05);
                for (int i = 0; i < rock.length; i++) {
                    rock[i] = n[i] > t;
                }
                rock = smooth(rock, w, h, null);
                rock = smooth(rock, w, h, null);
                rock = smooth(rock, w, h, null);
            }
            case ROCK_MAZE -> {
                double[] n = fractal(w, h, 3.2, 0.6, r);
                double t = threshold(n, density * 1.25);
                for (int i = 0; i < rock.length; i++) {
                    rock[i] = n[i] > t;
                }
                rock = smooth(rock, w, h, null);
                rock = smooth(rock, w, h, null);
            }
            case CANYONS -> {
                double base = r.nextDouble() * Math.PI;
                int count = Math.max(2, (int) Math.round(w * h * density / 13.0));
                for (int i = 0; i < count; i++) {
                    double ang = base + (r.nextDouble() - 0.5) * 0.7 + (r.nextBoolean() ? 0 : Math.PI);
                    ridge(rock, w, h, r.nextDouble() * w, r.nextDouble() * h, ang, 7 + r.nextInt(10), 0.5,
                            r.nextDouble() < 0.55, r);
                }
            }
            case SINKHOLES -> {
                int tries = 0;
                double filled = 0;
                while (filled < density * w * h && tries++ < 400) {
                    double rad = 1.4 + r.nextDouble() * 1.9;
                    double cx = r.nextDouble() * w;
                    double cy = r.nextDouble() * h;
                    boolean free = true;
                    int r0 = (int) Math.ceil(rad) + 2;
                    for (int dy = -r0; dy <= r0 && free; dy++) {
                        for (int dx = -r0; dx <= r0 && free; dx++) {
                            int x = (int) Math.round(cx) + dx;
                            int y = (int) Math.round(cy) + dy;
                            if (x >= 0 && y >= 0 && x < w && y < h && rock[y * w + x]
                                    && dx * dx + dy * dy <= (rad + 2) * (rad + 2)) {
                                free = false;
                            }
                        }
                    }
                    if (free) {
                        disc(rock, w, h, cx, cy, rad);
                        filled += Math.PI * rad * rad;
                    }
                }
            }
        }
        return rock;
    }
}
