package colony.engine.world;

import colony.api.DepositKind;
import colony.api.Pos;
import colony.engine.GameMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

/**
 * Карта мира под группу: {@code seats} мест, одно зерно — одна карта.
 *
 * <p>Как собирается:
 * <ol>
 *     <li><b>Раскладка.</b> Места округляются вверх до кратного 4 и делятся на кварталы по 4 (18 -> 20 = 5 × 4; лишние
 *     места играет «бронза»), кварталы — почти квадратной сеткой. Квартал на 2 — только запасная раскладка. Между ними — скальные гряды шириной 5, через середину мира — 9. Лишние клетки сетки — дикие
 *     земли.</li>
 *     <li><b>Скелет сектора</b> — один на мир: база, ниша домашней жилы, ближняя жила, карман, выход, сторона
 *     «вертушки». Его находит поиск на первом квартале; остальные кварталы повторяют скелет, а рельеф, завалы и край
 *     кратера строят каждый из своего зерна ({@link PodGen}). Скелет общий потому, что кварталы со своими ближними
 *     жилами при тех же длинах путей отличались по доходу одинаковых колоний до ±55 %.</li>
 *     <li><b>Перевалы.</b> Выходы кварталов — «вертушкой», по одному на сторону, у соседей разнесены. Перевал через
 *     гряду — изогнутый проход, симметричный относительно своей середины (поворот на 180°): обоим соседям до
 *     середины одинаково. Посередине — площадка и ничейная жила, если оба выхода принадлежат занятым секторам.</li>
 *     <li><b>Тропы.</b> По гряде от перевала к перекрёсткам — извилистая тропа. Кольцевой тропы нет: выход к краю мира —
 *     отрог вдоль края до ближайшей тропы по гряде.</li>
 *     <li><b>Сердце</b> — четыре самые богатые жилы посреди мира (в середине центрального перевала или на центральном
 *     перекрёстке), засыпанные обвалом: до них только с киркой.</li>
 *     <li><b>Проверки и оценка</b> ({@link WorldCheck}); из нескольких кандидатов берётся лучший.</li>
 * </ol>
 */
public final class WorldGen {

    /** Меньше двух мест мир не строит. */
    public static final int MIN_SEATS = 2;
    /** Больше 30 мест не бывает: на карте 35 знаков баз, на проекторе больше не прочитать. */
    public static final int MAX_SEATS = 30;

    /** Запасы жил: обычная (ближние и ничейные), богатая (прииск), сердце мира. */
    static final int NORMAL = 1000;
    static final int RICH = 20000;
    static final int CENTER = 50000;

    static final int SEAM = 5;
    static final int SEAM_CENTRAL = 9;
    static final int BAND = 4;

    /**
     * Настройки сборки.
     *
     * @param candidates сколько миров собрать, чтобы выбрать лучший по оценке интереса
     * @param lair       ставить логово налётчиков (нужно, если в правилах мира есть налётчики)
     */
    public record Options(int candidates, boolean lair) {
        public static final Options DEFAULT = new Options(3, false);
    }

    /** Пробовать мир из четверти до крепости ({@code -Dworldgen.quarter=true}). */
    static boolean QUARTER = Boolean.getBoolean("worldgen.quarter");

    /** Арена: если строгие проверки четверти не прошла ни одна попытка, взять лучший эскиз ({@code -Dworldgen.relaxed=true}). */
    static boolean RELAXED = Boolean.getBoolean("worldgen.relaxed");

    /**
     * Карта общей арены ({@link ArenaGen}) вместо крепости и мира из четверти ({@code -Dworldgen.arena=true}); от
     * {@link ArenaGen#MIN_SEATS} мест.
     */
    static boolean ARENA = Boolean.getBoolean("worldgen.arena");

    /**
     * Карта общей арены на {@code seats} мест — без флага, для превью и замеров; {@code null} — мест меньше
     * {@link ArenaGen#MIN_SEATS}.
     */
    public static WorldPlan arenaPlan(int seats, long seed) {
        if (seatsOnMap(seats) < ArenaGen.MIN_SEATS) {
            return null;
        }
        long t0 = System.nanoTime();
        WorldPlan p = ArenaGen.plan(seats, seatsOnMap(seats), seed, Options.DEFAULT.candidates());
        long ms = (System.nanoTime() - t0) / 1_000_000;
        return p == null ? null : new WorldPlan(p.map(), p.archetype(), seats, p.pods(), p.seats(), p.passes(),
                p.heart(), p.lair(), p.report(), p.candidates(), ms);
    }

    /** Карта общей арены на {@code seats} мест; мест меньше {@link ArenaGen#MIN_SEATS} — обычный мир. */
    public static GameMap arena(int seats, long seed) {
        WorldPlan p = arenaPlan(seats, seed);
        return p != null ? p.map() : generate(seats, seed);
    }

    /** Отладка арены: почему попытки отброшены (с {@code -Dworldgen.why=true}). */
    public static Map<String, Integer> arenaWhy() {
        return Map.copyOf(ArenaGen.WHY);
    }

    /**
     * Эскиз мира из четверти на {@code seats} мест: лучшая из 40 попыток, даже не прошедшая проверки (они — в
     * {@code report().failures()}); {@code null} — ни одна попытка не собралась. Для превью и разбора, не для игры.
     */
    public static WorldPlan quarterSketch(int seats, long seed) {
        return QuarterGen.sketch(seats, seatsOnMap(seats), seed, 40);
    }

    /** Отладка: вернуть и непрошедший мир (с причинами в отчёте), чтобы на него посмотреть. */
    static boolean DEBUG = Boolean.getBoolean("worldgen.debug");

    private WorldGen() {}

    /**
     * Карта мира на {@code seats} мест (2–30) по зерну {@code seed}. Число мест округляется вверх до кратного 4
     * ({@link #seatsOnMap}): лишние места — с номерами после {@code seats} — играет «бронза».
     */
    public static GameMap generate(int seats, long seed) {
        return plan(seats, seed, Options.DEFAULT).map();
    }

    /** Мир с пояснениями: из чего собран, проверки, пути мест. */
    public static WorldPlan plan(int seats, long seed, Options options) {
        if (seats < MIN_SEATS || seats > MAX_SEATS) {
            throw new IllegalArgumentException("мест должно быть от " + MIN_SEATS + " до " + MAX_SEATS + ", а не "
                    + seats);
        }
        long t0 = System.nanoTime();
        // арена — по флагу, от 12 мест: лучший из попыток мир, даже если строгие проверки не прошёл (замечания — в
        // отчёте); меньше мест — как без флага
        WorldPlan best = ARENA && !options.lair() && seatsOnMap(seats) >= ArenaGen.MIN_SEATS
                ? ArenaGen.plan(seats, seatsOnMap(seats), seed, options.candidates()) : null;
        // мир из четверти — только по флагу: пока его проверки почти не проходят (отчёт, «Итерация 4»); основное
        // устройство — крепость. Логово налётчиков одно на мир — только в крепости
        if (best == null) {
            best = options.lair() || !QUARTER ? null : QuarterGen.plan(seats, seatsOnMap(seats), seed, options);
        }
        if (best == null && QUARTER && RELAXED && !options.lair()) {
            // арена: строгая честность не нужна — берём лучший эскиз из четверти, даже с замечаниями
            best = QuarterGen.sketch(seats, seatsOnMap(seats), seed, 40);
        }
        if (best == null) {
            best = build(seats, seed, options, false);
        }
        if (best == null) {
            // запасной путь: квартал на два места вместо округления до четвёрок
            best = build(seats, seed, options, true);
        }
        if (best == null) {
            throw new IllegalStateException("не удалось собрать мир на " + seats + " мест, зерно " + seed
                    + (lastFailure == null ? "" : ": " + lastFailure));
        }
        long ms = (System.nanoTime() - t0) / 1_000_000;
        return new WorldPlan(best.map(), best.archetype(), seats, best.pods(), best.seats(), best.passes(),
                best.heart(), best.lair(), best.report(), best.candidates(), ms);
    }

    private static volatile List<String> lastFailure;

    /** Лучший из кандидатов; {@code pairs} — запасная раскладка с кварталом на два места. */
    static WorldPlan build(int seats, long seed, Options options, boolean pairs) {
        WorldPlan best = null;
        WorldPlan failed = null;
        int built = 0;
        int k = 0;
        int want = Math.max(1, options.candidates());
        while (k < want || best == null && k < want + 40) {
            WorldPlan cand = new Builder(seats, seed, k, options, pairs).build();
            k++;
            if (cand == null) {
                continue;
            }
            built++;
            if (cand.report().ok() && (best == null || cand.report().score() > best.report().score())) {
                best = cand;
            } else if (!cand.report().ok()) {
                failed = cand;
            }
        }
        if (best == null && DEBUG && failed != null) {
            best = failed;
        }
        if (best == null) {
            lastFailure = failed == null ? null : failed.report().failures();
            return null;
        }
        return new WorldPlan(best.map(), best.archetype(), seats, best.pods(), best.seats(), best.passes(),
                best.heart(), best.lair(), best.report(), built, 0);
    }

    static long mix(long z) {
        z = (z ^ (z >>> 33)) * 0xff51afd7ed558ccdL;
        z = (z ^ (z >>> 33)) * 0xc4ceb9fe1a85ec53L;
        return z ^ (z >>> 33);
    }

    /** Облик мира по зерну: один на все кандидаты. */
    public static Archetype archetypeOf(long seed) {
        return Archetype.values()[(int) Math.floorMod(mix(seed ^ 0x5eedL), Archetype.values().length)];
    }

    /**
     * Сколько мест на карте: число округляется вверх до кратного 4 — кварталы все на четыре места. Лишние места (до
     * трёх) играет «бронза»; они разнесены по разным кварталам.
     */
    public static int seatsOnMap(int seats) {
        return (seats + 3) / 4 * 4;
    }

    /** Запасная раскладка: нечётное число дополняется до чётного, пара мест — квартал на два. */
    static int seatsOnMapPairs(int seats) {
        return seats + (seats & 1);
    }

    // ---------------------------------------------------------------------------------------------------------------

    private static final class Builder {
        final int asked;
        final int seats;
        final long seed;
        final Options o;
        final SplittableRandom r;
        final Archetype arch;
        int pSize;
        int c;
        int exit;
        boolean mirror;
        PodGen.Params params4;
        int cols;
        int rows;
        int[] x0;
        int[] y0;
        int[] seamW;
        int[] seamH;
        int w;
        int h;
        Cells g;
        boolean[] lock;
        boolean[] inCell;
        /** Клетка внутри клетки сетки (квартал или дикие земли). */
        boolean[] inGrid;
        /** Какие клетки нельзя трогать рельефом проходов: кварталы, края, перевалы, сердце. */
        boolean[] keep;
        /** Что в клетке сетки: 4, 2 — квартал на столько мест; 0 — дикие земли. */
        int[][] kind;
        PodGen.Pod[][] podAt;
        final List<WorldPlan.PodInfo> podInfos = new ArrayList<>();
        final List<WorldPlan.Seat> seatList = new ArrayList<>();
        final List<WorldPlan.Pass> passes = new ArrayList<>();
        final List<Pos> passCenters = new ArrayList<>();
        final List<GameMap.Region> regions = new ArrayList<>();
        /** Номер места по клетке сетки и четверти квартала (0 — СЗ, 1 — СВ, 2 — ЮВ, 3 — ЮЗ); 0 — пусто. */
        int[][][] seatOf;
        Pos heart;
        Pos lair;

        Builder(int asked, long seed, int candidate, Options o, boolean pairs) {
            this.asked = asked;
            this.seats = pairs ? seatsOnMapPairs(asked) : seatsOnMap(asked);
            this.seed = seed;
            this.o = o;
            this.r = new SplittableRandom(mix(seed * 31 + candidate * 1_000_003L + asked));
            this.arch = archetypeOf(seed);
        }

        WorldPlan build() {
            layout();
            if (!pods()) {
                return null;
            }
            canvas();
            placePods();
            wilds();
            seamsBase();
            passesAndTrails();
            lairOnRing();
            heart();
            relief();
            cleanup();
            marks();
            names();
            Map<DepositKind, Integer> amounts = new EnumMap<>(DepositKind.class);
            String all = String.join("", g.rows());
            if (all.indexOf('*') >= 0) {
                amounts.put(DepositKind.NORMAL, NORMAL);
            }
            if (all.indexOf('$') >= 0) {
                amounts.put(DepositKind.RICH, RICH);
            }
            if (all.indexOf('C') >= 0) {
                amounts.put(DepositKind.CENTER, CENTER);
            }
            GameMap map = GameMap.of("world-" + seats + "-" + seed, seats, g.rows(), amounts, regions);
            WorldPlan.Report report = WorldCheck.check(map, seatList, passes, heart, podInfos);
            return new WorldPlan(map, arch, asked, List.copyOf(podInfos), List.copyOf(seatList), List.copyOf(passes),
                    heart, lair, report, 1, 0);
        }

        // ---- раскладка ----

        void layout() {
            int n4 = seats / 4;
            int n2 = (seats % 4) / 2;
            int pods = n4 + n2;
            int[] grid = switch (pods) {
                case 1 -> new int[] {1, 1};
                case 2 -> new int[] {2, 1};
                case 3, 4 -> new int[] {2, 2};
                case 5, 6 -> new int[] {3, 2};
                default -> new int[] {4, 2};
            };
            cols = grid[0];
            rows = grid[1];
            pSize = pods <= 4 ? 31 : 29;
            c = pSize / 2;
            kind = new int[cols][rows];
            List<int[]> cells = new ArrayList<>();
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    cells.add(new int[] {i, j});
                }
            }
            int wild = cols * rows - pods;
            List<int[]> wildCands = new ArrayList<>();
            for (int[] cell : cells) {
                boolean middle = cols <= 2 || cell[0] > 0 && cell[0] < cols - 1;
                if (middle) {
                    wildCands.add(cell);
                }
            }
            for (int i = 0; i < cols; i++) {
                Arrays.fill(kind[i], 4);
            }
            for (int k = 0; k < wild; k++) {
                int[] cell = wildCands.remove(r.nextInt(wildCands.size()));
                kind[cell[0]][cell[1]] = 0;
            }
            if (n2 > 0) {
                List<int[]> podCells = new ArrayList<>();
                for (int[] cell : cells) {
                    if (kind[cell[0]][cell[1]] == 4) {
                        podCells.add(cell);
                    }
                }
                int[] cell = podCells.get(r.nextInt(podCells.size()));
                kind[cell[0]][cell[1]] = 2;
            }
            seamW = new int[Math.max(0, cols - 1)];
            for (int i = 0; i < seamW.length; i++) {
                seamW[i] = cols % 2 == 0 && i == cols / 2 - 1 ? SEAM_CENTRAL : SEAM;
            }
            seamH = new int[Math.max(0, rows - 1)];
            for (int j = 0; j < seamH.length; j++) {
                seamH[j] = rows % 2 == 0 && j == rows / 2 - 1 ? SEAM_CENTRAL : SEAM;
            }
            x0 = new int[cols];
            y0 = new int[rows];
            int x = BAND;
            for (int i = 0; i < cols; i++) {
                x0[i] = x;
                x += pSize + (i < seamW.length ? seamW[i] : 0);
            }
            w = x + BAND;
            int y = BAND;
            for (int j = 0; j < rows; j++) {
                y0[j] = y;
                y += pSize + (j < seamH.length ? seamH[j] : 0);
            }
            h = y + BAND;
        }

        // ---- кварталы ----

        /** Скелет сектора на мир и кварталы по нему: первый — образец, остальные — в допуске от него. */
        boolean pods() {
            podAt = new PodGen.Pod[cols][rows];
            List<int[]> order = new ArrayList<>();
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    if (kind[i][j] == 4) {
                        order.add(0, new int[] {i, j});
                    } else if (kind[i][j] == 2) {
                        order.add(new int[] {i, j});
                    }
                }
            }
            int[] target = null;
            for (int skeleton = 0; skeleton < 12 && target == null; skeleton++) {
                exit = 4 + r.nextInt(c - 10);
                mirror = false;
                int bx = 4 + r.nextInt(2);
                int by = 4 + r.nextInt(2);
                // домашняя — к углу квартала: оттуда никто не приходит
                int hdx = -1;
                int hdy = -1;
                params4 = new PodGen.Params(pSize, exit, arch, kind[order.get(0)[0]][order.get(0)[1]], bx, by, hdx,
                        hdy, mirror, null);
                for (int t = 0; t < 300 && target == null; t++) {
                    PodGen.Pod pod = PodGen.build(params4, r.nextLong());
                    if (pod != null) {
                        target = pod.m.vector();
                        podAt[order.get(0)[0]][order.get(0)[1]] = pod;
                    }
                }
            }
            if (target == null) {
                return false;
            }
            for (int k = 1; k < order.size(); k++) {
                int[] cell = order.get(k);
                PodGen.Params p = params4.withNear(podAt[order.get(0)[0]][order.get(0)[1]].near,
                        kind[cell[0]][cell[1]]);
                PodGen.Pod found = null;
                for (int t = 0; t < 2500 && found == null; t++) {
                    PodGen.Pod pod = PodGen.build(p, r.nextLong());
                    if (pod != null && close(pod.m.vector(), target)) {
                        found = pod;
                    }
                }
                if (found == null) {
                    return false;
                }
                podAt[cell[0]][cell[1]] = found;
            }
            return true;
        }

        /** Длины путей в допуске: ближние ±1, прииск через дверь ±1, в обход ±2, выход ±2. */
        static boolean close(int[] a, int[] t) {
            return Math.abs(a[0] - t[0]) <= 1 && Math.abs(a[1] - t[1]) <= 1 && Math.abs(a[2] - t[2]) <= 1
                    && Math.abs(a[3] - t[3]) <= 2 && Math.abs(a[4] - t[4]) <= 2;
        }

        void canvas() {
            g = new Cells(w, h, Cells.ROCK);
            lock = new boolean[w * h];
            inCell = new boolean[w * h];
            inGrid = new boolean[w * h];
            keep = new boolean[w * h];
            for (int x = 0; x < w; x++) {
                rockLock(x, 0);
                rockLock(x, h - 1);
            }
            for (int y = 0; y < h; y++) {
                rockLock(0, y);
                rockLock(w - 1, y);
            }
            for (int i = 0; i < cols; i++) {
                for (int j = 0; j < rows; j++) {
                    for (int y = 0; y < pSize; y++) {
                        for (int x = 0; x < pSize; x++) {
                            inCell[g.idx(x0[i] + x, y0[j] + y)] = true;
                            inGrid[g.idx(x0[i] + x, y0[j] + y)] = true;
                        }
                    }
                }
            }
        }

        void rockLock(int x, int y) {
            g.set(x, y, Cells.ROCK);
            lock[g.idx(x, y)] = true;
        }

        void floorLock(int x, int y) {
            if (g.in(x, y) && !inCell[g.idx(x, y)]) {
                g.set(x, y, Cells.FLOOR);
                lock[g.idx(x, y)] = true;
            }
        }

        void setLock(int x, int y, char ch) {
            if (g.in(x, y) && !inCell[g.idx(x, y)]) {
                g.set(x, y, ch);
                lock[g.idx(x, y)] = true;
            }
        }

        void placePods() {
            seatOf = new int[cols][rows][4];
            // места «бронзы» (номера после asked) — по одному в разных кварталах, пока кварталов хватает; сектор — по
            // зерну
            List<int[]> slots = new ArrayList<>();
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    if (podAt[i][j] != null) {
                        for (PodGen.Sector s : podAt[i][j].sectors) {
                            slots.add(new int[] {i, j, s.index()});
                        }
                    }
                }
            }
            List<int[]> podCells = new ArrayList<>();
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    if (podAt[i][j] != null) {
                        podCells.add(new int[] {i, j});
                    }
                }
            }
            int bots = seats - asked;
            int studentNo = 0;
            int botNo = asked;
            int[][][] number = new int[cols][rows][4];
            List<int[]> left = new ArrayList<>();
            for (int b = 0; b < bots; b++) {
                if (left.isEmpty()) {
                    left.addAll(podCells);
                }
                int[] cell = left.remove(r.nextInt(left.size()));
                List<PodGen.Sector> sec = new ArrayList<>();
                for (PodGen.Sector s : podAt[cell[0]][cell[1]].sectors) {
                    if (number[cell[0]][cell[1]][s.index()] == 0) {
                        sec.add(s);
                    }
                }
                number[cell[0]][cell[1]][sec.get(r.nextInt(sec.size())).index()] = ++botNo;
            }
            for (int[] s : slots) {
                if (number[s[0]][s[1]][s[2]] == 0) {
                    number[s[0]][s[1]][s[2]] = ++studentNo;
                }
            }
            WorldPlan.Seat[] bySeat = new WorldPlan.Seat[seats];
            int index = 0;
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    PodGen.Pod pod = podAt[i][j];
                    if (pod == null) {
                        continue;
                    }
                    for (int y = 0; y < pSize; y++) {
                        for (int x = 0; x < pSize; x++) {
                            g.set(x0[i] + x, y0[j] + y, pod.g.get(x, y));
                            lock[g.idx(x0[i] + x, y0[j] + y)] = true;
                        }
                    }
                    podInfos.add(new WorldPlan.PodInfo(index, i, j, x0[i], y0[j], pSize, pod.seats, pod.seed,
                            pod.mirrored, new Pos(x0[i] + c, y0[j] + c), null));
                    for (PodGen.Sector s : pod.sectors) {
                        int seat = number[i][j][s.index()];
                        seatOf[i][j][s.index()] = seat;
                        bySeat[seat - 1] = new WorldPlan.Seat(seat, index, s.index(), at(i, j, s.base()),
                                at(i, j, s.home()), at(i, j, s.near1()), at(i, j, s.near2()));
                    }
                    index++;
                }
            }
            seatList.addAll(Arrays.asList(bySeat));
        }

        Pos at(int i, int j, int[] local) {
            return new Pos(x0[i] + local[0], y0[j] + local[1]);
        }

        // ---- выходы ----

        /**
         * Клетки выхода на стене клетки сетки {@code (i, j)} со стороны {@code side} (0 — север, 1 — восток, 2 — юг,
         * 3 — запад): две клетки посередине стороны. У квартала это концы выходов из площадки прииска; повороты дают
         * сдвиг на клетку: запад — ряды c, c+1, восток — c−1, c, север — столбцы c−1, c, юг — c, c+1. Перевал между
         * соседями поэтому симметричен относительно своей середины.
         */
        int[][] exitCells(int i, int j, int side) {
            int n = pSize;
            return switch (side) {
                case 0 -> new int[][] {{x0[i] + c - 1, y0[j]}, {x0[i] + c, y0[j]}};
                case 1 -> new int[][] {{x0[i] + n - 1, y0[j] + c - 1}, {x0[i] + n - 1, y0[j] + c}};
                case 2 -> new int[][] {{x0[i] + c, y0[j] + n - 1}, {x0[i] + c + 1, y0[j] + n - 1}};
                default -> new int[][] {{x0[i], y0[j] + c}, {x0[i], y0[j] + c + 1}};
            };
        }

        int quadrant(int lx, int ly) {
            if (lx < c) {
                return ly < c ? 0 : 3;
            }
            return ly < c ? 1 : 2;
        }

        /** Место, чей выход на стороне {@code side} клетки; 0 — дикие земли или пустой сектор. */
        int exitSeat(int i, int j, int side) {
            if (kind[i][j] == 0) {
                return 0;
            }
            // наружу квартал выходит через площадку: перевал принадлежит кварталу, а не сектору
            return seatOf[i][j][0];
        }

        // ---- дикие земли ----

        void wilds() {
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    if (kind[i][j] == 0) {
                        wild(i, j);
                    }
                }
            }
        }

        /** Клетка диких земель: скалы гуще, стены с выходами там же, где у кварталов, тропы от выходов к середине. */
        void wild(int i, int j) {
            int n = pSize;
            boolean[] rock = wildRocks(n);
            for (int y = 0; y < n; y++) {
                for (int x = 0; x < n; x++) {
                    g.set(x0[i] + x, y0[j] + y, rock[y * n + x] ? Cells.ROCK : Cells.FLOOR);
                }
            }
            for (int k = 0; k < n; k++) {
                g.set(x0[i] + k, y0[j], Cells.ROCK);
                g.set(x0[i] + k, y0[j] + n - 1, Cells.ROCK);
                g.set(x0[i], y0[j] + k, Cells.ROCK);
                g.set(x0[i] + n - 1, y0[j] + k, Cells.ROCK);
            }
            int mx = x0[i] + c;
            int my = y0[j] + c;
            for (int side = 0; side < 4; side++) {
                int[][] ex = exitCells(i, j, side);
                for (int[] e : ex) {
                    g.set(e[0], e[1], Cells.FLOOR);
                    lock[g.idx(e[0], e[1])] = true;
                }
                walk(ex[0][0], ex[0][1], mx - 1, my - 1, x0[i] + 1, y0[j] + 1, x0[i] + n - 3, y0[j] + n - 3, true);
            }
            if (o.lair() && lair == null) {
                // логово — в верхней части дикой клетки: середина может уйти под сердце
                int ly = y0[j] + 5;
                for (int dy = -2; dy <= 2; dy++) {
                    for (int dx = -2; dx <= 2; dx++) {
                        if (dx * dx + dy * dy <= 5) {
                            g.set(mx + dx, ly + dy, Cells.FLOOR);
                            lock[g.idx(mx + dx, ly + dy)] = true;
                        }
                    }
                }
                walk(mx, ly, mx - 1, my - 1, x0[i] + 1, y0[j] + 1, x0[i] + n - 3, y0[j] + n - 3, true);
                g.set(mx, ly, 'L');
                lair = new Pos(mx, ly);
            }
            // дикую клетку можно править рельефом, кроме стен и выходов
            for (int y = 1; y < n - 1; y++) {
                for (int x = 1; x < n - 1; x++) {
                    inCell[g.idx(x0[i] + x, y0[j] + y)] = false;
                }
            }
        }

        /**
         * Тропа шириной 2 (кисть 2×2) от {@code (sx, sy)} к {@code (tx, ty)} блужданием с тягой к цели, в рамке
         * {@code [xlo, xhi] × [ylo, yhi]} для левого верхнего угла кисти. {@code force} — писать и в клетки сетки.
         */
        void walk(int sx, int sy, int tx, int ty, int xlo, int ylo, int xhi, int yhi, boolean force) {
            int x = clamp(sx, xlo, xhi);
            int y = clamp(sy, ylo, yhi);
            brush(sx, sy, force);
            for (int step = 0; step < 6 * (w + h); step++) {
                brush(x, y, force);
                if (x == tx && y == ty) {
                    return;
                }
                int dx = Integer.signum(tx - x);
                int dy = Integer.signum(ty - y);
                double roll = r.nextDouble();
                if (roll < 0.15) {
                    // шаг вбок для извилистости
                    if (Math.abs(tx - x) >= Math.abs(ty - y)) {
                        y = clamp(y + (r.nextBoolean() ? 1 : -1), ylo, yhi);
                    } else {
                        x = clamp(x + (r.nextBoolean() ? 1 : -1), xlo, xhi);
                    }
                } else if (dx != 0 && (dy == 0 || r.nextDouble() < (double) Math.abs(tx - x)
                        / (Math.abs(tx - x) + Math.abs(ty - y)))) {
                    x = clamp(x + dx, xlo, xhi);
                } else if (dy != 0) {
                    y = clamp(y + dy, ylo, yhi);
                }
            }
            brush(tx, ty, force);
        }

        void brush(int x, int y, boolean force) {
            for (int dy = 0; dy <= 1; dy++) {
                for (int dx = 0; dx <= 1; dx++) {
                    int px = x + dx;
                    int py = y + dy;
                    if (g.in(px, py) && px > 0 && py > 0 && px < w - 1 && py < h - 1
                            && (force || !inCell[g.idx(px, py)]) && !isLockedRock(px, py)) {
                        if (g.get(px, py) == Cells.ROCK || g.get(px, py) == Cells.RUBBLE) {
                            g.set(px, py, Cells.FLOOR);
                        }
                    }
                }
            }
        }

        boolean isLockedRock(int x, int y) {
            return lock[g.idx(x, y)] && g.get(x, y) == Cells.ROCK;
        }

        static int clamp(int v, int lo, int hi) {
            return Math.max(lo, Math.min(hi, v));
        }

        /** Скалы диких земель: те же формы облика, но крупнее — здесь им есть место. */
        boolean[] wildRocks(int n) {
            boolean[] rock = new boolean[n * n];
            switch (arch) {
                case PLATEAU -> {
                    for (int k = 0; k < 2; k++) {
                        double rad = 3.6 + r.nextDouble() * 1.4;
                        double cx = 4 + rad + r.nextDouble() * (n - 8 - 2 * rad);
                        double cy = 4 + rad + r.nextDouble() * (n - 8 - 2 * rad);
                        int r0 = (int) Math.ceil(rad + 1);
                        for (int dy = -r0; dy <= r0; dy++) {
                            for (int dx = -r0; dx <= r0; dx++) {
                                int x = (int) Math.round(cx) + dx;
                                int y = (int) Math.round(cy) + dy;
                                if (x >= 0 && y >= 0 && x < n && y < n
                                        && Math.hypot(x - cx, y - cy) <= rad + (r.nextDouble() - 0.5) * 1.2) {
                                    rock[y * n + x] = true;
                                }
                            }
                        }
                    }
                }
                case SINKHOLES -> {
                    for (int k = 0; k < 6; k++) {
                        double rad = 2.6 + r.nextDouble() * 1.6;
                        Terrain.disc(rock, n, n, 3 + rad + r.nextDouble() * (n - 6 - 2 * rad),
                                3 + rad + r.nextDouble() * (n - 6 - 2 * rad), rad);
                    }
                }
                case CANYONS -> {
                    double ang = r.nextDouble() * Math.PI;
                    for (int k = 0; k < 8; k++) {
                        Terrain.ridge(rock, n, n, 2 + r.nextDouble() * (n - 4), 2 + r.nextDouble() * (n - 4), ang,
                                16 + r.nextInt(10), 0.1, true, r);
                    }
                }
                case ROCK_MAZE -> {
                    rock = Terrain.rocks(arch, n, n, 0.46, r);
                }
            }
            return rock;
        }

        double density() {
            return switch (arch) {
                case PLATEAU -> 0.22;
                case ROCK_MAZE -> 0.30;
                case CANYONS -> 0.26;
                case SINKHOLES -> 0.20;
            };
        }

        // ---- гряды, перевалы, тропы ----

        /** Всё вне клеток сетки — скала (гряды); дальше в ней прорубаются перевалы и тропы. */
        void seamsBase() {
            for (int i = 0; i < w * h; i++) {
                if (!inGrid[i] && !lock[i]) {
                    g.a[i] = Cells.ROCK;
                }
            }
        }

        /** Логово без диких земель — на кольцевой тропе посреди верхнего края. */
        void lairOnRing() {
            if (!o.lair() || lair != null) {
                return;
            }
            int lx = w / 2;
            for (int x = lx - 2; x <= lx + 2; x++) {
                floorLock(x, 1);
                floorLock(x, 2);
            }
            g.set(lx, 1, 'L');
            lock[g.idx(lx, 1)] = true;
            lair = new Pos(lx, 1);
            // к логову — отрог от ближайшей тропы по гряде
            int best = -1;
            for (int i = 0; i + 1 < cols; i++) {
                int sx = x0[i] + pSize + (seamW[i] - 2) / 2;
                if (best < 0 || Math.abs(sx - lx) < Math.abs(best - lx)) {
                    best = sx;
                }
            }
            if (best >= 0) {
                wind(2, lx, best, 1, BAND - 2, false);
            }
        }

        void passesAndTrails() {
            // перевалы между соседями по сетке
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    if (i + 1 < cols) {
                        pass(i, j, i + 1, j, true);
                    }
                    if (j + 1 < rows) {
                        pass(i, j, i, j + 1, false);
                    }
                }
            }
            // кольцевой тропы нет: выход к краю мира — отрог вдоль края до ближайшей тропы по гряде, в одну сторону.
            // Кольцо рвётся на углах и между отрогами
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    if (j == 0) {
                        edge(i, j, 0);
                    }
                    if (i == cols - 1) {
                        edge(i, j, 1);
                    }
                    if (j == rows - 1) {
                        edge(i, j, 2);
                    }
                    if (i == 0) {
                        edge(i, j, 3);
                    }
                }
            }
            // тропы по грядам от перевалов к перекрёсткам
            for (int i = 0; i + 1 < cols; i++) {
                int xa = x0[i] + pSize;
                int sw = seamW[i];
                for (int j = 0; j < rows; j++) {
                    // от верхнего конца перевала вверх, от нижнего вниз
                    int top = y0[j] + c - 3;
                    int bottom = y0[j] + c + 2;
                    int ytop = j == 0 ? 1 : y0[j] - seamH[j - 1] / 2 - 1;
                    int ybot = j == rows - 1 ? h - 3 : y0[j] + pSize + seamH[j] / 2;
                    wind(xa + (sw - 2) / 2, top, ytop, xa, xa + sw - 2, true);
                    wind(xa + (sw - 2) / 2, bottom, ybot, xa, xa + sw - 2, true);
                }
            }
            for (int j = 0; j + 1 < rows; j++) {
                int ya = y0[j] + pSize;
                int sh = seamH[j];
                for (int i = 0; i < cols; i++) {
                    int left = x0[i] + c - 3;
                    int right = x0[i] + c + 2;
                    int xl = i == 0 ? 1 : x0[i] - seamW[i - 1] / 2 - 1;
                    int xr = i == cols - 1 ? w - 3 : x0[i] + pSize + seamW[i] / 2;
                    wind(ya + (sh - 2) / 2, left, xl, ya, ya + sh - 2, false);
                    wind(ya + (sh - 2) / 2, right, xr, ya, ya + sh - 2, false);
                }
            }
        }

        /**
         * Перевал между клетками {@code A = (ai, aj)} и {@code B = (bi, bj)} — соседями по горизонтали ({@code across})
         * или вертикали. Половина пути от выхода A до середины прокладывается блужданием, вторая — её поворот на 180°
         * вокруг середины: обоим соседям до середины одинаково.
         */
        void pass(int ai, int aj, int bi, int bj, boolean across) {
            int sideA = across ? 1 : 2;
            int sideB = across ? 3 : 0;
            int[][] ea = exitCells(ai, aj, sideA);
            int cx;
            int cy;
            int sw;
            if (across) {
                int xa = x0[ai] + pSize;
                sw = seamW[ai];
                cx = xa + (sw - 1) / 2;
                cy = y0[aj] + c;
            } else {
                int ya = y0[aj] + pSize;
                sw = seamH[aj];
                cx = x0[ai] + c;
                cy = ya + (sw - 1) / 2;
            }
            // полупуть: кисть 2×2 от клетки за выходом до (cx−1, cy−1)
            List<int[]> half = new ArrayList<>();
            int x;
            int y;
            if (across) {
                x = ea[0][0] + 1;
                y = ea[0][1];
            } else {
                x = ea[0][0];
                y = ea[0][1] + 1;
            }
            int tx = cx - 1;
            int ty = cy - 1;
            for (int step = 0; step < 200; step++) {
                half.add(new int[] {x, y});
                if (x == tx && y == ty) {
                    break;
                }
                boolean nearCenter = Math.abs(x - tx) + Math.abs(y - ty) <= 3;
                int dx = Integer.signum(tx - x);
                int dy = Integer.signum(ty - y);
                // вдоль гряды — к середине, поперёк — не дальше своей половины
                if (across) {
                    boolean lateral = !nearCenter && r.nextDouble() < 0.3;
                    if (dy != 0 && !lateral) {
                        y += dy;
                    } else if (dx != 0) {
                        x += dx;
                    } else {
                        int nx = x + (r.nextBoolean() ? 1 : -1);
                        x = clamp(nx, ea[0][0] + 1, cx - 1);
                    }
                } else {
                    boolean lateral = !nearCenter && r.nextDouble() < 0.3;
                    if (dx != 0 && !lateral) {
                        x += dx;
                    } else if (dy != 0) {
                        y += dy;
                    } else {
                        int ny = y + (r.nextBoolean() ? 1 : -1);
                        y = clamp(ny, ea[0][1] + 1, cy - 1);
                    }
                }
            }
            for (int[] b : half) {
                for (int dy = 0; dy <= 1; dy++) {
                    for (int dx = 0; dx <= 1; dx++) {
                        floorLock(b[0] + dx, b[1] + dy);
                        floorLock(2 * cx - b[0] - dx, 2 * cy - b[1] - dy);
                    }
                }
            }
            // жилы посередине: по одной на хозяина, в нишах по обе стороны тропы
            List<Integer> owners = new ArrayList<>();
            int sa = exitSeat(ai, aj, sideA);
            int sb = exitSeat(bi, bj, sideB);
            if (sa > 0) {
                owners.add(sa);
            }
            if (sb > 0) {
                owners.add(sb);
            }
            boolean central = Math.abs(cx - w / 2) <= 1 && Math.abs(cy - h / 2) <= 1;
            if (central) {
                heart = new Pos(cx, cy);
                passCenters.add(new Pos(cx, cy));
                return;
            }
            // посередине — площадка 5×5, тропа огибает середину; там, между двумя кварталами, ничейная жила под
            // обвалом: свободного места у неё нет, пока кто-то не разберёт завал, — тогда она открыта обоим соседям.
            // Колония, которая выбирает видимое место поближе по прямой, не уводит туда рабочего от своего прииска
            for (int dy = -2; dy <= 2; dy++) {
                for (int dx = -2; dx <= 2; dx++) {
                    floorLock(cx + dx, cy + dy);
                }
            }
            passCenters.add(new Pos(cx, cy));
            if (owners.size() == 2) {
                for (int dy = -1; dy <= 1; dy++) {
                    for (int dx = -1; dx <= 1; dx++) {
                        setLock(cx + dx, cy + dy, Cells.RUBBLE);
                    }
                }
                setLock(cx, cy, '*');
                passes.add(new WorldPlan.Pass(List.of(new Pos(cx, cy)), List.copyOf(owners), null));
            }
        }

        /**
         * Извилистая тропа шириной 2 вдоль гряды: по главной оси от {@code from} до {@code to}, поперёк — синусоида с
         * шумом в полосе {@code [lo, hi]} (левый верхний угол кисти 2×2). {@code vertical} — главная ось вертикальна,
         * {@code mid} — x тропы; иначе {@code mid} — её y.
         */
        void wind(int mid, int from, int to, int lo, int hi, boolean vertical) {
            double phase = r.nextDouble() * 2 * Math.PI;
            double wave = 3.5 + r.nextDouble() * 3.0;
            // размах — чуть меньше полосы: у гряды остаётся скальный край
            double amp = Math.max(0.6, (hi - lo) / 2.0 - 0.2);
            double centre = (lo + hi) / 2.0;
            int step = Integer.signum(to - from);
            int prev = clamp(mid, lo, hi);
            for (int t = from; ; t += step) {
                int cross = clamp((int) Math.round(centre + amp * Math.sin(t / wave + phase)), lo, hi);
                if (t == from) {
                    cross = clamp(mid, lo, hi);
                }
                // поперёк — не больше клетки за шаг, чтобы кисть 2×2 шла без разрывов
                cross = clamp(cross, prev - 1, prev + 1);
                prev = cross;
                if (vertical) {
                    brush(cross, t, false);
                } else {
                    brush(t, cross, false);
                }
                if (t == to || step == 0) {
                    break;
                }
            }
        }

        /**
         * Выход к краю мира: ход шириной 2 до полосы у края и отрог вдоль неё до ближайшей тропы по гряде — в одну
         * сторону, выбранную по зерну (у угла — от угла). Ничейной жилы здесь нет: её не с кем делить.
         */
        void edge(int i, int j, int side) {
            int[][] ex = exitCells(i, j, side);
            boolean horizontalEdge = side == 0 || side == 2;
            int lane = side == 0 || side == 3 ? 1 : horizontalEdge ? h - 3 : w - 3;
            switch (side) {
                case 0 -> {
                    for (int y = 1; y < y0[j]; y++) {
                        floorLock(ex[0][0], y);
                        floorLock(ex[1][0], y);
                    }
                }
                case 1 -> {
                    for (int x = x0[i] + pSize; x < w - 1; x++) {
                        floorLock(x, ex[0][1]);
                        floorLock(x, ex[1][1]);
                    }
                }
                case 2 -> {
                    for (int y = y0[j] + pSize; y < h - 1; y++) {
                        floorLock(ex[0][0], y);
                        floorLock(ex[1][0], y);
                    }
                }
                default -> {
                    for (int x = 1; x < x0[i]; x++) {
                        floorLock(x, ex[0][1]);
                        floorLock(x, ex[1][1]);
                    }
                }
            }
            // концы троп по грядам у этого края: середины гряд по обе стороны клетки
            List<Integer> ends = new ArrayList<>();
            if (horizontalEdge) {
                if (i > 0) {
                    ends.add(x0[i] - seamW[i - 1] + (seamW[i - 1] - 2) / 2);
                }
                if (i + 1 < cols) {
                    ends.add(x0[i] + pSize + (seamW[i] - 2) / 2);
                }
            } else {
                if (j > 0) {
                    ends.add(y0[j] - seamH[j - 1] + (seamH[j - 1] - 2) / 2);
                }
                if (j + 1 < rows) {
                    ends.add(y0[j] + pSize + (seamH[j] - 2) / 2);
                }
            }
            if (ends.isEmpty()) {
                return;
            }
            int target = ends.get(r.nextInt(ends.size()));
            int at = horizontalEdge ? ex[0][0] : ex[0][1];
            int lo = side == 0 || side == 3 ? 1 : (horizontalEdge ? h : w) - 3 - (BAND - 3);
            int hi = side == 0 || side == 3 ? BAND - 2 : (horizontalEdge ? h : w) - 3;
            wind(lane, at, target, Math.min(lo, hi), Math.max(lo, hi), !horizontalEdge);
        }

        // ---- сердце ----

        /**
         * Сердце: столп, четыре жилы на осях, засыпанные обвалом (до жилы — две клетки завала с любой стороны), вокруг —
         * скальная кромка с проходами там, где идут тропы. Стоит в середине
         * центрального перевала (2 или 3 квартала в ряд) или на центральном перекрёстке.
         */
        void heart() {
            if (cols * rows < 2) {
                return;
            }
            int hx = w / 2;
            int hy = h / 2;
            // дикие земли не пустуют: сердце — в ближайшей к середине мира дикой клетке
            int best = Integer.MAX_VALUE;
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    if (kind[i][j] == 0) {
                        int d = Math.abs(x0[i] + c - hx) + Math.abs(y0[j] + c - hy);
                        if (d < best) {
                            best = d;
                            heart = new Pos(x0[i] + c, y0[j] + c);
                        }
                    }
                }
            }
            if (heart == null) {
                heart = new Pos(hx, hy);
            }
            passCenters.add(heart);
            hx = heart.x();
            hy = heart.y();
            for (int y = hy - 5; y <= hy + 5; y++) {
                for (int x = hx - 5; x <= hx + 5; x++) {
                    if (!g.in(x, y) || inCell[g.idx(x, y)]) {
                        continue;
                    }
                    double d = Math.hypot(x - hx, y - hy);
                    if (d <= 1.0) {
                        setLock(x, y, Cells.ROCK);
                    } else if (d <= 3.3) {
                        // жилы засыпаны: свободной клетки рядом с ними нет, пока кто-то не прокопает. Колония без
                        // кирки их не выбирает и не встаёт в очередь к недостижимому месту
                        setLock(x, y, Cells.RUBBLE);
                    } else if (d <= 3.9) {
                        setLock(x, y, Cells.RUBBLE);
                    } else if (d <= 4.6 && g.get(x, y) != Cells.FLOOR) {
                        setLock(x, y, Cells.ROCK);
                    }
                }
            }
            int[][] axes = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};
            for (int[] a : axes) {
                setLock(hx + 2 * a[0], hy + 2 * a[1], 'C');
            }
        }

        // ---- рельеф гряд ----

        /**
         * Гряды не ровные: вдоль троп — промоины и ниши (пол), на тропах между перекрёстками — оползни из завалов, если
         * в обход всё равно можно пройти. Перевалы и сердце не трогаются: их симметрия держит равенство соседей.
         */
        void relief() {
            for (int i = 0; i < w * h; i++) {
                keep[i] = inCell[i] || lock[i];
            }
            for (Pos p : passCenters) {
                for (int y = p.y() - 5; y <= p.y() + 5; y++) {
                    for (int x = p.x() - 5; x <= p.x() + 5; x++) {
                        if (g.in(x, y)) {
                            keep[g.idx(x, y)] = true;
                        }
                    }
                }
            }
            double[] noise = Terrain.valueNoise(w, h, 3.0, r);
            double t = switch (arch) {
                case PLATEAU -> 0.35;
                case SINKHOLES -> 0.6;
                case CANYONS -> 0.85;
                case ROCK_MAZE -> 0.75;
            };
            char[] next = g.a.clone();
            for (int y = 1; y < h - 1; y++) {
                for (int x = 1; x < w - 1; x++) {
                    int i = g.idx(x, y);
                    if (keep[i] || inGrid[i] || g.a[i] != Cells.ROCK) {
                        continue;
                    }
                    int open = 0;
                    for (int[] d : Cells.DIRS) {
                        if (Cells.walk(g.get(x + d[0], y + d[1]))) {
                            open++;
                        }
                    }
                    if (open > 0 && noise[i] > t) {
                        next[i] = Cells.FLOOR;
                    }
                }
            }
            System.arraycopy(next, 0, g.a, 0, next.length);
        }

        /** Все жилы и выходы достижимы с закрытыми завалами хоть с какой-то базы. */
        boolean allReachable(List<int[]> sources) {
            int[] d = g.dist(sources, false, 0);
            for (int i = 0; i < g.a.length; i++) {
                if (Cells.deposit(g.a[i]) || g.a[i] == 'L') {
                    int x = i % w;
                    int y = i / w;
                    if (g.toSpots(d, x, y) < 0) {
                        return false;
                    }
                }
            }
            return true;
        }

        // ---- чистка ----

        void cleanup() {
            List<int[]> src = new ArrayList<>();
            for (WorldPlan.Seat s : seatList) {
                src.addAll(g.spots(s.base().x(), s.base().y()));
            }
            for (int pass = 0; pass < 4; pass++) {
                List<Integer> sizes = new ArrayList<>();
                int[] comp = g.components(i -> g.a[i] == Cells.ROCK, true, sizes);
                for (int i = 0; i < comp.length; i++) {
                    if (comp[i] >= 0 && sizes.get(comp[i]) <= 2 && !lock[i] && !inCell[i]) {
                        g.a[i] = Cells.FLOOR;
                    }
                }
                int[] d = g.dist(src, true, 0);
                sizes.clear();
                int[] fc = g.components(i -> (Cells.walk(g.a[i]) || g.a[i] == Cells.RUBBLE) && d[i] < 0, false,
                        sizes);
                boolean changed = false;
                int[] first = new int[sizes.size()];
                boolean[] locked = new boolean[sizes.size()];
                Arrays.fill(first, -1);
                for (int i = 0; i < fc.length; i++) {
                    if (fc[i] >= 0) {
                        if (first[fc[i]] < 0) {
                            first[fc[i]] = i;
                        }
                        if (lock[i] || inCell[i]) {
                            locked[fc[i]] = true;
                        }
                    }
                }
                for (int id = 0; id < sizes.size(); id++) {
                    if (sizes.get(id) <= 10 && !locked[id]) {
                        for (int i = 0; i < fc.length; i++) {
                            if (fc[i] == id) {
                                g.a[i] = Cells.ROCK;
                            }
                        }
                    } else {
                        carve(first[id], d);
                    }
                    changed = true;
                }
                if (!changed) {
                    break;
                }
            }
        }

        void carve(int from, int[] reach) {
            int[] prev = new int[w * h];
            Arrays.fill(prev, -2);
            ArrayDeque<Integer> q = new ArrayDeque<>();
            prev[from] = -1;
            q.add(from);
            int hit = -1;
            while (!q.isEmpty() && hit < 0) {
                int i = q.poll();
                for (int[] dd : Cells.DIRS) {
                    int x = i % w + dd[0];
                    int y = i / w + dd[1];
                    if (!g.in(x, y)) {
                        continue;
                    }
                    int j = g.idx(x, y);
                    if (prev[j] != -2) {
                        continue;
                    }
                    char ch = g.a[j];
                    if (reach[j] >= 0 && (Cells.walk(ch) || ch == Cells.RUBBLE)) {
                        prev[j] = i;
                        hit = j;
                        break;
                    }
                    if (Cells.walk(ch) || ch == Cells.RUBBLE || ch == Cells.ROCK && !lock[j] && !inCell[j]) {
                        prev[j] = i;
                        q.add(j);
                    }
                }
            }
            for (int i = hit; i >= 0; i = prev[i]) {
                if (g.a[i] == Cells.ROCK) {
                    g.a[i] = Cells.FLOOR;
                }
            }
        }

        // ---- знаки баз и имена ----

        void marks() {
            for (WorldPlan.Seat s : seatList) {
                g.set(s.base().x(), s.base().y(), GameMap.BASE_MARKS.charAt(s.seat() - 1));
            }
            for (int i = 0; i < g.a.length; i++) {
                if (g.a[i] == '@') {
                    g.a[i] = Cells.ROCK;
                }
            }
        }

        void names() {
            Names names = new Names(r);
            List<WorldPlan.PodInfo> named = new ArrayList<>();
            for (WorldPlan.PodInfo p : podInfos) {
                String nm = names.name(Names.MINE, -1);
                regions.add(new GameMap.Region(nm, p.mine().x(), p.mine().y()));
                named.add(new WorldPlan.PodInfo(p.index(), p.col(), p.row(), p.x0(), p.y0(), p.size(), p.seats(),
                        p.seed(), p.mirrored(), p.mine(), nm));
            }
            podInfos.clear();
            podInfos.addAll(named);
            if (heart != null) {
                regions.add(new GameMap.Region("Сердце", heart.x(), heart.y() + 6));
            }
            if (lair != null) {
                regions.add(new GameMap.Region("Логово", lair.x(), Math.max(1, lair.y() + 2)));
            }
            for (int j = 0; j < rows; j++) {
                for (int i = 0; i < cols; i++) {
                    boolean heartHere = heart != null && heart.x() == x0[i] + c && heart.y() == y0[j] + c;
                    if (kind[i][j] == 0 && !heartHere) {
                        regions.add(new GameMap.Region(names.name(Names.WILD, -1), x0[i] + c, y0[j] + c + 4));
                    }
                }
            }
            List<WorldPlan.Pass> out = new ArrayList<>(passes);
            passes.clear();
            for (WorldPlan.Pass p : out) {
                String nm = null;
                if (p.owners().size() == 2) {
                    nm = names.name(Names.PASS, -1);
                    Pos a = p.deposits().get(0);
                    regions.add(new GameMap.Region(nm, a.x(), Math.min(h - 2, a.y() + 3)));
                }
                passes.add(new WorldPlan.Pass(p.deposits(), p.owners(), nm));
            }
        }
    }
}
