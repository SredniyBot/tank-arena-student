package colony.engine.world;

import colony.api.DepositKind;
import colony.api.Pos;
import colony.engine.GameMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

/**
 * Мир из четверти: квадрат с поворотной симметрией четвёртого порядка вокруг сердца.
 *
 * <p>Рельеф — скалярное поле {@code F(p) = Σ f(Rᵏp)} по четырём поворотам (для гряд и провалов — максимум вместо
 * суммы), порог и клеточный автомат: симметрия по построению, швов между четвертями нет. Всё, что ставится поверх
 * (сердце, базы, жилы, двери), пишется сразу в четыре поворота. Поэтому четыре копии одного места (класс) равны в
 * точности, а равенство разных классов одной четверти добирается замерами: ближняя и карман, два общих прииска на
 * похожих расстояниях, сердце.
 *
 * <p>Общий прииск — богатая жила в точке, почти равноудалённой по пути от двух соседних баз, в каменном кольце.
 * Со стороны баз в кольце — завал (общая дверь: кто разберёт, откроет короткий путь и соседу), с другой стороны —
 * проход: без кирки — в обход кольца, на 6 и больше шагов длиннее.
 */
final class QuarterGen {

    /** Общих приисков у каждого места. */
    static final int MINES_PER_SEAT = 2;
    /** Обход к общему прииску длиннее двери хотя бы на столько шагов. */
    static final int DOOR_GAIN_MIN = 6;
    /** Попыток собрать годный мир (каждая — новое зерно). */
    static final int ATTEMPTS = 160;

    /**
     * Радиус круга баз: соседи по кругу — в {@link #spacing} клетках, но не ближе 15 к сердцу. Все базы на одном круге:
     * только так до сердца всем поровну.
     */
    static double radius(int seats) {
        // общие прииски стоят в 6 клетках внутрь от круга, соседние — не ближе 9 друг к другу
        return Math.max(21, Math.max(spacing(seats) * seats / (2 * Math.PI), 6 + 9.0 * seats / (2 * Math.PI)));
    }

    /** Шаг между соседними базами по кругу: 11 клеток, на 28 местах и больше — 10 (иначе карта не влезет в проектор). */
    static double spacing(int seats) {
        return seats >= 28 ? 10 : 11;
    }

    /** Сторона мира: круг баз и семь клеток до края; нечётная — в середине клетка сердца. */
    static int side(int seats) {
        return 2 * ((int) Math.ceil(radius(seats)) + 7) + 1;
    }

    /** Лучший из годных миров или {@code null}, если за {@link #ATTEMPTS} попыток ни одного. */
    static WorldPlan plan(int asked, int seats, long seed, WorldGen.Options o) {
        WorldPlan best = null;
        int ok = 0;
        int want = Math.max(1, o.candidates());
        for (int t = 0; t < ATTEMPTS && ok < want; t++) {
            WorldPlan p = new QuarterGen(asked, seats, seed, t).build();
            if (p == null || !p.report().ok()) {
                continue;
            }
            ok++;
            if (best == null || p.report().score() > best.report().score()) {
                best = p;
            }
        }
        if (best == null) {
            return null;
        }
        return new WorldPlan(best.map(), best.archetype(), asked, best.pods(), best.seats(), best.passes(),
                best.heart(), best.lair(), best.report(), ok, 0);
    }

    /**
     * Эскиз: лучшая из первых {@code tries} попыток, даже если проверки не прошла (меньше всего замечаний, затем
     * оценка). Для превью и разбора, не для игры.
     */
    static WorldPlan sketch(int asked, int seats, long seed, int tries) {
        WorldPlan best = null;
        for (int t = 0; t < tries; t++) {
            WorldPlan p = new QuarterGen(asked, seats, seed, t).build();
            if (p == null) {
                continue;
            }
            if (best == null || p.report().failures().size() < best.report().failures().size()
                    || p.report().failures().size() == best.report().failures().size()
                    && p.report().score() > best.report().score()) {
                best = p;
            }
        }
        return best;
    }

    /** Одна попытка как есть (и непрошедшая) — для отладки и замеров. */
    static WorldPlan attempt(int asked, int seats, long seed, int t) {
        return new QuarterGen(asked, seats, seed, t).build();
    }

    /** Отладка: последняя причина отказа по каждой попытке. */
    static final Map<String, Integer> WHY = new java.util.concurrent.ConcurrentHashMap<>();
    private static final boolean TRACE = Boolean.getBoolean("worldgen.why");

    private WorldPlan why(String reason) {
        if (TRACE) {
            WHY.merge(reason, 1, Integer::sum);
        }
        return null;
    }

    private final int asked;
    private final int seats;
    private final int k;
    private final int n;
    private final int c;
    private final long seed;
    private final SplittableRandom r;
    private final Archetype arch;
    private final Cells g;
    private final boolean[] lock;
    private final int[][] base;
    private final int[][] home;
    private final int[][] near1;
    private final int[][] near2;
    private final List<int[]> mines = new ArrayList<>();

    private QuarterGen(int asked, int seats, long seed, int attempt) {
        this.asked = asked;
        this.seats = seats;
        this.k = seats / 4;
        this.n = side(seats);
        this.c = n / 2;
        this.seed = seed;
        this.r = new SplittableRandom(WorldGen.mix(seed * 0x9E3779B97F4A7C15L + attempt * 7_919L + seats));
        this.arch = WorldGen.archetypeOf(seed);
        this.g = new Cells(n, n, Cells.ROCK);
        this.lock = new boolean[n * n];
        this.base = new int[k][];
        this.home = new int[k][];
        this.near1 = new int[k][];
        this.near2 = new int[k][];
    }

    // ---- симметрия ----

    /** Поворот на 90° {@code t} раз: (x, y) → (n−1−y, x). */
    int[] rot(int x, int y, int t) {
        int ax = x;
        int ay = y;
        for (int i = 0; i < (t & 3); i++) {
            int nx = n - 1 - ay;
            ay = ax;
            ax = nx;
        }
        return new int[] {ax, ay};
    }

    private int[] copy(int cls, int t) {
        return rot(base[cls][0], base[cls][1], t);
    }

    private void put(int x, int y, char ch) {
        for (int t = 0; t < 4; t++) {
            int[] q = rot(x, y, t);
            if (g.in(q[0], q[1])) {
                g.set(q[0], q[1], ch);
            }
        }
    }

    private void hold(int x, int y) {
        for (int t = 0; t < 4; t++) {
            int[] q = rot(x, y, t);
            if (g.in(q[0], q[1])) {
                lock[g.idx(q[0], q[1])] = true;
            }
        }
    }

    private void putHold(int x, int y, char ch) {
        put(x, y, ch);
        hold(x, y);
    }

    private boolean locked(int x, int y) {
        return !g.in(x, y) || lock[g.idx(x, y)];
    }

    // ---- сборка ----

    private WorldPlan build() {
        bases();
        field();
        heart();
        for (int i = 0; i < k; i++) {
            placeBase(i);
        }
        connect();
        List<int[]> pairs = pairs();
        if (pairs == null) {
            return why("нет пар соседей с равными путями");
        }
        for (int[] e : pairs) {
            if (!mine(e)) {
                return why("кольцо прииска не встало");
            }
        }
        connect();
        if (!nearDeposits()) {
            return why("ближняя или карман");
        }
        widen();
        cleanup();
        return finish();
    }

    // ---- рельеф ----

    /** Поле по облику, сумма (или максимум) по четырём поворотам, порог, клеточный автомат; край мира — скала. */
    private void field() {
        double[] f = noise();
        boolean max = arch == Archetype.CANYONS || arch == Archetype.SINKHOLES;
        double[] sum = new double[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                double s = max ? -1e9 : 0;
                for (int t = 0; t < 4; t++) {
                    int[] q = rot(x, y, t);
                    double v = f[q[1] * n + q[0]];
                    s = max ? Math.max(s, v) : s + v;
                }
                sum[y * n + x] = s;
            }
        }
        double share = switch (arch) {
            case PLATEAU -> 0.22;
            case CANYONS -> 0.30;
            case SINKHOLES -> 0.27;
            case ROCK_MAZE -> 0.40;
        };
        // поле — в доли (ранг клетки среди всех), долины снижают его: скала там, где доля выше порога и долины
        Integer[] order = new Integer[n * n];
        for (int i = 0; i < order.length; i++) {
            order[i] = i;
        }
        Arrays.sort(order, (p, q) -> Double.compare(sum[p], sum[q]));
        double[] rank = new double[n * n];
        for (int i = 0; i < order.length; i++) {
            rank[order[i]] = (double) i / (order.length - 1);
        }
        double[] valley = valleys();
        boolean[] rock = new boolean[n * n];
        for (int i = 0; i < rock.length; i++) {
            int x = i % n;
            int y = i / n;
            rock[i] = rank[i] > 1 - share + valley[i] || x == 0 || y == 0 || x == n - 1 || y == n - 1;
        }
        int smooth = switch (arch) {
            case PLATEAU -> 3;
            case CANYONS -> 0;
            case SINKHOLES -> 1;
            case ROCK_MAZE -> 2;
        };
        for (int s = 0; s < smooth; s++) {
            rock = Terrain.smooth(rock, n, n, null);
        }
        for (int i = 0; i < rock.length; i++) {
            g.a[i] = rock[i] ? Cells.ROCK : Cells.FLOOR;
            int x = i % n;
            int y = i / n;
            if (x == 0 || y == 0 || x == n - 1 || y == n - 1) {
                g.a[i] = Cells.ROCK;
                lock[i] = true;
            }
        }
    }

    /**
     * Долины, которые рельеф не перекрывает: вдоль круга баз (соседям друг до друга поровну) и от каждой базы к сердцу
     * (до сердца поровну). Ширина гуляет по шуму, у краёв долины скала возможна — это склоны, а не стены. Всё задано
     * по всем копиям баз, поэтому долины симметричны так же, как поле.
     */
    private double[] valleys() {
        double rho = radius(seats);
        double[] wob = Terrain.valueNoise(n, n, 5.0, r);
        double[] sym = new double[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                double s = 0;
                for (int t = 0; t < 4; t++) {
                    int[] q = rot(x, y, t);
                    s += wob[q[1] * n + q[0]];
                }
                sym[y * n + x] = s / 4;
            }
        }
        List<double[]> spokes = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                int[] q = copy(i, t);
                spokes.add(new double[] {q[0] - c, q[1] - c});
            }
        }
        double[] v = new double[n * n];
        for (int y = 0; y < n; y++) {
            for (int x = 0; x < n; x++) {
                double dx = x - c;
                double dy = y - c;
                double rr = Math.hypot(dx, dy);
                double w = 0.7 + 0.6 * sym[y * n + x];
                double ring = Math.exp(-Math.pow((rr - rho) / (2.6 * w), 2));
                double spoke = 0;
                for (double[] b : spokes) {
                    double bl = Math.hypot(b[0], b[1]);
                    double along = (dx * b[0] + dy * b[1]) / bl;
                    if (along < 6 || along > bl) {
                        continue;
                    }
                    double across = Math.abs(dx * b[1] - dy * b[0]) / bl;
                    spoke = Math.max(spoke, Math.exp(-Math.pow(across / (1.9 * w), 2)));
                }
                // гряда внутри круга баз: между долиной круга и серединой, прорезана долинами к сердцу. Общие прииски
                // стоят в ней: со стороны круга — дверь, со стороны сердца — проход, обход — через долину к сердцу
                double wall = Math.exp(-Math.pow((rr - (rho - 6.5)) / (2.0 * w), 2));
                // и внутренняя долина: от прохода прииска к соседним долинам к сердцу
                double inner = Math.exp(-Math.pow((rr - (rho - 11.5)) / (1.8 * w), 2));
                v[y * n + x] = Math.max(Math.max(0.8 * ring, 0.5 * spoke), 0.35 * inner) - 1.4 * wall * (1 - spoke);
            }
        }
        return v;
    }

    /**
     * Шум облика на всём квадрате: плато — крупный, гладкий; ущелья — гребни (узкие полосы у середины шума);
     * провалы — круглые ямы; лабиринт — мелкий.
     */
    private double[] noise() {
        return switch (arch) {
            case PLATEAU -> Terrain.fractal(n, n, n / 4.5, 0.35, r);
            case ROCK_MAZE -> Terrain.fractal(n, n, 3.4, 0.6, r);
            case CANYONS -> {
                double[] b = Terrain.fractal(n, n, n / 5.0, 0.25, r);
                for (int i = 0; i < b.length; i++) {
                    b[i] = 1 - Math.abs(2 * b[i] - 1);
                }
                yield b;
            }
            case SINKHOLES -> {
                double[] b = new double[n * n];
                double[] wob = Terrain.valueNoise(n, n, 2.5, r);
                int count = Math.max(3, (int) Math.round(n * n * 0.075 / (Math.PI * 3.6 * 3.6)));
                for (int m = 0; m < count; m++) {
                    double rad = 2.6 + r.nextDouble() * 2.2;
                    double cx = 2 + r.nextDouble() * (n - 4);
                    double cy = 2 + r.nextDouble() * (n - 4);
                    int r0 = (int) Math.ceil(rad * 1.3) + 1;
                    for (int dy = -r0; dy <= r0; dy++) {
                        for (int dx = -r0; dx <= r0; dx++) {
                            int x = (int) Math.round(cx) + dx;
                            int y = (int) Math.round(cy) + dy;
                            if (x < 0 || y < 0 || x >= n || y >= n) {
                                continue;
                            }
                            double d = Math.hypot(x - cx, y - cy);
                            double v = 1 - d / (rad * (0.85 + 0.3 * wob[y * n + x]));
                            b[y * n + x] = Math.max(b[y * n + x], v);
                        }
                    }
                }
                yield b;
            }
        };
    }

    /**
     * Сердце в середине: столп, четыре жилы на осях под обвалом и поляна вокруг; к поляне сходятся долины от баз.
     * Поляна прячет «калейдоскоп» поля у самой середины.
     */
    private void heart() {
        for (int y = c - 9; y <= c + 9; y++) {
            for (int x = c - 9; x <= c + 9; x++) {
                double d = Math.hypot(x - c, y - c);
                char ch;
                if (d <= 1.0) {
                    ch = Cells.ROCK;
                } else if (d <= 3.9) {
                    ch = Cells.RUBBLE;
                } else if (d <= 6.5) {
                    ch = Cells.FLOOR;
                } else {
                    continue;
                }
                g.set(x, y, ch);
                lock[g.idx(x, y)] = true;
            }
        }
        putHold(c, c - 2, 'C');
    }

    // ---- базы ----

    /**
     * {@code k} баз в четверти на одном круге вокруг сердца, через равные углы (поворот четверти даёт остальные);
     * сдвиг всего круга по углу — по зерну, каждой базе — ещё на клетку-две. Соседи по кругу — пары для общих
     * приисков: расстояния между ними почти равны, разницу даёт только рельеф.
     */
    private boolean bases() {
        double rho = radius(seats);
        double step = Math.PI / 2 / k;
        double phase = r.nextDouble() * step;
        for (int i = 0; i < k; i++) {
            double a = phase + i * step + (r.nextDouble() - 0.5) * step * 0.12;
            double rr = rho + r.nextInt(3) - 1;
            int x = (int) Math.round(c - rr * Math.cos(a));
            int y = (int) Math.round(c - rr * Math.sin(a));
            x = Math.max(4, Math.min(c - 1, x));
            y = Math.max(4, Math.min(c, y));
            base[i] = new int[] {x, y};
        }
        return true;
    }

    /** Площадка 5×5, база, домашняя жила по диагонали наружу в нише: туда только появляются (как в квартале). */
    private void placeBase(int i) {
        int x = base[i][0];
        int y = base[i][1];
        int dx = -1;
        int dy = y < c ? -1 : 1;
        for (int yy = y - 2; yy <= y + 2; yy++) {
            for (int xx = x - 2; xx <= x + 2; xx++) {
                if (!locked(xx, yy)) {
                    if (Math.max(Math.abs(xx - x), Math.abs(yy - y)) <= 1) {
                        putHold(xx, yy, Cells.FLOOR);
                    } else {
                        put(xx, yy, Cells.FLOOR);
                    }
                }
            }
        }
        putHold(x, y, '@');
        putHold(x + dx, y + dy, 'H');
        home[i] = new int[] {x + dx, y + dy};
        putHold(x + dx, y, Cells.ROCK);
        putHold(x + 2 * dx, y + dy, Cells.ROCK);
        putHold(x + dx, y + 2 * dy, Cells.ROCK);
        putHold(x + 2 * dx, y + 2 * dy, Cells.ROCK);
        putHold(x, y + 2 * dy, Cells.ROCK);
        putHold(x - dx, y + dy, Cells.ROCK);
    }

    private List<int[]> out(int[] b) {
        return PodGen.walkOut(g, b[0], b[1]);
    }

    private List<int[]> allOut() {
        List<int[]> src = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                src.addAll(out(copy(i, t)));
            }
        }
        return src;
    }

    // ---- связность ----

    /**
     * Весь пол связан с базой 0 (завалы разобраны): мелкие отрезанные клочки заливаются скалой, крупные
     * соединяются ходом сквозь незакреплённую скалу. Каждое исправление пишется в четыре поворота.
     */
    private void connect() {
        for (int pass = 0; pass < 60; pass++) {
            // завалы закрыты: пол за завалом тоже должен быть достижим в обход
            int[] d = g.dist(out(copy(0, 0)), false, 0);
            List<Integer> sizes = new ArrayList<>();
            int[] comp = g.components(i -> Cells.walk(g.a[i]) && d[i] < 0 && !nicheOrInside(i), false, sizes);
            int pick = -1;
            for (int i = 0; i < comp.length && pick < 0; i++) {
                if (comp[i] >= 0) {
                    pick = i;
                }
            }
            if (pick < 0) {
                return;
            }
            int id = comp[pick];
            boolean held = false;
            for (int i = 0; i < comp.length; i++) {
                if (comp[i] == id && lock[i]) {
                    held = true;
                    break;
                }
            }
            if (sizes.get(id) <= 12 && !held) {
                for (int i = 0; i < comp.length; i++) {
                    if (comp[i] == id) {
                        put(i % n, i / n, Cells.ROCK);
                    }
                }
            } else {
                carve(pick, d);
            }
        }
    }

    /** Ниша домашней жилы — к ней не ходят, а появляются. */
    private boolean nicheOrInside(int i) {
        int x = i % n;
        int y = i / n;
        for (int[] d : Cells.DIRS) {
            if (g.get(x + d[0], y + d[1]) == 'H') {
                return true;
            }
        }
        return false;
    }

    /** Прорубить ход от клетки {@code from} до ближайшей достижимой — сквозь незакреплённую скалу, в четыре поворота. */
    private void carve(int from, int[] reach) {
        int[] prev = new int[n * n];
        Arrays.fill(prev, -2);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        prev[from] = -1;
        q.add(from);
        int hit = -1;
        while (!q.isEmpty() && hit < 0) {
            int i = q.poll();
            for (int[] dd : Cells.DIRS) {
                int x = i % n + dd[0];
                int y = i / n + dd[1];
                if (!g.in(x, y)) {
                    continue;
                }
                int j = g.idx(x, y);
                if (prev[j] != -2) {
                    continue;
                }
                char ch = g.a[j];
                if (reach[j] >= 0 && Cells.walk(ch)) {
                    prev[j] = i;
                    hit = j;
                    break;
                }
                if (Cells.walk(ch) || ch == Cells.ROCK && !lock[j]) {
                    prev[j] = i;
                    q.add(j);
                }
            }
        }
        for (int i = hit; i >= 0; i = prev[i]) {
            if (g.a[i] == Cells.ROCK && !lock[i]) {
                put(i % n, i / n, Cells.FLOOR);
            }
        }
    }

    // ---- общие прииски ----

    /**
     * Пары соседей по кругу для общих приисков: у каждого места два соседа — два прииска. Для пары (класс a, копия 0)
     * и (класс b, копия rb) — клетка M почти посередине по пути ({@code |dA − dB| ≤ 1}), ближе к которой нет других
     * баз. Возвращает {a, b, rb, mx, my, half}; {@code null} — середины нет или расстояния у классов расходятся
     * больше чем на 3.
     */
    private List<int[]> pairs() {
        int copies = 4 * k;
        int[][] d = new int[copies][];
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                d[i * 4 + t] = g.dist(out(copy(i, t)), false, 0);
            }
        }
        // соседи по кругу: i и i+1 в четверти, последний — с первым следующей четверти
        List<int[]> want = new ArrayList<>();
        for (int i = 0; i + 1 < k; i++) {
            want.add(new int[] {i, i + 1, 0});
        }
        want.add(k == 1 ? new int[] {0, 0, 1} : new int[] {0, k - 1, 3});
        List<int[]> chosen = new ArrayList<>();
        for (int[] w : want) {
            int a = w[0];
            int b = w[1];
            int rb = w[2];
            int[] da = d[a * 4];
            int[] db = d[b * 4 + rb];
            int best = -1;
            int bestM = Integer.MAX_VALUE;
            for (int i = 0; i < n * n; i++) {
                int va = da[i];
                int vb = db[i];
                if (va < 0 || vb < 0 || Math.abs(va - vb) > 1 || g.a[i] != Cells.FLOOR || lock[i]) {
                    continue;
                }
                int m = Math.max(va, vb);
                if (m >= bestM || Math.hypot(i % n - c, i / n - c) < 11) {
                    continue;
                }
                boolean pair = true;
                for (int x = 0; x < copies && pair; x++) {
                    if (x == a * 4 || x == b * 4 + rb) {
                        continue;
                    }
                    pair = d[x][i] < 0 || d[x][i] >= m;
                }
                if (pair) {
                    best = i;
                    bestM = m;
                }
            }
            if (best < 0) {
                return null;
            }
            chosen.add(new int[] {a, b, rb, best % n, best / n, bestM});
        }
        if (spread(chosen) > 3) {
            if (TRACE) {
                WHY.merge("разброс пар " + spread(chosen), 1, Integer::sum);
            }
            return null;
        }
        return chosen;
    }

    /** Разброс расстояний до приисков между классами: по первому и второму приииску класса, худший. */
    private int spread(List<int[]> chosen) {
        List<List<Integer>> per = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            per.add(new ArrayList<>());
        }
        for (int[] cd : chosen) {
            per.get(cd[0]).add(cd[5]);
            per.get(cd[1]).add(cd[5]);
        }
        int worst = 0;
        for (int m = 0; m < MINES_PER_SEAT; m++) {
            int lo = Integer.MAX_VALUE;
            int hi = Integer.MIN_VALUE;
            for (List<Integer> l : per) {
                l.sort(null);
                lo = Math.min(lo, l.get(m));
                hi = Math.max(hi, l.get(m));
            }
            worst = Math.max(worst, hi - lo);
        }
        return worst;
    }

    /**
     * Общий прииск пары: жила в стороне от середины M (на 3 клетки поперёк линии баз), вокруг — кольцо скалы.
     * В кольце со стороны M — завал (дверь на двоих), напротив — проход; вокруг кольца — расчищенный обход.
     */
    private boolean mine(int[] e) {
        int[] a = copy(e[0], 0);
        int[] b = copy(e[1], e[2]);
        double ax = a[0] - c;
        double ay = a[1] - c;
        double bx = b[0] - c;
        double by = b[1] - c;
        double ux = ax / Math.hypot(ax, ay) + bx / Math.hypot(bx, by);
        double uy = ay / Math.hypot(ax, ay) + by / Math.hypot(bx, by);
        double ul = Math.hypot(ux, uy);
        ux /= ul;
        uy /= ul;
        double rho = (Math.hypot(ax, ay) + Math.hypot(bx, by)) / 2;
        for (double depth : new double[] {6.0, 5.5, 6.5}) {
            int px = (int) Math.round(c + ux * (rho - depth));
            int py = (int) Math.round(c + uy * (rho - depth));
            if (fits(px, py)) {
                ring(px, py, ux, uy);
                mines.add(new int[] {px, py, e[0], e[1], e[2]});
                return true;
            }
        }
        return false;
    }

    private boolean fits(int px, int py) {
        if (Math.hypot(px - c, py - c) < 12.7) {
            return false;
        }
        for (int y = py - 6; y <= py + 6; y++) {
            for (int x = px - 6; x <= px + 6; x++) {
                if (Math.hypot(x - px, y - py) > 4.3) {
                    continue;
                }
                if (x < 2 || y < 2 || x > n - 3 || y > n - 3 || lock[g.idx(x, y)]) {
                    return false;
                }
            }
        }
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                int[] q = copy(i, t);
                if (Math.hypot(q[0] - px, q[1] - py) < 5.5) {
                    return false;
                }
            }
        }
        // свои повороты не должны задевать друг друга
        int[] q = rot(px, py, 1);
        return Math.hypot(q[0] - px, q[1] - py) > 9;
    }

    /**
     * Кольцо прииска с дверью в сторону {@code (dx, dy)} (к кругу баз) и проходом напротив (к сердцу). Снаружи кольца:
     * со стороны двери и со стороны прохода — пол, с боков — скала, чтобы кольцо не обойти рядом.
     */
    private void ring(int px, int py, double dx, double dy) {
        for (int y = py - 6; y <= py + 6; y++) {
            for (int x = px - 6; x <= px + 6; x++) {
                double d = Math.hypot(x - px, y - py);
                double cos = d == 0 ? 0 : ((x - px) * dx + (y - py) * dy) / d;
                if (d > 4.3 && !(d <= 5.8 && cos <= -0.75 && !locked(x, y))) {
                    continue;
                }
                char ch;
                if (d <= 1.5) {
                    ch = Cells.FLOOR;
                } else if (d <= 2.6) {
                    ch = cos >= 0.86 ? Cells.RUBBLE : cos <= -0.86 ? Cells.FLOOR : Cells.ROCK;
                } else {
                    ch = Math.abs(cos) >= 0.5 ? Cells.FLOOR : Cells.ROCK;
                }
                putHold(x, y, ch);
            }
        }
        putHold(px, py, '$');
    }

    // ---- ближние жилы ----

    /** Ближняя жила (3–6 шагов, жадный шаг доходит) и карман (5–12, не доходит) у каждого класса; классы — в допуске. */
    private boolean nearDeposits() {
        int t1 = -1;
        int t2 = -1;
        for (int i = 0; i < k; i++) {
            boolean done = false;
            int[] d0 = g.dist(out(copy(i, 0)), false, 0);
            List<int[]> cands = new ArrayList<>();
            int bx = base[i][0];
            int by = base[i][1];
            for (int y = by - 7; y <= by + 7; y++) {
                for (int x = bx - 7; x <= bx + 7; x++) {
                    if (!g.in(x, y) || locked(x, y) || g.get(x, y) != Cells.FLOOR) {
                        continue;
                    }
                    int v = d0[g.idx(x, y)];
                    if (v >= 3 && v <= 6 && quiet(x, y) && own(x, y, i) && farFromMines(x, y)) {
                        cands.add(new int[] {x, y});
                    }
                }
            }
            shuffle(cands);
            cands.sort((p, q) -> rockSides(q) - rockSides(p));
            for (int ci = 0; ci < Math.min(10, cands.size()) && !done; ci++) {
                char[] save = g.a.clone();
                boolean[] saveLock = lock.clone();
                int[] q = cands.get(ci);
                putHold(q[0], q[1], '*');
                trimSpots(q, d0);
                near1[i] = q;
                int[] dd = g.dist(out(copy(i, 0)), false, 0);
                int n1 = g.toSpots(dd, q[0], q[1]);
                if (n1 >= 3 && n1 <= 6 && !crumbAround(q) && (t1 < 0 || Math.abs(n1 - t1) <= 1) && pocket(i, t2)) {
                    if (t1 < 0) {
                        t1 = n1;
                        t2 = g.toSpots(g.dist(out(copy(i, 0)), false, 0), near2[i][0], near2[i][1]);
                    }
                    done = true;
                } else {
                    System.arraycopy(save, 0, g.a, 0, save.length);
                    System.arraycopy(saveLock, 0, lock, 0, lock.length);
                    near1[i] = null;
                    near2[i] = null;
                }
            }
            if (!done) {
                return false;
            }
        }
        return true;
    }

    /** Карман: жила в скальном блоке 3×3 с прорезью от базы; 5–12 шагов, жадный шаг ни от одной копии не доходит. */
    private boolean pocket(int i, int target) {
        int bx = base[i][0];
        int by = base[i][1];
        List<int[]> cands = new ArrayList<>();
        int[] d = g.dist(out(copy(i, 0)), false, 0);
        for (int y = by - 9; y <= by + 9; y++) {
            for (int x = bx - 9; x <= bx + 9; x++) {
                if (x < 3 || y < 3 || x > n - 4 || y > n - 4) {
                    continue;
                }
                int v = d[g.idx(x, y)];
                if (v < 4 || v > 12 || Math.abs(x - near1[i][0]) + Math.abs(y - near1[i][1]) < 4
                        || !own(x, y, i) || !farFromMines(x, y)) {
                    continue;
                }
                boolean free = true;
                for (int yy = y - 1; yy <= y + 1 && free; yy++) {
                    for (int xx = x - 1; xx <= x + 1; xx++) {
                        if (locked(xx, yy)) {
                            free = false;
                            break;
                        }
                    }
                }
                if (free) {
                    cands.add(new int[] {x, y});
                }
            }
        }
        shuffle(cands);
        int tries = 0;
        for (int[] cand : cands) {
            if (++tries > 30) {
                break;
            }
            int x = cand[0];
            int y = cand[1];
            int[] o = null;
            int best = Integer.MIN_VALUE;
            for (int[] dir : Cells.DIRS) {
                int dot = dir[0] * (x - bx) + dir[1] * (y - by);
                if (dot > best) {
                    best = dot;
                    o = dir;
                }
            }
            int mx = x + o[0];
            int my = y + o[1];
            int ox = x + 2 * o[0];
            int oy = y + 2 * o[1];
            if (!g.in(ox, oy) || locked(ox, oy) || g.get(ox, oy) != Cells.FLOOR) {
                continue;
            }
            char[] save = g.a.clone();
            boolean[] saveLock = lock.clone();
            int[] pp = {o[1], o[0]};
            for (int yy = y - 1; yy <= y + 1; yy++) {
                for (int xx = x - 1; xx <= x + 1; xx++) {
                    putHold(xx, yy, Cells.ROCK);
                }
            }
            putHold(mx + pp[0], my + pp[1], Cells.ROCK);
            putHold(mx - pp[0], my - pp[1], Cells.ROCK);
            putHold(x, y, '*');
            putHold(mx, my, Cells.FLOOR);
            putHold(ox, oy, Cells.FLOOR);
            int[] d2 = g.dist(out(copy(i, 0)), false, 0);
            int v = d2[g.idx(mx, my)];
            near2[i] = new int[] {x, y};
            boolean ok = v >= 5 && v <= 12 && (target < 0 || Math.abs(g.toSpots(d2, x, y) - target) <= 2)
                    && g.toSpots(d2, near1[i][0], near1[i][1]) >= 0 && greedyOk(i);
            if (ok) {
                return true;
            }
            near2[i] = null;
            System.arraycopy(save, 0, g.a, 0, save.length);
            System.arraycopy(saveLock, 0, lock, 0, lock.length);
        }
        return false;
    }

    /** Жадный шаг в каждой копии класса: до ближней и обратно доходит, до кармана — нет. */
    private boolean greedyOk(int i) {
        for (int t = 0; t < 4; t++) {
            int[] b = copy(i, t);
            int[] q1 = rot(near1[i][0], near1[i][1], t);
            int[] q2 = rot(near2[i][0], near2[i][1], t);
            PodGen.Sector s = new PodGen.Sector(t, b, null, q1, q2);
            if (!PodGen.greedyOk(g, s)) {
                return false;
            }
        }
        return true;
    }

    /** Сколько сторон клетки упирается в скалу: лучше две (жила у стены), хуже — ни одной. */
    private int rockSides(int[] q) {
        int s = 0;
        for (int[] d : Cells.DIRS) {
            if (g.get(q[0] + d[0], q[1] + d[1]) == Cells.ROCK) {
                s++;
            }
        }
        return s == 2 ? 3 : s == 1 ? 2 : s == 3 ? 1 : 0;
    }

    /** Закрытые места у жилы не остались отдельными камнями в 1–2 клетки. */
    private boolean crumbAround(int[] q) {
        for (int[] d : Cells.DIRS) {
            int x = q[0] + d[0];
            int y = q[1] + d[1];
            if (g.get(x, y) != Cells.ROCK) {
                continue;
            }
            int rock = 0;
            for (int[] e : Cells.RING8) {
                if (g.get(x + e[0], y + e[1]) == Cells.ROCK) {
                    rock++;
                }
            }
            if (rock == 0) {
                return true;
            }
        }
        return false;
    }

    /** Рядом нет закреплённых жил, баз и завалов. */
    private boolean quiet(int x, int y) {
        for (int yy = y - 1; yy <= y + 1; yy++) {
            for (int xx = x - 1; xx <= x + 1; xx++) {
                char ch = g.get(xx, yy);
                if (locked(xx, yy) && !(xx == x && yy == y) && ch != Cells.FLOOR && ch != Cells.ROCK) {
                    return false;
                }
            }
        }
        return true;
    }

    /** Жила своя: по прямой ({@code |dx| + |dy|}) любая чужая база хотя бы на 3 дальше своей. */
    private boolean own(int x, int y, int i) {
        int mine = Math.abs(x - base[i][0]) + Math.abs(y - base[i][1]);
        for (int j = 0; j < k; j++) {
            for (int t = 0; t < 4; t++) {
                if (j == i && t == 0) {
                    continue;
                }
                int[] q = copy(j, t);
                if (Math.abs(x - q[0]) + Math.abs(y - q[1]) < mine + 3) {
                    return false;
                }
            }
        }
        return true;
    }

    private boolean farFromMines(int x, int y) {
        for (int[] m : mines) {
            for (int t = 0; t < 4; t++) {
                int[] q = rot(m[0], m[1], t);
                if (Math.hypot(q[0] - x, q[1] - y) < 5.5) {
                    return false;
                }
            }
        }
        return true;
    }

    private void trimSpots(int[] q, int[] d) {
        List<int[]> s = g.spots(q[0], q[1]);
        s.sort((a, b) -> Integer.compare(score(d, a), score(d, b)));
        for (int i = 2; i < s.size(); i++) {
            putHold(s.get(i)[0], s.get(i)[1], Cells.ROCK);
        }
        for (int i = 0; i < Math.min(2, s.size()); i++) {
            hold(s.get(i)[0], s.get(i)[1]);
        }
    }

    private int spotsOrFar(int[] d, int[] cell) {
        int v = g.toSpots(d, cell[0], cell[1]);
        return v < 0 ? 9999 : v;
    }

    private int score(int[] d, int[] cell) {
        int v = d[g.idx(cell[0], cell[1])];
        return v < 0 ? 999 : v;
    }

    // ---- магистрали и чистка ----

    /** Пути от базы к ближней, карману, приискам и сердцу — не уже двух клеток. */
    private void widen() {
        for (int i = 0; i < k; i++) {
            List<int[]> ms = new ArrayList<>();
            for (int[] m : mines) {
                for (int t = 0; t < 4; t++) {
                    ms.add(rot(m[0], m[1], t));
                }
            }
            int[] b = copy(i, 0);
            int[] dAll = g.dist(out(b), false, 0);
            ms.sort((p, q) -> Integer.compare(spotsOrFar(dAll, p), spotsOrFar(dAll, q)));
            // свои два прииска — ближайшие; ещё ближняя, карман и поляна у сердца
            List<int[]> use = new ArrayList<>(ms.subList(0, Math.min(ms.size(), MINES_PER_SEAT)));
            use.add(near1[i]);
            use.add(near2[i]);
            use.add(new int[] {c, c - 8});
            for (int[] t : use) {
                List<int[]> path = route(out(b), t);
                for (int p = 1; p + 1 < path.size(); p++) {
                    int[] cur = path.get(p);
                    int[] nx = path.get(p + 1);
                    int dx = nx[0] - cur[0];
                    int dy = nx[1] - cur[1];
                    int[] sa = {cur[0] - dy, cur[1] + dx};
                    int[] sb = {cur[0] + dy, cur[1] - dx};
                    if (Cells.walk(g.get(sa[0], sa[1])) || Cells.walk(g.get(sb[0], sb[1]))) {
                        continue;
                    }
                    for (int[] side : new int[][] {sa, sb}) {
                        if (g.in(side[0], side[1]) && g.get(side[0], side[1]) == Cells.ROCK
                                && !locked(side[0], side[1])) {
                            put(side[0], side[1], Cells.FLOOR);
                            break;
                        }
                    }
                }
            }
        }
    }

    private List<int[]> route(List<int[]> from, int[] to) {
        int[] prev = new int[n * n];
        Arrays.fill(prev, -2);
        ArrayDeque<Integer> q = new ArrayDeque<>();
        for (int[] f : from) {
            prev[g.idx(f[0], f[1])] = -1;
            q.add(g.idx(f[0], f[1]));
        }
        int hit = -1;
        while (!q.isEmpty() && hit < 0) {
            int i = q.poll();
            int x = i % n;
            int y = i / n;
            if (Math.abs(x - to[0]) + Math.abs(y - to[1]) <= 1) {
                hit = i;
                break;
            }
            for (int[] d : Cells.DIRS) {
                int nx = x + d[0];
                int ny = y + d[1];
                if (g.walk(nx, ny, false) && prev[g.idx(nx, ny)] == -2) {
                    prev[g.idx(nx, ny)] = i;
                    q.add(g.idx(nx, ny));
                }
            }
        }
        List<int[]> outPath = new ArrayList<>();
        for (int i = hit; i >= 0; i = prev[i]) {
            outPath.add(0, new int[] {i % n, i / n});
        }
        return outPath;
    }

    /** Камни в 1–2 клетки — в пол; отрезанный пол — залить или соединить. */
    private void cleanup() {
        for (int pass = 0; pass < 3; pass++) {
            List<Integer> sizes = new ArrayList<>();
            int[] comp = g.components(i -> g.a[i] == Cells.ROCK, true, sizes);
            boolean any = false;
            for (int i = 0; i < comp.length; i++) {
                if (comp[i] >= 0 && sizes.get(comp[i]) <= 2 && !lock[i]) {
                    put(i % n, i / n, Cells.FLOOR);
                    any = true;
                }
            }
            connect();
            if (!any) {
                break;
            }
        }
    }

    // ---- итог ----

    private WorldPlan finish() {
        // номера мест: копия t класса i; «бронза» — по одной в разных четвертях, номера после asked
        int[][] number = new int[k][4];
        int bots = seats - asked;
        List<Integer> quarters = new ArrayList<>(List.of(0, 1, 2, 3));
        int botNo = asked;
        for (int b = 0; b < bots; b++) {
            int t = quarters.remove(r.nextInt(quarters.size()));
            number[r.nextInt(k)][t] = ++botNo;
        }
        int no = 0;
        for (int t = 0; t < 4; t++) {
            for (int i = 0; i < k; i++) {
                if (number[i][t] == 0) {
                    number[i][t] = ++no;
                }
            }
        }
        WorldPlan.Seat[] bySeat = new WorldPlan.Seat[seats];
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                int[] b = copy(i, t);
                int[] h = rot(home[i][0], home[i][1], t);
                int[] a = rot(near1[i][0], near1[i][1], t);
                int[] p = rot(near2[i][0], near2[i][1], t);
                int s = number[i][t];
                bySeat[s - 1] = new WorldPlan.Seat(s, t, i, new Pos(b[0], b[1]), new Pos(h[0], h[1]),
                        new Pos(a[0], a[1]), new Pos(p[0], p[1]));
            }
        }
        List<WorldPlan.Seat> seatList = List.of(bySeat);
        for (WorldPlan.Seat s : seatList) {
            g.set(s.base().x(), s.base().y(), GameMap.BASE_MARKS.charAt(s.seat() - 1));
        }
        WorldPlan.Report report = check(seatList);
        // имена: общие прииски и сердце
        Names names = new Names(r);
        List<GameMap.Region> regions = new ArrayList<>();
        regions.add(new GameMap.Region("Сердце", c, Math.min(n - 2, c + 10)));
        List<WorldPlan.Pass> shared = new ArrayList<>();
        for (int[] m : mines) {
            for (int t = 0; t < 4; t++) {
                int[] q = rot(m[0], m[1], t);
                String nm = names.name(Names.MINE, -1);
                regions.add(new GameMap.Region(nm, q[0], Math.min(n - 2, q[1] + 3)));
                List<Integer> owners = List.of(number[m[2]][t], number[m[3]][(m[4] + t) & 3]);
                shared.add(new WorldPlan.Pass(List.of(new Pos(q[0], q[1])), owners, nm));
            }
        }
        Map<DepositKind, Integer> amounts = new EnumMap<>(DepositKind.class);
        amounts.put(DepositKind.NORMAL, WorldGen.NORMAL);
        amounts.put(DepositKind.RICH, WorldGen.RICH);
        amounts.put(DepositKind.CENTER, WorldGen.CENTER);
        GameMap map = GameMap.of("world-" + seats + "-" + seed, seats, g.rows(), amounts, regions);
        return new WorldPlan(map, arch, asked, List.of(), seatList, List.copyOf(shared), new Pos(c, c), null,
                report, 1, 0);
    }

    /**
     * Проверки мира из четверти. Жёсткие: нет мелочи, всё связно, у жил нет мест, куда без кирки не дойти; у каждого
     * места ближняя 3–6, карман 5–12 и жадный шаг до него не доходит, два общих прииска, обход длиннее двери хотя бы на
     * {@link #DOOR_GAIN_MIN}; у каждого прииска два хозяина почти поровну (±1); между классами — ближняя ±1, карман и
     * прииски ±2, сердце ±3.
     */
    private WorldPlan.Report check(List<WorldPlan.Seat> seatList) {
        List<String> fail = new ArrayList<>();
        List<Integer> sizes = new ArrayList<>();
        g.components(i -> g.a[i] == Cells.ROCK, true, sizes);
        long crumbs = sizes.stream().filter(s -> s <= 2).count();
        if (crumbs > 0) {
            fail.add("скал из 1–2 клеток: " + crumbs);
        }
        List<int[]> all = allOut();
        List<int[]> withNiche = new ArrayList<>();
        for (WorldPlan.Seat st : seatList) {
            withNiche.addAll(g.spots(st.base().x(), st.base().y()));
        }
        int[] open = g.dist(withNiche, true, 0);
        int[] closed = g.dist(all, false, 0);
        int lost = 0;
        int hidden = 0;
        for (int i = 0; i < g.a.length; i++) {
            if ((Cells.walk(g.a[i]) || g.a[i] == Cells.RUBBLE) && open[i] < 0) {
                lost++;
            }
            char ch = g.a[i];
            if (Cells.deposit(ch) && ch != 'H' && ch != 'C') {
                for (int[] sp : g.spots(i % n, i / n)) {
                    if (closed[g.idx(sp[0], sp[1])] < 0) {
                        hidden++;
                    }
                }
            }
        }
        if (lost > 0) {
            fail.add("недостижимых клеток: " + lost);
        }
        if (hidden > 0) {
            fail.add("мест у жил за завалом без обхода: " + hidden);
        }
        // замеры по классам (копия 0; остальные — её повороты)
        List<int[]> mineCells = new ArrayList<>();
        for (int i = 0; i < g.a.length; i++) {
            if (g.a[i] == '$') {
                mineCells.add(new int[] {i % n, i / n});
            }
        }
        int[][] per = new int[k][];
        WorldPlan.Paths[] paths = new WorldPlan.Paths[seats];
        double gainSum = 0;
        int gainN = 0;
        for (int i = 0; i < k; i++) {
            int[] b = copy(i, 0);
            int[] dc = g.dist(out(b), false, 0);
            int[] dd = g.dist(out(b), true, 0);
            int n1 = g.toSpots(dc, near1[i][0], near1[i][1]);
            int n2 = g.toSpots(dc, near2[i][0], near2[i][1]);
            int heartD = heartDist(dd);
            int[][] m = new int[mineCells.size()][];
            for (int j = 0; j < m.length; j++) {
                int[] mc = mineCells.get(j);
                m[j] = new int[] {g.toSpots(dd, mc[0], mc[1]), g.toSpots(dc, mc[0], mc[1])};
            }
            Arrays.sort(m, (p, q) -> Integer.compare(p[0] < 0 ? 9999 : p[0], q[0] < 0 ? 9999 : q[0]));
            boolean trap = greedyOk(i);
            String who = "класс " + (i + 1) + ": ";
            if (n1 < 3 || n1 > 6) {
                fail.add(who + "ближняя в " + n1 + " шагах");
            }
            if (n2 < 5 || n2 > 12 || !trap) {
                fail.add(who + "карман в " + n2 + " шагах" + (trap ? "" : ", жадный шаг доходит"));
            }
            if (m.length < MINES_PER_SEAT || heartD < 0) {
                fail.add(who + "приисков " + m.length + ", сердце " + heartD);
                per[i] = new int[] {n1, n2, -1, -1, heartD, -1, -1};
                continue;
            }
            for (int j = 0; j < MINES_PER_SEAT; j++) {
                if (m[j][0] < 0 || m[j][1] < 0 || m[j][1] - m[j][0] < DOOR_GAIN_MIN) {
                    fail.add(who + "прииск " + (j + 1) + ": дверь " + m[j][0] + ", обход " + m[j][1]);
                } else {
                    gainSum += m[j][1] - m[j][0];
                    gainN++;
                }
            }
            per[i] = new int[] {n1, n2, m[0][0], m[1][0], heartD, m[0][1], m[1][1]};
        }
        // у каждого прииска два хозяина почти поровну
        List<int[]> digFrom = new ArrayList<>();
        for (int i = 0; i < k; i++) {
            for (int t = 0; t < 4; t++) {
                digFrom.add(g.dist(out(copy(i, t)), true, 0));
            }
        }
        for (int[] mc : mineCells) {
            List<Integer> ds = new ArrayList<>();
            for (int[] dd : digFrom) {
                ds.add(g.toSpots(dd, mc[0], mc[1]));
            }
            ds.removeIf(v -> v < 0);
            ds.sort(null);
            if (ds.size() >= 2 && ds.get(1) - ds.get(0) > 2) {
                fail.add("прииск (" + mc[0] + ", " + mc[1] + "): хозяевам " + ds.get(0) + " и " + ds.get(1));
                break;
            }
        }
        int[] tol = {1, 2, 2, 2, 3};
        String[] what = {"ближняя", "карман", "первый прииск", "второй прииск", "сердце"};
        double spreadSum = 0;
        for (int f = 0; f < tol.length; f++) {
            int lo = Integer.MAX_VALUE;
            int hi = Integer.MIN_VALUE;
            for (int[] p : per) {
                lo = Math.min(lo, p[f]);
                hi = Math.max(hi, p[f]);
            }
            if (hi - lo > tol[f]) {
                fail.add(what[f] + ": между классами " + lo + "–" + hi);
            }
            spreadSum += (double) (hi - lo) / tol[f];
        }
        for (WorldPlan.Seat s : seatList) {
            int[] p = per[s.sector()];
            paths[s.seat() - 1] = new WorldPlan.Paths(s.seat(), p[0], p[1], p[2], p[5], p[3], p[4],
                    greedyOk(s.sector()));
        }
        Map<String, Double> parts = new LinkedHashMap<>();
        parts.put("fair", -spreadSum);
        parts.put("door", gainN == 0 ? 0 : Math.min(12, gainSum / gainN) / 6);
        int rock = 0;
        for (char ch : g.a) {
            if (ch == Cells.ROCK) {
                rock++;
            }
        }
        parts.put("rock", (double) rock / g.a.length);
        double score = parts.get("fair") + parts.get("door");
        return new WorldPlan.Report(fail, List.of(paths), score, parts);
    }

    /** До клетки вплотную к жиле сердца (она засыпана: путь — с разобранными завалами). */
    private int heartDist(int[] dd) {
        int best = -1;
        for (int[] d : Cells.DIRS) {
            int v = dd[g.idx(c + d[0], c - 2 + d[1])];
            if (v >= 0 && (best < 0 || v < best)) {
                best = v;
            }
        }
        return best;
    }

    private <T> void shuffle(List<T> list) {
        for (int i = list.size() - 1; i > 0; i--) {
            int j = r.nextInt(i + 1);
            T t = list.get(i);
            list.set(i, list.get(j));
            list.set(j, t);
        }
    }
}
