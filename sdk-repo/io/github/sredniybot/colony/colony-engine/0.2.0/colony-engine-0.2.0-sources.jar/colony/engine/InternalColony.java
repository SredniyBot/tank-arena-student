package colony.engine;

import colony.api.Colony;
import colony.api.ColonyView;
import colony.api.Orders;

/**
 * Колония встроенного бота. Навигатор движок передаёт только классам из пакетов {@code colony.bots}
 * и {@code colony.gatebots}; остальным вызывается обычный {@link #onTick(ColonyView, Orders)}, и навигатор равен
 * {@code null}. В API студента навигатора нет: поиск пути пишет студент.
 */
public interface InternalColony extends Colony {

    void onTick(ColonyView view, Orders orders, Navigator nav);

    @Override
    default void onTick(ColonyView view, Orders orders) {
        onTick(view, orders, null);
    }
}
