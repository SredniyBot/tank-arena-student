package colony.engine;

import colony.api.Building;
import colony.api.DepositKind;
import colony.api.Direction;
import colony.api.EventKind;
import colony.api.Pos;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.api.UnitType;
import colony.api.Upgrade;
import colony.engine.OrderBook.Kind;
import colony.engine.OrderBook.Order;
import colony.engine.World.BaseEntity;
import colony.engine.World.Cause;
import colony.engine.World.ColonyState;
import colony.engine.World.DepositEntity;
import colony.engine.World.Shell;
import colony.engine.World.StructureEntity;
import colony.engine.World.UnitEntity;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.TreeMap;

/**
 * Один одновременный такт: проверка приказов, движение, производство, стройка, выстрелы и полёт снарядов, добыча,
 * передача, содержание, гибель (и трофеи), центр, налёты, события, возвращение колоний, восстановление залежей.
 * Все решения — по состоянию на начало такта, порядок — по id. Механики шага 2б работают только при своих флагах
 * {@link RuleSet#features()}.
 */
final class TickResolver implements TickLog {

    private static final String UPKEEP = "upkeep";

    private record Pending(int colonyId, UnitEntity unit, BaseEntity base, Order order) {
        int id() {
            return order.id();
        }
    }

    private static final class Mover {
        final Pending p;
        final Pos to;
        RejectCode failure;
        String message;

        Mover(Pending p, Pos to) {
            this.p = p;
            this.to = to;
        }

        UnitEntity u() {
            return p.unit();
        }

        void fail(RejectCode code, String text) {
            if (failure == null) {
                failure = code;
                message = text;
            }
        }
    }

    private final World w;
    private final RuleSet rules;
    private final RuleSet.Features features;
    private final Map<Integer, List<Rejection>> rejections;
    private final List<Frame.Event> events;
    private final List<Frame.Shot> shots;
    private final Map<Integer, ViewSnapshot> views;
    /** Номер этого такта — тот же, что {@code view.tick()} у колоний в этом такте. */
    private final int t;
    private final boolean truce;
    /** Под защитой новичка на начало такта, по номеру колонии. */
    private final boolean[] guarded;
    /** Юнитов у колонии на начало такта, по номеру колонии. */
    private final int[] unitsAtStart;
    private final List<Pending> moves = new ArrayList<>();
    private final List<Pending> harvests = new ArrayList<>();
    private final List<Pending> transfers = new ArrayList<>();
    private final List<Pending> produces = new ArrayList<>();
    private final List<Pending> fires = new ArrayList<>();
    private final List<Pending> baseFires = new ArrayList<>();
    private final List<Pending> builds = new ArrayList<>();
    private final List<Pending> constructs = new ArrayList<>();
    private final List<Pending> digs = new ArrayList<>();
    private final List<Pending> upgrades = new ArrayList<>();
    private final List<Strikes.Request> attacks = new ArrayList<>();
    private final List<Strikes.Request> strikes = new ArrayList<>();

    private TickResolver(World w, Map<Integer, List<Rejection>> rejections, List<Frame.Event> events,
                         List<Frame.Shot> shots, Map<Integer, ViewSnapshot> views) {
        this.w = w;
        this.rules = w.rules;
        this.features = rules.features();
        this.rejections = rejections;
        this.events = events;
        this.shots = shots;
        this.views = views;
        this.t = w.tick;
        this.truce = w.truce();
        this.guarded = new boolean[w.colonies.size() + 1];
        this.unitsAtStart = new int[w.colonies.size() + 1];
        for (ColonyState c : w.colonies) {
            guarded[c.id] = w.protectedAt(c.id, t);
        }
        for (UnitEntity u : w.units.values()) {
            unitsAtStart[u.colonyId]++;
        }
    }

    /**
     * Считает такт. {@code orders} — приказы ответивших колоний по id колонии; не ответившие стоят.
     * {@code views} — что видела каждая колония в начале такта: чужой юнит вне обзора для неё «не существует».
     * Отказы дописываются в {@code rejections}, события — в {@code events}, выстрелы — в {@code shots}.
     */
    static void resolve(World w, Map<Integer, List<Order>> orders, Map<Integer, ViewSnapshot> views,
                        Map<Integer, List<Rejection>> rejections, List<Frame.Event> events, List<Frame.Shot> shots) {
        new TickResolver(w, rejections, events, shots, views).run(orders);
    }

    private void run(Map<Integer, List<Order>> orders) {
        for (Map.Entry<Integer, List<Order>> e : new TreeMap<>(orders).entrySet()) {
            validate(e.getKey(), e.getValue());
        }
        raiders();
        Comparator<Pending> byId = Comparator.comparingInt(Pending::id);
        for (List<Pending> list : List.of(moves, harvests, transfers, produces, fires, baseFires, builds, constructs,
                digs, upgrades)) {
            list.sort(byId);
        }

        List<UnitEntity>[] startCells = w.occupancy();
        Map<Integer, Integer> startCarry = new HashMap<>();
        for (UnitEntity u : w.units.values()) {
            startCarry.put(u.id, u.carry);
        }
        // удары лиг — мгновенные, по положению на начало такта
        Strikes instant = new Strikes(w, this, startCells);
        instant.melee(attacks);
        instant.tanks(strikes);

        if (features.shellsFirst()) {
            fire();
            baseFire();
            flyShells();
            move();
            produce();
            build();
        } else {
            move();
            produce();
            build();
            fire();
            baseFire();
            flyShells();
        }
        construct();
        dig();
        upgrade();
        harvest();
        transfer(startCells, startCarry);
        upkeep();
        deaths();
        centre();
        if (truce && t + 1 == rules.truceTicks()) {
            event(0, EventKind.TRUCE_END, Messages.truceEnded(), null);
        }
        raid();
        worldEvents();
        respawn();
        FreeWorker.apply(w, this);
        regenerate();
        script();
        w.tick = t + 1;
    }

    // ---- 2. проверка приказов ----

    /**
     * Номер в приказе — номер в колонии: юниты считаются с 1, первая база — {@code 0}, следующие базы берут номера из
     * того же счёта, что и юниты.
     */
    private void validate(int colonyId, List<Order> list) {
        Set<Integer> ordered = new HashSet<>();
        World.Unlocked open = w.colony(colonyId).unlocked;
        for (Order o : list) {
            int id = o.id();
            UnitEntity u = w.ownUnit(colonyId, id);
            BaseEntity b = u == null ? w.ownBase(colonyId, id) : null;
            if (u == null && b == null) {
                if (foreignInView(colonyId, id)) {
                    reject(colonyId, id, RejectCode.NOT_YOURS, Messages.notYours(id));
                } else {
                    reject(colonyId, id, RejectCode.UNKNOWN_UNIT, Messages.unknown(id));
                }
                continue;
            }
            String who = u != null ? u.label() : b.label();
            if (!ordered.add(id)) {
                reject(colonyId, id, RejectCode.DUPLICATE_ORDER, Messages.duplicate(who));
                continue;
            }
            Pending p = new Pending(colonyId, u, b, o);
            switch (o.kind()) {
                case MOVE -> {
                    if (u == null) {
                        wrong(p, Messages.baseCannotMove(who));
                    } else {
                        moves.add(p);
                    }
                }
                case HARVEST -> {
                    if (u == null || u.type != UnitType.WORKER) {
                        wrong(p, Messages.onlyWorkerHarvests(who));
                    } else {
                        harvests.add(p);
                    }
                }
                case TRANSFER -> {
                    if (u == null) {
                        wrong(p, Messages.baseCannotTransfer(who));
                    } else {
                        transfers.add(p);
                    }
                }
                case PRODUCE -> {
                    if (b == null) {
                        wrong(p, Messages.onlyBaseProduces(who));
                    } else if (o.type() == UnitType.TANK && !features.tanks()) {
                        wrong(p, Messages.tanksLater(who));
                    } else {
                        produces.add(p);
                    }
                }
                case FIRE -> {
                    if (u == null || u.type != UnitType.TANK) {
                        wrong(p, Messages.onlyTankFires(who));
                    } else if (!features.tanks()) {
                        wrong(p, Messages.fireLater(who));
                    } else if (features.tankStrike()) {
                        strikes.add(new Strikes.Request(colonyId, u, o.dir()));
                    } else {
                        fires.add(p);
                    }
                }
                case ATTACK -> {
                    if (u == null || u.type != UnitType.WORKER) {
                        wrong(p, Messages.onlyWorkerAttacks(who));
                    } else if (!features.melee()) {
                        wrong(p, Messages.meleeLater(who));
                    } else {
                        attacks.add(new Strikes.Request(colonyId, u, o.dir()));
                    }
                }
                case BASE_FIRE -> {
                    if (b == null) {
                        wrong(p, Messages.onlyBaseFiresAtCell(who));
                    } else if (!features.baseFire()) {
                        wrong(p, Messages.baseFireLater(who));
                    } else {
                        baseFires.add(p);
                    }
                }
                case BUILD -> {
                    if (u == null || u.type != UnitType.WORKER) {
                        wrong(p, Messages.onlyWorkerBuilds(who));
                    } else if (!features.secondBase()) {
                        wrong(p, Messages.buildLater(who));
                    } else {
                        builds.add(p);
                    }
                }
                case CONSTRUCT -> {
                    if (u == null || u.type != UnitType.WORKER) {
                        wrong(p, Messages.onlyWorkerBuilds(who));
                    } else if (o.building() == Building.DEPOT && !features.depots()) {
                        wrong(p, Messages.buildingLater(who, o.building()));
                    } else if (o.building() == Building.DEPOT && locked(open, Ability.DEPOT)) {
                        wrong(p, Messages.locked(who, Ability.DEPOT, open.hint().apply(Ability.DEPOT)));
                    } else {
                        constructs.add(p);
                    }
                }
                case DIG -> {
                    if (u == null || u.type != UnitType.WORKER) {
                        wrong(p, Messages.onlyWorkerDigs(who));
                    } else if (!features.dig()) {
                        wrong(p, Messages.digLater(who));
                    } else if (locked(open, Ability.DIG)) {
                        wrong(p, Messages.locked(who, Ability.DIG, open.hint().apply(Ability.DIG)));
                    } else {
                        digs.add(p);
                    }
                }
                case UPGRADE -> {
                    if (u == null || u.type != UnitType.WORKER) {
                        wrong(p, Messages.onlyWorkerUpgrades(who));
                    } else if (!features.upgrades()) {
                        wrong(p, Messages.upgradeLater(who));
                    } else if (locked(open, Ability.UPGRADES)) {
                        wrong(p, Messages.locked(who, Ability.UPGRADES, open.hint().apply(Ability.UPGRADES)));
                    } else {
                        upgrades.add(p);
                    }
                }
                default -> throw new IllegalStateException(o.kind().name());
            }
        }
    }

    /** Возможность есть в мире, но колонии её не открыли. */
    private static boolean locked(World.Unlocked open, Ability a) {
        return !open.abilities().contains(a);
    }

    /** Колония видит чужой юнит под этим номером. */
    private boolean foreignInView(int colonyId, int number) {
        int internal = number < 0 ? w.sightings.byNumber(colonyId, -number) : -1;
        ViewSnapshot view = views.get(colonyId);
        if (internal < 0 || view == null) {
            return false;
        }
        UnitEntity other = w.units.get(internal);
        BaseEntity base = w.bases.get(internal);
        return (other != null && view.seen(other.pos)) || (base != null && view.seen(base.pos));
    }

    private void wrong(Pending p, String message) {
        reject(p.colonyId(), p.id(), RejectCode.WRONG_UNIT_TYPE, message);
    }

    @Override
    public void reject(int colonyId, int unitId, RejectCode code, String message) {
        if (colonyId == 0) {
            return;
        }
        rejections.computeIfAbsent(colonyId, k -> new ArrayList<>()).add(new Rejection(unitId, code, message));
        w.colony(colonyId).rejections++;
    }

    @Override
    public void event(int colonyId, EventKind kind, String message, Pos pos) {
        String text = colonyId == 0 ? message : w.colony(colonyId).name + ": " + message;
        events.add(new Frame.Event(t, colonyId, kind, message, text, pos));
    }

    /** Событие с отдельным текстом для всех: «Вера ▸ Глеб: рабочий 4». */
    private void event(int colonyId, EventKind kind, String message, String text, Pos pos) {
        events.add(new Frame.Event(t, colonyId, kind, message, text, pos));
    }

    // ---- налётчики решают сами ----

    private void raiders() {
        boolean any = false;
        for (UnitEntity u : w.units.values()) {
            if (u.colonyId == 0) {
                any = true;
                break;
            }
        }
        if (!any) {
            return;
        }
        List<UnitEntity>[] cells = w.occupancy();
        for (UnitEntity r : w.units.values()) {
            if (r.colonyId != 0) {
                continue;
            }
            if (!truce && t >= r.readyAt) {
                Direction aim = aim(r, cells);
                if (aim != null) {
                    fires.add(new Pending(0, r, null, new Order(Kind.FIRE, r.id, aim, 0, null, null)));
                    continue;
                }
            }
            if (r.target <= 0 || !w.colony(r.target).alive || w.protectedAt(r.target, t)) {
                ColonyState target = w.raidTarget();
                if (target == null) {
                    continue;
                }
                r.target = target.id;
            }
            int[] field = w.distanceToBases(r.target);
            int here = field[w.index(r.pos)];
            if (here <= 1) {
                continue;
            }
            for (Direction d : Direction.values()) {
                Pos n = r.pos.step(d);
                if (w.free(n) && field[w.index(n)] == here - 1) {
                    moves.add(new Pending(0, r, null, new Order(Kind.MOVE, r.id, d, 0, null, null)));
                    break;
                }
            }
        }
    }

    /** Ближайшая цель налётчика на прямой в пределах дальности: чужой юнит или база. Своих не стреляет. */
    private Direction aim(UnitEntity r, List<UnitEntity>[] cells) {
        Direction best = null;
        int bestK = Integer.MAX_VALUE;
        for (Direction d : Direction.values()) {
            Pos p = r.pos;
            for (int k = 1; k <= rules.shellRange() && k < bestK; k++) {
                p = p.step(d);
                if (!w.map.inside(p) || w.wall(p)) {
                    break;
                }
                List<UnitEntity> there = cells[w.index(p)];
                if (there != null && !there.isEmpty()) {
                    if (there.stream().anyMatch(x -> x.colonyId != 0)) {
                        best = d;
                        bestK = k;
                    }
                    break;
                }
                if (w.baseAt(p) != null) {
                    best = d;
                    bestK = k;
                    break;
                }
            }
        }
        return best;
    }

    // ---- 3. движение ----

    private void move() {
        List<Mover> movers = new ArrayList<>();
        for (Pending p : moves) {
            UnitEntity u = p.unit();
            Pos to = u.pos.step(p.order().dir());
            String who = u.label();
            if (!w.map.inside(to)) {
                reject(p.colonyId(), u.number, RejectCode.BLOCKED, Messages.edge(who));
            } else if (w.rubbleAt(to) > 0) {
                reject(p.colonyId(), u.number, RejectCode.BLOCKED, Messages.rubbleAhead(who));
            } else if (w.wall(to)) {
                reject(p.colonyId(), u.number, RejectCode.BLOCKED, Messages.wall(who));
            } else if (w.baseAt(to) != null) {
                reject(p.colonyId(), u.number, RejectCode.BLOCKED, Messages.baseAhead(who));
            } else if (w.depositAt(to) != null) {
                reject(p.colonyId(), u.number, RejectCode.BLOCKED, Messages.depositAhead(who));
            } else if (w.structureAt(to) != null) {
                reject(p.colonyId(), u.number, RejectCode.BLOCKED, Messages.structureAhead(who));
            } else {
                movers.add(new Mover(p, to));
            }
        }
        Map<Integer, List<Mover>> byTarget = new TreeMap<>();
        Map<Integer, List<Mover>> byFrom = new TreeMap<>();
        Map<Integer, Mover> byUnit = new HashMap<>();
        for (Mover m : movers) {
            byTarget.computeIfAbsent(w.index(m.to), k -> new ArrayList<>()).add(m);
            byFrom.computeIfAbsent(w.index(m.u().pos), k -> new ArrayList<>()).add(m);
            byUnit.put(m.u().id, m);
        }
        if (features.softCollisions()) {
            softCollisions(movers, byTarget, byFrom, byUnit);
        } else {
            hardCollisions(movers, byTarget, byFrom, byUnit);
        }
        for (Mover m : movers) {
            if (m.failure != null) {
                reject(m.p.colonyId(), m.u().number, m.failure, m.message);
            } else {
                m.u().pos = m.to;
            }
        }
    }

    /** Столкновения как в лигах: двое в одну клетку или обмен местами — стоят оба; в клетку стоящего не войти. */
    private void hardCollisions(List<Mover> movers, Map<Integer, List<Mover>> byTarget,
                                Map<Integer, List<Mover>> byFrom, Map<Integer, Mover> byUnit) {
        for (Mover m : movers) {
            for (Mover o : byTarget.get(w.index(m.to))) {
                if (o != m && w.conflict(m.u().colonyId, o.u().colonyId)) {
                    m.fail(RejectCode.COLLISION, Messages.collision(m.u().label(), o.u().type, o.u().colonyId == m.u().colonyId ? o.u().number : 0));
                }
            }
            for (Mover o : byFrom.getOrDefault(w.index(m.to), List.of())) {
                if (o.to.equals(m.u().pos) && w.conflict(m.u().colonyId, o.u().colonyId)) {
                    m.fail(RejectCode.COLLISION, Messages.swap(m.u().label(), o.u().type, o.u().colonyId == m.u().colonyId ? o.u().number : 0));
                }
            }
        }
        List<UnitEntity>[] cells = w.occupancy();
        boolean changed = true;
        while (changed) {
            changed = false;
            for (Mover m : movers) {
                if (m.failure != null) {
                    continue;
                }
                List<UnitEntity> there = cells[w.index(m.to)];
                if (there == null) {
                    continue;
                }
                for (UnitEntity occupant : there) {
                    if (!w.conflict(m.u().colonyId, occupant.colonyId)) {
                        continue;
                    }
                    Mover leaving = byUnit.get(occupant.id);
                    if (leaving == null || leaving.failure != null) {
                        m.fail(RejectCode.BLOCKED, Messages.occupied(m.u().label()));
                        changed = true;
                        break;
                    }
                }
            }
        }
    }

    /**
     * Мягкие столкновения своих (флаг {@code softCollisions}). С чужими — как прежде. Свои меняются местами и ходят
     * по кругу. Ходы разбираются по возрастанию номера: юнит идёт, если его клетка свободна или освободится —
     * стоящий в ней тоже идёт, и так по цепочке до свободной клетки или обратно к первому. Клетку, которую уже занял
     * юнит с меньшим номером, другой не получает. Кто не прошёл, стоит.
     */
    private void softCollisions(List<Mover> movers, Map<Integer, List<Mover>> byTarget,
                                Map<Integer, List<Mover>> byFrom, Map<Integer, Mover> byUnit) {
        for (Mover m : movers) {
            for (Mover o : byTarget.get(w.index(m.to))) {
                if (o != m && o.u().colonyId != m.u().colonyId && w.conflict(m.u().colonyId, o.u().colonyId)) {
                    m.fail(RejectCode.COLLISION, Messages.collision(m.u().label(), o.u().type, 0));
                }
            }
            for (Mover o : byFrom.getOrDefault(w.index(m.to), List.of())) {
                if (o.to.equals(m.u().pos) && o.u().colonyId != m.u().colonyId
                        && w.conflict(m.u().colonyId, o.u().colonyId)) {
                    m.fail(RejectCode.COLLISION, Messages.swap(m.u().label(), o.u().type, 0));
                }
            }
        }
        List<UnitEntity>[] cells = w.occupancy();
        List<Mover> order = new ArrayList<>(movers);
        order.sort(Comparator.<Mover>comparingInt(m -> m.u().colonyId).thenComparingInt(m -> m.u().number));
        Set<Mover> moving = new HashSet<>();
        Map<Long, Mover> claimed = new HashMap<>();
        for (Mover m : order) {
            if (m.failure != null || moving.contains(m)) {
                continue;
            }
            List<Mover> chain = new ArrayList<>();
            Set<Long> slots = new HashSet<>();
            Mover cur = m;
            Mover rival = null;
            boolean ok;
            while (true) {
                if (cur.failure != null) {
                    ok = false;
                    break;
                }
                if (claimed.containsKey(slot(cur)) || !slots.add(slot(cur))) {
                    rival = claimed.get(slot(cur));
                    ok = false;
                    break;
                }
                chain.add(cur);
                UnitEntity occupant = null;
                int occupants = 0;
                List<UnitEntity> there = cells[w.index(cur.to)];
                for (UnitEntity u : there == null ? List.<UnitEntity>of() : there) {
                    if (w.conflict(cur.u().colonyId, u.colonyId)) {
                        occupant = u;
                        occupants++;
                    }
                }
                if (occupants == 0) {
                    ok = true;
                    break;
                }
                Mover next = occupants == 1 ? byUnit.get(occupant.id) : null;
                if (next == null) {
                    ok = false;
                    break;
                }
                if (moving.contains(next)) {
                    ok = true;
                    break;
                }
                if (chain.contains(next)) {
                    ok = next == m; // круг замкнулся на первом — все в нём идут
                    break;
                }
                cur = next;
            }
            if (ok) {
                for (Mover c : chain) {
                    moving.add(c);
                    claimed.put(slot(c), c);
                }
            } else if (rival != null && cur == m) {
                m.fail(RejectCode.COLLISION, Messages.collision(m.u().label(), rival.u().type, rival.u().number));
            } else {
                m.fail(RejectCode.BLOCKED, Messages.occupied(m.u().label()));
            }
        }
    }

    /** Клетка, за которую спорит юнит, — отдельно для каждой колонии: чужие спорят по правилам лиги. */
    private long slot(Mover m) {
        return (long) w.index(m.to) * 1_000 + m.u().colonyId;
    }

    // ---- 4. производство ----

    private void produce() {
        if (produces.isEmpty()) {
            return;
        }
        List<UnitEntity>[] cells = w.occupancy();
        for (Pending p : produces) {
            BaseEntity b = p.base();
            ColonyState col = w.colony(b.colonyId);
            UnitType type = p.order().type();
            int cost = w.cost(type);
            String who = b.label();
            String cap = UnitCaps.refusal(w, b.colonyId, type, who);
            if (cap != null) {
                reject(p.colonyId(), b.number, RejectCode.UNIT_LIMIT, cap);
                continue;
            }
            if (col.energy < cost) {
                reject(p.colonyId(), b.number, RejectCode.NOT_ENOUGH_ENERGY, Messages.notEnoughEnergy(who, cost, col.energy));
                continue;
            }
            Pos spawn = null;
            for (Pos c : w.spawnOrder(b.pos)) {
                if (w.free(c) && !blocked(cells, c, b.colonyId)) {
                    spawn = c;
                    break;
                }
            }
            if (spawn == null) {
                reject(p.colonyId(), b.number, RejectCode.SPAWN_BLOCKED, Messages.spawnBlocked(who));
                continue;
            }
            col.energy -= cost;
            UnitEntity u = w.addUnit(b.colonyId, type, spawn);
            int i = w.index(spawn);
            if (cells[i] == null) {
                cells[i] = new ArrayList<>(2);
            }
            cells[i].add(u);
            event(b.colonyId, EventKind.PRODUCED, Messages.produced(type, u.number), spawn);
        }
    }

    private boolean blocked(List<UnitEntity>[] cells, Pos p, int colonyId) {
        List<UnitEntity> there = cells[w.index(p)];
        if (there != null) {
            for (UnitEntity u : there) {
                if (w.conflict(colonyId, u.colonyId)) {
                    return true;
                }
            }
        }
        return false;
    }

    // ---- 4а. вторая база (флаг secondBase) ----

    private void build() {
        if (builds.isEmpty()) {
            return;
        }
        List<UnitEntity>[] cells = w.occupancy();
        int min = rules.buildMinDistanceToCenter();
        for (Pending p : builds) {
            UnitEntity u = p.unit();
            ColonyState col = w.colony(u.colonyId);
            Pos at = u.pos.step(p.order().dir());
            String who = u.label();
            if (w.baseCount(u.colonyId) >= rules.maxBases()) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.tooManyBases(who, rules.maxBases()));
            } else if (!w.map.inside(at) || w.wall(at)) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.buildWall(who));
            } else if (w.baseAt(at) != null || w.depositAt(at) != null) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.buildTaken(who));
            } else if (cells[w.index(at)] != null) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.occupied(who));
            } else if (w.centreDistance2(at) < min * min) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.buildNearCentre(who, min));
            } else if (col.energy < rules.buildCost()) {
                reject(p.colonyId(), u.number, RejectCode.NOT_ENOUGH_ENERGY,
                        Messages.notEnoughEnergy(who, rules.buildCost(), col.energy));
            } else {
                col.energy -= rules.buildCost();
                BaseEntity b = w.addBase(u.colonyId, at);
                event(u.colonyId, EventKind.PRODUCED, Messages.built(b.number), at);
            }
        }
    }

    // ---- 4б. выстрелы танков (флаг tanks) ----

    private void fire() {
        for (Pending p : fires) {
            UnitEntity u = p.unit();
            String who = u.label();
            if (truce) {
                reject(p.colonyId(), u.number, RejectCode.TRUCE, Messages.truceNoFire(who));
            } else if (t < u.readyAt) {
                reject(p.colonyId(), u.number, RejectCode.COOLDOWN, Messages.cooldown(who, u.readyAt - t));
            } else {
                u.readyAt = t + rules.tankCooldown();
                w.shells.add(new Shell(p.colonyId(), u.pos, p.order().dir(), rules.shellRange()));
                endProtection(p.colonyId());
            }
        }
    }

    /** Кто выстрелил сам, теряет защиту новичка со следующего такта. */
    private void endProtection(int colonyId) {
        if (colonyId > 0) {
            ColonyState c = w.colony(colonyId);
            c.protectedUntil = Math.min(c.protectedUntil, t + 1);
        }
    }

    // ---- 4в. выстрел базы (флаг baseFire) ----

    private void baseFire() {
        if (baseFires.isEmpty()) {
            return;
        }
        List<UnitEntity>[] cells = w.occupancy();
        int range = rules.baseFireRange();
        for (Pending p : baseFires) {
            BaseEntity b = p.base();
            ColonyState col = w.colony(b.colonyId);
            Pos target = p.order().target();
            String who = b.label();
            int dx = target.x() - b.pos.x();
            int dy = target.y() - b.pos.y();
            if (truce) {
                reject(p.colonyId(), b.number, RejectCode.TRUCE, Messages.truceNoFire(who));
            } else if (!w.map.inside(target)) {
                reject(p.colonyId(), b.number, RejectCode.NO_TARGET, Messages.offMap(who));
            } else if (target.equals(b.pos)) {
                reject(p.colonyId(), b.number, RejectCode.NO_TARGET, Messages.notAtSelf(who));
            } else if (dx * dx + dy * dy > range * range) {
                reject(p.colonyId(), b.number, RejectCode.OUT_OF_RANGE, Messages.outOfRange(who, range));
            } else if (col.energy < rules.baseFireCost()) {
                reject(p.colonyId(), b.number, RejectCode.NOT_ENOUGH_ENERGY,
                        Messages.notEnoughEnergy(who, rules.baseFireCost(), col.energy));
            } else {
                col.energy -= rules.baseFireCost();
                endProtection(b.colonyId);
                int hit = 0;
                List<UnitEntity> there = cells[w.index(target)];
                BaseEntity other = w.baseAt(target);
                if (there != null && !there.isEmpty()) {
                    UnitEntity v = there.get(0);
                    hit = v.id;
                    hitUnit(v, b.colonyId, Cause.BASE_FIRE, rules.baseFireDamage());
                } else if (other != null) {
                    hit = other.id;
                    hitBase(other, b.colonyId, rules.baseFireDamage());
                }
                shots.add(new Frame.Shot(b.colonyId, b.pos, target, hit, Frame.Shot.BASE));
            }
        }
    }

    // ---- 4г. полёт снарядов ----

    private void flyShells() {
        if (w.shells.isEmpty()) {
            return;
        }
        List<UnitEntity>[] cells = w.occupancy();
        for (Shell s : w.shells) {
            s.from = s.pos;
            // снаряд с прошлого такта задевает того, кто вошёл в его клетку: пролететь сквозь нельзя
            List<UnitEntity> here = s.fresh ? null : cells[w.index(s.pos)];
            if (here != null && !here.isEmpty()) {
                UnitEntity v = here.get(0);
                s.hit = v.id;
                s.done = true;
                hitUnit(v, s.colonyId, s.colonyId == 0 ? Cause.RAIDER : Cause.SHELL, rules.shellDamage());
            }
            s.fresh = false;
        }
        for (int step = 0; step < rules.shellSpeed(); step++) {
            for (Shell s : w.shells) {
                if (s.done) {
                    continue;
                }
                Pos next = s.pos.step(s.dir);
                if (s.left <= 0 || !w.map.inside(next) || w.wall(next)) {
                    s.done = true;
                    continue;
                }
                s.pos = next;
                s.left--;
                List<UnitEntity> there = cells[w.index(next)];
                BaseEntity b = w.baseAt(next);
                if (there != null && !there.isEmpty()) {
                    UnitEntity v = there.get(0);
                    s.hit = v.id;
                    s.done = true;
                    hitUnit(v, s.colonyId, s.colonyId == 0 ? Cause.RAIDER : Cause.SHELL, rules.shellDamage());
                } else if (b != null) {
                    s.hit = b.id;
                    s.done = true;
                    hitBase(b, s.colonyId, rules.shellDamage());
                } else if (s.left <= 0) {
                    s.done = true;
                }
            }
        }
        for (Shell s : w.shells) {
            shots.add(new Frame.Shot(s.colonyId, s.from, s.pos, s.hit));
        }
        w.shells.removeIf(s -> s.done);
    }

    @Override
    public void shot(Frame.Shot shot) {
        shots.add(shot);
    }

    @Override
    public void hit(UnitEntity victim, int attackerColony, Cause cause, int damage) {
        hitUnit(victim, attackerColony, cause, damage);
    }

    private void hitUnit(UnitEntity v, int shooter, Cause cause, int damage) {
        if (truce || (v.colonyId > 0 && guarded[v.colonyId]) || w.homeGuarded(v)) {
            return;
        }
        boolean alive = v.hp > 0;
        v.hp -= damage;
        if (alive && v.hp <= 0) {
            v.killedBy = cause;
            v.killer = shooter;
        }
        if (v.colonyId > 0) {
            String message = Messages.wounded(v.label(), damage, v.hp);
            if (shooter > 0 && shooter != v.colonyId) {
                event(v.colonyId, EventKind.HIT, message,
                        Messages.struck(w.colony(shooter).name, w.colony(v.colonyId).name, v.label(), damage, v.hp),
                        v.pos);
            } else {
                event(v.colonyId, EventKind.HIT, message, v.pos);
            }
            if (shooter == v.colonyId) {
                event(shooter, EventKind.FRIENDLY_FIRE, Messages.friendlyFire(v.type, v.number), v.pos);
            }
        }
    }

    private void hitBase(BaseEntity b, int shooter, int damage) {
        if (truce || guarded[b.colonyId]) {
            return;
        }
        b.hp -= damage;
        event(b.colonyId, EventKind.HIT, Messages.baseHit(b.number, damage), b.pos);
        if (shooter == b.colonyId) {
            event(shooter, EventKind.FRIENDLY_FIRE, Messages.friendlyFireBase(b.number), b.pos);
        }
    }

    // ---- 4д. постройки, завалы, улучшения (ДЗ «лестница возможностей») ----

    /** Склад на свободной соседней клетке пола: без юнита, базы, постройки и залежи; цена — из запаса. */
    private void construct() {
        if (constructs.isEmpty()) {
            return;
        }
        List<UnitEntity>[] cells = w.occupancy();
        for (Pending p : constructs) {
            UnitEntity u = p.unit();
            ColonyState col = w.colony(u.colonyId);
            Building type = p.order().building();
            Pos at = u.pos.step(p.order().dir());
            String who = u.label();
            if (w.structureCount(u.colonyId, type) >= rules.maxDepots()) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.tooManyDepots(who, rules.maxDepots()));
            } else if (w.rubbleAt(at) > 0) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.buildRubble(who));
            } else if (!w.map.inside(at) || w.wall(at)) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.buildWall(who));
            } else if (w.baseAt(at) != null || w.depositAt(at) != null || w.structureAt(at) != null) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.buildOccupied(who));
            } else if (cells[w.index(at)] != null) {
                reject(p.colonyId(), u.number, RejectCode.BUILD_FORBIDDEN, Messages.occupied(who));
            } else if (col.energy < rules.depotCost()) {
                reject(p.colonyId(), u.number, RejectCode.NOT_ENOUGH_ENERGY,
                        Messages.notEnoughEnergy(who, rules.depotCost(), col.energy));
            } else {
                col.energy -= rules.depotCost();
                StructureEntity s = w.addStructure(u.colonyId, type, at);
                event(u.colonyId, EventKind.PRODUCED, Messages.builtStructure(type, s.number), at);
            }
        }
    }

    /** Удар киркой по соседнему завалу: прочность минус один; на нуле клетка — пол. */
    private void dig() {
        for (Pending p : digs) {
            UnitEntity u = p.unit();
            Pos at = u.pos.step(p.order().dir());
            if (w.rubbleAt(at) <= 0) {
                reject(p.colonyId(), u.number, RejectCode.NO_TARGET, Messages.noRubble(u.label()));
            } else {
                w.dig(at);
            }
        }
    }

    /** Улучшение рабочему вплотную к своей базе: один раз каждое, цена — из запаса. */
    private void upgrade() {
        for (Pending p : upgrades) {
            UnitEntity u = p.unit();
            ColonyState col = w.colony(u.colonyId);
            Upgrade what = p.order().upgrade();
            String who = u.label();
            boolean nearBase = false;
            for (World.BaseEntity b : w.bases.values()) {
                nearBase |= b.colonyId == u.colonyId && b.pos.manhattan(u.pos) == 1;
            }
            if (!nearBase) {
                reject(p.colonyId(), u.number, RejectCode.NO_TARGET, Messages.noBaseNear(who));
            } else if (u.upgrades.contains(what)) {
                reject(p.colonyId(), u.number, RejectCode.ALREADY_UPGRADED, Messages.alreadyUpgraded(who, what));
            } else if (col.energy < rules.upgradeCost()) {
                reject(p.colonyId(), u.number, RejectCode.NOT_ENOUGH_ENERGY,
                        Messages.notEnoughEnergy(who, rules.upgradeCost(), col.energy));
            } else {
                col.energy -= rules.upgradeCost();
                u.upgrades.add(what);
            }
        }
    }

    // ---- 5. добыча ----

    private void harvest() {
        Map<Integer, List<Pending>> byDeposit = new TreeMap<>();
        for (Pending p : harvests) {
            UnitEntity u = p.unit();
            DepositEntity d = w.depositAt(u.pos.step(p.order().dir()));
            if (d == null) {
                reject(p.colonyId(), u.number, RejectCode.NO_DEPOSIT, Messages.noDeposit(u.label()));
            } else if (d.kind == DepositKind.HOME && d.homeOwner != u.colonyId) {
                reject(p.colonyId(), u.number, RejectCode.NOT_YOURS, Messages.foreignHome(u.label()));
            } else if (d.kind == DepositKind.LOOT && guarded[u.colonyId]) {
                reject(p.colonyId(), u.number, RejectCode.TRUCE, Messages.guardedLoot(u.label()));
            } else if (u.carry >= w.carryOf(u)) {
                reject(p.colonyId(), u.number, RejectCode.CARRY_FULL, Messages.carryFull(u.label(), u.carry));
            } else {
                byDeposit.computeIfAbsent(d.id, k -> new ArrayList<>()).add(p);
            }
        }
        for (Map.Entry<Integer, List<Pending>> e : byDeposit.entrySet()) {
            DepositEntity d = w.deposits.get(e.getKey());
            for (Pending p : e.getValue()) {
                UnitEntity u = p.unit();
                int room = w.carryOf(u) - u.carry;
                int pick = u.upgrades.contains(Upgrade.PICK) ? 2 : 1;
                int take;
                if (d.kind == DepositKind.HOME) {
                    take = Math.min(pick * rules.homeHarvestRate(), room);
                } else {
                    if (d.amount <= 0) {
                        reject(p.colonyId(), u.number, RejectCode.DEPOSIT_EMPTY, Messages.depositEmpty(u.label()));
                        continue;
                    }
                    take = Math.min(Math.min(pick * rules.rateOf(d.kind), room), d.amount);
                    // в бесконечном мире не иссякают залежи карты; жила события и трофей иссякают всё равно
                    if (!features.endlessDeposits() || !d.renewable) {
                        d.amount -= take;
                    }
                }
                u.carry += take;
                w.recordHarvest(u.colonyId, d, take);
            }
            if (d.kind != DepositKind.HOME && !d.renewable && d.amount <= 0) {
                w.removeDeposit(d);
            }
        }
    }

    // ---- 6. передача ----

    private void transfer(List<UnitEntity>[] startCells, Map<Integer, Integer> startCarry) {
        for (Pending p : transfers) {
            UnitEntity u = p.unit();
            String who = u.label();
            int amount = p.order().amount();
            if (amount <= 0) {
                reject(p.colonyId(), u.number, RejectCode.NOTHING_TO_TRANSFER, Messages.badAmount(who, amount));
                continue;
            }
            int give = Math.min(Math.min(amount, startCarry.getOrDefault(u.id, 0)), u.carry);
            if (give <= 0) {
                reject(p.colonyId(), u.number, RejectCode.NOTHING_TO_TRANSFER, Messages.emptyCarry(who));
                continue;
            }
            Pos at = u.pos.step(p.order().dir());
            if (!w.map.inside(at)) {
                reject(p.colonyId(), u.number, RejectCode.NO_TARGET, Messages.noReceiver(who));
                continue;
            }
            BaseEntity b = w.baseAt(at);
            if (b != null) {
                if (b.colonyId == u.colonyId) {
                    ColonyState col = w.colony(u.colonyId);
                    col.energy += give;
                    col.delivered += give;
                    u.carry -= give;
                } else if (!features.foreignTransfer()) {
                    wrong(p, Messages.foreignTransferLater(who));
                } else {
                    reject(p.colonyId(), u.number, RejectCode.NOT_YOURS, Messages.foreignBase(who));
                }
                continue;
            }
            StructureEntity depot = w.structureAt(at);
            if (depot != null && depot.type == Building.DEPOT) {
                if (depot.colonyId == u.colonyId) {
                    ColonyState col = w.colony(u.colonyId);
                    col.energy += give;
                    col.delivered += give;
                    u.carry -= give;
                } else {
                    reject(p.colonyId(), u.number, RejectCode.NOT_YOURS, Messages.foreignBase(who));
                }
                continue;
            }
            UnitEntity own = null;
            UnitEntity foreign = null;
            List<UnitEntity> there = startCells[w.index(at)];
            if (there != null) {
                for (UnitEntity r : there) {
                    if (r == u || !w.units.containsKey(r.id)) {
                        continue;
                    }
                    if (r.colonyId == u.colonyId) {
                        own = r;
                        break;
                    }
                    if (foreign == null) {
                        foreign = r;
                    }
                }
            }
            if (own != null) {
                int room = w.carryOf(own) - own.carry;
                if (room <= 0) {
                    reject(p.colonyId(), u.number, RejectCode.CARRY_FULL, Messages.receiverFull(who, own.type, own.number));
                    continue;
                }
                int moved = Math.min(give, room);
                own.carry += moved;
                u.carry -= moved;
            } else if (foreign != null) {
                giveForeign(p, u, foreign, give);
            } else {
                reject(p.colonyId(), u.number, RejectCode.NO_TARGET, Messages.noReceiver(who));
            }
        }
    }

    /** Передача чужому юниту: доходит на {@code transferLossPercent} процентов меньше. */
    private void giveForeign(Pending p, UnitEntity u, UnitEntity r, int give) {
        String who = u.label();
        if (!features.foreignTransfer()) {
            wrong(p, Messages.foreignTransferLater(who));
            return;
        }
        if (r.colonyId == 0) {
            reject(p.colonyId(), u.number, RejectCode.NOT_YOURS, Messages.raiderTakesNothing(who));
            return;
        }
        if (guarded[u.colonyId] || guarded[r.colonyId]) {
            reject(p.colonyId(), u.number, RejectCode.TRUCE, Messages.guardedTrade(who));
            return;
        }
        int keep = 100 - rules.transferLossPercent();
        int room = w.carryOf(r) - r.carry;
        if (room <= 0 || keep <= 0) {
            reject(p.colonyId(), u.number, RejectCode.CARRY_FULL, Messages.receiverFull(who, r.type, 0));
            return;
        }
        int given = Math.min(give, (room * 100 + keep - 1) / keep);
        int received = Math.min(room, given * keep / 100);
        u.carry -= given;
        r.carry += received;
    }

    // ---- 7. содержание ----

    private void upkeep() {
        for (UnitEntity u : w.units.values()) {
            if (u.colonyId == 0) {
                continue;
            }
            int every = u.type == UnitType.TANK ? rules.tankUpkeepEvery() : rules.workerUpkeepEvery();
            if (every <= 0 || t % every != 0) {
                continue;
            }
            ColonyState col = w.colony(u.colonyId);
            if (col.energy >= 1) {
                col.energy--;
            } else if (features.upkeepNoDeath()) {
                continue; // опыт экономики мира: без энергии рабочий работает даром
            } else {
                u.hp--;
                u.deathCause = UPKEEP;
                event(u.colonyId, EventKind.HIT, Messages.upkeepUnpaid(u.label()), u.pos);
            }
        }
    }

    // ---- 8. гибель ----

    private void deaths() {
        for (UnitEntity u : new ArrayList<>(w.units.values())) {
            if (u.hp > 0) {
                continue;
            }
            w.units.remove(u.id);
            if (u.colonyId == 0) {
                if (u.killer > 0) {
                    ViewSnapshot seen = views.get(u.killer);
                    event(u.killer, EventKind.DIED, Messages.raiderDown(u.number),
                            seen != null && seen.seen(u.pos) ? u.pos : null);
                }
                continue;
            }
            boolean starved = UPKEEP.equals(u.deathCause) && u.killedBy == null;
            event(u.colonyId, EventKind.DIED, starved ? Messages.diedUpkeep(u.label()) : Messages.died(u.label()), u.pos);
            Loot.drop(w, u, unitsAtStart);
        }
        for (BaseEntity b : new ArrayList<>(w.bases.values())) {
            if (b.hp <= 0) {
                w.removeBase(b);
                event(b.colonyId, EventKind.BASE_DESTROYED, Messages.baseDestroyed(b.number), b.pos);
            }
        }
        for (ColonyState c : w.colonies) {
            if (!c.alive) {
                continue;
            }
            boolean hasBase = w.bases.values().stream().anyMatch(b -> b.colonyId == c.id);
            if (!hasBase) {
                c.alive = false;
                c.deathTick = t;
                w.units.values().removeIf(u -> u.colonyId == c.id);
                event(c.id, EventKind.COLONY_DIED, Messages.colonyDied(), null);
                if (w.respawn) {
                    c.respawnAt = t + rules.respawnTicks();
                }
            }
        }
    }

    // ---- 8а. центр ----

    private void centre() {
        int holder = Centre.holder(w, guarded);
        w.centerHolder = holder;
        if (holder > 0) {
            w.colony(holder).centerTicks++;
        }
    }

    // ---- 8б. налёт (флаг raiders) ----

    private void raid() {
        if (!features.raiders() || w.map.lair().isEmpty() || t < rules.raidFirstTick()) {
            return;
        }
        int since = t - rules.raidFirstTick();
        if (rules.raidEvery() > 0 ? since % rules.raidEvery() != 0 : since != 0) {
            return;
        }
        ColonyState target = w.raidTarget();
        if (target == null) {
            return;
        }
        Pos lair = w.map.lair().get();
        int n = 0;
        for (int i = 0; i < rules.raidSize(); i++) {
            Pos at = w.nearestOpen(lair);
            if (at == null) {
                break;
            }
            UnitEntity r = w.addUnit(0, UnitType.TANK, at);
            r.target = target.id;
            n++;
        }
        if (n > 0) {
            event(0, EventKind.RAID, Messages.raid(n, target.name), lair);
        }
    }

    // ---- 8в. объявленные события (флаг events) ----

    private void worldEvents() {
        int every = rules.eventEvery();
        if (!features.events() || every <= 0) {
            return;
        }
        for (int s = every; s < w.maxTicks; s += every) {
            int announce = Math.max(0, s - rules.eventAnnounceTicks());
            if (announce > t) {
                break;
            }
            if (t == announce) {
                Pos p = w.chooseEventSpot();
                w.eventSpots.put(s, p);
                event(0, EventKind.ANNOUNCE, Messages.announce(s - t, Messages.square(p)), p);
            }
            if (t == s) {
                Pos p = w.eventSpots.remove(s);
                if (p == null) {
                    p = w.chooseEventSpot();
                }
                Pos open = w.free(p) && w.occupancy()[w.index(p)] == null ? p : w.nearestOpen(p);
                if (open != null) {
                    w.addDeposit(DepositKind.RICH, open, rules.eventDepositAmount());
                    event(0, EventKind.EVENT_STARTED, Messages.eventStarted(Messages.square(open)), open);
                }
            }
        }
    }

    // ---- 8г. возвращение колоний (мир на занятие) ----

    private void respawn() {
        if (!w.respawn) {
            return;
        }
        for (ColonyState c : w.colonies) {
            if (!c.alive && c.respawnAt >= 0 && t >= c.respawnAt && w.respawn(c, t)) {
                event(c.id, EventKind.PRODUCED, Messages.returned(), w.map.base(c.id));
            }
        }
    }

    // ---- 8д. сценарий карты (шаг «Устойчивость» ДЗ) ----

    /** События сценария, чей такт настал; обвал в клетке с юнитом ждёт, пока она освободится. */
    private void script() {
        for (java.util.Iterator<ScriptEvent> it = w.script.iterator(); it.hasNext(); ) {
            ScriptEvent e = it.next();
            if (e.tick() > t) {
                break;
            }
            switch (e.kind()) {
                case DRY -> {
                    DepositEntity d = w.depositAt(e.pos());
                    if (d != null && d.kind != DepositKind.HOME) {
                        d.amount = 0;
                        event(0, EventKind.EVENT_STARTED, "залежь " + Messages.square(e.pos()) + " иссякла", e.pos());
                    }
                    it.remove();
                }
                case CLOSE -> {
                    if (w.occupancy()[w.index(e.pos())] != null) {
                        continue; // в клетке юнит — обвал подождёт
                    }
                    if (w.free(e.pos())) {
                        w.close(e.pos());
                        event(0, EventKind.EVENT_STARTED, "обвал: клетка " + Messages.square(e.pos()) + " закрыта",
                                e.pos());
                    }
                    it.remove();
                }
                case VANISH -> {
                    UnitEntity gone = null;
                    for (UnitEntity u : w.units.values()) {
                        if (u.colonyId == e.colonyId() && u.type == UnitType.WORKER
                                && (gone == null || u.carry > gone.carry
                                || u.carry == gone.carry && u.number < gone.number)) {
                            gone = u;
                        }
                    }
                    if (gone != null) {
                        w.units.remove(gone.id);
                        event(e.colonyId(), EventKind.DIED, gone.label() + " пропал", gone.pos);
                    }
                    it.remove();
                }
            }
        }
    }

    // ---- 9. восстановление ----

    private void regenerate() {
        int every = rules.depositRegenEvery();
        if (every <= 0 || t % every != 0) {
            return;
        }
        for (DepositEntity d : w.deposits.values()) {
            boolean renewable = d.renewable
                    && (d.kind == DepositKind.NORMAL || d.kind == DepositKind.RICH || d.kind == DepositKind.CENTER);
            if (renewable && d.amount < d.initial) {
                d.amount++;
            }
        }
    }
}
