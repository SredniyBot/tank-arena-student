package colony.api;

/**
 * Залежь энергии. Места всех залежей известны с начала матча, запас — только в обзоре.
 * В «Тумане» (шаг 7 ДЗ) в списке только залежи в обзоре: что видели раньше, колония помнит сама.
 *
 * @param id      номер залежи
 * @param pos     клетка
 * @param kind    вид
 * @param amount  запас; {@code -1} — вне обзора или домашняя (она не иссякает)
 * @param visible клетка сейчас в обзоре
 * @param rate    сколько энергии рабочий добывает из неё за такт; {@code 0} — неизвестно (старый сервер)
 */
public record Deposit(int id, Pos pos, DepositKind kind, int amount, boolean visible, int rate) {

    /** Залежь без скорости добычи — как до шагов ДЗ. */
    public Deposit(int id, Pos pos, DepositKind kind, int amount, boolean visible) {
        this(id, pos, kind, amount, visible, 0);
    }
}
