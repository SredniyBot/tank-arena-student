package colony.api;

import java.util.List;

/**
 * Приказы на такт. Каждый вызов — приказ. Юнит выполняет не больше одного приказа за такт:
 * первый приказ принимается к рассмотрению, следующие отклоняются ({@link RejectCode#DUPLICATE_ORDER}).
 * Все приказы такта вычисляются по состоянию на его начало и выполняются одновременно.
 * Причины отказов видны в {@link ColonyView#lastRejections()} следующего такта. Номер юнита или базы — тот, что
 * в {@link Unit#id()} и {@link Base#id()}.
 */
public interface Orders {

    /** Шаг на соседнюю клетку. */
    void move(int unitId, Direction d);

    /** Добыть энергию из залежи или трофея на соседней клетке. */
    void harvest(int workerId, Direction d);

    /**
     * Передать энергию на соседнюю клетку: своей базе — в запас колонии, своему юниту — в груз. Чужому рабочему —
     * если включён {@code rules().features().foreignTransfer()}: доходит на {@code transferLossPercent} процентов
     * меньше. Чужой базе передать нельзя.
     */
    void transfer(int unitId, Direction d, int amount);

    /**
     * Выпустить юнита. Он появится на свободной соседней клетке базы, ближайшей к центру карты
     * (при равенстве — в порядке N, E, S, W).
     */
    void produce(int baseId, UnitType type);

    /**
     * Выстрел танка в направлении. Снаряд летит {@code shellSpeed} клеток за такт, не дальше {@code shellRange}, и
     * попадает в первого на пути — юнита, базу или стену, в том числе в своего. Между выстрелами —
     * {@code tankCooldown} тактов. Работает, если включены танки: {@code rules().features().tanks()}.
     */
    void fire(int tankId, Direction d);

    /**
     * Выстрел базы по клетке не дальше {@code baseFireRange}: урон {@code baseFireDamage} юниту или базе в клетке,
     * стоит {@code baseFireCost} энергии из запаса. Работает, если включён {@code rules().features().baseFire()}.
     */
    void baseFire(int baseId, Pos target);

    /**
     * Построить базу на свободной соседней клетке не ближе {@code buildMinDistanceToCenter} к центру; стоит
     * {@code buildCost}; баз у колонии — не больше {@code maxBases}. Работает, если включена
     * {@code rules().features().secondBase()}.
     */
    void build(int workerId, Direction d);

    /**
     * Удар рабочего по чужому юниту на соседней клетке: {@code meleeDamage} здоровья. Удар приходится по тому, кто
     * стоял в клетке в начале такта, даже если он в этом такте ушёл. Работает, если включён
     * {@code rules().features().melee()}.
     */
    default void attack(int workerId, Direction d) {
        throw new UnsupportedOperationException("attack: этот Orders не умеет бить");
    }

    /**
     * Построить на свободной соседней клетке пола постройку {@code type}. Энергия — из запаса колонии; цена и
     * предел — в правилах, для склада — {@link Rules#depot()}. Если на карте строить нельзя, приказ отклоняется.
     *
     * <pre>{@code orders.build(worker.id(), Direction.NORTH, Building.DEPOT);}</pre>
     */
    default void build(int workerId, Direction d, Building type) {
        throw new UnsupportedOperationException("build: этот Orders не умеет строить постройки");
    }

    /**
     * Ударить киркой по завалу на соседней клетке: прочность завала падает на единицу, на нуле клетка навсегда
     * становится полом. Несколько рабочих могут бить один завал в одном такте. Работает, если в правилах есть
     * {@link Rules#dig()}.
     *
     * <pre>{@code orders.dig(worker.id(), Direction.EAST);}</pre>
     */
    default void dig(int workerId, Direction d) {
        throw new UnsupportedOperationException("dig: этот Orders не умеет копать");
    }

    /**
     * Купить рабочему улучшение. Рабочий должен стоять вплотную к своей базе; цена — {@link Rules#upgrades()},
     * из запаса колонии. Каждое улучшение — один раз на рабочего.
     *
     * <pre>{@code orders.upgrade(worker.id(), Upgrade.BAG);}</pre>
     */
    default void upgrade(int workerId, Upgrade upgrade) {
        throw new UnsupportedOperationException("upgrade: этот Orders не умеет улучшать");
    }

    /**
     * Пометка для просмотра: путь, который вы задумали для своего юнита. Просмотр рисует его линией от юнита — видно,
     * где путь расходится с тем, куда юнит пошёл. На игру не влияет и приказом не считается: предел приказов не
     * тратит, отказов не даёт. За такт юниту — одна пометка, следующая её заменяет. Клеток в пути — не больше 64,
     * остальные отбрасываются.
     *
     * <pre>{@code orders.mark(worker.id(), List.of(worker.pos(), next, deposit.pos()));}</pre>
     */
    default void mark(int unitId, List<Pos> path) {
    }
}
