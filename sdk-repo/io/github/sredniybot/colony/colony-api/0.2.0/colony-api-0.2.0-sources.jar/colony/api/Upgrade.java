package colony.api;

/**
 * Улучшение рабочего: {@link Orders#upgrade}. Каждое покупается рабочему один раз и остаётся с ним навсегда.
 * Что у рабочего уже есть — {@link Unit#upgrades()}.
 *
 * <pre>{@code boolean bag = worker.upgrades().contains(Upgrade.BAG);}</pre>
 */
public enum Upgrade {
    /** Кирка: рабочий добывает вдвое больше за такт. */
    PICK,
    /** Сумка: рабочий несёт вдвое больше, чем {@link Rules#workerCarry()}. */
    BAG
}
