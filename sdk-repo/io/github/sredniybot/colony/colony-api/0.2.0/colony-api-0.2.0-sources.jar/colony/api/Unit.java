package colony.api;

import java.util.Collections;
import java.util.EnumSet;
import java.util.Set;

/**
 * Юнит.
 *
 * <pre>{@code int capacity = view.rules().workerCarry() * (worker.upgrades().contains(Upgrade.BAG) ? 2 : 1);}</pre>
 *
 * @param id       номер юнита. Свои юниты колония считает с 1 в порядке выпуска: «рабочий 5» — {@code id} 5.
 *                 Чужие — со знаком минус в порядке, в каком ты их увидел: −1, −2… Номер держится, пока юнит жив
 * @param colonyId номер колонии-хозяина; {@code 0} — налётчики
 * @param type     рабочий или танк
 * @param pos      клетка
 * @param hp       здоровье; на нуле юнит погибает
 * @param carry    груз энергии
 * @param upgrades купленные улучшения ({@link Orders#upgrade}); неизменяемое множество в порядке {@link Upgrade}, обычно пустое
 */
public record Unit(int id, int colonyId, UnitType type, Pos pos, int hp, int carry, Set<Upgrade> upgrades) {

    public Unit {
        upgrades = upgrades == null || upgrades.isEmpty() ? Set.of()
                : Collections.unmodifiableSet(EnumSet.copyOf(upgrades));
    }

    /** Юнит без улучшений. */
    public Unit(int id, int colonyId, UnitType type, Pos pos, int hp, int carry) {
        this(id, colonyId, type, pos, hp, carry, Set.of());
    }
}
