package colony.api;

/**
 * Рельеф клетки. Известен с начала матча.
 *
 * <pre>{@code if (view.terrain(p) == Terrain.RUBBLE) { orders.dig(worker.id(), d); }}</pre>
 */
public enum Terrain {
    /** Пол: по нему ходят. */
    FLOOR,
    /** Стена: непроходима навсегда. */
    WALL,
    /**
     * Завал: непроходим, пока его не разберут. {@link Orders#dig} снимает единицу прочности, на нуле клетка
     * навсегда становится полом — для всех. Сколько осталось, показывает {@link ColonyView#rubble(Pos)}.
     */
    RUBBLE
}
