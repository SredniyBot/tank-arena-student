package colony.api;

import java.util.Optional;

/**
 * Правила твоей лиги. Числа лучше брать отсюда, а не переписывать: в следующей лиге они могут быть другими.
 * Такт длится около секунды. Что появляется в лиге позже, здесь пусто: {@link #melee()} — с лиги 3,
 * {@link #centre()} — с лиги 4, {@link #tanks()} — в лиге 5.
 *
 * @param league            номер лиги, 1–5; {@code 0} — не лига (сезон 1)
 * @param maxTicks          длина матча в тактах
 * @param truceTicks        перемирие с начала матча: никто никого не ранит, чужие юниты проходимы
 * @param startEnergy       энергия колонии в начале
 * @param workerCost        цена рабочего
 * @param maxWorkers        больше стольких рабочих у колонии не бывает; {@code 0} — без предела
 * @param workerHp          здоровье рабочего
 * @param workerCarry       сколько энергии несёт рабочий
 * @param harvestRate       сколько энергии рабочий добывает за такт
 * @param workerVision      радиус обзора рабочего
 * @param baseVision        радиус обзора базы
 * @param foreignPassable   чужие юниты проходимы всегда (лиги 1–2); иначе — только в перемирие
 * @param melee             удар рабочего вплотную ({@link Orders#attack}) — с лиги 3
 * @param centre            удержание центра — с лиги 4
 * @param tanks             танки — в лиге 5
 * @param tickTimeoutMillis сколько миллисекунд есть у {@link Colony#onTick} на такт
 * @param depot             склад ({@link Building#DEPOT}); пусто — на этой карте строить нельзя
 * @param dig               завалы и кирка ({@link Orders#dig}); пусто — копать нельзя
 * @param upgrades          улучшения рабочих ({@link Orders#upgrade}); пусто — улучшать нельзя
 */
public record Rules(
        int league,
        int maxTicks,
        int truceTicks,
        int startEnergy,
        int workerCost,
        int maxWorkers,
        int workerHp,
        int workerCarry,
        int harvestRate,
        int workerVision,
        int baseVision,
        boolean foreignPassable,
        Optional<Melee> melee,
        Optional<Centre> centre,
        Optional<Tanks> tanks,
        int tickTimeoutMillis,
        Optional<Depot> depot,
        Optional<Dig> dig,
        Optional<Upgrades> upgrades) {

    /** Правила без складов, завалов и улучшений — как до ДЗ «лестница возможностей». */
    public Rules(int league, int maxTicks, int truceTicks, int startEnergy, int workerCost, int maxWorkers,
                 int workerHp, int workerCarry, int harvestRate, int workerVision, int baseVision,
                 boolean foreignPassable, Optional<Melee> melee, Optional<Centre> centre, Optional<Tanks> tanks,
                 int tickTimeoutMillis) {
        this(league, maxTicks, truceTicks, startEnergy, workerCost, maxWorkers, workerHp, workerCarry, harvestRate,
                workerVision, baseVision, foreignPassable, melee, centre, tanks, tickTimeoutMillis, Optional.empty(),
                Optional.empty(), Optional.empty());
    }

    /**
     * Удар вплотную.
     *
     * @param damage     сколько здоровья снимает удар
     * @param homeRadius у своей базы юнит не ранится: не дальше стольких шагов ({@code |dx| + |dy|}) от неё;
     *                   {@code 0} — защиты нет
     */
    public record Melee(int damage, int homeRadius) {}

    /**
     * Центр.
     *
     * @param radius центр держит колония, у которой больше всех юнитов не дальше стольких шагов от центральной жилы
     */
    public record Centre(int radius) {}

    /**
     * Танки.
     *
     * @param cost     цена танка
     * @param hp       здоровье танка
     * @param vision   радиус обзора танка
     * @param range    танк бьёт первого чужого на прямой не дальше стольких клеток
     * @param damage   урон удара
     * @param cooldown тактов между ударами
     * @param max      больше стольких танков у колонии не бывает
     */
    public record Tanks(int cost, int hp, int vision, int range, int damage, int cooldown, int max) {}

    /**
     * Склад.
     *
     * <pre>{@code int cost = view.rules().depot().orElseThrow().cost();}</pre>
     *
     * @param cost   цена склада, из запаса колонии
     * @param max    больше стольких складов у колонии не бывает
     * @param vision радиус обзора склада
     */
    public record Depot(int cost, int max, int vision) {}

    /**
     * Завалы.
     *
     * <pre>{@code boolean canDig = view.rules().dig().isPresent();}</pre>
     *
     * @param durability прочность нового завала: столько ударов {@link Orders#dig} его разбирают
     */
    public record Dig(int durability) {}

    /**
     * Улучшения рабочих.
     *
     * <pre>{@code int cost = view.rules().upgrades().orElseThrow().cost();}</pre>
     *
     * @param cost цена одного улучшения, из запаса колонии
     */
    public record Upgrades(int cost) {}
}
