package colony.api;

import java.util.List;

/**
 * Клетка карты. {@code x} растёт на восток, {@code y} — на юг; (0, 0) — северо-западный угол.
 *
 * @param x столбец
 * @param y строка
 */
public record Pos(int x, int y) {

    /** Соседняя клетка в направлении {@code d}. Может оказаться за краем карты: проверяйте {@link ColonyView#inside}. */
    public Pos step(Direction d) {
        return switch (d) {
            case NORTH -> new Pos(x, y - 1);
            case EAST -> new Pos(x + 1, y);
            case SOUTH -> new Pos(x, y + 1);
            case WEST -> new Pos(x - 1, y);
        };
    }

    /** Расстояние «по клеткам»: |dx| + |dy|. Стены не учитывает. */
    public int manhattan(Pos other) {
        return Math.abs(x - other.x) + Math.abs(y - other.y);
    }

    /** Четыре соседние клетки в порядке N, E, S, W. Край карты не учитывается. */
    public List<Pos> neighbours() {
        return List.of(step(Direction.NORTH), step(Direction.EAST), step(Direction.SOUTH), step(Direction.WEST));
    }

    @Override
    public String toString() {
        return "(" + x + ", " + y + ")";
    }
}
