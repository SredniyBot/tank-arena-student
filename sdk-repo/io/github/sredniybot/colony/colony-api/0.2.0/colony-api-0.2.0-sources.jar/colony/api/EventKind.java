package colony.api;

/** Вид события. */
public enum EventKind {
    /** База выпустила юнита. */
    PRODUCED,
    /** Юнит погиб. */
    DIED,
    /** Юнит потерял здоровье. */
    HIT,
    /** Выстрел попал в своего. */
    FRIENDLY_FIRE,
    /** База разрушена. */
    BASE_DESTROYED,
    /** Колония погибла. */
    COLONY_DIED,
    /** Перемирие закончилось. */
    TRUCE_END,
    /** Объявление для всех. */
    ANNOUNCE,
    /** Налёт. */
    RAID,
    /** Началось объявленное событие. */
    EVENT_STARTED
}
