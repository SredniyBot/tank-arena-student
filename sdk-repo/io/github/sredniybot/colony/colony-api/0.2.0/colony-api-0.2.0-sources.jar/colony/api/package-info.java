/**
 * API колонии для студента: интерфейс {@link colony.api.Colony}, взгляд на мир {@link colony.api.ColonyView}
 * и приказы {@link colony.api.Orders}. Поиска пути, «иди к точке» и выбора цели здесь нет — это пишете вы.
 */
package colony.api;
