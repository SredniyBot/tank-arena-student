package colony.api;

/**
 * Постройка, которую ставит рабочий: {@link Orders#build(int, Direction, Building)}.
 *
 * <pre>{@code orders.build(worker.id(), Direction.EAST, Building.DEPOT);}</pre>
 */
public enum Building {
    /**
     * Склад. Принимает энергию от своих рабочих, как база: переданное через {@link Orders#transfer} уходит в запас
     * колонии. Сам ничего не производит, содержания не требует, видит недалеко. Цена и предел —
     * в {@link Rules#depot()}.
     */
    DEPOT
}
