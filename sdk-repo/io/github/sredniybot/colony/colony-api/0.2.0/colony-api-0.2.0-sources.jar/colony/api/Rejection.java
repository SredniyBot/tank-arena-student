package colony.api;

/**
 * Отказ в приказе за прошлый такт.
 *
 * @param unitId  номер юнита или базы, которой отдан приказ (первая база — {@code 0}); у отказов всей колонии —
 *                {@code 0} и код {@link RejectCode#EXCEPTION}, {@link RejectCode#TIMEOUT} или
 *                {@link RejectCode#TOO_MANY_ORDERS}
 * @param code    причина, удобная для кода
 * @param message причина для человека, например «рабочий 7: залежь пуста»
 */
public record Rejection(int unitId, RejectCode code, String message) {}
