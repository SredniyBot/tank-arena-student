package colony.api;

/**
 * Постройка на карте: например, склад. Стоит на своей клетке, сквозь неё не пройти.
 *
 * <pre>{@code for (Structure s : view.myStructures()) { System.out.println(s.type() + " в " + s.pos()); }}</pre>
 *
 * @param id       номер постройки в колонии, с 1 в порядке постройки: «склад 1»
 * @param colonyId номер колонии-хозяина
 * @param type     что построено
 * @param pos      клетка
 */
public record Structure(int id, int colonyId, Building type, Pos pos) {}
