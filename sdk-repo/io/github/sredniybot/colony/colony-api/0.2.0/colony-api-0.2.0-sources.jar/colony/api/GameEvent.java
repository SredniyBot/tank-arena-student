package colony.api;

/**
 * Событие: своё или общее объявление.
 *
 * @param tick    такт, в котором событие случилось: тот же номер, что {@link ColonyView#tick()} в том такте
 * @param kind    вид
 * @param message текст для человека, например «новый рабочий 5»
 * @param pos     клетка события; может быть {@code null}
 */
public record GameEvent(int tick, EventKind kind, String message, Pos pos) {}
