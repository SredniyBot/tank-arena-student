package colony.api;

/** Направление шага. Север — вверх по карте: {@code y} растёт на юг. */
public enum Direction {
    NORTH, EAST, SOUTH, WEST
}
