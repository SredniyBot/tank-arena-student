package colony.api;

import java.util.List;
import java.util.Optional;

/**
 * Мир глазами колонии на начало такта. Снимок не меняется, пока идёт такт.
 * Все списки неизменяемые. Свои юниты и базы — по номеру, чужие — в порядке, в каком колония их впервые увидела.
 *
 * <p>Обзор: клетку видно, если до неё от своего юнита, базы или постройки {@code dx² + dy² ≤ r²}.
 * Рельеф, завалы и места залежей известны с начала; запас залежей и чужие юниты — только в обзоре.
 */
public interface ColonyView {

    /** Номер такта, начиная с 0. */
    int tick();

    /** Длина матча в тактах. */
    int maxTicks();

    /** Номер вашей колонии. */
    int myId();

    /** Запас энергии колонии. */
    int energy();

    /** Правила сезона. */
    Rules rules();

    /** Ширина карты в клетках. */
    int width();

    /** Высота карты в клетках. */
    int height();

    /** Клетка внутри карты. */
    boolean inside(Pos p);

    /** Рельеф клетки; за краем карты — {@link Terrain#WALL}; разобранный завал — {@link Terrain#FLOOR}. */
    Terrain terrain(Pos p);

    /** Клетка сейчас в обзоре. */
    boolean isVisible(Pos p);

    /** Идёт перемирие. */
    boolean truce();

    /** Свои юниты. */
    List<Unit> myUnits();

    /** Свои базы. */
    List<Base> myBases();

    /** Чужие юниты в обзоре. */
    List<Unit> visibleEnemies();

    /** Чужие базы в обзоре. */
    List<Base> visibleEnemyBases();

    /** Все известные залежи; у видимых — с запасом. */
    List<Deposit> deposits();

    /** Юнит в клетке, если клетку видно. В перемирие в клетке может стоять несколько: сначала свой, затем меньший id. */
    Optional<Unit> unitAt(Pos p);

    /** Своя база или видимая чужая в клетке. */
    Optional<Base> baseAt(Pos p);

    /** Залежь в клетке. */
    Optional<Deposit> depositAt(Pos p);

    /** Отказы в приказах за прошлый такт. */
    List<Rejection> lastRejections();

    /** Свои события и общие объявления за прошлый такт. */
    List<GameEvent> events();

    /**
     * Свои постройки по номеру: например, склады.
     *
     * <pre>{@code boolean hasDepot = !view.myStructures().isEmpty();}</pre>
     */
    default List<Structure> myStructures() {
        return List.of();
    }

    /**
     * Постройка в клетке: своя или чужая в обзоре.
     *
     * <pre>{@code boolean blocked = view.structureAt(p).isPresent();}</pre>
     */
    default Optional<Structure> structureAt(Pos p) {
        return Optional.empty();
    }

    /**
     * Сколько ударов киркой осталось завалу в клетке; {@code 0} — завала нет (пол, стена или край карты).
     * Завалы известны с начала, как стены.
     *
     * <pre>{@code int left = view.rubble(worker.pos().step(Direction.EAST));}</pre>
     */
    default int rubble(Pos p) {
        return 0;
    }
}
