package colony.api;

/**
 * Ваша колония. Движок вызывает {@link #onTick} раз в такт: смотрите на мир через {@code view}
 * и отдавайте приказы через {@code orders}. Приказы, отданные после возврата из метода, не принимаются.
 */
public interface Colony {

    /**
     * Один такт колонии. Не успели за {@link Rules#tickTimeoutMillis()} или бросили исключение —
     * колония в этом такте стоит, причина видна в {@link ColonyView#lastRejections()} следующего такта.
     */
    void onTick(ColonyView view, Orders orders);
}
