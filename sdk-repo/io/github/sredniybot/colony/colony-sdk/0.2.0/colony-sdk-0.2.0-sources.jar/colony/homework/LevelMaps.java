package colony.homework;

import colony.api.DepositKind;
import colony.api.Pos;
import colony.engine.GameMap;
import colony.engine.ScriptEvent;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

/**
 * Карты пяти уровней ДЗ на правилах арены. Карта задаётся зерном: одно зерно — одна карта и в тренировке, и в
 * попытке. Студент видит только номер уровня, цель и карту; что требует уровень, карта показывает сама:
 * <ol>
 *     <li>вокруг базы много мелких жил, у каждой одно место — рабочих надо развести;</li>
 *     <li>у базы почти пусто, богатый прииск далеко — без склада у прииска не успеть;</li>
 *     <li>богатые жилы в залах за завалами — без разбора завалов к ним не пройти;</li>
 *     <li>жилы и рядом, и далеко, цель высокая — без прокачки рабочих не успеть;</li>
 *     <li>жилы иссякают, проходы засыпает обвалом, по ходу открываются новые жилы — план надо менять на ходу.</li>
 * </ol>
 */
public final class LevelMaps {

    /** Запас жил, которые на уровнях 1–4 не иссякают (правила уровня включают {@code endlessDeposits}). */
    static final int ENDLESS = 1_000_000;
    /** Уровень 5: запас обычной жилы. */
    static final int SMALL = 260;

    private LevelMaps() {}

    /** Карта уровня и сценарий событий на ней (уровень 5: иссякание, обвалы). */
    public record Plan(GameMap map, List<ScriptEvent> script) {}

    /** Карта уровня {@code level} по зерну {@code seed}. */
    public static GameMap build(int level, long seed) {
        return plan(level, seed).map();
    }

    /** Карта и сценарий уровня {@code level} по зерну {@code seed}. */
    public static Plan plan(int level, long seed) {
        SplittableRandom rnd = new SplittableRandom(mix(mix(seed) + 9_000 + level));
        String name = "level-" + level + "-" + seed;
        for (int attempt = 0; attempt < 5000; attempt++) {
            Plan m = switch (level) {
                case 1 -> brigade(rnd, name);
                case 2 -> farMine(rnd, name);
                case 3 -> rubble(rnd, name);
                case 4 -> upgrades(rnd, name);
                case 5 -> changes(rnd, name);
                default -> throw new IllegalArgumentException("уровня " + level + " нет: есть 1–5");
            };
            if (m != null) {
                return m;
            }
        }
        throw new IllegalStateException("не удалось построить карту " + name);
    }

    /**
     * Сценарий карты по её имени («level-5-81723» → события уровня 5 с зерном 81723); другие карты — без сценария.
     * Нужен серверу: он получает карту, а не план, и так же собирает матч при воспроизведении повтора.
     */
    public static List<ScriptEvent> scriptOf(String mapName) {
        java.util.regex.Matcher m = java.util.regex.Pattern.compile("level-([0-9])-([0-9]+)").matcher(String.valueOf(mapName));
        if (!m.matches()) {
            return List.of();
        }
        return plan(Integer.parseInt(m.group(1)), Long.parseLong(m.group(2))).script();
    }

    static long mix(long z) {
        z = (z ^ (z >>> 33)) * 0xff51afd7ed558ccdL;
        z = (z ^ (z >>> 33)) * 0xc4ceb9fe1a85ec53L;
        return z ^ (z >>> 33);
    }

    // ---- 1. много мелких жил, у каждой одно место ----

    private static Plan brigade(SplittableRandom r, String name) {
        TrialMaps.Grid g = new TrialMaps.Grid(26, 18, Map.of(DepositKind.NORMAL, ENDLESS));
        int bx = 11 + r.nextInt(4);
        int by = 7 + r.nextInt(4);
        g.set(bx, by, '1');
        int nooks = 7 + r.nextInt(2);
        for (int i = 0; i < nooks; i++) {
            if (!g.nook(r, bx, by, 4, 11)) {
                return null;
            }
        }
        for (int i = 0, n = 5 + r.nextInt(5); i < n; i++) {
            g.stone(r);
        }
        return g.playable() ? new Plan(g.toMap(name), List.of()) : null;
    }

    // ---- 2. богатый прииск далеко ----

    private static Plan farMine(SplittableRandom r, String name) {
        TrialMaps.Grid g = new TrialMaps.Grid(46, 16, Map.of(DepositKind.NORMAL, ENDLESS, DepositKind.RICH, ENDLESS));
        int bx = 2 + r.nextInt(2);
        int by = 4 + r.nextInt(8);
        g.set(bx, by, '1');
        if (!g.nook(r, bx, by, 3, 6)) {
            return null;
        }
        int rich = 3 + r.nextInt(2);
        for (int i = 0; i < rich; i++) {
            if (!placeIn(g, r, '$', 35, 44, bx, by, 32)) {
                return null;
            }
        }
        for (int i = 0, n = 5 + r.nextInt(4); i < n; i++) {
            g.segment(r, 3, 6);
        }
        return g.playable() ? new Plan(g.toMap(name), List.of()) : null;
    }

    // ---- 3. богатые жилы в залах за завалами ----

    private static Plan rubble(SplittableRandom r, String name) {
        TrialMaps.Grid g = new TrialMaps.Grid(40, 20, Map.of(DepositKind.NORMAL, ENDLESS, DepositKind.RICH, ENDLESS));
        int bx = 2 + r.nextInt(3);
        int by = 7 + r.nextInt(6);
        g.set(bx, by, '1');
        if (!g.nook(r, bx, by, 3, 6)) {
            return null;
        }
        int halls = 2 + r.nextInt(2);
        int made = 0;
        for (int i = 0; i < 60 && made < halls; i++) {
            int w = 7 + r.nextInt(3);
            int h = 6 + r.nextInt(2);
            int x0 = 14 + r.nextInt(40 - 14 - w - 1);
            int y0 = 1 + r.nextInt(20 - h - 1);
            if (hall(g, r, x0, y0, w, h, bx, by)) {
                made++;
            }
        }
        if (made < 2) {
            return null;
        }
        for (int i = 0, n = 3 + r.nextInt(3); i < n; i++) {
            g.stone(r);
        }
        return g.playable(true) ? new Plan(g.toMap(name), List.of()) : null;
    }

    /** Зал из скалы с богатыми жилами; вход — пробка завала толщиной 2–3 клетки со стороны базы. */
    private static boolean hall(TrialMaps.Grid g, SplittableRandom r, int x0, int y0, int w, int h, int bx, int by) {
        for (int y = y0 - 2; y <= y0 + h + 1; y++) {
            for (int x = x0 - 3; x <= x0 + w + 1; x++) {
                if (g.in(x, y) && g.at(x, y) != '.') {
                    return false;
                }
            }
        }
        for (int y = y0; y < y0 + h; y++) {
            for (int x = x0; x < x0 + w; x++) {
                boolean edge = x == x0 || y == y0 || x == x0 + w - 1 || y == y0 + h - 1;
                g.set(x, y, edge ? '#' : '.');
            }
        }
        int deposits = 2 + r.nextInt(2);
        for (int i = 0; i < deposits; i++) {
            if (!placeIn(g, r, '$', x0 + 2, x0 + w - 3, y0 + 2, y0 + h - 3)) {
                return false;
            }
        }
        // вход — на левой стене, напротив середины, пробка выходит наружу
        int dy = y0 + 1 + r.nextInt(h - 2);
        int thick = 2 + r.nextInt(2);
        for (int k = 0; k < thick; k++) {
            g.set(x0 - k, dy, '%');
        }
        return true;
    }

    // ---- 4. жилы рядом и далеко, цель высокая ----

    private static Plan upgrades(SplittableRandom r, String name) {
        TrialMaps.Grid g = new TrialMaps.Grid(36, 20, Map.of(DepositKind.NORMAL, ENDLESS, DepositKind.RICH, ENDLESS));
        int bx = 8 + r.nextInt(4);
        int by = 7 + r.nextInt(6);
        g.set(bx, by, '1');
        for (int i = 0; i < 2; i++) {
            if (!g.place(r, '*', bx, by, 4, 7)) {
                return null;
            }
        }
        for (int i = 0; i < 2; i++) {
            if (!placeIn(g, r, '$', 26, 34, bx, by, 18)) {
                return null;
            }
        }
        for (int i = 0, n = 4 + r.nextInt(3); i < n; i++) {
            g.segment(r, 2, 5);
        }
        return g.playable() ? new Plan(g.toMap(name), List.of()) : null;
    }

    // ---- 5. перемены: жилы иссякают, проходы засыпает, открываются новые ----

    private static Plan changes(SplittableRandom r, String name) {
        TrialMaps.Grid g = new TrialMaps.Grid(40, 20, Map.of(DepositKind.NORMAL, SMALL, DepositKind.RICH, ENDLESS));
        int bx = 3 + r.nextInt(3);
        int by = 7 + r.nextInt(6);
        g.set(bx, by, '1');
        // хребет поперёк карты с тремя проходами: два из них по ходу засыплет обвалом
        int ridge = 16 + r.nextInt(6);
        List<Integer> gaps = new ArrayList<>();
        while (gaps.size() < 3) {
            int y = 2 + r.nextInt(16);
            if (gaps.stream().allMatch(o -> Math.abs(o - y) >= 4)) {
                gaps.add(y);
            }
        }
        for (int y = 0; y < 20; y++) {
            if (!gaps.contains(y)) {
                g.set(ridge, y, '#');
            }
        }
        // по эту сторону хребта — мелкие жилы, которые иссякнут; за ним — богатые
        List<int[]> small = new ArrayList<>();
        for (int i = 0; i < 4; i++) {
            int[] at = placeAt(g, r, '*', 2, ridge - 3, 1, 18, bx, by, 4);
            if (at == null) {
                return null;
            }
            small.add(at);
        }
        List<int[]> far = new ArrayList<>();
        for (int i = 0; i < 2; i++) {
            int[] at = placeAt(g, r, '$', ridge + 4, 37, 2, 17, bx, by, 0);
            if (at == null) {
                return null;
            }
            far.add(at);
        }
        if (!g.playable()) {
            return null;
        }
        // сценарий: две ближние жилы иссякают, два прохода засыпает, одна богатая жила за хребтом иссякает
        List<ScriptEvent> script = new ArrayList<>();
        script.add(new ScriptEvent(90 + r.nextInt(30), ScriptEvent.Kind.DRY, pos(small.get(0)), 0));
        script.add(new ScriptEvent(160 + r.nextInt(40), ScriptEvent.Kind.DRY, pos(small.get(1)), 0));
        script.add(new ScriptEvent(200 + r.nextInt(40), ScriptEvent.Kind.CLOSE, new Pos(ridge, gaps.get(0)), 0));
        script.add(new ScriptEvent(320 + r.nextInt(40), ScriptEvent.Kind.CLOSE, new Pos(ridge, gaps.get(1)), 0));
        script.add(new ScriptEvent(380 + r.nextInt(60), ScriptEvent.Kind.DRY, pos(far.get(0)), 0));
        script.sort(java.util.Comparator.comparingInt(ScriptEvent::tick));
        return new Plan(g.toMap(name), List.copyOf(script));
    }

    private static Pos pos(int[] xy) {
        return new Pos(xy[0], xy[1]);
    }

    // ---- помощники ----

    /** Залежь {@code kind} в прямоугольнике x∈[x0,x1], y∈[y0,y1] на свободном месте. */
    private static boolean placeIn(TrialMaps.Grid g, SplittableRandom r, char kind, int x0, int x1, int y0, int y1) {
        for (int i = 0; i < 300; i++) {
            int x = x0 + r.nextInt(Math.max(1, x1 - x0 + 1));
            int y = y0 + r.nextInt(Math.max(1, y1 - y0 + 1));
            if (g.clear(x, y, 1)) {
                g.set(x, y, kind);
                return true;
            }
        }
        return false;
    }

    /** Залежь в полосе x∈[x0,x1] не ближе {@code min} шагов к базе. */
    private static boolean placeIn(TrialMaps.Grid g, SplittableRandom r, char kind, int x0, int x1, int bx, int by,
                                   int min) {
        return placeAt(g, r, kind, x0, x1, 1, g.h - 2, bx, by, min) != null;
    }

    private static int[] placeAt(TrialMaps.Grid g, SplittableRandom r, char kind, int x0, int x1, int y0, int y1,
                                 int bx, int by, int min) {
        for (int i = 0; i < 300; i++) {
            int x = x0 + r.nextInt(Math.max(1, x1 - x0 + 1));
            int y = y0 + r.nextInt(Math.max(1, y1 - y0 + 1));
            if (Math.abs(x - bx) + Math.abs(y - by) >= min && g.clear(x, y, 1)) {
                g.set(x, y, kind);
                return new int[] {x, y};
            }
        }
        return null;
    }
}
