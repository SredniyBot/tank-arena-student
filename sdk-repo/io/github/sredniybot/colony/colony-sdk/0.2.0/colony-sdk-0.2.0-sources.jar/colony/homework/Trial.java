package colony.homework;

/**
 * Испытание домашнего задания: что на карте, условие зачёта, что надо понять и подсказка-понятие. Решений здесь нет.
 *
 * @param number     номер, 1–12
 * @param title      «Лабиринт»
 * @param block      «Для всех», «Структура» или «Сила»
 * @param onMap      что на картах испытания
 * @param understand что надо понять
 * @param hint       подсказка-понятие: куда смотреть, а не как написать
 * @param opens      {@code null} — испытание открыто; иначе — когда откроется («с механикой «копание»», «скоро»)
 * @param goal       условие зачёта
 * @param maps       карт в попытке
 * @param ticks      тактов на карте
 * @param gift       «подарочное»: колония, написанная нейросетью с одного раза по тексту условия, его проходит, —
 *                   понимания оно не проверяет
 */
public record Trial(int number, String title, String block, String onMap, String understand, String hint,
                    String opens, Goal goal, int maps, int ticks, boolean gift) {

    /** Условие зачёта. */
    public sealed interface Goal permits PerMap, Share, Wins {}

    /** На каждой карте сдано не меньше {@code energy}. */
    public record PerMap(int energy) implements Goal {}

    /** Сданная энергия на всех картах вместе — не меньше {@code percent} процентов эталона на тех же картах. */
    public record Share(int percent) implements Goal {}

    /** Побед над встроенным соперником не меньше {@code need} из {@link #maps}. */
    public record Wins(int need, String opponent, String opponentName) implements Goal {}

    public boolean available() {
        return opens == null;
    }

    /** На двоих: студент против встроенного соперника. */
    public boolean duel() {
        return goal instanceof Wins;
    }

    /** «Лабиринт» в кавычках-ёлочках. */
    public String quoted() {
        return "«" + title + "»";
    }

    /** Условие одной строкой: «сданная энергия ≥ 80% эталона на тех же 3 картах по 600 тактов». */
    public String condition() {
        return switch (goal) {
            case PerMap p -> "≥ " + p.energy() + " энергии за " + ticks + " тактов на каждой из " + maps + " карт";
            case Share s -> "сданная энергия ≥ " + s.percent() + "% эталона на тех же " + maps + " картах по " + ticks
                    + " тактов";
            case Wins w -> "победа на " + w.need() + " из " + maps + " карт по " + ticks + " тактов, соперник — «"
                    + w.opponentName() + "»";
        };
    }
}
