package colony.net;

import colony.protocol.Board;
import colony.protocol.Order;
import colony.api.Colony;
import colony.api.ColonyView;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.engine.Ability;
import colony.engine.Version;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.management.ManagementFactory;
import java.net.URI;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.UUID;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.function.BooleanSupplier;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * Колония на сервере: мир на занятие, допуск или бой по вызову. Код студента тот же, что в локальной игре:
 * {@code onTick(view, orders)}, и работает он здесь, на ноутбуке студента; на сервер уходят только приказы.
 *
 * <p>Цикл: вход по токену → длинный опрос обзора → {@code onTick} с лимитом до срока такта → отправка приказов.
 * Обрыв связи — пауза и новая попытка. Консоль спокойная: строка на смену состояния, сводка опозданий раз
 * в 30 секунд, отказы — как в локальной игре.
 */
public final class NetGame {

    /** Счётчики: обзоров получено, приказов отправлено, тактов с опозданием, самое долгое решение. */
    public record Stats(int views, int sent, int late, long decideMillisMax) {}

    private final ServerLink link;
    private final Supplier<Colony> factory;
    private final NetConsole console;
    private final long retryMillis;
    private final long summaryMillis;
    private final BooleanSupplier debugger;
    private final String session;
    private final String clientId = UUID.randomUUID().toString().substring(0, 8);
    private final AtomicInteger views = new AtomicInteger();
    private final AtomicInteger sent = new AtomicInteger();
    private final AtomicInteger late = new AtomicInteger();
    private volatile long decideMax;
    private volatile boolean stopped;

    // матч, в который вошли
    private String gameId;
    private int colonyId;
    private Board board;
    private int tickMs;
    private ColonyCall colony;

    private NetGame(Builder b) {
        this.link = new ServerLink(b.server, b.token);
        this.factory = b.me;
        this.console = new NetConsole(b.out, b.err);
        this.retryMillis = b.retryMillis;
        this.summaryMillis = b.summaryMillis;
        this.debugger = b.debugger;
        this.session = b.session;
    }

    public static Builder builder() {
        return new Builder();
    }

    /** Настройки сетевой игры. */
    public static final class Builder {
        private URI server;
        private String token;
        private Supplier<Colony> me;
        private PrintStream out = System.out;
        private PrintStream err = System.err;
        private long retryMillis = 3000;
        private long summaryMillis = 30_000;
        private BooleanSupplier debugger = NetGame::jdwp;
        private String session = "world";

        public Builder server(URI uri) {
            this.server = uri;
            return this;
        }

        public Builder token(String token) {
            this.token = token;
            return this;
        }

        public Builder me(Supplier<Colony> me) {
            this.me = me;
            return this;
        }

        public Builder console(PrintStream out, PrintStream err) {
            this.out = out;
            this.err = err;
            return this;
        }

        /** Пауза перед новой попыткой при обрыве связи. */
        public Builder retryMillis(long millis) {
            this.retryMillis = millis;
            return this;
        }

        /** Как часто печатать сводку опозданий. */
        public Builder summaryMillis(long millis) {
            this.summaryMillis = millis;
            return this;
        }

        /** Подключён ли отладчик: тогда {@code onTick} ждём без лимита (сервер такт не ждёт). */
        public Builder debugger(BooleanSupplier detector) {
            this.debugger = detector;
            return this;
        }

        /**
         * {@code world} — мир на занятие, {@code admission} — допуск, {@code challenge} — бой по вызову, {@code boss} —
         * проверка босса, {@code homework} — попытка домашнего задания.
         */
        public Builder session(String kind) {
            this.session = kind;
            return this;
        }

        public NetGame build() {
            if (server == null || token == null || me == null) {
                throw new IllegalStateException("нужны адрес сервера, токен и колония");
            }
            return new NetGame(this);
        }
    }

    private static boolean jdwp() {
        return ManagementFactory.getRuntimeMXBean().getInputArguments().stream()
                .anyMatch(a -> a.startsWith("-agentlib:jdwp") || a.startsWith("-Xrunjdwp"));
    }

    /** Остановить цикл; {@link #run()} вернёт 0. */
    public void stop() {
        stopped = true;
    }

    public Stats stats() {
        return new Stats(views.get(), sent.get(), late.get(), decideMax);
    }

    /** Отказ сервера, после которого играть нет смысла (токен, версия, мест нет, окно закрыто). */
    private static final class Fatal extends Exception {
        Fatal(String message) {
            super(message, null, false, false);
        }
    }

    /**
     * Играть, пока не остановят или пока серия (допуск, бой по вызову) не сыграна. 0 — остановлено или сыграно,
     * 1 — сервер не пускает.
     */
    public int run() {
        console.line("Колония: подключаюсь к серверу " + link.base() + (session.equals("world") ? ""
                : " (" + kindTitle(session) + ")"));
        boolean offline = false;
        String shownState = null;
        String shownMessage = null;
        int after = -1;
        long windowStart = System.nanoTime();
        int windowViews = 0;
        int windowLate = 0;
        try {
            while (!stopped) {
                try {
                    if (gameId == null) {
                        join();
                        after = -1;
                        shownState = null;
                    }
                    ServerLink.Reply reply = link.view(after, gameId, session);
                    if (offline) {
                        offline = false;
                        console.line("Связь восстановлена: такт " + reply.body().path("tick").asInt() + ".");
                    }
                    JsonNode r = viewReply(reply);
                    if (r == null) {
                        continue;
                    }
                    String state = r.path("state").asText();
                    String message = r.hasNonNull("message") ? r.get("message").asText() : null;
                    if (message != null && !message.equals(shownMessage)) {
                        shownMessage = message;
                        console.line(message);
                    }
                    if (state.equals("done")) {
                        return 0;
                    }
                    if (!r.path("gameId").asText().equals(gameId)) {
                        if (session.equals("world")) {
                            console.line("Преподаватель начал новый мир: колония начинает заново.");
                        }
                        leave();
                        continue;
                    }
                    if (!state.equals(shownState)) {
                        shownState = state;
                        if (session.equals("world")) {
                            stateLine(state, r);
                        }
                    }
                    JsonNode v = r.get("view");
                    if (v != null && v.isObject() && board != null) {
                        ColonyView view = Protocol.view(v, board);
                        views.incrementAndGet();
                        windowViews++;
                        if (view.lastRejections().stream().anyMatch(x -> x.code() == RejectCode.LATE)) {
                            late.incrementAndGet();
                            windowLate++;
                        }
                        console.rejections(view.tick(), view.lastRejections().stream().filter(x ->
                                x.code() != RejectCode.LATE && x.code() != RejectCode.EXCEPTION
                                        && x.code() != RejectCode.TIMEOUT).toList());
                        after = view.tick();
                        decideAndSend(view, r.path("deadlineInMs"));
                    }
                } catch (IOException e) {
                    if (stopped) {
                        break;
                    }
                    if (!offline) {
                        offline = true;
                        console.line("Нет связи с сервером, пробую снова через " + seconds(retryMillis) + ".");
                    }
                    Thread.sleep(retryMillis);
                }
                long now = System.nanoTime();
                if (now - windowStart >= summaryMillis * 1_000_000L) {
                    if (windowLate > 0) {
                        console.line("За " + seconds(summaryMillis) + " приказы опоздали в " + windowLate + " "
                                + (windowLate % 10 == 1 && windowLate % 100 != 11 ? "такте" : "тактах") + " из "
                                + windowViews + ". Колония в эти такты стояла: ускорьте onTick или проверьте сеть.");
                    }
                    windowStart = now;
                    windowViews = 0;
                    windowLate = 0;
                }
            }
            return 0;
        } catch (Fatal f) {
            console.error(f.getMessage());
            return 1;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return 0;
        } finally {
            leave();
            link.close();
        }
    }

    private static String kindTitle(String session) {
        return switch (session) {
            case "admission" -> "допуск";
            case "boss" -> "проверка босса";
            case "homework" -> "попытка домашнего задания";
            default -> "бой по вызову";
        };
    }

    /** Ответ длинного опроса или {@code null}, если надо просто спросить снова. */
    private JsonNode viewReply(ServerLink.Reply r) throws Fatal, InterruptedException, IOException {
        if (r.status() == 429) {
            Thread.sleep(1000); // сервер просит реже; тихо пробуем снова
            return null;
        }
        if (r.status() == 409 && r.code().equals("NO_SESSION")) {
            leave(); // сервер не помнит серию — войти заново
            return null;
        }
        if (r.status() != 200) {
            refused(r);
        }
        return r.body();
    }

    private void stateLine(String state, JsonNode r) {
        switch (state) {
            case "paused" -> console.line("Мир на паузе: ждём преподавателя.");
            case "running" -> console.line("Мир идёт: такт " + r.path("tick").asInt() + ".");
            case "finished" -> {
                JsonNode result = r.path("result");
                String mine = "";
                for (JsonNode p : result.path("ranking")) {
                    if (p.path("id").asInt() == colonyId) {
                        mine = ": " + p.path("place").asInt() + " место из " + result.path("ranking").size()
                                + ", счёт " + p.path("score").asInt();
                    }
                }
                console.line("Мир окончен" + mine + ". Ждём новый мир от преподавателя.");
            }
            default -> console.line("Мир: " + state + ".");
        }
    }

    private static String seconds(long millis) {
        if (millis % 1000 == 0) {
            return millis / 1000 + " с";
        }
        return String.format(Locale.ROOT, "%.1f с", millis / 1000.0).replace('.', ',');
    }

    // ---- вход ----

    private void join() throws IOException, InterruptedException, Fatal {
        ServerLink.Reply info = link.info();
        if (info.status() != 200) {
            throw new IOException("сервер ответил " + info.status());
        }
        String protocol = info.body().path("protocol").asText("?");
        String needed = info.body().path("protocolMin").asText(null);
        if (Protocol.major(protocol) != Protocol.MAJOR
                || needed != null && Protocol.compareVersions(Protocol.VERSION, needed) < 0) {
            throw new Fatal("Сервер говорит на протоколе " + protocol + ", а этот SDK — на " + Protocol.VERSION
                    + ". Обновите SDK (версия — в pom.xml) или спросите преподавателя.");
        }
        String min = info.body().path("sdkMin").asText(null);
        if (min != null && Protocol.compareVersions(Version.get(), min) < 0) {
            throw new Fatal("Серверу нужен SDK " + min + " или новее, а у вас " + Version.get() + ". В pom.xml "
                    + "поставьте <colony.sdk.version>" + min + "</colony.sdk.version> и нажмите Maven → Reload.");
        }
        ObjectNode body = Protocol.JSON.createObjectNode().put("sdkVersion", Version.get())
                .put("protocol", Protocol.VERSION).put("client", clientId).put("session", session);
        ServerLink.Reply r = link.join(body);
        if (r.status() != 200) {
            refused(r);
        }
        JsonNode j = r.body();
        board = j.has("map") ? Protocol.board(j.path("map"), Protocol.rules(j.path("rules"))) : null;
        colonyId = j.path("colonyId").asInt();
        tickMs = j.path("tickMs").asInt(1000);
        gameId = j.path("gameId").asText();
        if (j.hasNonNull("title")) {
            console.line(j.get("title").asText());
            if (j.hasNonNull("place")) {
                console.line(j.get("place").asText());
            }
        } else if (board != null && session.equals("world")) {
            console.line("На связи: карта " + board.name() + ", вы — колония " + colonyId + " «"
                    + j.path("name").asText() + "» (знак " + j.path("sign").asText() + "). Такт " + tickMs + " мс.");
            if (j.hasNonNull("place")) {
                // мир под список группы: где база на карте («Рядом с вашей базой — «Северный прииск».»)
                console.line(j.get("place").asText());
            }
            Set<Ability> open = board.rules().abilities();
            if (!open.isEmpty()) {
                // в мире с открытиями ДЗ здесь только то, что студент сдал
                console.line("Доступно вашей колонии в этом мире: "
                        + open.stream().map(Ability::title).collect(Collectors.joining(", ")) + ".");
            }
        }
        if (board != null) {
            colony = new ColonyCall(factory);
            console.newMatch();
            if (debugger.getAsBoolean()) {
                console.line("Отладчик подключён: сервер такт не ждёт — пока стоите на точке останова, колония стоит.");
            }
        }
    }

    private void refused(ServerLink.Reply r) throws Fatal, IOException {
        if (r.status() >= 500) {
            throw new IOException("сервер ответил " + r.status()); // сбой сервера — как обрыв: пробуем снова
        }
        if (r.status() == 401 || r.status() == 403 || r.status() == 409) {
            throw new Fatal("Сервер не пускает: " + r.error() + ".");
        }
        throw new Fatal("Сервер ответил ошибкой: " + r.error() + ".");
    }

    private void leave() {
        gameId = null;
        if (colony != null) {
            colony.close();
            colony = null;
        }
    }

    // ---- такт ----

    /** Вызвать {@code onTick} до срока и отправить приказы (или причину, по которой колония стоит). */
    private void decideAndSend(ColonyView view, JsonNode deadline) throws IOException, InterruptedException, Fatal {
        long received = System.nanoTime();
        int limit = view.rules().tickTimeoutMillis();
        if (deadline != null && deadline.canConvertToInt()) {
            limit = (int) Math.min(limit, deadline.asInt() - Math.min(150, tickMs / 5));
        }
        boolean debugging = debugger.getAsBoolean();
        if (limit <= 0 && !debugging) {
            return; // не успеть: сервер отметит опоздание, сводка его покажет
        }
        NetOrders orders = new NetOrders(view.tick());
        ColonyCall.Outcome outcome = colony.call(view, orders, debugging ? Long.MAX_VALUE : limit);
        List<Order> list = orders.close();
        decideMax = Math.max(decideMax, (System.nanoTime() - received) / 1_000_000);
        Rejection failure = outcome.failure();
        if (failure != null) {
            console.error("такт " + (view.tick() + 1) + ": " + failure.message());
            console.stackOnce(outcome.error());
        }
        ObjectNode body = Protocol.ordersJson(gameId, view.tick(), failure == null ? list : List.of());
        body.put("client", clientId);
        if (failure != null) {
            body.putObject("failure").put("code", failure.code().name()).put("text", failure.message());
        }
        ServerLink.Reply r = link.orders(body, session);
        sent.incrementAndGet();
        String status = r.body().path("status").asText();
        if (r.status() == 200 && r.body().hasNonNull("warning")) {
            console.error("Сервер: " + r.body().get("warning").asText() + ".");
        } else if (status.equals("stale")) {
            leave();
        } else if (r.status() != 200 && r.status() != 409 && r.status() != 429) {
            refused(r); // 409 late — сервер отметит опоздание; 429 — эти приказы пропали
        }
        if (orders.dropped() > 0) {
            console.error("такт " + (view.tick() + 1) + ": приказов больше " + NetOrders.LIMIT + ", лишние "
                    + orders.dropped() + " не отправлены");
        }
    }
}
