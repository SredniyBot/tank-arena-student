// Интерфейс поверх карты: подпись, колонии, выбранная колония с отказами, события, шкала времени.
// Данные повтора попадают в DOM только через textContent и setProperty. Списки обновляются на месте:
// строки не пересоздаются под курсором, прокрутка и щелчки не теряются.
import { $, h, icon, num, numShort, plural, clamp, shortName, KIND_NAME } from './util.js';
import { hotspots } from './scene.js';

export const SPEEDS = [0.5, 1, 2, 4, 8, 16, 32, 50];
export const speedText = v => String(v).replace('.', ',') + '×';

const SVG = {
  W: '<svg width="13" height="10" viewBox="0 0 13 10" aria-hidden="true"><rect x=".5" y="1" width="12" height="8" rx="2.6" fill="currentColor"/><rect x="8" y="2.6" width="3" height="4.8" rx="1" fill="#1E2529" opacity=".5"/></svg>',
  T: '<svg width="14" height="10" viewBox="0 0 14 10" aria-hidden="true"><rect x=".5" y=".8" width="10" height="8.4" rx="2" fill="currentColor"/><rect x="5" y="4.1" width="8.6" height="1.8" rx=".9" fill="currentColor"/><circle cx="5" cy="5" r="2.3" fill="#1E2529" opacity=".45"/></svg>',
  play: '<path d="M5 3.2 L14.6 9 L5 14.8 Z" fill="currentColor" stroke="currentColor" stroke-width="1.6" stroke-linejoin="round"/>',
  pause: '<rect x="4" y="3" width="3.8" height="12" rx="1.3" fill="currentColor"/><rect x="10.2" y="3" width="3.8" height="12" rx="1.3" fill="currentColor"/>',
  caret: '<svg width="12" height="12" viewBox="0 0 12 12" aria-hidden="true"><path d="M4 2.5 L8 6 L4 9.5" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>',
};
const DANGER_KINDS = new Set(['BASE_DESTROYED', 'COLONY_DIED']);
const SVGNS = 'http://www.w3.org/2000/svg';

export class Hud {
  constructor(match, ctl) {
    this.m = match; this.ctl = ctl;
    this.el = {
      cap: $('#caption'), capText: $('#capText'), capSub: $('#capSub'), capAcc: $('#capAcc'),
      side: $('#side'), cols: $('#cols'), colsScroll: $('#colsScroll'), detail: $('#detail'), feed: $('#feedList'),
      mapName: $('#mapName'), mode: $('#modeLabel'), clock: $('#clock'), track: $('#track'), knob: $('#knob'), done: $('#done'),
      marks: $('#marks'), density: $('#density'), trackTip: $('#trackTip'), speed: $('#speed'), speedMenu: $('#speedMenu'),
      playIco: $('#playIco'), play: $('#play'), tip: $('#tip'), card: $('#card'), toast: $('#toast'),
    };
    this.rows = new Map();
    this.lastCap = ''; this.marksKey = ''; this.rowH = 0;
    this.total = 1; this.order = []; this.sortedAt = 0; this.listHover = false; this.listScrolled = -1e9;
    this.rejOpen = false; this.det = null; this.feedNodes = new Map(); this.cardState = null;
    this.scoreMax = 1; this.scoreScanned = 0;
  }

  build() {
    const m = this.m, e = this.el;
    // пока зритель листает список или держит над ним мышь, строки не переставляются
    if (e.colsScroll && !e.colsScroll.dataset.bound) {
      e.colsScroll.dataset.bound = '1';
      e.colsScroll.addEventListener('pointerenter', () => { this.listHover = true; });
      e.colsScroll.addEventListener('pointerleave', () => { this.listHover = false; });
      e.colsScroll.addEventListener('scroll', () => { this.listScrolled = performance.now(); }, { passive: true });
    }
    e.mapName.textContent = m.league ? `${m.league} · ${m.map.name || 'карта'}` : (m.map.name || 'карта');
    e.side.classList.toggle('dense', m.colonyList.length > 6);
    this.spark = m.colonyList.length <= 6;
    e.side.classList.toggle('sparks', this.spark);
    e.cols.replaceChildren();
    for (const c of m.colonyList) {
      const pl = h('span', { class: 'pl' }), en = h('span', { class: 'en' }), sc = h('span', { class: 'sc' });
      const wTxt = document.createTextNode(''), tTxt = document.createTextNode('');
      const wSpan = h('span', { title: 'рабочие' }, icon(SVG.W), wTxt), tSpan = h('span', { title: 'танки' }, icon(SVG.T), tTxt);
      const gone = h('span', { class: 'gone', text: 'выбыла', hidden: true });
      const u = h('span', { class: 'u' }, wSpan, tSpan, gone);
      let line = null, dot = null, svg = null;
      if (this.spark) {
        svg = document.createElementNS(SVGNS, 'svg'); svg.setAttribute('viewBox', '0 0 64 22'); svg.setAttribute('class', 'spark'); svg.setAttribute('aria-hidden', 'true');
        line = document.createElementNS(SVGNS, 'polyline'); line.setAttribute('fill', 'none'); line.setAttribute('stroke', c.pal.hi); line.setAttribute('stroke-width', '2'); line.setAttribute('stroke-linejoin', 'round'); line.setAttribute('stroke-linecap', 'round');
        dot = document.createElementNS(SVGNS, 'circle'); dot.setAttribute('r', '2.4'); dot.setAttribute('fill', '#fff');
        svg.append(line, dot);
      }
      const b = h('button', { class: 'col', data: { id: c.id }, style: { '--c': c.color }, 'aria-label': `Колония ${c.name}` },
        pl, h('span', { class: 'badge', text: c.sign }), h('span', { class: 'nm' }, h('b', { text: this.rowName(c), title: c.name }), u), en, sc);
      if (svg) u.append(svg);
      e.cols.appendChild(b);
      this.rows.set(c.id, { el: b, pl, u, en, sc, wTxt, tTxt, tSpan, wSpan, gone, line, dot, key: '' });
    }
    e.speedMenu.replaceChildren(...SPEEDS.map(v => h('button', { role: 'menuitemradio', data: { speed: v }, 'aria-checked': 'false', text: speedText(v) })));
    this.measure();
  }

  // Колония сменила имя посреди живой игры (сервер мира: «Аня (бот)» → «Аня»).
  rename(c) {
    const row = this.rows.get(c.id); if (!row) return;
    row.el.setAttribute('aria-label', `Колония ${c.name}`);
    const b = row.el.querySelector('.nm b'); if (b) { b.textContent = this.rowName(c); b.title = c.name; }
    if (this.det && this.det.id === c.id) this.det = null; // карточка выбранной соберётся с новым именем
  }

  // Много колоний — в таблице короткое имя («Фамилия И.»), полное — во всплывающей подсказке.
  rowName(c) {
    return this.m.colonyList.length > 6 ? shortName(c.name, 16) : c.name;
  }

  measure() {
    const first = this.el.cols.firstElementChild;
    this.rowH = first ? first.getBoundingClientRect().height + 2 : 44;
    this.el.cols.style.height = (this.rowH * this.m.colonyList.length) + 'px';
    for (const r of this.rows.values()) r.key = '';
    this.marksKey = '';
  }

  setMode(text, cls) { this.el.mode.textContent = text; this.el.mode.className = 'mode ' + (cls || ''); }
  setPlaying(on) {
    this.el.playIco.innerHTML = on ? SVG.pause : SVG.play;
    this.el.play.setAttribute('aria-label', on ? 'Пауза' : 'Смотреть');
  }
  setSpeed(v) {
    this.el.speed.textContent = speedText(v);
    for (const b of this.el.speedMenu.children) b.setAttribute('aria-checked', String(+b.dataset.speed === v));
  }
  setPressed(act, on) { for (const b of document.querySelectorAll(`[data-act="${act}"]`)) b.setAttribute('aria-pressed', String(on)); }
  // Просмотр выбросил первые d кадров (общая арена).
  trimmed(d) { this.scoreScanned = Math.max(0, this.scoreScanned - d); this.marksKey = ''; }

  // Длина шкалы в кадрах: в живой игре — по плану матча, а не по пришедшим кадрам.
  setTotal(n) { if (n !== this.total) { this.total = Math.max(1, n); this.marksKey = ''; } }

  tick(T) {
    const p = clamp(T / this.total, 0, 1) * 100;
    this.el.knob.style.left = p + '%'; this.el.done.style.width = p + '%';
  }

  update(i, st) {
    const m = this.m, f = m.frames[i]; if (!f) return;
    const maxT = st.live && !m.finished && !m.endless ? (m.rules.maxTicks || m.frames[m.last].t) : m.frames[m.last].t;
    // на арене конца нет: только номер такта
    this.el.clock.replaceChildren(h('b', { text: f.t }), m.endless ? '' : ` / ${num(maxT)}`);
    this.el.track.setAttribute('aria-valuenow', String(f.t));
    this.el.track.setAttribute('aria-valuemax', String(maxT));
    this.colonies(i, st);
    this.detail(i, st);
    this.feed(i, st);
    this.caption(i, st);
  }

  colonies(i, st) {
    const m = this.m, rank = m.ranking(i), counts = m.counts(i), now = performance.now();
    // Порядок строк меняется не чаще раза в 3 с вживую и не меняется, пока список листают или он под мышью.
    // Равные по месту сохраняют прежний порядок: строки не прыгают от каждой единицы энергии.
    const prev = this.order, same = prev.length === rank.length && rank.every(r => prev.includes(r.id));
    const hold = same && (this.listHover || now - this.listScrolled < 4000 || (st.live && now - this.sortedAt < 3000));
    if (!hold) {
      const at = new Map(prev.map((id, k) => [id, k]));
      this.order = [...rank].sort((a, b) => (b.alive - a.alive) || (a.place - b.place)
        || ((at.get(a.id) ?? 1e9) - (at.get(b.id) ?? 1e9)) || (a.id - b.id)).map(r => r.id);
      this.sortedAt = now;
    }
    const byId = new Map(rank.map(r => [r.id, r]));
    if (this.spark) for (; this.scoreScanned < m.frames.length; this.scoreScanned++) for (const c of m.frames[this.scoreScanned].colonies) this.scoreMax = Math.max(this.scoreMax, c.score || 0);
    this.order.forEach((id, idx) => {
      const r = byId.get(id), row = this.rows.get(id); if (!r || !row) return;
      row.el.style.transform = `translateY(${idx * this.rowH}px)`;
      row.el.classList.toggle('sel', st.selected === r.id);
      if (this.spark) this.sparkline(row, r.id, i);
      const cnt = counts.get(r.id) || { W: 0, T: 0 }, showT = m.features.tanks || cnt.T > 0;
      const key = [r.place, r.alive, r.energy, r.score, cnt.W, cnt.T, showT].join(':');
      if (row.key === key) return; row.key = key;
      row.pl.textContent = r.alive ? String(r.place) : '';
      row.el.classList.toggle('out', !r.alive);
      row.en.textContent = r.alive ? numShort(r.energy ?? 0) : '';
      row.sc.textContent = numShort(r.score ?? 0);
      // в лигах — сколько из предела: «6/8»
      const caps = m.features.unitCaps;
      row.wTxt.data = caps && m.rules.maxWorkers ? `${cnt.W}/${m.rules.maxWorkers}` : String(cnt.W);
      row.tTxt.data = caps && m.rules.maxTanks ? `${cnt.T}/${m.rules.maxTanks}` : String(cnt.T);
      row.wSpan.hidden = !r.alive; row.tSpan.hidden = !r.alive || !showT; row.gone.hidden = !!r.alive;
    });
  }

  // Перевес во времени: кто выигрывает, без чтения таблицы. Шкала общая для всех колоний.
  sparkline(row, id, i) {
    const m = this.m, n = Math.min(48, i + 1), pts = [];
    for (let k = 0; k < n; k++) {
      const j = Math.round(k / Math.max(1, n - 1) * i), c = m.frames[j].colonies.find(x => x.id === id);
      pts.push(`${(j / Math.max(1, this.total) * 62 + 1).toFixed(1)},${(20 - (c ? c.score : 0) / this.scoreMax * 18).toFixed(1)}`);
    }
    row.line.setAttribute('points', pts.join(' '));
    const last = pts[pts.length - 1].split(','); row.dot.setAttribute('cx', last[0]); row.dot.setAttribute('cy', last[1]);
  }

  // Выбранная колония: факты и журнал отказов. Журнал свёрнут в строку и раскрывается щелчком.
  detail(i, st) {
    const m = this.m, el = this.el.detail, id = st.selected;
    if (id == null || !m.colonies.has(id)) { el.hidden = true; this.det = null; el.replaceChildren(); return; }
    const c = m.colonies.get(id);
    if (!this.det || this.det.id !== id) {
      const facts = h('div', { class: 'facts' });
      const sumText = document.createTextNode('');
      const sum = h('button', { class: 'rej-sum', data: { act: 'rej' }, 'aria-expanded': String(this.rejOpen) }, icon(SVG.caret), sumText);
      const list = h('ol', { class: 'rej', hidden: !this.rejOpen });
      el.replaceChildren(
        h('div', { class: 'detail-head' }, h('span', { class: 'badge', style: { '--c': c.color }, text: c.sign }), h('b', { text: c.name }), h('code', { title: c.bot, text: c.bot }), h('button', { data: { act: 'unselect' }, 'aria-label': 'Снять выбор', text: '×' })),
        facts, sum, list);
      this.det = { id, facts, sum, sumText, list, nodes: new Map(), key: '' };
    }
    el.hidden = false;
    const d = this.det, f = m.frames[i], fc = f.colonies.find(x => x.id === id) || {}, cnt = m.counts(i).get(id) || { W: 0, T: 0 };
    const ms = f.decideMillis ? f.decideMillis[String(id)] : undefined;
    const fact = (b, rest) => h('span', null, h('b', { text: b }), ' ' + rest);
    const facts = fc.alive === false ? [h('span', { text: 'колония выбыла' })] : [
      fact(cnt.W, plural(cnt.W, 'рабочий', 'рабочих', 'рабочих')),
      (m.features.tanks || cnt.T) ? fact(cnt.T, plural(cnt.T, 'танк', 'танка', 'танков')) : null,
      ms !== undefined ? h('span', null, 'решение ', h('b', { text: num(ms) }), ' мс') : null,
      (m.features.center || fc.centerTicks) ? h('span', null, 'в центре ', h('b', { text: num(fc.centerTicks || 0) }), ' ' + plural(fc.centerTicks || 0, 'такт', 'такта', 'тактов')) : null,
    ].filter(Boolean);
    const factKey = facts.map(x => x.textContent).join('|');
    if (d.factKey !== factKey) { d.factKey = factKey; d.facts.replaceChildren(...facts); }

    const now = (f.rejections[String(id)] || []).length;
    d.sumText.data = now ? `В этом такте ${now} ${plural(now, 'отказ', 'отказа', 'отказов')}` : 'В этом такте отказов нет';
    d.sum.classList.toggle('hot', now > 0);
    d.sum.setAttribute('aria-expanded', String(this.rejOpen)); d.list.hidden = !this.rejOpen;
    if (!this.rejOpen) return;
    const key = id + ':' + i;
    if (d.key === key) return; d.key = key;
    // одинаковые отказы склеиваем: «рабочий 20: столкновение ×6», такт — последний
    const groups = new Map();
    for (let j = i, raw = 0; j >= 0 && j > i - 600 && raw < 400; j--) {
      const list = m.frames[j].rejections[String(id)];
      if (list) for (const r of list) {
        raw++;
        const text = String(r.text || r.code || '');
        const g = groups.get(text);
        if (g) g.n++; else groups.set(text, { text, n: 1, j, t: m.frames[j].t, unit: Number(r.unit) || 0 });
      }
    }
    const items = [...groups.values()].slice(0, 40);
    const seen = new Set();
    items.forEach(g => {
      seen.add(g.text);
      let node = d.nodes.get(g.text);
      if (!node) {
        const tk = h('span', { class: 'tk' }), cnt2 = h('span', { class: 'cnt' }), btn = h('button', { text: g.text });
        node = { li: h('li', null, tk, btn, cnt2), tk, cnt: cnt2, btn };
        d.nodes.set(g.text, node);
      }
      node.tk.textContent = String(g.t);
      node.cnt.textContent = g.n > 1 ? `×${g.n}` : '';
      node.btn.dataset.seek = String(g.j); node.btn.dataset.unit = g.unit ? String(g.unit) : '';
      node.li.classList.toggle('now', g.j === i);
    });
    for (const [k, node] of d.nodes) if (!seen.has(k)) { node.li.remove(); d.nodes.delete(k); }
    if (!items.length) { if (!d.list.querySelector('.none')) d.list.replaceChildren(h('li', { class: 'none', text: 'Отказов нет. Все приказы приняты.' })); return; }
    d.list.querySelector('.none')?.remove();
    // порядок меняем только если он изменился: те же узлы переставляются, щелчок не теряется
    const want = items.map(g => d.nodes.get(g.text).li);
    want.forEach((li, k) => { if (d.list.children[k] !== li) d.list.insertBefore(li, d.list.children[k] || null); });
  }

  // Лента событий: новые строки добавляются сверху, старые не пересоздаются; повторы склеены.
  feed(i, st) {
    const m = this.m, ev = m.events, many = m.colonyList.length > 4;
    let lo = 0, hi = ev.length - 1, end = -1;
    while (lo <= hi) { const mid = (lo + hi) >> 1; if (ev[mid].i <= i) { end = mid; lo = mid + 1; } else hi = mid - 1; }
    const runs = [];
    for (let j = end; j >= 0 && runs.length < 40; j--) {
      const e = ev[j];
      if (e.level < 2 && many && e.c !== st.selected) continue;
      if ((e.kind === 'PRODUCED' || (e.kind === 'DIED' && e.k === 'W')) && many && e.c !== st.selected) continue;
      const text = e.kind === 'DIED' && e.killer !== undefined ? m.killText(e) : e.text;
      const lead = e.kind === 'DIED' && e.killer !== undefined ? e.killer : e.c;
      const top = runs[runs.length - 1];
      if (top && top.text === text && top.lead === lead) { top.n++; top.first = j; continue; }
      runs.push({ e, text, lead, n: 1, first: j });
    }
    const list = this.el.feed, nodes = this.feedNodes, seen = new Set();
    if (!runs.length) { nodes.clear(); if (!list.querySelector('.none')) list.replaceChildren(h('li', { class: 'none', text: 'Пока тихо.' })); return; }
    list.querySelector('.none')?.remove();
    const want = runs.map(r => {
      const key = r.first + ':' + r.text; seen.add(key);
      let n = nodes.get(key);
      if (!n) {
        const c = m.colonies.get(r.lead);
        const chip = c ? h('span', { class: 'chip', style: { '--c': c.color }, text: c.sign }) : h('span', { class: 'chip', text: r.e.kind === 'RAID' || r.lead === 0 ? '!' : '•' });
        const cnt = h('span', { class: 'cnt' }), tk = h('span', { class: 'tk' });
        const btn = h('button', { data: { seek: Math.max(0, r.e.i - 2) } }, chip, h('span', { class: 'tx' }, h('span', { text: r.text }), cnt), tk);
        n = { li: h('li', { class: DANGER_KINDS.has(r.e.kind) ? 'danger' : '' }, btn), cnt, tk, btn };
        nodes.set(key, n);
      }
      n.cnt.textContent = r.n > 1 ? ` ×${r.n}` : '';
      n.tk.textContent = String(r.e.t);
      n.btn.dataset.seek = String(Math.max(0, r.e.i - 2));
      n.li.classList.toggle('fresh', i - r.e.i < 8);
      return n.li;
    });
    for (const [k, n] of nodes) if (!seen.has(k)) { n.li.remove(); nodes.delete(k); }
    want.forEach((li, k) => { if (list.children[k] !== li) list.insertBefore(li, list.children[k] || null); });
  }

  // Подпись наверху: что сейчас происходит, по данным, без выдумок.
  caption(i, st) {
    const m = this.m, f = m.frames[i];
    let text = '', sub = '', acc = '#707C82';
    const hs = hotspots(m, i)[0];
    const names = ids => { const list = [...ids].map(id => m.colonies.get(id)?.name).filter(Boolean); return list.length > 2 ? list.slice(0, -1).join(', ') + ' и ' + list.at(-1) : list.join(' и '); };
    const recent = (lvl, span) => { for (let j = m.events.length - 1; j >= 0; j--) { const e = m.events[j]; if (e.i > i) continue; if (i - e.i > span) break; if (e.level >= lvl && e.kind !== 'DIED' && e.kind !== 'FRIENDLY_FIRE') return e; } return null; };
    const big = recent(3, 30), fresh = recent(3, 6);
    const raiders = f.units.some(u => u.k === 'R');
    if (fresh) {
      // разрушение базы или гибель колонии важнее идущего рядом боя
      text = fresh.text; sub = `такт ${fresh.t}`; acc = '#E03A3A';
    } else if (hs && hs.w >= 3) {
      const who = names(hs.cols), withRaid = f.units.some(u => u.k === 'R' && Math.hypot(u.x - hs.x, u.y - hs.y) < 7), one = hs.cols.size === 1;
      text = !who ? (withRaid ? 'Налётчики атакуют' : 'Бой') : one ? (withRaid ? `Налётчики у колонии ${who}` : `${who} ведёт огонь`) : `Бой: ${who}${withRaid ? ' и налётчики' : ''}`;
      const reg = (m.map.regions || []).map(r => ({ r, d: Math.hypot(r.x - hs.x, r.y - hs.y) })).sort((a, b) => a.d - b.d)[0];
      sub = reg && reg.d < 9 ? String(reg.r.name) : '';
      acc = '#E03A3A';
    } else if (big) {
      text = big.text; sub = `такт ${big.t}`; acc = '#E03A3A';
    } else if (raiders) {
      const r = recent(2, 400); text = r && r.kind === 'RAID' ? r.text : 'Налётчики на карте'; acc = '#3A4044';
    } else if (m.finished && i === m.last) {
      const top = m.ranking(i)[0], c = top && m.colonies.get(top.id);
      text = 'Матч окончен'; sub = c ? `побеждает ${c.name}, счёт ${num(top.score)}` : ''; acc = c ? c.color : acc;
    } else if (m.rules.truceTicks && f.t < m.rules.truceTicks) {
      const left = m.rules.truceTicks - f.t;
      text = 'Перемирие'; sub = `ещё ${num(left)} ${plural(left, 'такт', 'такта', 'тактов')}, чужие юниты не мешают`; acc = '#A9B4AE';
    } else {
      const r = m.ranking(i).filter(x => x.alive);
      const a = r[0], b = r[1], c = a && m.colonies.get(a.id);
      if (c && b && a.score > b.score) { text = `Впереди ${c.name}`; sub = `счёт ${num(a.score)}, у следующей ${num(b.score)}`; acc = c.color; }
      else if (c && b) { text = 'Счёт равный'; sub = `${num(a.score)} у первых колоний`; }
      else if (c) { text = c.name; sub = `счёт ${num(a.score)}`; acc = c.color; }
    }
    if (st.liveWait) { text = st.liveWait; sub = ''; acc = '#E8B13A'; }
    const key = text + '|' + sub;
    if (key === this.lastCap) return; this.lastCap = key;
    this.el.capText.textContent = text; this.el.capSub.textContent = sub; this.el.capAcc.style.background = acc;
    if (!st.reduced) { this.el.cap.classList.remove('swap'); void this.el.cap.offsetWidth; this.el.cap.classList.add('swap'); }
  }

  // Метки и плотность боя на шкале. Плотность нейтральная; красные — только разрушения.
  marks(st) {
    const m = this.m, n = m.frames.length;
    const key = n + ':' + st.selected + ':' + this.el.track.clientWidth + ':' + this.total;
    if (this.marksKey === key) return; this.marksKey = key;
    const den = this.total;
    this.el.marks.replaceChildren(...m.moments.filter(x => x.kind !== 'FIGHT' && x.kind !== 'ANNOUNCE').map(x => {
      const cls = DANGER_KINDS.has(x.kind) ? 'big' : x.kind === 'RAID' ? 'raid' : x.kind === 'EVENT_STARTED' ? 'gold' : '';
      return h('span', { class: 'mk ' + cls, title: x.text, style: { left: (x.i / den * 100).toFixed(3) + '%' } });
    }));
    const cv = this.el.density, w = cv.clientWidth, hh = cv.clientHeight, dpr = Math.min(2, devicePixelRatio || 1);
    if (!w) return;
    cv.width = Math.round(w * dpr); cv.height = Math.round(hh * dpr);
    const g = cv.getContext('2d'); g.setTransform(dpr, 0, 0, dpr, 0, 0); g.clearRect(0, 0, w, hh);
    const cols = Math.max(1, Math.floor(w / 2)), bins = new Float32Array(cols), rej = new Float32Array(cols);
    for (let j = 0; j < n; j++) {
      const b = Math.min(cols - 1, Math.floor(j / den * (cols - 1)));
      bins[b] += m.combat[j] || 0;
      if (st.selected != null) { const l = m.frames[j].rejections[String(st.selected)]; if (l) rej[b] += l.length; }
    }
    const max = Math.max(1, ...bins), mid = hh / 2;
    g.fillStyle = 'rgba(255,255,255,.3)';
    for (let b = 0; b < cols; b++) if (bins[b] > 0) { const bh = 2 + Math.sqrt(bins[b] / max) * (mid - 6); g.fillRect(b * 2, mid - 2 - bh, 1.6, bh); }
    if (st.selected != null) { const rmax = Math.max(1, ...rej); for (let b = 0; b < cols; b++) if (rej[b] > 0) { g.fillStyle = `rgba(255,255,255,${0.12 + 0.3 * rej[b] / rmax})`; g.fillRect(b * 2, mid + 5, 1.6, 3); } }
  }

  trackTip(px, frac) {
    const m = this.m, i = Math.min(m.last, Math.round(frac * this.total)), f = m.frames[i]; if (!f) return;
    const near = m.moments.find(x => Math.abs(x.i - i) <= Math.max(1, this.total * 0.006) && x.kind !== 'FIGHT');
    const tip = this.el.trackTip;
    tip.replaceChildren(`такт ${f.t}`, near ? h('small', { text: near.text }) : '');
    tip.style.left = px + 'px'; tip.hidden = false;
  }

  unitTip(u, px, py) {
    const m = this.m, tip = this.el.tip;
    if (!u) { tip.hidden = true; return; }
    const kind = KIND_NAME[u.k] || 'юнит', own = u.c ? `, ${m.name(u.c)}` : '';
    const parts = [`здоровье ${u.hp} из ${u.max}`];
    if (u.k === 'W') parts.push(`груз ${u.carry} из ${m.rules.workerCarry || 20}`);
    tip.replaceChildren(`${kind[0].toUpperCase() + kind.slice(1)} ${u.n ?? u.id}${own}`, h('small', { text: parts.join(', ') }), h('small', { text: `клетка ${Math.round(u.x)}, ${Math.round(u.y)}` }));
    tip.hidden = false;
    const r = tip.getBoundingClientRect();
    tip.style.left = Math.min(innerWidth - r.width - 8, px + 16) + 'px'; tip.style.top = Math.min(innerHeight - r.height - 8, py + 16) + 'px';
  }

  // Карточка выбранного юнита: строится при выборе, дальше меняются только числа.
  card(i, id, at) {
    const m = this.m, el = this.el.card;
    if (id == null) { el.hidden = true; this.cardState = null; return; }
    const f = m.frames[i], u = f.units.find(x => x.id === id);
    let s = this.cardState;
    if (!s || s.id !== id) {
      // кто это — по последнему кадру, где юнит был; ищем один раз при выборе
      let known = u;
      for (let j = i; !known && j >= 0 && j > i - 400; j--) known = m.frames[j].units.find(x => x.id === id);
      const c = known && m.colonies.get(known.c);
      const num = known ? (known.n ?? id) : null;
      const title = known ? `${(KIND_NAME[known.k] || 'юнит').replace(/^./, ch => ch.toUpperCase())} ${num}` : 'Юнит';
      const hp = h('span'), bar = h('i'), carry = h('dd'), cell = h('dd'), gone = h('p', { class: 'gone', hidden: true }), rj = h('ul', { class: 'rj', hidden: true });
      // чей юнит — словами, а не только цветом
      const owner = c ? [h('dt', { text: 'колония' }), h('dd', { text: c.name })] : known && known.k === 'R' ? [h('dt', { text: 'чей' }), h('dd', { text: 'налётчики' })] : [];
      const dl = h('dl', null, ...owner, h('dt', { text: 'здоровье' }), h('dd', null, hp, h('div', { class: 'bar' }, bar)),
        ...(known && known.k === 'W' ? [h('dt', { text: 'груз' }), carry] : []), h('dt', { text: 'клетка' }), cell);
      el.replaceChildren(h('div', { class: 'card-head' }, c ? h('span', { class: 'badge', style: { '--c': c.color }, text: c.sign }) : null, h('b', { text: title }), h('button', { data: { act: 'unpin' }, 'aria-label': 'Закрыть', text: '×' })), dl, gone, rj);
      s = this.cardState = { id, num, hp, bar, carry, cell, gone, rj, dl, pal: c ? c.pal : null, deathT: undefined, rjKey: '' };
    }
    if (!u) {
      if (s.deathT === undefined) { s.deathT = null; for (let j = i; j > 0 && j > i - 400; j--) if (m.frames[j]._deaths.some(d => d.id === id)) { s.deathT = m.frames[j].t; break; } }
      s.dl.hidden = true; s.rj.hidden = true; s.gone.hidden = false;
      s.gone.textContent = s.deathT != null ? `Погиб на такте ${s.deathT}.` : 'Юнита нет на этом такте.';
    } else {
      s.deathT = undefined;
      const max = m.unitMax(u);
      s.dl.hidden = false; s.gone.hidden = true;
      s.hp.textContent = `${u.hp} из ${max}`;
      s.bar.parentElement.style.color = u.hp / max < 0.35 ? 'var(--danger)' : (s.pal ? s.pal.hi : '#ccc');
      s.bar.style.width = clamp(u.hp / max, 0, 1) * 100 + '%';
      s.carry.textContent = `${u.carry} из ${m.rules.workerCarry || 20}`;
      s.cell.textContent = `${u.x}, ${u.y}`;
      const rj = u.c ? (f.rejections[String(u.c)] || []).filter(r => r.unit === (u.n ?? id)).map(r => String(r.text || r.code)) : [];
      const rk = rj.join('|');
      if (rk !== s.rjKey) { s.rjKey = rk; s.rj.replaceChildren(...rj.map(t => h('li', { text: t }))); }
      s.rj.hidden = !rj.length;
    }
    el.hidden = false;
    if (at) { const r = el.getBoundingClientRect(); el.style.left = clamp(at[0] + 18, 8, innerWidth - r.width - 8) + 'px'; el.style.top = clamp(at[1] - r.height / 2, 8, innerHeight - r.height - 8) + 'px'; }
  }

  toast(text) {
    const t = this.el.toast; t.textContent = text; t.hidden = false;
    clearTimeout(this._toast); this._toast = setTimeout(() => { t.hidden = true; }, 2200);
  }
}
