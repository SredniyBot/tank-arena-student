// Стартовый экран: список повторов, вход в живую игру, загрузка и понятные ошибки.
// Имена файлов и карт — данные: в DOM только через textContent.
import { $, h, icon, bytes, when } from './util.js';

const MARK = `<svg width="44" height="44" viewBox="0 0 44 44" aria-hidden="true"><rect width="44" height="44" rx="12" fill="#243036"/>
<path d="M22 7 L30 19 L22 37 L14 19 Z" fill="#E9A912"/><path d="M22 7 L14 19 L22 37 Z" fill="#FFD34D"/><path d="M22 7 L25 15 L22 19 L19 15 Z" fill="#FFF6D6" opacity=".9"/>
<path d="M11 26 L14.5 31 L11 38 L7.5 31 Z" fill="#E9A912" opacity=".85"/><path d="M33 24 L36.5 29.5 L33 37 L29.5 29.5 Z" fill="#E9A912" opacity=".85"/></svg>`;

const el = () => $('#start');
const shell = (...kids) => { const s = el(); s.hidden = false; s.replaceChildren(h('div', { class: 'start-col' }, h('div', { class: 'brand' }, icon(MARK), h('h1', { text: 'Колония' })), ...kids)); };
export const hideStart = () => { el().hidden = true; el().replaceChildren(); };
export const pretty = name => String(name).replace(/\.json(\.gz)?$/i, '');
// Пояснение с именем файла или команды: <code> — отдельным узлом.
const note = (...parts) => h('p', { class: 'note' }, ...parts.map(p => (Array.isArray(p) ? h('code', { text: p[0] }) : p)));

export async function showStart() {
  const liveSlot = h('div'), listSlot = h('div', null, note('Загружаю список…'));
  shell(h('p', { class: 'lead', text: 'Повторы матчей с этого компьютера.' }), liveSlot, listSlot);
  document.title = 'Колония';
  try {
    const live = await fetch('api/live/meta', { cache: 'no-store' });
    if (live.ok && live.status !== 204) {
      const meta = await live.json();
      if (meta && meta.format === 'colony-replay') {
        liveSlot.replaceChildren(h('a', { class: 'live-card', href: '?live=1' }, h('span', { class: 'dot' }), h('b', { text: `Идёт игра${meta.map?.name ? ' на карте ' + meta.map.name : ''}` }), h('span', { text: 'смотреть' })));
      }
    }
  } catch { /* игры нет — и не надо */ }
  let list = [];
  try {
    const r = await fetch('api/replays', { cache: 'no-store' });
    if (!r.ok) throw new Error(String(r.status));
    list = await r.json();
    if (!Array.isArray(list)) throw new Error('не список');
  } catch {
    listSlot.replaceChildren(note('Список повторов недоступен. Просмотр открывают из локальной игры: запустите ', ['Main'], '.'));
    return;
  }
  if (!list.length) {
    listSlot.replaceChildren(note('Повторов пока нет. Запустите ', ['Main'], ': после матча повтор появится в папке ', ['replays'], ' и здесь.'));
    return;
  }
  listSlot.replaceChildren(h('h2', { text: 'Повторы' }), h('ol', { class: 'replays' }, ...list.map(x => {
    const a = h('a', null, h('b', { text: pretty(x.name) }), h('span', { text: when(x.modified) }), h('span', { text: bytes(Number(x.size) || 0) }));
    a.href = '?replay=' + encodeURIComponent(String(x.name));
    return h('li', null, a);
  })));
}

export function showLoading(title) {
  const text = h('p', { text: title }), bar = h('i');
  shell(h('div', { class: 'loading' }, text, h('div', { class: 'bar-line' }, bar)));
  return {
    progress(p) { bar.style.width = Math.round(Math.min(1, p) * 100) + '%'; },
    text(t) { text.textContent = t; },
  };
}

// text — строка или массив частей для note(): ['Main'] станет <code>. Имя файла вставляется как текст.
export function showMessage(title, text, back = true) {
  const parts = Array.isArray(text) ? text : text ? [text] : [];
  shell(h('p', { class: 'lead', text: title }), parts.length ? note(...parts) : null, back ? h('a', { class: 'back', href: './', text: 'К списку повторов' }) : null);
}
