package colony.local;

import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.ByteBuffer;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Stream;

/**
 * Снимок своего кода при зачёте испытания: файлы {@code .java} из {@code src/main/java} как текст, не больше
 * {@link #MAX_BYTES}. Сервер хранит его со своим хэшем; раз в неделю снимки группы сравниваются.
 */
final class Snapshot {

    static final int MAX_BYTES = 200 * 1024;

    /** Файл: путь от {@code src/main/java} через «/» и текст. */
    record File(String path, String text) {}

    private Snapshot() {}

    /** Файлы снимка по порядку пути; {@link IllegalStateException} — исходников нет или они больше 200 КБ. */
    static List<File> collect(Path project) {
        Path root = project.resolve("src/main/java");
        if (!Files.isDirectory(root)) {
            throw new IllegalStateException("нет папки src/main/java");
        }
        List<File> out = new ArrayList<>();
        long bytes = 0;
        try (Stream<Path> walk = Files.walk(root)) {
            for (Path p : walk.filter(Files::isRegularFile).filter(f -> f.getFileName().toString().endsWith(".java"))
                    .sorted().toList()) {
                byte[] raw = Files.readAllBytes(p);
                String text = utf8(raw);
                if (text == null || text.indexOf('\0') >= 0) {
                    continue; // не текст в UTF-8 — не наш исходник
                }
                bytes += raw.length;
                if (bytes > MAX_BYTES) {
                    throw new IllegalStateException("исходники больше " + MAX_BYTES / 1024 + " КБ");
                }
                out.add(new File(root.relativize(p).toString().replace('\\', '/'), text));
            }
        } catch (IOException e) {
            throw new UncheckedIOException("не удалось прочитать src/main/java: " + e.getMessage(), e);
        }
        if (out.isEmpty()) {
            throw new IllegalStateException("в src/main/java нет файлов .java");
        }
        return out;
    }

    private static String utf8(byte[] raw) {
        try {
            return StandardCharsets.UTF_8.newDecoder().onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT).decode(ByteBuffer.wrap(raw)).toString();
        } catch (CharacterCodingException e) {
            return null;
        }
    }
}
