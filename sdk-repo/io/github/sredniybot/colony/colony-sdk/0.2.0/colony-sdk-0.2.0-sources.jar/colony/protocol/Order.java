package colony.protocol;

import colony.api.Building;
import colony.api.Direction;
import colony.api.Orders;
import colony.api.Pos;
import colony.api.UnitType;
import colony.api.Upgrade;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.Objects;

/**
 * Приказ, который колония отдала вне движка: по сети, в журнале приказов. Поля, которые виду приказа не нужны, —
 * {@code null} или 0. Форма для записи — {@link #toMap()}: {@code kind, id, dir, amount, type, x, y, building,
 * upgrade}.
 *
 * <p>Склад — отдельный вид {@link Kind#CONSTRUCT}, а не {@code BUILD} с постройкой: сервер 1.0 не знает поля
 * {@code building} и построил бы вместо склада базу, а незнакомый вид он отклонит.
 */
public record Order(Kind kind, int id, Direction dir, int amount, UnitType type, Pos target, Building building,
                    Upgrade upgrade) {

    public enum Kind { MOVE, HARVEST, TRANSFER, PRODUCE, FIRE, BASE_FIRE, BUILD, ATTACK, CONSTRUCT, DIG, UPGRADE }

    public Order {
        Objects.requireNonNull(kind, "kind");
    }

    /** Приказ без постройки и улучшения. */
    public Order(Kind kind, int id, Direction dir, int amount, UnitType type, Pos target) {
        this(kind, id, dir, amount, type, target, null, null);
    }

    /** Отдать этот приказ настоящему {@link Orders} движка. */
    public void applyTo(Orders o) {
        switch (kind) {
            case MOVE -> o.move(id, dir);
            case HARVEST -> o.harvest(id, dir);
            case TRANSFER -> o.transfer(id, dir, amount);
            case PRODUCE -> o.produce(id, type);
            case FIRE -> o.fire(id, dir);
            case BASE_FIRE -> o.baseFire(id, target);
            case BUILD -> o.build(id, dir);
            case ATTACK -> o.attack(id, dir);
            case CONSTRUCT -> o.build(id, dir, building);
            case DIG -> o.dig(id, dir);
            case UPGRADE -> o.upgrade(id, upgrade);
        }
    }

    /** Поля приказа по порядку, только нужные этому виду. */
    public Map<String, Object> toMap() {
        Map<String, Object> m = new LinkedHashMap<>();
        m.put("kind", kind.name());
        m.put("id", id);
        if (dir != null) {
            m.put("dir", dir.name());
        }
        if (kind == Kind.TRANSFER) {
            m.put("amount", amount);
        }
        if (type != null) {
            m.put("type", type.name());
        }
        if (target != null) {
            m.put("x", target.x());
            m.put("y", target.y());
        }
        if (building != null) {
            m.put("building", building.name());
        }
        if (upgrade != null) {
            m.put("upgrade", upgrade.name());
        }
        return m;
    }

    /**
     * Приказ из полей; лишние поля не мешают.
     *
     * @throws IllegalArgumentException приказ испорчен — в тексте сказано чем
     */
    public static Order fromMap(Map<?, ?> m) {
        Object k = m.get("kind");
        Kind kind = constant(Kind.class, k);
        if (kind == null) {
            throw new IllegalArgumentException("нет такого приказа «" + (k == null ? "" : k) + "»");
        }
        Integer id = integer(m.get("id"));
        if (id == null) {
            throw new IllegalArgumentException("нет номера юнита или базы");
        }
        Direction dir = null;
        int amount = 0;
        UnitType type = null;
        Pos target = null;
        Building building = null;
        Upgrade upgrade = null;
        switch (kind) {
            case MOVE, HARVEST, FIRE, BUILD, ATTACK, CONSTRUCT, DIG, TRANSFER -> {
                dir = constant(Direction.class, m.get("dir"));
                if (dir == null) {
                    throw new IllegalArgumentException("нет направления");
                }
                if (kind == Kind.TRANSFER) {
                    Integer a = integer(m.get("amount"));
                    if (a == null) {
                        throw new IllegalArgumentException("не сказано, сколько передать");
                    }
                    amount = a;
                }
                if (kind == Kind.CONSTRUCT) {
                    building = constant(Building.class, m.get("building"));
                    if (building == null) {
                        throw new IllegalArgumentException("нет такой постройки «" + text(m.get("building")) + "»");
                    }
                }
            }
            case PRODUCE -> {
                type = constant(UnitType.class, m.get("type"));
                if (type == null) {
                    throw new IllegalArgumentException("нет такого юнита «" + text(m.get("type")) + "»");
                }
            }
            case BASE_FIRE -> {
                Integer x = integer(m.get("x"));
                Integer y = integer(m.get("y"));
                if (x == null || y == null) {
                    throw new IllegalArgumentException("нет клетки цели");
                }
                target = new Pos(x, y);
            }
            case UPGRADE -> {
                upgrade = constant(Upgrade.class, m.get("upgrade"));
                if (upgrade == null) {
                    throw new IllegalArgumentException("нет такого улучшения «" + text(m.get("upgrade")) + "»");
                }
            }
        }
        return new Order(kind, id, dir, amount, type, target, building, upgrade);
    }

    private static String text(Object v) {
        return v == null ? "" : String.valueOf(v);
    }

    private static Integer integer(Object v) {
        if (v instanceof Integer || v instanceof Long || v instanceof Short || v instanceof Byte) {
            long n = ((Number) v).longValue();
            return n >= Integer.MIN_VALUE && n <= Integer.MAX_VALUE ? (int) n : null;
        }
        return null;
    }

    private static <E extends Enum<E>> E constant(Class<E> type, Object name) {
        if (!(name instanceof String s)) {
            return null;
        }
        try {
            return Enum.valueOf(type, s);
        } catch (IllegalArgumentException e) {
            return null;
        }
    }
}
