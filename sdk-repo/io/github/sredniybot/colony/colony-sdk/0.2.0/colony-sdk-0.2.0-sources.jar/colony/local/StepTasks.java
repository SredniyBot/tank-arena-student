package colony.local;

import colony.api.Colony;
import colony.engine.MatchConfig;
import colony.homework.Step;
import colony.homework.Steps;
import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.List;
import java.util.function.Supplier;

/**
 * ДЗ «лестница возможностей» из {@code Main} (прототип, ветка {@code demo/homework-abilities}): {@code --task} —
 * шаги, {@code --practice N [--seed S] [--headless]} — тренировка на карте шага, {@code --try N} — попытка у себя:
 * новые карты, итог сразу. Сервер в прототипе не нужен: цель шага — число.
 */
final class StepTasks {

    private static final SecureRandom RANDOM = new SecureRandom();

    private StepTasks() {}

    // ---- Main --task ----

    static int task(Env env) {
        var out = env.out();
        out.println("Домашнее задание «Колония»: пять уровней, за каждый — " + Steps.POINTS + " балла.");
        out.println("Уровень пройден, если на картах попытки вместе сдано не меньше цели.");
        for (Step s : Steps.all()) {
            out.println();
            out.println(s.title() + ": " + s.goalText() + ".");
        }
        out.println();
        out.println("Тренировка: --practice N (просмотр в браузере) или --practice N --headless (итог в консоль); "
                + "та же карта — --seed S. Попытка: --try N — новые карты, итог сразу. Попыток в сутки на уровень — "
                + Steps.ATTEMPTS_PER_DAY + ".");
        return 0;
    }

    // ---- Main --practice ----

    static int practice(Env env, Supplier<Colony> mine, Integer number, Long seed, boolean headless) {
        Step s = Steps.get(number == null ? 1 : number);
        long sd = seed != null ? seed : RANDOM.nextInt(1, 100_000);
        var out = env.out();
        out.println("Тренировка: " + s.label() + ", зерно " + sd + ". В среднем нужно сдать " + s.goal()
                + " энергии за " + s.ticks() + " тактов.");
        int delivered = play(env, s, sd, mine, headless);
        out.println(verdict(s, delivered));
        out.println("Эта же карта ещё раз: --practice " + s.number() + " --seed " + sd + ". Другая — без --seed. "
                + "Попытка (новые карты): --try " + s.number() + ".");
        if (!headless && LocalGame.viewer() != null) {
            out.println("Просмотр открыт, пока работает программа. Остановить — Stop в IntelliJ или Ctrl+C.");
        }
        return 0;
    }

    // ---- Main --try ----

    static int attempt(Env env, Supplier<Colony> mine, Integer number) {
        Step s = Steps.get(number == null ? 1 : number);
        var out = env.out();
        List<Long> seeds = Steps.attemptSeeds(s, () -> RANDOM.nextInt(1, 100_000));
        out.println("Попытка: " + s.label() + ", карты " + seeds + ". Условие: " + s.goalText() + ".");
        List<Integer> delivered = new ArrayList<>();
        int i = 0;
        for (long sd : seeds) {
            i++;
            int d = play(env, s, sd, mine, true);
            delivered.add(d);
            out.println("  карта " + i + " (зерно " + sd + "): " + verdict(s, d));
        }
        Steps.Verdict v = Steps.judge(s, delivered);
        out.println((v.passed() ? "Уровень пройден" : "Уровень не пройден") + ": " + v.detail() + ".");
        out.println("Повторы — в папке replays/; любую карту можно сыграть ещё раз: --practice " + s.number()
                + " --seed S.");
        return 0;
    }

    // ---- общее ----

    private static int play(Env env, Step s, long seed, Supplier<Colony> mine, boolean headless) {
        MatchConfig cfg = Steps.config(s, seed);
        LocalGame.Played p = LocalGame.builder().env(env).me(mine).map(cfg.map()).rules(cfg.rules())
                .script(cfg.script()).seed(seed).quiet(true).headless(headless).alone().play();
        return Steps.played(p.result()).delivered();
    }

    /** Итог одной карты: уровень решает сумма на картах попытки, поэтому здесь — сравнение со средней целью. */
    private static String verdict(Step s, int delivered) {
        return "сдано " + delivered + " (в среднем нужно " + s.goal() + ") — " + (delivered >= s.goal()
                ? "не меньше средней цели ✓." : "меньше средней цели на " + (s.goal() - delivered) + ".");
    }
}
