package colony.protocol;

import colony.api.Pos;
import colony.api.Terrain;
import colony.engine.GameMap;
import colony.engine.RuleSet;
import java.util.ArrayList;
import java.util.List;

/**
 * Неизменная часть матча, которую колония получает при входе: имя карты, размеры, рельеф строками из {@code #}
 * (стена), {@code %} (завал в начале матча) и {@code .} (пол), правила. Мест залежей и баз здесь нет — они в
 * обзоре; сколько осталось от завалов — тоже в обзоре.
 */
public record Board(String name, int width, int height, List<String> terrain, RuleSet rules) {

    public Board {
        terrain = List.copyOf(terrain);
    }

    /** Доска по карте; {@code label} — имя для колонии (у скрытой карты — «карта N»). */
    public static Board of(GameMap map, String label, RuleSet rules) {
        List<String> rows = new ArrayList<>();
        for (int y = 0; y < map.height(); y++) {
            StringBuilder row = new StringBuilder(map.width());
            for (int x = 0; x < map.width(); x++) {
                row.append(switch (map.terrain(new Pos(x, y))) {
                    case WALL -> '#';
                    case RUBBLE -> '%';
                    case FLOOR -> '.';
                });
            }
            rows.add(row.toString());
        }
        return new Board(label, map.width(), map.height(), rows, rules);
    }

    public boolean inside(Pos p) {
        return p != null && p.x() >= 0 && p.y() >= 0 && p.x() < width && p.y() < height;
    }

    /** Рельеф в начале матча; незнакомый знак — пол. */
    public Terrain terrain(Pos p) {
        if (!inside(p)) {
            return Terrain.WALL;
        }
        return switch (terrain.get(p.y()).charAt(p.x())) {
            case '#' -> Terrain.WALL;
            case '%' -> Terrain.RUBBLE;
            default -> Terrain.FLOOR;
        };
    }
}
