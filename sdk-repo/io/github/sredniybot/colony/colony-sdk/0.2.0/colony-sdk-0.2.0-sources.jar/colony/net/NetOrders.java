package colony.net;

import colony.protocol.Order;
import colony.api.Building;
import colony.api.Direction;
import colony.api.Orders;
import colony.api.Pos;
import colony.api.UnitType;
import colony.api.Upgrade;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;

/**
 * Приказы одного такта для отправки на сервер, в порядке вызова. Ведёт себя как приказы локальной игры: пустое
 * направление — {@link NullPointerException} с тем же текстом, после {@link #close()} —
 * {@link IllegalStateException}. Проверяет приказы движок на сервере. Пометки пути ({@link #mark}) не отправляются:
 * на сервере их никто не смотрит, а запрос каждого такта они раздули бы.
 */
public final class NetOrders implements Orders {

    /** Больше приказов за такт не отправляем: тело запроса должно оставаться маленьким. */
    public static final int LIMIT = 1000;

    private final Object lock = new Object();
    private final int tick;
    private final List<Order> orders = new ArrayList<>();
    private int dropped;
    private boolean closed;

    public NetOrders(int tick) {
        this.tick = tick;
    }

    private void add(Order o) {
        synchronized (lock) {
            if (closed) {
                throw new IllegalStateException("приказы такта " + tick
                        + " уже приняты: Orders действует только внутри onTick");
            }
            if (orders.size() < LIMIT) {
                orders.add(o);
            } else {
                dropped++;
            }
        }
    }

    /** Закрыть и отдать приказы в порядке вызова. */
    public List<Order> close() {
        synchronized (lock) {
            closed = true;
            return List.copyOf(orders);
        }
    }

    /** Сколько приказов не поместилось в {@link #LIMIT}. */
    public int dropped() {
        synchronized (lock) {
            return dropped;
        }
    }

    private static Direction dir(Direction d) {
        return Objects.requireNonNull(d, "направление не задано (null)");
    }

    @Override
    public void move(int unitId, Direction d) {
        add(new Order(Order.Kind.MOVE, unitId, dir(d), 0, null, null));
    }

    @Override
    public void harvest(int workerId, Direction d) {
        add(new Order(Order.Kind.HARVEST, workerId, dir(d), 0, null, null));
    }

    @Override
    public void transfer(int unitId, Direction d, int amount) {
        add(new Order(Order.Kind.TRANSFER, unitId, dir(d), amount, null, null));
    }

    @Override
    public void produce(int baseId, UnitType type) {
        Objects.requireNonNull(type, "тип юнита не задан (null)");
        add(new Order(Order.Kind.PRODUCE, baseId, null, 0, type, null));
    }

    @Override
    public void fire(int tankId, Direction d) {
        add(new Order(Order.Kind.FIRE, tankId, dir(d), 0, null, null));
    }

    @Override
    public void baseFire(int baseId, Pos target) {
        Objects.requireNonNull(target, "клетка цели не задана (null)");
        add(new Order(Order.Kind.BASE_FIRE, baseId, null, 0, null, target));
    }

    @Override
    public void build(int workerId, Direction d) {
        add(new Order(Order.Kind.BUILD, workerId, dir(d), 0, null, null));
    }

    @Override
    public void attack(int workerId, Direction d) {
        add(new Order(Order.Kind.ATTACK, workerId, dir(d), 0, null, null));
    }

    @Override
    public void build(int workerId, Direction d, Building type) {
        Direction dd = dir(d);
        Objects.requireNonNull(type, "постройка не задана (null)");
        add(new Order(Order.Kind.CONSTRUCT, workerId, dd, 0, null, null, type, null));
    }

    @Override
    public void dig(int workerId, Direction d) {
        add(new Order(Order.Kind.DIG, workerId, dir(d), 0, null, null));
    }

    @Override
    public void upgrade(int workerId, Upgrade upgrade) {
        Objects.requireNonNull(upgrade, "улучшение не задано (null)");
        add(new Order(Order.Kind.UPGRADE, workerId, null, 0, null, null, null, upgrade));
    }

    /** По сети пометки не идут: просмотр рисует их только в игре у себя. */
    @Override
    public void mark(int unitId, List<Pos> path) {
        synchronized (lock) {
            if (closed) {
                throw new IllegalStateException("приказы такта " + tick
                        + " уже приняты: Orders действует только внутри onTick");
            }
        }
    }

    @Override
    public String toString() {
        return "Orders[такт " + tick + ", сервер]";
    }
}
