// Мини-карта: вся карта всегда видна, когда камера приближена. Щелчок переносит камеру.
import { rgba, DANGER } from './util.js';
import { hotspots } from './scene.js';

export class Minimap {
  constructor(canvas, wrap, match) {
    this.cv = canvas; this.wrap = wrap; this.m = match; this.c = canvas.getContext('2d');
    this.base = document.createElement('canvas');
    this.base.width = match.W; this.base.height = match.H;
    const g = this.base.getContext('2d'), img = g.createImageData(match.W, match.H);
    for (let i = 0; i < match.W * match.H; i++) {
      const wall = match.wall[i], q = i * 4;
      img.data[q] = wall ? 92 : 58; img.data[q + 1] = wall ? 104 : 68; img.data[q + 2] = wall ? 108 : 72; img.data[q + 3] = 255;
    }
    g.putImageData(img, 0, 0);
    this.geom = null;
  }
  layout() {
    const w = this.cv.clientWidth || 160, h = Math.round(w * this.m.H / this.m.W);
    this.cv.style.height = h + 'px';
    const dpr = Math.min(2, devicePixelRatio || 1);
    this.cv.width = Math.round(w * dpr); this.cv.height = Math.round(h * dpr);
    this.c.setTransform(dpr, 0, 0, dpr, 0, 0);
    this.geom = { w, h, s: w / this.m.W };
  }
  render(S, quad) {
    if (!this.geom) this.layout();
    const { w, h, s } = this.geom, c = this.c, m = this.m;
    c.imageSmoothingEnabled = false; c.drawImage(this.base, 0, 0, w, h); c.imageSmoothingEnabled = true;
    for (const b of S.frame.bases) { c.fillStyle = rgba(m.pal(b.c).m, 0.35); c.beginPath(); c.arc((b.x + 0.5) * s, (b.y + 0.5) * s, 4.6 * s, 0, Math.PI * 2); c.fill(); }
    for (const b of S.frame.bases) { c.fillStyle = m.pal(b.c).m; c.fillRect((b.x - 0.6) * s, (b.y - 0.6) * s, 2.2 * s, 2.2 * s); c.strokeStyle = '#fff'; c.lineWidth = 1; c.strokeRect((b.x - 0.6) * s, (b.y - 0.6) * s, 2.2 * s, 2.2 * s); }
    for (const u of S.units) {
      if (u.alpha < 0.5) continue;
      c.fillStyle = u.k === 'R' ? DANGER : m.pal(u.c).l;
      const r = u.k === 'W' ? 0.8 : 1.6;
      c.fillRect((u.x + 0.5) * s - r, (u.y + 0.5) * s - r, r * 2, r * 2);
    }
    for (const hs of hotspots(m, S.a)) { if (hs.w < 3) break; c.strokeStyle = rgba('#FF7468', 0.9); c.lineWidth = 1.5; c.beginPath(); c.arc(hs.x * s, hs.y * s, Math.max(5, 3 * s), 0, Math.PI * 2); c.stroke(); }
    if (quad) {
      c.strokeStyle = '#fff'; c.lineWidth = 1.5; c.beginPath();
      quad.forEach(([x, y], i) => (i ? c.lineTo(x * s, y * s) : c.moveTo(x * s, y * s))); c.closePath(); c.stroke();
    }
  }
  toWorld(px, py) { const r = this.cv.getBoundingClientRect(), s = this.geom.s; return [(px - r.left) / s, (py - r.top) / s]; }
}
