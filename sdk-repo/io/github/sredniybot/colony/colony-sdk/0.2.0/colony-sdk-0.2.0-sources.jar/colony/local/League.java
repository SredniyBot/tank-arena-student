package colony.local;

import colony.engine.RuleSet;
import colony.engine.MapLoader;
import colony.engine.RulesLoader;
import java.util.List;

/**
 * Лига студента: правила, карты и босс. Лигу задаёт {@code league=N} в {@code colony.properties} (по умолчанию 1)
 * или {@code --league=N}; на сервере класса — журнал лиг преподавателя. Один каталог лиг и для SDK, и для сервера.
 *
 * @param number номер, 1…{@link RulesLoader#LEAGUES}
 */
public record League(int number) {

    static final int DEFAULT = 1;

    /** Проверка босса: три матча по столько тактов — и на сервере (такт 250 мс, около 8 минут), и локально. */
    public static final int BOSS_TICKS = 600;

    private static final List<String> TITLES = List.of("Добыча", "Стены", "Соседи", "Центр", "Танки");
    private static final List<String> BOSSES = List.of("bronze", "silver", "gold", "platinum", "diamond");

    public League {
        if (number < 1 || number > RulesLoader.LEAGUES) {
            throw new IllegalArgumentException("лиги " + number + " нет: есть 1–" + RulesLoader.LEAGUES);
        }
    }

    /** «Лига 3 «Соседи»». */
    public String title() {
        return "Лига " + number + " «" + TITLES.get(number - 1) + "»";
    }

    public RuleSet rules() {
        return RulesLoader.league(number);
    }

    /** Три карты проверки босса; первая — тренировочная. */
    public List<String> duels() {
        return MapLoader.leagueDuels(number);
    }

    public String trainingMap() {
        return duels().get(0);
    }

    /** Босс лиги: {@code bronze} … {@code diamond}. */
    public String boss() {
        return BOSSES.get(number - 1);
    }

    /** Боссы лиг с первой по эту — лестница. */
    public List<String> ladder() {
        return BOSSES.subList(0, number);
    }

    public static boolean isBoss(String id) {
        return BOSSES.contains(id);
    }

    public static List<String> bosses() {
        return BOSSES;
    }
}
