package colony.local;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.core.util.DefaultIndenter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.nio.channels.FileChannel;
import java.nio.channels.FileLock;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.FileSystemException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.ArrayList;
import java.util.List;

/**
 * {@code ladder-results.json} в папке проекта: массив результатов лестницы. Файл только дописывается; его видит
 * преподаватель в репозитории студента.
 */
public final class LadderResults {

    /** Имя файла в папке проекта. */
    public static final String FILE = "ladder-results.json";

    private static final ObjectMapper JSON = new ObjectMapper();
    /** Блокировка файла — между программами; внутри одной программы — этот замок. */
    private static final Object JVM_LOCK = new Object();
    private static final int MOVE_ATTEMPTS = 4;
    private static final long MOVE_PAUSE_MILLIS = 100;
    /** Отступы и переводы строк одинаковые на Windows и Linux: в git видно только дописанное. */
    private static final DefaultPrettyPrinter PRETTY = new DefaultPrettyPrinter()
            .withObjectIndenter(new DefaultIndenter("  ", "\n"))
            .withArrayIndenter(new DefaultIndenter("  ", "\n"));

    /**
     * Один матч лестницы.
     *
     * @param time       когда запущена лестница, ISO-8601 с часовым поясом
     * @param opponent   {@code bronze} или {@code silver}
     * @param map        карта
     * @param seed       зерно
     * @param place      место своей колонии
     * @param score      счёт своей колонии
     * @param sdkVersion версия SDK
     * @param commit     короткий хеш коммита, с {@code -dirty} при незакоммиченных правках; {@code null} — не git
     */
    public record Entry(String time, String opponent, String map, long seed, int place, int score, String sdkVersion,
                        String commit) {

        ObjectNode toJson() {
            ObjectNode o = JSON.createObjectNode();
            o.put("time", time).put("opponent", opponent).put("map", map).put("seed", seed).put("place", place)
                    .put("score", score).put("sdkVersion", sdkVersion);
            if (commit == null) {
                o.putNull("commit");
            } else {
                o.put("commit", commit);
            }
            return o;
        }

        static Entry fromJson(JsonNode n) {
            return new Entry(n.path("time").asText(""), n.path("opponent").asText(""), n.path("map").asText(""),
                    n.path("seed").asLong(), n.path("place").asInt(), n.path("score").asInt(),
                    n.path("sdkVersion").asText(""), n.path("commit").isTextual() ? n.path("commit").asText() : null);
        }
    }

    private LadderResults() {}

    /** Все записи; файла нет — пусто. */
    public static List<Entry> read(Path file) {
        if (!Files.exists(file)) {
            return List.of();
        }
        List<Entry> list = new ArrayList<>();
        for (JsonNode n : readArray(file)) {
            list.add(Entry.fromJson(n));
        }
        return list;
    }

    /**
     * Дописать записи в конец. Старые записи остаются как есть. Два запуска сразу не теряют записей друг друга:
     * чтение и запись идут под блокировкой файла {@code ladder-results.json.lock}, запись — через свой временный
     * файл и переименование (на Windows — с повтором, если файл ненадолго занят антивирусом или индексатором).
     *
     * @throws IllegalStateException файл испорчен — его не трогаем
     * @throws UncheckedIOException  записать не удалось; в сообщении — записи этого запуска, чтобы не пропали
     */
    public static void append(Path file, List<Entry> entries) {
        Path dir = file.toAbsolutePath().getParent();
        synchronized (JVM_LOCK) {
            try (FileChannel channel = FileChannel.open(dir.resolve(file.getFileName() + ".lock"),
                    StandardOpenOption.CREATE, StandardOpenOption.WRITE);
                 FileLock lock = channel.lock()) {
                ArrayNode all = Files.exists(file) ? readArray(file) : JSON.createArrayNode();
                entries.forEach(e -> all.add(e.toJson()));
                Path tmp = Files.createTempFile(dir, "ladder-results", ".tmp");
                try {
                    Files.writeString(tmp, JSON.writer(PRETTY).writeValueAsString(all) + "\n");
                    moveWithRetry(tmp, file);
                } finally {
                    Files.deleteIfExists(tmp);
                }
            } catch (IOException e) {
                ArrayNode mine = JSON.createArrayNode();
                entries.forEach(en -> mine.add(en.toJson()));
                throw new UncheckedIOException("не удалось записать " + file.getFileName() + " (" + e.getMessage()
                        + "). Результаты этого запуска: " + mine, e);
            }
        }
    }

    private static void moveWithRetry(Path from, Path to) throws IOException {
        for (int attempt = 1; ; attempt++) {
            try {
                try {
                    Files.move(from, to, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException e) {
                    Files.move(from, to, StandardCopyOption.REPLACE_EXISTING);
                }
                return;
            } catch (FileSystemException e) {
                if (attempt >= MOVE_ATTEMPTS) {
                    throw e;
                }
                try {
                    Thread.sleep(MOVE_PAUSE_MILLIS);
                } catch (InterruptedException ie) {
                    Thread.currentThread().interrupt();
                    throw e;
                }
            }
        }
    }

    private static ArrayNode readArray(Path file) {
        try {
            JsonNode n = JSON.readTree(file.toFile());
            if (n == null || n.isMissingNode()) {
                return JSON.createArrayNode();
            }
            if (!n.isArray()) {
                throw new IllegalStateException(file.getFileName() + " испорчен: ждали массив [...]. "
                        + "Верните файл из git (git checkout -- " + FILE + ") и запустите лестницу снова.");
            }
            return (ArrayNode) n;
        } catch (JsonProcessingException e) {
            throw new IllegalStateException(file.getFileName() + " испорчен: " + e.getOriginalMessage()
                    + ". Верните файл из git (git checkout -- " + FILE + ") и запустите лестницу снова.", e);
        } catch (IOException e) {
            throw new UncheckedIOException("не удалось прочитать " + file, e);
        }
    }

    /**
     * Короткий хеш текущего коммита; {@code -dirty}, если в отслеживаемых файлах проекта есть незакоммиченные
     * правки (кроме самого {@code ladder-results.json}); {@code null} — не репозиторий git или git нет.
     */
    static String commit(Path dir) {
        Git.Result head = Git.run(dir, 10, "rev-parse", "--short", "HEAD");
        String hash = head.out().strip();
        if (!head.ok() || !hash.matches("[0-9a-f]{4,64}")) {
            return null;
        }
        Git.Result diff = Git.run(dir, 10, "diff", "--quiet", "HEAD", "--", ".", ":(exclude)" + FILE);
        return diff.code() == 1 ? hash + "-dirty" : hash;
    }
}
