package colony.local;

import java.net.URL;
import java.net.URLClassLoader;

/**
 * Загрузчик кода студента: свои классы (из {@code urls}) — раньше родителя. Так у каждого матча свои static-поля,
 * а у прошлой версии — свои классы, даже если в classpath лежат текущие с теми же именами. JDK и {@code colony.*}
 * (API, движок, SDK) всегда берутся у родителя: колония и движок должны видеть одни и те же типы.
 */
final class ChildFirstLoader extends URLClassLoader {

    ChildFirstLoader(String name, URL[] urls, ClassLoader parent) {
        super(name, urls, parent);
    }

    @Override
    protected Class<?> loadClass(String name, boolean resolve) throws ClassNotFoundException {
        synchronized (getClassLoadingLock(name)) {
            Class<?> c = findLoadedClass(name);
            if (c == null && !shared(name)) {
                try {
                    c = findClass(name);
                } catch (ClassNotFoundException e) {
                    // нет в своих — возьмём у родителя
                }
            }
            if (c == null) {
                return super.loadClass(name, resolve);
            }
            if (resolve) {
                resolveClass(c);
            }
            return c;
        }
    }

    private static boolean shared(String name) {
        return name.startsWith("java.") || name.startsWith("javax.") || name.startsWith("jdk.")
                || name.startsWith("sun.") || name.startsWith("colony.");
    }
}
