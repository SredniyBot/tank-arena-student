package colony.bots;

import colony.api.ColonyView;

/**
 * «Платина» — босс лиги 4. Как «золото», но трое рабочих держат центр: встают у центральной жилы, добывают её и бьют
 * чужих рядом. Если чужих в зоне заметно больше, отряд отходит к базе и возвращается позже.
 */
public final class Platinum extends LeagueBoss {

    public Platinum() {
        this(1);
    }

    public Platinum(long seed) {
        super(seed);
    }

    @Override
    int guards(ColonyView view, int workers) {
        return 2;
    }

    @Override
    int holders(ColonyView view, int workers) {
        return workers >= 4 ? 3 : 0;
    }
}
