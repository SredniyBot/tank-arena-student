// Светлая 2D-сцена: стол, поле, залежи, базы, юниты, снаряды, следы.
// Слои по важности: бой → юниты → базы → ресурсы → местность. Местность спокойная и не спорит с игрой.
// Колония видна не только цветом: знак на базе, на метке армии и над танками в бою.
import { clamp, easeOut, rgba, clip, clipName, shortName, DANGER, ENERGY, NEUTRAL } from './util.js';
import { paintBoard, GROUND } from './board.js';
import { hotspots } from './scene.js';

const FONT = '"Onest", system-ui, -apple-system, "Segoe UI", sans-serif';
const INK = '#1C2328';
export const BASE_GLOW = 4.6; // радиус мягкого пятна вокруг базы, клеток

export class Renderer2D {
  constructor(canvas, match, cam) {
    this.cv = canvas; this.c = canvas.getContext('2d');
    this.m = match; this.cam = cam;
    this.board = paintBoard(match);
    this.W = 1; this.H = 1; this.dpr = 1; this.labelPx = 15;
    this.last = null; this.sprites = new Map();
  }
  resize(W, H, dpr, labelPx) {
    this.W = W; this.H = H; this.dpr = dpr; this.labelPx = labelPx; this.sprites = new Map();
    this.cv.width = Math.round(W * dpr); this.cv.height = Math.round(H * dpr);
    const g = this.c.createLinearGradient(0, 0, W, H);
    g.addColorStop(0, '#CBD3C6'); g.addColorStop(1, '#B4BDB0');
    this.table = g;
  }
  // размеры по старшинству: база > танк > рабочий; на общем плане 1280 — не меньше 18–20 px
  sizes() {
    const s = this.cam.s;
    return { ws: Math.max(14, s * 0.8), ts: Math.max(19, s * 1.06), rs: Math.max(17, s * 0.96), bs: Math.max(30, s * 1.5) };
  }

  render(S, o) {
    const c = this.c, cam = this.cam, m = this.m, s = cam.s, lod = cam.lod();
    const [fx, fy] = cam.focus();
    const X = x => fx + (x - cam.cx) * s, Y = y => fy + (y - cam.cy) * s;
    this.X = X; this.Y = Y; this.lod = lod; this.last = S;
    const dim = col => (o.hoverCol && col !== o.hoverCol ? 0.3 : 1);
    c.setTransform(this.dpr, 0, 0, this.dpr, 0, 0);
    c.imageSmoothingEnabled = true;

    // стол и поле; тень подставки — несколько полупрозрачных слоёв вместо дорогого размытия
    c.fillStyle = this.table; c.fillRect(0, 0, this.W, this.H);
    const bx = X(0), by = Y(0), bw = m.W * s, bh = m.H * s, br = Math.min(s * 0.9, 16);
    for (const [d, a] of [[16, 0.05], [9, 0.07], [4, 0.09]]) { c.fillStyle = `rgba(28,44,34,${a})`; c.beginPath(); c.roundRect(bx - d * 0.3, by + d * 0.45, bw + d * 0.6, bh + d * 0.3, br + d * 0.5); c.fill(); }
    c.fillStyle = GROUND; c.beginPath(); c.roundRect(bx, by, bw, bh, br); c.fill();
    c.save(); c.beginPath(); c.roundRect(bx, by, bw, bh, br); c.clip();
    const x0 = clamp(-bx / s, 0, m.W), y0 = clamp(-by / s, 0, m.H), x1 = clamp((this.W - bx) / s, 0, m.W), y1 = clamp((this.H - by) / s, 0, m.H);
    const ppc = this.board.ppc;
    if (x1 > x0 && y1 > y0) c.drawImage(this.board.canvas, x0 * ppc, y0 * ppc, (x1 - x0) * ppc, (y1 - y0) * ppc, X(x0), Y(y0), (x1 - x0) * s, (y1 - y0) * s);

    // мягкое пятно цвета колонии вокруг базы, без контура: это не правило игры, а «чей это угол»
    for (const b of S.frame.bases) {
      const x = X(b.x + 0.5), y = Y(b.y + 0.5), r = BASE_GLOW * s, g = c.createRadialGradient(x, y, r * 0.15, x, y, r);
      g.addColorStop(0, rgba(m.pal(b.c).m, 0.2 * dim(b.c))); g.addColorStop(1, rgba(m.pal(b.c).m, 0));
      c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
    }

    if (s > 44) this.grid(x0, y0, x1, y1);
    if (x1 > x0 && y1 > y0) c.drawImage(this.board.walls, x0 * ppc, y0 * ppc, (x1 - x0) * ppc, (y1 - y0) * ppc, X(x0), Y(y0), (x1 - x0) * s, (y1 - y0) * s);
    this.regions(lod);
    c.restore();
    c.strokeStyle = 'rgba(255,255,255,.5)'; c.lineWidth = 1.5; c.beginPath(); c.roundRect(bx + 0.75, by + 0.75, bw - 1.5, bh - 1.5, br); c.stroke();

    this.rubble(S);
    this.digs(S, lod);
    this.scorches(S);
    this.centreHolder(S);
    this.deposits(S, lod);
    this.ruins(S, lod);
    this.depots(S, lod, dim);
    this.bases(S, lod, dim);
    if (lod === 'far') this.farUnits(S, dim, o); else this.units(S, lod, dim, o);
    this.paths(S);
    this.deathTraces(S, lod, o);
    this.flows(S, lod);
    this.shots(S);
    this.effects(S, lod, o);
    this.marks(S);
    if (lod === 'far') this.fights(S);
    this.pops(S, lod);
    this.labels(S, lod, dim);
    if (lod !== 'far') this.tags(S, dim);
  }

  grid(x0, y0, x1, y1) {
    const c = this.c, X = this.X, Y = this.Y;
    c.strokeStyle = 'rgba(58,74,60,.07)'; c.lineWidth = 1; c.beginPath();
    for (let x = Math.ceil(x0); x <= x1; x++) { c.moveTo(Math.round(X(x)) + 0.5, Y(y0)); c.lineTo(Math.round(X(x)) + 0.5, Y(y1)); }
    for (let y = Math.ceil(y0); y <= y1; y++) { c.moveTo(X(x0), Math.round(Y(y)) + 0.5); c.lineTo(X(x1), Math.round(Y(y)) + 0.5); }
    c.stroke();
  }

  // Названия мест: на общем плане не мельче подписей баз; если не помещаются — прячем, а не уменьшаем.
  regions(lod) {
    const c = this.c, s = this.cam.s, regs = this.m.map.regions || [];
    if (!regs.length || s < 8) return;
    const px = Math.max(this.labelPx, Math.min(24, s * 0.62));
    c.font = `600 ${px}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
    c.fillStyle = lod === 'near' ? 'rgba(52,66,54,.3)' : 'rgba(52,66,54,.46)';
    const f0 = this.m.frames[0], busy = (x, y) => f0.deposits.some(d => Math.abs(d.x - x) <= 1 && Math.abs(d.y - y) <= 1) || f0.bases.some(b => Math.abs(b.x - x) <= 1 && Math.abs(b.y - y) <= 1) || this.m.isWall(x, y);
    // имя места не прячем под кристаллами и базой: если точка занята, пишем под ней
    for (const r of regs) { const x = Number(r.x), y = Number(r.y), dy = busy(x, y) ? 1.25 + px / s * 0.5 : 0; c.fillText(clip(r.name, 24), this.X(x + 0.5), this.Y(y + 0.5 + dy) + (dy ? px * 0.2 : 0)); }
  }

  // Обвал (шаг «Устойчивость» ДЗ): клетки, закрытые посреди матча, — камень поверх поля
  rubble(S) {
    const c = this.c, s = this.cam.s, X = this.X, Y = this.Y, r = Math.min(s * 0.25, 8);
    for (const p of S.frame.closed || []) {
      const x = X(p[0]), y = Y(p[1]);
      c.fillStyle = '#7C887A'; c.beginPath(); c.roundRect(x + s * 0.04, y + s * 0.12, s * 0.92, s * 0.88, r); c.fill();
      c.fillStyle = '#A9B3A4'; c.beginPath(); c.roundRect(x + s * 0.04, y + s * 0.02, s * 0.92, s * 0.82, r); c.fill();
      c.strokeStyle = 'rgba(58,52,42,.55)'; c.lineWidth = Math.max(1, s * 0.05); c.beginPath();
      c.moveTo(x + s * 0.25, y + s * 0.3); c.lineTo(x + s * 0.5, y + s * 0.55); c.lineTo(x + s * 0.75, y + s * 0.35); c.stroke();
    }
  }

  // Завалы (ДЗ «лестница возможностей»): клетка-завал с остатком прочности; разобранный — пол, его не рисуем
  digs(S, lod) {
    const c = this.c, s = this.cam.s, X = this.X, Y = this.Y, r = Math.min(s * 0.22, 7);
    for (const p of S.frame.rubble || []) {
      const left = p[2]; if (!(left > 0)) continue;
      const x = X(p[0]), y = Y(p[1]);
      c.fillStyle = '#8E7A62'; c.beginPath(); c.roundRect(x + s * 0.03, y + s * 0.1, s * 0.94, s * 0.86, r); c.fill();
      c.fillStyle = '#B9A68C'; c.beginPath(); c.roundRect(x + s * 0.03, y + s * 0.03, s * 0.94, s * 0.8, r); c.fill();
      c.fillStyle = '#9C8770';
      for (const [ox, oy, rr] of [[0.3, 0.32, 0.13], [0.66, 0.28, 0.11], [0.5, 0.6, 0.15], [0.24, 0.66, 0.09], [0.76, 0.64, 0.1]]) { c.beginPath(); c.arc(x + s * ox, y + s * oy, s * rr, 0, Math.PI * 2); c.fill(); }
      // остаток прочности — вблизи
      if (s >= 14 && lod !== 'far') {
        c.font = `700 ${clamp(s * 0.36, 10, 16)}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
        c.lineJoin = 'round'; c.lineWidth = 3; c.strokeStyle = 'rgba(245,240,230,.9)'; c.strokeText(String(left), x + s * 0.5, y + s * 0.47);
        c.fillStyle = '#4A3A28'; c.fillText(String(left), x + s * 0.5, y + s * 0.47);
      }
    }
  }

  // Пометки пути (orders.mark): пунктир цвета колонии от юнита через клетки, которые колония задумала
  paths(S) {
    const P = S.frame.paths; if (!P) return;
    const c = this.c, s = this.cam.s, X = this.X, Y = this.Y;
    for (const [id, cells] of Object.entries(P)) {
      const u = S.units.find(v => String(v.id) === id); if (!u || !cells.length) continue;
      c.strokeStyle = rgba(this.m.pal(u.c).d, 0.75); c.lineWidth = Math.max(1.5, s * 0.08); c.setLineDash([Math.max(3, s * 0.2), Math.max(3, s * 0.15)]);
      c.beginPath(); c.moveTo(X(u.x + 0.5), Y(u.y + 0.5));
      for (const p of cells) c.lineTo(X(p[0] + 0.5), Y(p[1] + 0.5));
      c.stroke(); c.setLineDash([]);
      const e = cells[cells.length - 1];
      c.fillStyle = rgba(this.m.pal(u.c).d, 0.75); c.beginPath(); c.arc(X(e[0] + 0.5), Y(e[1] + 0.5), Math.max(2.5, s * 0.12), 0, Math.PI * 2); c.fill();
    }
  }

  // Склады: квадрат цвета колонии с ящиком; меньше базы
  depots(S, lod, dim) {
    const c = this.c, m = this.m, s = this.cam.s, X = this.X, Y = this.Y, z = Math.max(14, s * 0.92);
    for (const st of S.frame.structures || []) {
      const pal = m.pal(st.c), x = X(st.x + 0.5), y = Y(st.y + 0.5);
      c.globalAlpha = dim(st.c);
      c.fillStyle = 'rgba(30,45,35,.28)'; rr(c, x - z / 2 + z * 0.06, y - z / 2 + z * 0.1, z, z, z * 0.2); c.fill();
      c.fillStyle = '#F2EEE4'; rr(c, x - z / 2, y - z / 2, z, z, z * 0.2); c.fill();
      c.strokeStyle = rgba(pal.d, 0.8); c.lineWidth = Math.max(1.5, z * 0.08); c.stroke();
      c.fillStyle = pal.m; rr(c, x - z * 0.28, y - z * 0.2, z * 0.56, z * 0.44, z * 0.06); c.fill();
      c.strokeStyle = 'rgba(255,255,255,.75)'; c.lineWidth = Math.max(1, z * 0.05); c.beginPath();
      c.moveTo(x - z * 0.28, y + z * 0.02); c.lineTo(x + z * 0.28, y + z * 0.02); c.moveTo(x, y - z * 0.2); c.lineTo(x, y + z * 0.24); c.stroke();
      c.globalAlpha = 1;
    }
  }

  scorches(S) {
    const c = this.c, s = this.cam.s, X = this.X, Y = this.Y;
    for (const d of S.deaths) {
      const a = 0.28 * clamp(1 - d.age / 12, 0, 1); if (a <= 0) continue;
      c.fillStyle = `rgba(58,52,42,${a})`; c.beginPath(); c.ellipse(X(d.x + 0.5), Y(d.y + 0.55), s * 0.62, s * 0.44, 0.3, 0, Math.PI * 2); c.fill();
    }
  }

  deposits(S, lod) {
    const c = this.c, s = this.cam.s, m = this.m, X = this.X, Y = this.Y;
    for (const d of S.frame.deposits) {
      const x = X(d.x + 0.5), y = Y(d.y + 0.5), home = d.kind === 'HOME';
      const max = m.depMax.get(d.id) || d.amount || 1, frac = home ? 1 : clamp(d.amount / max, 0, 1);
      const spec = DEP[d.kind] || DEP.NORMAL, u = Math.max(lod === 'far' ? 3.2 : 5, s) * spec.k;
      if (home) {
        const pal = m.pal(m.homeOwner.get(d.id));
        c.fillStyle = rgba(pal.l, 0.9); c.beginPath(); c.arc(x, y, Math.max(5, s * 0.5), 0, Math.PI * 2); c.fill();
        c.strokeStyle = rgba(pal.d, 0.6); c.lineWidth = Math.max(1.2, s * 0.05); c.stroke();
      } else if (frac > 0.02 && lod !== 'far') {
        const R = u * (d.kind === 'CENTER' ? 1.9 : 1.5), g = c.createRadialGradient(x, y, 0, x, y, R);
        g.addColorStop(0, `rgba(255,206,70,${0.24 * frac + 0.06})`); g.addColorStop(1, 'rgba(255,206,70,0)');
        c.fillStyle = g; c.beginPath(); c.arc(x, y, R, 0, Math.PI * 2); c.fill();
      }
      if (d.kind === 'LOOT') { c.fillStyle = 'rgba(70,62,48,.22)'; c.beginPath(); c.ellipse(x, y + u * 0.15, u * 0.7, u * 0.4, 0, 0, Math.PI * 2); c.fill(); }
      c.fillStyle = 'rgba(60,72,48,.22)'; c.beginPath(); c.ellipse(x + u * 0.06, y + u * 0.32, u * spec.base, u * spec.base * 0.34, 0, 0, Math.PI * 2); c.fill();
      const set = spec.set, lit = home ? set.length : Math.round(frac * set.length);
      const order = [...set.keys()].sort((p, q) => set[p][1] - set[q][1]);
      for (const i of order) { const [ox, oy, hh] = set[i]; crystal(c, x + ox * u, y + oy * u, hh * u, i < lit, d.kind === 'LOOT'); }
      // количество — только вблизи и только у непустых
      if (s >= 48 && !home && d.amount > 0) {
        c.font = `600 ${clamp(s * 0.3, 12, 16)}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'top';
        c.lineJoin = 'round'; c.lineWidth = 3; c.strokeStyle = 'rgba(236,240,230,.9)'; c.strokeText(String(d.amount), x, y + u * 0.55);
        c.fillStyle = 'rgba(92,70,10,.95)'; c.fillText(String(d.amount), x, y + u * 0.55);
      }
    }
  }

  ruins(S, lod) {
    const c = this.c, X = this.X, Y = this.Y, { bs } = this.sizes();
    for (const r of S.ruins) {
      const x = X(r.x + 0.5), y = Y(r.y + 0.5);
      c.fillStyle = 'rgba(58,52,44,.3)'; c.beginPath(); c.ellipse(x, y + bs * 0.1, bs * 0.85, bs * 0.62, 0, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#B4BAB1'; c.beginPath(); c.moveTo(x - bs * 0.42, y + bs * 0.36); c.lineTo(x - bs * 0.42, y - bs * 0.08); c.lineTo(x - bs * 0.1, y - bs * 0.38); c.lineTo(x + bs * 0.05, y - bs * 0.05); c.lineTo(x + bs * 0.28, y - bs * 0.28); c.lineTo(x + bs * 0.42, y + bs * 0.36); c.closePath(); c.fill();
      c.strokeStyle = 'rgba(28,35,40,.55)'; c.lineWidth = 1.4; c.stroke();
      c.fillStyle = rgba(this.m.pal(r.c).m, 0.6); c.fillRect(x - bs * 0.3, y + bs * 0.1, bs * 0.28, bs * 0.16);
    }
  }

  bases(S, lod, dim) {
    const c = this.c, m = this.m, X = this.X, Y = this.Y, { bs } = this.sizes();
    for (const b of S.frame.bases) {
      const col = m.colonies.get(b.c), pal = m.pal(b.c), x = X(b.x + 0.5), y = Y(b.y + 0.5);
      c.globalAlpha = dim(b.c);
      c.fillStyle = 'rgba(30,45,35,.3)'; rr(c, x - bs / 2 + bs * 0.07, y - bs / 2 + bs * 0.13, bs, bs, bs * 0.26); c.fill();
      c.fillStyle = '#F7F8F4'; rr(c, x - bs / 2, y - bs / 2, bs, bs, bs * 0.26); c.fill();
      c.strokeStyle = 'rgba(28,35,40,.55)'; c.lineWidth = 1.5; c.stroke();
      c.fillStyle = '#DFE4DC'; rr(c, x - bs / 2 + 0.75, y + bs * 0.3, bs - 1.5, bs * 0.2 - 0.75, [0, 0, bs * 0.26, bs * 0.26]); c.fill();
      const g = c.createLinearGradient(x, y - bs * 0.34, x, y + bs * 0.26); g.addColorStop(0, pal.hi); g.addColorStop(1, pal.m);
      c.fillStyle = g; rr(c, x - bs * 0.36, y - bs * 0.37, bs * 0.72, bs * 0.62, bs * 0.15); c.fill();
      // знак на крыше дублирует плашку с именем; мелким не рисуем (на проекторе — не мельче 18 px)
      const sp = Math.round(bs * 0.32);
      if (col && sp >= Math.max(10, this.labelPx * 0.9)) {
        c.fillStyle = '#fff'; c.font = `700 ${sp}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
        c.fillText(col.sign, x, y - bs * 0.05);
      }
      // цена рабочего — на базе: сколько энергии нужно на нового
      const cost = m.rules.workerCost, cp = Math.round(Math.max(11, bs * 0.26));
      if (cost && lod !== 'far') {
        c.font = `700 ${cp}px ${FONT}`; c.textAlign = 'left'; c.textBaseline = 'middle';
        const tx = x + bs * 0.52, ty = y - bs * 0.46, tw = c.measureText(String(cost)).width + cp * 0.9;
        c.fillStyle = 'rgba(92,70,10,.92)'; rr(c, tx - cp * 0.15, ty - cp * 0.62, tw, cp * 1.24, cp * 0.4); c.fill();
        c.fillStyle = '#FFE08A'; c.fillText(String(cost), tx + cp * 0.3, ty + 0.5);
      }
      const max = m.baseMax(), f = clamp(b.hp / max, 0, 1);
      if (f < 0.999) {
        const w = bs * 1.05, yy = y + bs * 0.62;
        c.fillStyle = 'rgba(28,36,32,.4)'; rr(c, x - w / 2, yy, w, 5, 2.5); c.fill();
        c.fillStyle = f < 0.35 ? DANGER : pal.m; rr(c, x - w / 2, yy, Math.max(2, w * f), 5, 2.5); c.fill();
      }
      c.globalAlpha = 1;
    }
  }

  units(S, lod, dim, o) {
    const c = this.c, m = this.m, X = this.X, Y = this.Y, { ws, ts, rs } = this.sizes();
    const all = S.units.concat(S.dying), d = this.dpr;
    // юниты — готовые спрайты: 480 юнитов укладываются в кадр и на слабом ноутбуке
    for (const pass of ['W', 'R', 'T']) for (const u of all) {
      if (u.k !== pass || u.alpha <= 0.01) continue;
      const pal = m.pal(u.c), x = X(u.x + 0.5), y = Y(u.y + 0.5);
      c.globalAlpha = u.alpha * dim(u.c);
      // выбранная колония видна не только цветом: под её юнитами — светлая подложка с тёмным краем
      if (o.selected != null && u.c === o.selected) { const r = (u.k === 'T' ? ts : ws) * 0.7; c.fillStyle = 'rgba(255,255,255,.75)'; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill(); c.strokeStyle = 'rgba(20,26,30,.55)'; c.lineWidth = 1.5; c.stroke(); }
      if (o.hoverUnit === u.id || o.pinned === u.id) { c.strokeStyle = 'rgba(255,255,255,.95)'; c.lineWidth = 3; c.beginPath(); c.arc(x, y, (u.k === 'T' ? ts : ws) * 0.82, 0, Math.PI * 2); c.stroke(); }
      if (u.k === 'W') this.blit(this.sprite('W', u.c, ws, u.carry > 0 ? 1 : 0, (g, z) => worker(g, 0, 0, z, 0, pal, u.carry)), x, y, u.h, ws);
      else if (u.k === 'T') {
        this.blit(this.sprite('TH', u.c, ts, 0, (g, z) => tankHull(g, z, pal, false)), x, y, u.h, ts);
        this.blit(this.sprite('TT', u.c, ts, u.fired ? 1 : 0, (g, z) => tankTurret(g, z, pal, u.fired ? 1 : 0, false)), x, y, u.tur, ts);
      } else this.blit(this.sprite('R', 0, rs, 0, (g, z) => raider(g, 0, 0, z, 0)), x, y, u.h, rs);
      c.setTransform(d, 0, 0, d, 0, 0);
      if (u.up && u.k === 'W') upgrades(c, x, y, ws, u.up);
      if (u.hp < u.max && u.alpha > 0.5 && (lod === 'near' || u.k !== 'W' || u.hp / u.max < 0.6)) hpRing(c, x, y, (u.k === 'T' ? ts * 0.74 : u.k === 'R' ? rs * 0.72 : ws * 0.72), u.hp / u.max, u.k === 'R' ? NEUTRAL : pal);
      c.globalAlpha = 1;
    }
  }

  // Спрайт рисуется в целом размере (кэш не разрастается при плавном приближении), выводится в точном.
  sprite(kind, col, sz, variant, paint) {
    const q = Math.max(6, Math.round(sz)), key = kind + ':' + col + ':' + variant + ':' + q;
    let sp = this.sprites.get(key);
    if (sp) return sp;
    if (this.sprites.size > 600) this.sprites.clear();
    const size = Math.ceil(q * 1.7), px = Math.ceil(size * this.dpr), cv = document.createElement('canvas');
    cv.width = cv.height = px;
    const g = cv.getContext('2d'); g.setTransform(this.dpr, 0, 0, this.dpr, px / 2, px / 2);
    paint(g, q);
    sp = { cv, size: px / this.dpr, q }; this.sprites.set(key, sp);
    return sp;
  }
  blit(sp, x, y, ang, sz) {
    const d = this.dpr, co = Math.cos(ang), si = Math.sin(ang), k = sz / sp.q, sz2 = sp.size * k;
    this.c.setTransform(d * co, d * si, -d * si, d * co, d * x, d * y);
    this.c.drawImage(sp.cv, -sz2 / 2, -sz2 / 2, sz2, sz2);
  }

  farUnits(S, dim, o) {
    const c = this.c, m = this.m, s = this.cam.s, X = this.X, Y = this.Y;
    for (const u of S.units) {
      if (u.k !== 'W' || u.alpha <= 0.01) continue;
      c.globalAlpha = u.alpha * dim(u.c);
      if (o.selected != null && u.c === o.selected) { c.fillStyle = 'rgba(255,255,255,.9)'; c.beginPath(); c.arc(X(u.x + 0.5), Y(u.y + 0.5), Math.max(4, s * 0.48), 0, Math.PI * 2); c.fill(); }
      c.fillStyle = m.pal(u.c).d; c.beginPath(); c.arc(X(u.x + 0.5), Y(u.y + 0.5), Math.max(2.4, s * 0.32), 0, Math.PI * 2); c.fill();
      c.fillStyle = u.carry > 0 ? ENERGY.m : m.pal(u.c).m; c.beginPath(); c.arc(X(u.x + 0.5), Y(u.y + 0.5), Math.max(1.4, s * 0.2), 0, Math.PI * 2); c.fill();
    }
    c.globalAlpha = 1;
    // армии сливаются в метку «знак число»: кто и сколько, без опоры на цвет
    for (const g of groupUnits(S.units)) {
      const x = X(g.x + 0.5), y = Y(g.y + 0.5), sz = Math.max(16, s * 1.4);
      c.globalAlpha = dim(g.c);
      if (g.k === 'R') raider(c, x, y, sz, g.h); else tank(c, x, y, sz, m.pal(g.c), g.h, g.h, 0, false);
      this.pill(x, y - sz * 0.62, g.k === 'R' ? (g.n > 1 ? `налётчики ${g.n}` : 'налётчик') : `${m.colonies.get(g.c)?.sign || ''}${g.n > 1 ? ' ' + g.n : ''}`, g.k === 'R' ? '#2B3034' : m.pal(g.c).d);
      c.globalAlpha = 1;
    }
  }

  // Знак колонии у каждого танка: в бою — над каждым, стоящие рядом танки одной колонии — одна плашка «ЖЕ 3».
  tags(S, dim) {
    const { ts } = this.sizes();
    for (const t of tankTags(S.units, this.m)) {
      this.c.globalAlpha = dim(t.c) * (t.fight ? 1 : 0.92);
      this.pill(this.X(t.x + 0.5), this.Y(t.y + 0.5) - ts * 0.62, t.text, t.bg);
      this.c.globalAlpha = 1;
    }
  }
  pill(x, yBottom, text, bg) {
    if (!text) return;
    const c = this.c, px = Math.max(12, Math.round(this.labelPx * 0.95));
    c.font = `700 ${px}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
    const w = c.measureText(text).width + px * 0.8, hgt = px * 1.35, y = yBottom - hgt / 2;
    c.fillStyle = 'rgba(20,26,30,.25)'; rr(c, x - w / 2 + 1, y - hgt / 2 + 2, w, hgt, hgt / 2); c.fill();
    c.fillStyle = bg; rr(c, x - w / 2, y - hgt / 2, w, hgt, hgt / 2); c.fill();
    c.fillStyle = '#fff'; c.fillText(text, x, y + 0.5);
  }

  deathTraces(S, lod, o) {
    const c = this.c, m = this.m, s = this.cam.s, X = this.X, Y = this.Y, { ws, ts } = this.sizes();
    for (const d of S.deaths) {
      const x = X(d.x + 0.5), y = Y(d.y + 0.5), sz = d.k === 'T' ? ts : ws;
      if (d.age < 5 && lod !== 'far') {
        c.globalAlpha = 0.85 * (1 - d.age / 5);
        if (d.k === 'T') tank(c, x, y, sz, m.pal(d.c), d.h, (d.tur ?? d.h) + 0.6, 0, true);
        else if (d.k === 'W') worker(c, x, y, sz, d.h + 0.4, GHOST, 0);
        else raider(c, x, y, sz, d.h, true);
        c.globalAlpha = 1;
      }
      if (d.killer && d.age < 2.5) {
        const a = 1 - d.age / 2.5, kp = m.pal(d.killer.c);
        c.strokeStyle = rgba(kp.d, 0.75 * a); c.lineWidth = 1.8; c.setLineDash([2, 6]); c.lineCap = 'round';
        c.beginPath(); c.moveTo(x, y); c.lineTo(X(d.killer.x + 0.5), Y(d.killer.y + 0.5)); c.stroke(); c.setLineDash([]); c.lineCap = 'butt';
      }
      if (!o.reduced && d.age < 4 && lod !== 'far') for (let i = 0; i < 4; i++) {
        const ph = d.age + i * 0.35, a = clamp(0.32 * (1 - ph / 4.4), 0, 0.32); if (a <= 0) continue;
        c.fillStyle = `rgba(112,114,108,${a})`; c.beginPath();
        c.arc(x + s * (0.3 * ph + Math.sin(i * 2.1) * 0.15), y - s * (0.5 * ph), s * (0.2 + 0.15 * ph), 0, Math.PI * 2); c.fill();
      }
    }
  }

  flows(S, lod) {
    if (lod === 'far') return;
    const c = this.c, s = this.cam.s;
    for (const f of S.flows) {
      const x = this.X(f.x0 + (f.x1 - f.x0) * f.k), y = this.Y(f.y0 + (f.y1 - f.y0) * f.k);
      c.fillStyle = ENERGY.hi; c.beginPath(); c.arc(x, y, Math.max(1.8, s * 0.08), 0, Math.PI * 2); c.fill();
    }
  }

  shots(S) {
    const c = this.c, s = this.cam.s, X = this.X, Y = this.Y;
    c.lineCap = 'round';
    for (const p of S.shots) {
      const hx = X(p.hx), hy = Y(p.hy), tx = X(p.tx), ty = Y(p.ty);
      const g = c.createLinearGradient(tx, ty, hx, hy);
      g.addColorStop(0, 'rgba(255,214,90,0)'); g.addColorStop(1, `rgba(255,206,80,${0.95 * p.alpha})`);
      c.strokeStyle = g; c.lineWidth = Math.max(3.5, s * 0.15); c.beginPath(); c.moveTo(tx, ty); c.lineTo(hx, hy); c.stroke();
      c.strokeStyle = `rgba(28,35,40,${p.alpha})`; c.lineWidth = Math.max(1.8, s * 0.06);
      const ux = Math.cos(p.ang), uy = Math.sin(p.ang), L = Math.min(Math.hypot(hx - tx, hy - ty), s * 0.38);
      c.beginPath(); c.moveTo(hx - ux * L, hy - uy * L); c.lineTo(hx, hy); c.stroke();
    }
    c.lineCap = 'butt';
  }

  effects(S, lod, o) {
    const c = this.c, s = this.cam.s, X = this.X, Y = this.Y;
    for (const e of S.fx) {
      const x = X(e.x), y = Y(e.y), a = 1 - e.age;
      if (e.kind === 'hit') {
        const r = (e.big ? 1.3 : 0.7) * Math.max(10, s) * (o.reduced ? 0.7 : 0.4 + 0.6 * easeOut(e.age));
        c.strokeStyle = rgba(DANGER, o.reduced ? 0.9 : a); c.lineWidth = e.big ? 3 : 2.5; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.stroke();
        if (!o.reduced) {
          c.strokeStyle = `rgba(255,214,90,${a})`; c.lineWidth = 2; c.lineCap = 'round';
          for (let i = 0; i < 5; i++) { const an = i * 1.256 + 0.4, d0 = s * 0.18, d1 = s * (0.32 + 0.5 * e.age); c.beginPath(); c.moveTo(x + Math.cos(an) * d0, y + Math.sin(an) * d0); c.lineTo(x + Math.cos(an) * d1, y + Math.sin(an) * d1); c.stroke(); }
          c.lineCap = 'butt';
        }
      } else if (e.kind === 'slash') {
        // удар вплотную: короткий росчерк поперёк направления удара
        const r = Math.max(7, s * 0.42), an = e.ang + Math.PI / 2;
        c.strokeStyle = `rgba(255,244,214,${a})`; c.lineWidth = Math.max(2.5, s * 0.1); c.lineCap = 'round';
        for (const off of [-0.18, 0.18]) {
          const ox = Math.cos(e.ang) * s * off, oy = Math.sin(e.ang) * s * off;
          c.beginPath(); c.moveTo(x + ox - Math.cos(an) * r, y + oy - Math.sin(an) * r); c.lineTo(x + ox + Math.cos(an) * r, y + oy + Math.sin(an) * r); c.stroke();
        }
        c.lineCap = 'butt';
      } else if (e.kind === 'beam') {
        // удар танка по прямой: луч от танка до цели гаснет за мгновение
        c.strokeStyle = `rgba(255,214,90,${0.95 * a})`; c.lineWidth = Math.max(3, s * 0.14); c.lineCap = 'round';
        c.beginPath(); c.moveTo(x, y); c.lineTo(X(e.x1), Y(e.y1)); c.stroke(); c.lineCap = 'butt';
      } else if (e.kind === 'puff') {
        c.fillStyle = `rgba(150,150,140,${0.4 * a})`; c.beginPath(); c.arc(x, y, Math.max(3, s * (0.18 + 0.25 * e.age)), 0, Math.PI * 2); c.fill();
      } else if (e.kind === 'muzzle' && e.first && lod !== 'far') {
        const tx = x + Math.cos(e.ang) * s * 0.66, ty = y + Math.sin(e.ang) * s * 0.66;
        c.fillStyle = `rgba(255,236,170,${a})`; c.beginPath(); c.arc(tx, ty, Math.max(3, s * (0.26 - 0.08 * e.age)), 0, Math.PI * 2); c.fill();
        c.fillStyle = `rgba(255,255,255,${a})`; c.beginPath(); c.arc(tx, ty, Math.max(1.5, s * 0.1), 0, Math.PI * 2); c.fill();
      }
    }
  }

  // Кто держит центр: обвод зоны цветом колонии-держателя (в кадре — поле holder).
  centreHolder(S) {
    const m = this.m, at = m.centerAt, holder = S.frame.holder;
    if (!at || !holder) return;
    const col = m.colonies.get(holder); if (!col) return;
    const c = this.c, r = (m.rules.centerRadius || 3) + 0.5, x = this.X(at.x + 0.5), y = this.Y(at.y + 0.5), R = r * this.cam.s;
    c.save();
    c.strokeStyle = col.pal.hi; c.lineWidth = Math.max(3, this.cam.s * 0.14); c.globalAlpha = 0.9; c.lineCap = 'round';
    c.beginPath();
    if (m.centerEdges) for (const [x0, y0, x1, y1] of m.centerEdges) { c.moveTo(this.X(x0), this.Y(y0)); c.lineTo(this.X(x1), this.Y(y1)); }
    else if (m.centerSteps) { c.moveTo(x, y - R); c.lineTo(x + R, y); c.lineTo(x, y + R); c.lineTo(x - R, y); c.closePath(); }
    else c.arc(x, y, R, 0, Math.PI * 2);
    c.stroke(); c.restore();
  }

  // Отказы выбранной колонии в этом такте: тонкое красное кольцо на юните.
  marks(S) {
    if (!S.marks.length) return;
    const c = this.c, s = this.cam.s, X = this.X, Y = this.Y;
    for (const k of S.marks) {
      const x = X(k.x + 0.5), y = Y(k.y + 0.5), r = Math.max(11, s * (k.base ? 0.95 : 0.62));
      c.strokeStyle = rgba(DANGER, 0.85); c.lineWidth = 2; c.setLineDash([4, 3]); c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.stroke(); c.setLineDash([]);
      const bx = x + r * 0.72, by = y - r * 0.72, br = Math.max(6, s * 0.18);
      c.fillStyle = DANGER; c.beginPath(); c.arc(bx, by, br, 0, Math.PI * 2); c.fill();
      c.fillStyle = '#fff'; c.font = `800 ${Math.round(br * 1.4)}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.fillText('!', bx, by + 0.5);
    }
  }

  fights(S) {
    const c = this.c, s = this.cam.s;
    for (const h of hotspots(this.m, S.a)) {
      if (h.w < 3) break;
      const x = this.X(h.x), y = this.Y(h.y), r = Math.max(24, s * (3 + Math.min(2, h.w / 12)));
      const g = c.createRadialGradient(x, y, r * 0.15, x, y, r); g.addColorStop(0, rgba(DANGER, 0.18)); g.addColorStop(1, rgba(DANGER, 0));
      c.fillStyle = g; c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.fill();
      c.strokeStyle = rgba(DANGER, 0.8); c.lineWidth = 2.5; c.setLineDash([10, 7]); c.beginPath(); c.arc(x, y, r, 0, Math.PI * 2); c.stroke(); c.setLineDash([]);
    }
  }

  // «+20» над базой — подпись доставки, а не вспышка: держится около секунды.
  pops(S, lod) {
    if (lod === 'far') return;
    const c = this.c, { bs } = this.sizes(), px = this.labelPx;
    c.font = `700 ${px}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle'; c.lineJoin = 'round';
    for (const p of S.pops) {
      const x = this.X(p.x + 0.5) + (p.idx % 3 - 1) * px * 1.4, y = this.Y(p.y + 0.5) - bs * 0.75 - px * (0.4 + 1.1 * easeOut(p.age));
      c.globalAlpha = 1 - p.age * p.age;
      c.lineWidth = 4; c.strokeStyle = 'rgba(255,255,255,.95)'; c.strokeText('+' + p.n, x, y);
      c.fillStyle = '#8A5E00'; c.fillText('+' + p.n, x, y);
    }
    c.globalAlpha = 1;
  }

  // Имена баз — белым на тёмной плашке цвета колонии: читается на любом грунте и на проекторе.
  // Имя короткое («Фамилия И.»), шрифт не крупнее базы. Плашка встаёт под базу, иначе над ней; если и там занято —
  // имя не рисуется (оно есть в таблице и во всплывающей карточке), чтобы плашки не налезали друг на друга.
  labels(S, lod, dim) {
    const c = this.c, m = this.m, { bs } = this.sizes();
    const px = Math.round(clamp(Math.min(this.labelPx, bs * 0.85), 10, 22));
    c.font = `600 ${px}px ${FONT}`; c.textAlign = 'center'; c.textBaseline = 'middle';
    const hgt = Math.round(px * 1.45), taken = [];
    const hit = r => taken.some(p => p.x0 < r.x1 && r.x0 < p.x1 && p.y0 < r.y1 && r.y0 < p.y1);
    for (const b of S.frame.bases) {
      const x = this.X(b.x + 0.5), y = this.Y(b.y + 0.5);
      taken.push({ x0: x - bs * 0.5, x1: x + bs * 0.5, y0: y - bs * 0.5, y1: y + bs * 0.5 });
    }
    for (const b of S.frame.bases) {
      const col = m.colonies.get(b.c); if (!col) continue;
      const text = shortName(col.name), w = c.measureText(text).width + px * 0.9;
      const x = this.X(b.x + 0.5), by = this.Y(b.y + 0.5);
      // сначала к середине карты (на кольце баз там свободно), потом под, над и наружу
      const inward = b.x + 0.5 < m.W / 2 ? 1 : -1, side = bs * 0.5 + 4 + w / 2;
      const spots = [[x + inward * side, by], [x, by + bs * 0.5 + (b.hp < m.baseMax() ? 10 : 3) + hgt / 2],
        [x, by - bs * 0.5 - 3 - hgt / 2], [x - inward * side, by]];
      let at = null;
      for (const [cx, cy] of spots) {
        const r = { x0: cx - w / 2 - 2, x1: cx + w / 2 + 2, y0: cy - hgt / 2 - 1, y1: cy + hgt / 2 + 1 };
        if (!hit(r)) { taken.push(r); at = [cx, cy]; break; }
      }
      if (at === null) continue;
      const [lx, y] = at;
      c.globalAlpha = dim(b.c);
      c.fillStyle = 'rgba(20,26,30,.22)'; rr(c, lx - w / 2 + 1, y - hgt / 2 + 2, w, hgt, hgt / 2); c.fill();
      c.fillStyle = col.pal.d; rr(c, lx - w / 2, y - hgt / 2, w, hgt, hgt / 2); c.fill();
      c.fillStyle = '#fff'; c.fillText(text, lx, y + 0.5);
      c.globalAlpha = 1;
    }
  }

  // Что под курсором: юнит, база или ничего.
  pick(px, py) {
    const S = this.last; if (!S || !this.X) return null;
    const s = this.cam.s, r = Math.max(14, s * 0.7);
    let best = null, bd = r;
    if (this.lod !== 'far') for (const u of S.units) {
      if (u.alpha < 0.5) continue;
      const d = Math.hypot(this.X(u.x + 0.5) - px, this.Y(u.y + 0.5) - py);
      if (d < bd) { bd = d; best = { unit: u }; }
    }
    if (best) return best;
    const { bs } = this.sizes();
    for (const b of S.frame.bases) if (Math.abs(this.X(b.x + 0.5) - px) < bs * 0.6 && Math.abs(this.Y(b.y + 0.5) - py) < bs * 0.6) return { base: b };
    return null;
  }
}

// Плашки со знаком колонии для танков на среднем и ближнем плане (общие для 2D и диорамы).
// y — верхний танк группы, чтобы плашка не закрывала технику.
export function tankTags(units, m) {
  const out = [], idle = [];
  for (const u of units) {
    if (u.k !== 'T' || u.alpha < 0.5) continue;
    const sign = m.colonies.get(u.c)?.sign || '';
    if (u.fight) out.push({ c: u.c, x: u.x, y: u.y, text: sign, bg: m.pal(u.c).d, fight: true });
    else {
      let g = idle.find(g => g.c === u.c && Math.hypot(g.x - u.x, g.y - u.y) < 2.6);
      if (!g) { g = { c: u.c, x: u.x, y: u.y, n: 0, sign }; idle.push(g); }
      g.x = (g.x * g.n + u.x) / (g.n + 1); g.y = Math.min(g.y, u.y); g.n++;
    }
  }
  for (const g of idle) out.push({ c: g.c, x: g.x, y: g.y, text: g.n > 1 ? `${g.sign} ${g.n}` : g.sign, bg: m.pal(g.c).d, fight: false });
  return out;
}

// Армии на общем плане: танки одной колонии ближе 4 клеток — одна метка.
export function groupUnits(units) {
  const groups = [];
  for (const u of units) {
    if (u.k === 'W' || u.alpha < 0.5) continue;
    let g = groups.find(g => g.c === u.c && g.k === (u.k === 'R' ? 'R' : 'T') && Math.hypot(g.x - u.x, g.y - u.y) < 4);
    if (!g) { g = { c: u.c, k: u.k === 'R' ? 'R' : 'T', x: u.x, y: u.y, n: 0, h: u.h }; groups.push(g); }
    g.x = (g.x * g.n + u.x) / (g.n + 1); g.y = (g.y * g.n + u.y) / (g.n + 1); g.n++; g.h = u.h;
  }
  return groups;
}

const GHOST = { m: '#B9C1B8', d: '#9AA39A', l: '#D5DAD3', hi: '#C6CDC4', ink: '#7D857C' };
const DEP = {
  HOME: { k: 0.5, base: 0.6, set: [[-0.32, 0.12, 0.6], [0.3, 0.14, 0.66], [0, 0.02, 0.86]] },
  NORMAL: { k: 0.55, base: 0.7, set: [[-0.34, 0.1, 0.55], [0.32, 0.12, 0.6], [0, 0.04, 0.82]] },
  RICH: { k: 0.66, base: 0.95, set: [[-0.55, 0.12, 0.62], [0.55, 0.16, 0.66], [0, 0.05, 0.95], [-0.25, 0.3, 0.5], [0.3, 0.32, 0.48]] },
  CENTER: { k: 0.58, base: 1.0, set: [[-0.6, 0.14, 0.62], [0.6, 0.16, 0.66], [0, 0.04, 1.05], [-0.3, 0.32, 0.52], [0.34, 0.34, 0.5], [-0.22, -0.2, 0.6], [0.26, -0.18, 0.64]] },
  LOOT: { k: 0.45, base: 0.6, set: [[-0.3, 0.12, 0.45], [0.28, 0.06, 0.55]] },
};

function rr(c, x, y, w, h, r) { c.beginPath(); c.roundRect(x, y, w, h, r); }

function crystal(c, x, y, h, lit, loot) {
  if (!lit) { const w = h * 0.4, hh = h * 0.42; c.beginPath(); c.moveTo(x - w, y + h * 0.1); c.lineTo(x - w * 0.55, y - hh); c.lineTo(x + w * 0.5, y - hh * 0.8); c.lineTo(x + w, y + h * 0.1); c.lineTo(x, y + h * 0.36); c.closePath(); c.fillStyle = '#A3AB9F'; c.fill(); c.fillStyle = '#B9C0B5'; c.beginPath(); c.moveTo(x - w * 0.55, y - hh); c.lineTo(x + w * 0.5, y - hh * 0.8); c.lineTo(x, y - hh * 0.2); c.closePath(); c.fill(); return; }
  const w = h * 0.44;
  c.beginPath(); c.moveTo(x, y - h); c.lineTo(x + w, y - h * 0.16); c.lineTo(x, y + h * 0.42); c.lineTo(x - w, y - h * 0.16); c.closePath();
  c.fillStyle = loot ? '#D69A1E' : '#E3A30E'; c.fill();
  c.strokeStyle = 'rgba(120,80,0,.45)'; c.lineWidth = 1; c.stroke();
  c.beginPath(); c.moveTo(x, y - h); c.lineTo(x - w, y - h * 0.16); c.lineTo(x, y + h * 0.42); c.closePath();
  c.fillStyle = loot ? '#F1C25A' : '#FFD34D'; c.fill();
  c.beginPath(); c.moveTo(x, y - h); c.lineTo(x + w * 0.34, y - h * 0.3); c.lineTo(x, y - h * 0.04); c.lineTo(x - w * 0.34, y - h * 0.3); c.closePath();
  c.fillStyle = 'rgba(255,250,220,.9)'; c.fill();
}

// Единый тёмный контур у всей техники: силуэт читается на светлом грунте и на проекторе.
const OUTLINE = 'rgba(20,26,30,.72)';

function worker(c, x, y, sz, h, pal, carry) {
  c.save(); c.translate(x, y); c.rotate(h);
  c.fillStyle = 'rgba(30,45,35,.26)'; rr(c, -sz * 0.5 + sz * 0.08, -sz * 0.34 + sz * 0.12, sz, sz * 0.68, sz * 0.22); c.fill();
  c.fillStyle = pal.d; rr(c, -sz * 0.5, -sz * 0.34, sz, sz * 0.68, sz * 0.22); c.fill();
  c.strokeStyle = OUTLINE; c.lineWidth = Math.max(1, sz * 0.07); c.stroke();
  c.fillStyle = pal.m; rr(c, -sz * 0.42, -sz * 0.26, sz * 0.84, sz * 0.52, sz * 0.16); c.fill();
  c.fillStyle = '#F7F8F4'; rr(c, sz * 0.12, -sz * 0.2, sz * 0.26, sz * 0.4, sz * 0.08); c.fill();
  c.fillStyle = carry > 0 ? ENERGY.m : rgba(pal.d, 0.6); rr(c, -sz * 0.37, -sz * 0.2, sz * 0.42, sz * 0.4, sz * 0.08); c.fill();
  if (carry > 0 && sz >= 14) { c.fillStyle = ENERGY.hi; rr(c, -sz * 0.33, -sz * 0.16, sz * 0.18, sz * 0.14, sz * 0.04); c.fill(); }
  c.restore();
}

// Танк сверху: гусеницы, корпус со скошенным носом, башня и ствол с откатом.
function tank(c, x, y, s, pal, hull, tur, recoil, ghost) {
  c.save(); c.translate(x, y); c.rotate(hull); tankHull(c, s, pal, ghost); c.restore();
  c.save(); c.translate(x, y); c.rotate(tur); tankTurret(c, s, pal, recoil, ghost); c.restore();
}
function tankHull(c, s, pal, ghost) {
  if (!ghost) { c.fillStyle = 'rgba(30,45,35,.3)'; rr(c, -s * 0.52 + s * 0.08, -s * 0.42 + s * 0.14, s * 1.04, s * 0.84, s * 0.16); c.fill(); }
  c.fillStyle = ghost ? '#9AA39A' : '#262C30';
  rr(c, -s * 0.52, -s * 0.42, s * 1.04, s * 0.22, s * 0.08); c.fill(); rr(c, -s * 0.52, s * 0.2, s * 1.04, s * 0.22, s * 0.08); c.fill();
  if (!ghost && s > 16) { c.strokeStyle = 'rgba(255,255,255,.16)'; c.lineWidth = 1; c.beginPath(); for (let i = -4; i <= 4; i++) { const tx = i * s * 0.11; for (const yy of [-0.31, 0.31]) { c.moveTo(tx, s * (yy - 0.08)); c.lineTo(tx, s * (yy + 0.08)); } } c.stroke(); }
  c.beginPath(); c.moveTo(-s * 0.46, -s * 0.27); c.lineTo(s * 0.3, -s * 0.27); c.lineTo(s * 0.48, -s * 0.12); c.lineTo(s * 0.48, s * 0.12); c.lineTo(s * 0.3, s * 0.27); c.lineTo(-s * 0.46, s * 0.27); c.closePath();
  c.fillStyle = ghost ? '#B9C1B8' : pal.m; c.fill();
  if (!ghost) { c.strokeStyle = OUTLINE; c.lineWidth = Math.max(1, s * 0.05); c.stroke(); c.fillStyle = pal.d; c.fillRect(-s * 0.44, -s * 0.25, s * 0.08, s * 0.5); }
}
function tankTurret(c, s, pal, recoil, ghost) {
  const L = s * (0.62 - 0.16 * recoil);
  c.fillStyle = ghost ? '#8E978E' : INK; rr(c, s * 0.08, -s * 0.06, L, s * 0.12, s * 0.04); c.fill();
  if (!ghost) { rr(c, s * 0.08 + L - s * 0.1, -s * 0.085, s * 0.1, s * 0.17, s * 0.03); c.fill(); }
  c.beginPath(); c.moveTo(-s * 0.2, -s * 0.2); c.lineTo(s * 0.12, -s * 0.2); c.lineTo(s * 0.24, -s * 0.07); c.lineTo(s * 0.24, s * 0.07); c.lineTo(s * 0.12, s * 0.2); c.lineTo(-s * 0.2, s * 0.2); c.closePath();
  c.fillStyle = ghost ? '#C6CDC4' : pal.hi; c.fill(); c.lineWidth = Math.max(1.2, s * 0.05); c.strokeStyle = ghost ? '#9AA39A' : OUTLINE; c.stroke();
}

// Налётчик: тёмный панцирь с рогами и красной щелью — красный у него потому, что он и есть опасность.
function raider(c, x, y, s, h, ghost) {
  c.save(); c.translate(x, y); c.rotate(h);
  if (!ghost) { c.fillStyle = 'rgba(30,45,35,.28)'; c.beginPath(); c.ellipse(s * 0.06, s * 0.12, s * 0.5, s * 0.38, 0, 0, Math.PI * 2); c.fill(); }
  if (s >= 12) {
    c.strokeStyle = ghost ? '#9AA39A' : '#1E2326'; c.lineWidth = Math.max(1.4, s * 0.07); c.lineCap = 'round'; c.beginPath();
    for (const q of [-0.22, 0.02, 0.24]) for (const sg of [-1, 1]) { c.moveTo(s * q, sg * s * 0.22); c.lineTo(s * (q - 0.1), sg * s * 0.44); }
    c.stroke(); c.lineCap = 'butt';
  }
  c.beginPath(); c.moveTo(s * 0.5, 0); c.lineTo(s * 0.24, -s * 0.3); c.lineTo(-s * 0.3, -s * 0.3); c.lineTo(-s * 0.46, 0); c.lineTo(-s * 0.3, s * 0.3); c.lineTo(s * 0.24, s * 0.3); c.closePath();
  c.fillStyle = ghost ? '#B9C1B8' : '#353B3F'; c.fill(); c.strokeStyle = ghost ? '#9AA39A' : '#14181A'; c.lineWidth = Math.max(1.2, s * 0.06); c.stroke();
  c.beginPath(); c.moveTo(s * 0.12, -s * 0.18); c.lineTo(-s * 0.26, -s * 0.18); c.lineTo(-s * 0.34, 0); c.lineTo(-s * 0.26, s * 0.18); c.lineTo(s * 0.12, s * 0.18); c.closePath();
  c.fillStyle = ghost ? '#C6CDC4' : '#596166'; c.fill();
  if (!ghost) { c.fillStyle = DANGER; rr(c, s * 0.2, -s * 0.15, s * 0.11, s * 0.3, s * 0.04); c.fill(); }
  c.restore();
}

// Здоровье — сегменты дуги вокруг юнита; потерянное — красным.
// Улучшения рабочего: кирка — серый клин справа сверху, сумка — коричневый мешок слева снизу
function upgrades(c, x, y, sz, up) {
  const r = Math.max(3, sz * 0.2);
  if (up.includes('PICK')) {
    const px = x + sz * 0.42, py = y - sz * 0.42;
    c.fillStyle = '#3E464E'; c.beginPath(); c.arc(px, py, r, 0, Math.PI * 2); c.fill();
    c.strokeStyle = '#fff'; c.lineWidth = 1; c.stroke();
    c.strokeStyle = '#E8ECEF'; c.lineWidth = Math.max(1, r * 0.35); c.beginPath(); c.moveTo(px - r * 0.5, py + r * 0.5); c.lineTo(px + r * 0.45, py - r * 0.45); c.stroke();
  }
  if (up.includes('BAG')) {
    const bx = x - sz * 0.42, by = y + sz * 0.4;
    c.fillStyle = '#8A5A2B'; c.beginPath(); c.arc(bx, by, r, 0, Math.PI * 2); c.fill();
    c.strokeStyle = '#fff'; c.lineWidth = 1; c.stroke();
  }
}

function hpRing(c, x, y, R, f, pal) {
  const n = 5, gap = 0.22, seg = (Math.PI * 2 - gap * n) / n, full = Math.ceil(f * n - 0.001);
  c.lineCap = 'round'; c.lineWidth = Math.max(2.4, R * 0.13);
  for (let i = 0; i < n; i++) {
    const a0 = -Math.PI / 2 + gap / 2 + i * (seg + gap);
    c.strokeStyle = i < full ? pal.d : rgba(DANGER, 0.9);
    c.beginPath(); c.arc(x, y, R, a0, a0 + seg); c.stroke();
  }
  c.lineCap = 'butt';
}
