package colony.net;

import java.io.IOException;
import java.io.InputStream;
import java.io.PrintStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.concurrent.TimeUnit;

/**
 * Токен для игры на сервере: переменная {@code COLONY_TOKEN} или файл {@code ~/.colony/token}. Токена нет, а сервер
 * умеет вход через GitHub, — SDK входит сам ({@link Login}) и кладёт токен в файл. В репозитории токена быть не
 * должно: его не печатаем и предупреждаем, если он нашёлся в файле под Git.
 */
public final class Token {

    public static final String ENV = "COLONY_TOKEN";

    /** Токен и откуда он взят (для сообщений; сам токен не печатается). */
    public record Found(String value, String source) {}

    /** Токена нет ни в переменной, ни в файле; в тексте сказано, куда его положить. */
    public static final class Missing extends IllegalStateException {
        Missing(String message) {
            super(message);
        }
    }

    private Token() {}

    /** Файл токена в домашней папке. */
    public static Path file(Path home) {
        return home.resolve(".colony").resolve("token");
    }

    /**
     * Найти токен: сначала переменная окружения, потом файл.
     *
     * @throws IllegalStateException токена нет — в тексте сказано, куда его положить
     */
    public static Found find(Map<String, String> env, Path home) {
        String v = env.get(ENV);
        if (v != null && !v.isBlank()) {
            return new Found(v.strip(), "переменной " + ENV);
        }
        Path f = file(home);
        if (Files.isRegularFile(f)) {
            try {
                String text = Files.readString(f, StandardCharsets.UTF_8).replace("﻿", "").strip();
                String first = text.lines().findFirst().orElse("").strip();
                if (!first.isEmpty()) {
                    return new Found(first, "файла " + f);
                }
            } catch (IOException e) {
                throw new IllegalStateException("Не удалось прочитать токен из " + f + ": " + e.getMessage());
            }
        }
        throw new Missing("Нет токена для игры на сервере. Токен выдаёт преподаватель. Сохраните его "
                + "одной строкой в файл " + f + " (не в папку проекта) или в переменную " + ENV
                + ". Играть без сервера: Main --local.");
    }

    /**
     * Найти токен, а если его нет — войти ({@link Login}): через GitHub или по коду преподавателя, токен ложится в
     * {@link #file}. Сервер не умеет такого входа или не отвечает — та же ошибка, что у {@link #find}.
     *
     * @param server адрес сервера; {@code null} — только искать
     * @param out    куда печатать, как войти
     * @throws IllegalStateException токена нет и войти не вышло — в тексте сказано, что делать
     */
    public static Found obtain(Map<String, String> env, Path home, URI server, PrintStream out) {
        return obtain(env, home, server == null ? null : Login.builder().server(server).home(home).out(out).build());
    }

    /** То же с готовым входом; {@code login == null} — только искать. */
    public static Found obtain(Map<String, String> env, Path home, Login login) {
        try {
            return find(env, home);
        } catch (Missing missing) {
            if (login == null) {
                throw missing;
            }
            return login.run().orElseThrow(() -> missing);
        }
    }

    /** Файлы проекта под Git, в которых есть этот токен (пусто, если это не репозиторий или Git нет). */
    public static List<String> trackedFilesWith(Path projectDir, String token) {
        List<String> out = new ArrayList<>();
        if (token == null || token.length() < 8) {
            return out;
        }
        String listed = gitLsFiles(projectDir);
        if (listed == null) {
            return out;
        }
        byte[] needle = token.getBytes(StandardCharsets.UTF_8);
        for (String name : listed.split("\0")) {
            if (name.isBlank()) {
                continue;
            }
            try (InputStream in = Files.newInputStream(projectDir.resolve(name))) {
                if (contains(in.readNBytes(1 << 20), needle)) {
                    out.add(name);
                }
            } catch (IOException | RuntimeException e) {
                // удалённый или недоступный файл пропускаем
            }
        }
        return out;
    }

    /** Предупреждение о токене в Git или {@code null}. */
    public static String gitWarning(Path projectDir, String token) {
        List<String> files = trackedFilesWith(projectDir, token);
        if (files.isEmpty()) {
            return null;
        }
        return "Токен лежит в файле под Git: " + String.join(", ", files) + ". Уберите его оттуда и из истории "
                + "(или попросите у преподавателя новый): токен — только в " + ENV + " или ~/.colony/token.";
    }

    /** {@code git ls-files -z} в папке проекта; не репозиторий или нет Git — {@code null}. */
    private static String gitLsFiles(Path dir) {
        Path list = null;
        try {
            list = Files.createTempFile("colony-ls-", ".txt");
            Process p = new ProcessBuilder("git", "ls-files", "-z").directory(dir.toFile())
                    .redirectOutput(list.toFile()).redirectError(ProcessBuilder.Redirect.DISCARD).start();
            p.getOutputStream().close();
            if (!p.waitFor(10, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return null;
            }
            return p.exitValue() == 0 ? Files.readString(list, StandardCharsets.UTF_8) : null;
        } catch (IOException e) {
            return null;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return null;
        } finally {
            if (list != null) {
                try {
                    Files.deleteIfExists(list);
                } catch (IOException ignored) {
                    // временный файл
                }
            }
        }
    }

    private static boolean contains(byte[] data, byte[] needle) {
        outer:
        for (int i = 0; i + needle.length <= data.length; i++) {
            for (int j = 0; j < needle.length; j++) {
                if (data[i + j] != needle[j]) {
                    continue outer;
                }
            }
            return true;
        }
        return false;
    }
}
