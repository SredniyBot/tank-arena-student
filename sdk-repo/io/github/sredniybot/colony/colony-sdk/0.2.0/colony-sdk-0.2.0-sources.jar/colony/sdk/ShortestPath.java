package colony.sdk;

import colony.api.ColonyView;
import colony.api.Direction;
import colony.api.Pos;
import java.util.Comparator;
import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.PriorityQueue;

/**
 * Кратчайший путь: волна от {@code from} до {@code to}. Шаг по полу стоит 1. Завал, если копать можно, тоже
 * проходим, но дорог: 1 + его прочность. Поэтому путь может вести сквозь завал — тогда очередной шаг упирается в
 * него, и его надо разобрать ({@code orders.dig}). Юнитов не обходит. Готовая реализация — {@link Pathfinder#SHORTEST}.
 */
public final class ShortestPath implements Pathfinder {

    @Override
    public Optional<Direction> next(ColonyView view, Pos from, Pos to) {
        boolean closed = !Pathfinder.passable(view, to);
        if (from.equals(to) || closed && from.manhattan(to) == 1) {
            return Optional.empty();
        }
        Map<Pos, Pos> came = new HashMap<>();
        Map<Pos, Integer> cost = new HashMap<>();
        PriorityQueue<Pos> queue = new PriorityQueue<>(Comparator.comparingInt(cost::get));
        came.put(from, from);
        cost.put(from, 0);
        queue.add(from);
        while (!queue.isEmpty()) {
            Pos p = queue.poll();
            if (closed ? p.manhattan(to) == 1 : p.equals(to)) {
                Pos step = p;
                while (!came.get(step).equals(from)) {
                    step = came.get(step);
                }
                for (Direction d : Direction.values()) {
                    if (from.step(d).equals(step)) {
                        return Optional.of(d);
                    }
                }
            }
            for (Pos n : p.neighbours()) {
                int c = stepCost(view, n);
                if (c < 0) {
                    continue;
                }
                int total = cost.get(p) + c;
                if (!cost.containsKey(n) || total < cost.get(n)) {
                    queue.remove(n);
                    came.put(n, p);
                    cost.put(n, total);
                    queue.add(n);
                }
            }
        }
        return Optional.empty();
    }

    private static int stepCost(ColonyView view, Pos p) {
        if (Pathfinder.passable(view, p)) {
            return 1;
        }
        if (view.rules().dig().isPresent() && view.inside(p) && view.rubble(p) > 0) {
            return 1 + view.rubble(p);
        }
        return -1;
    }
}
