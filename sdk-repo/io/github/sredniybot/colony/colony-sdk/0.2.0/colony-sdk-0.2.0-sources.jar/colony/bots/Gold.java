package colony.bots;

import colony.api.ColonyView;

/**
 * «Золото» — босс лиги 3. Делит рабочих на добытчиков и охрану: когда у наших рабочих появляются чужие, двое
 * ближайших к ним бросают добычу и бьют их; когда чужих нет — все добывают.
 */
public final class Gold extends LeagueBoss {

    public Gold() {
        this(1);
    }

    public Gold(long seed) {
        super(seed);
    }

    @Override
    int guards(ColonyView view, int workers) {
        return 2;
    }

    @Override
    int holders(ColonyView view, int workers) {
        return 0;
    }
}
