package colony.bots;

import colony.api.Base;
import colony.api.ColonyView;
import colony.api.Deposit;
import colony.api.DepositKind;
import colony.api.Unit;
import colony.engine.Navigator;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * «Бронза» — первый соперник. Первый рабочий добывает у дома, остальные — на ближайшей непустой залежи. Держит трёх
 * рабочих. Толкотню у залежи не замечает.
 */
public final class Bronze extends HarvestBot {

    static final int CAP = 3;

    private final int reserve;

    public Bronze() {
        this(1);
    }

    /** @param seed зерно матча: от него — запас энергии перед стройкой и выбор между равными залежами */
    public Bronze(long seed) {
        super(seed);
        this.reserve = random.nextInt(41);
    }

    @Override
    int workerCap(ColonyView view) {
        return CAP;
    }

    @Override
    boolean wantWorker(ColonyView view) {
        return view.energy() >= view.rules().workerCost() + reserve;
    }

    @Override
    Optional<Deposit> choose(ColonyView view, Navigator nav, Base base, Unit worker) {
        Optional<Deposit> home = home(view, base);
        if (home.isPresent() && crowd(home.get().id()) == 0) {
            return home;
        }
        int best = -1;
        List<Deposit> nearest = new ArrayList<>();
        for (Deposit d : view.deposits()) {
            if (d.kind() == DepositKind.HOME || exhausted(d)) {
                continue;
            }
            int dist = fromBase(nav, view, base, d);
            if (dist < 0) {
                continue;
            }
            if (best < 0 || dist < best) {
                best = dist;
                nearest.clear();
            }
            if (dist == best) {
                nearest.add(d);
            }
        }
        return nearest.isEmpty() ? home : Optional.of(nearest.get(random.nextInt(nearest.size())));
    }
}
