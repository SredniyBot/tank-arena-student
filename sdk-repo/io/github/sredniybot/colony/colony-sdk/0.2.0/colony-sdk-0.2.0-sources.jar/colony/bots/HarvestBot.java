package colony.bots;

import colony.api.Base;
import colony.api.ColonyView;
import colony.api.Deposit;
import colony.api.DepositKind;
import colony.api.Direction;
import colony.api.Orders;
import colony.api.Pos;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.api.Unit;
import colony.api.UnitType;
import colony.engine.InternalColony;
import colony.engine.Navigator;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.SplittableRandom;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Основа встроенных соперников: рабочий идёт к своей залежи, добывает, полный несёт на базу. Путь знает навигатор
 * движка. В занятую клетку рабочий не идёт: ждёт, обходит, а если стоит долго — отступает в случайную сторону.
 * Случайность — от зерна матча, поэтому одно зерно даёт один и тот же матч.
 */
abstract class HarvestBot implements InternalColony {

    protected final SplittableRandom random;
    /** Рабочий → залежь, к которой он приписан. */
    protected final Map<Integer, Integer> assigned = new TreeMap<>();
    /** Рабочий → сколько тактов подряд он ждёт, когда освободится дорога. */
    private final Map<Integer, Integer> waiting = new TreeMap<>();
    /** Рабочие, чей шаг в прошлом такте не удался: столкнулись с чужим или упёрлись. */
    private final Set<Integer> bumped = new TreeSet<>();

    HarvestBot(long seed) {
        this.random = new SplittableRandom(seed);
    }

    /** Сколько рабочих держать. */
    abstract int workerCap(ColonyView view);

    /** Строить ли рабочего сейчас (рабочих меньше предела, энергии хватает). */
    abstract boolean wantWorker(ColonyView view);

    /** Залежь для рабочего; пусто — постоять. */
    abstract Optional<Deposit> choose(ColonyView view, Navigator nav, Base base, Unit worker);

    /**
     * Особые роли до добычи (охрана, центр, танки): отдать приказы своим юнитам и вернуть их номера. Остальные рабочие
     * добывают. По умолчанию ролей нет.
     */
    Set<Integer> roles(ColonyView view, Orders orders, Navigator nav, Base base, Traffic traffic) {
        return Set.of();
    }

    /** Строить ли сейчас вместо рабочего другой юнит; пусто — рабочего, как обычно. */
    Optional<UnitType> special(ColonyView view) {
        return Optional.empty();
    }

    @Override
    public void onTick(ColonyView view, Orders orders, Navigator nav) {
        if (nav == null || view.myBases().isEmpty()) {
            return;
        }
        Base base = view.myBases().get(0);
        TreeSet<Integer> alive = new TreeSet<>();
        view.myUnits().forEach(u -> alive.add(u.id()));
        assigned.keySet().retainAll(alive);
        waiting.keySet().retainAll(alive);
        bumped.clear();
        for (Rejection r : view.lastRejections()) {
            if (r.code() == RejectCode.DEPOSIT_EMPTY || r.code() == RejectCode.NO_DEPOSIT) {
                assigned.remove(r.unitId());
            } else if (r.code() == RejectCode.COLLISION || r.code() == RejectCode.BLOCKED) {
                bumped.add(r.unitId());
            }
        }

        Traffic traffic = new Traffic(view);
        Set<Integer> special = roles(view, orders, nav, base, traffic);
        for (Unit u : view.myUnits()) {
            if (u.type() != UnitType.WORKER || special.contains(u.id())) {
                continue;
            }
            Deposit target = target(view, nav, base, u);
            boolean full = u.carry() >= view.rules().workerCarry();
            if (full || (u.carry() > 0 && target == null)) {
                Optional<Direction> toBase = adjacent(u.pos(), base.pos());
                if (toBase.isPresent()) {
                    orders.transfer(u.id(), toBase.get(), u.carry());
                } else {
                    approach(view, orders, nav, u, base.pos(), base.pos(), traffic);
                }
            } else if (target != null) {
                Optional<Direction> toDeposit = adjacent(u.pos(), target.pos());
                if (toDeposit.isPresent()) {
                    orders.harvest(u.id(), toDeposit.get());
                } else {
                    approach(view, orders, nav, u, target.pos(), base.pos(), traffic);
                }
            } else if (adjacent(u.pos(), base.pos()).isPresent()) {
                stepAside(view, orders, u, base.pos(), traffic);
            }
        }

        Optional<UnitType> other = special(view);
        boolean nobody = view.myUnits().isEmpty() && view.energy() >= view.rules().workerCost();
        if (other.isPresent() && !nobody) {
            orders.produce(base.id(), other.get());
        } else if (nobody || (workers(view) < workerCap(view) && wantWorker(view))) {
            orders.produce(base.id(), UnitType.WORKER);
        }
    }

    static int workers(ColonyView view) {
        return (int) view.myUnits().stream().filter(u -> u.type() == UnitType.WORKER).count();
    }

    /** Кто где стоит в этом такте и кто куда уже пошёл. */
    static final class Traffic {
        /** Клетки, где стоят свои и видимые чужие юниты. */
        final Set<Pos> busy = new HashSet<>();
        /** Клетки, куда в этом такте уже идёт кто-то из своих. */
        final Set<Pos> claimed = new HashSet<>();
        /** Клетки своих, которые в этом такте уходят. */
        final Set<Pos> leaving = new HashSet<>();
        /** Клетки у залежей, которые уже выбрали добытчики. */
        final Set<Pos> reserved = new HashSet<>();

        Traffic(ColonyView view) {
            view.myUnits().forEach(u -> busy.add(u.pos()));
            if (!view.truce() && !view.rules().foreignPassable()) {
                view.visibleEnemies().forEach(u -> busy.add(u.pos()));
            }
        }

        /** В клетку можно шагнуть: туда никто не идёт, и там никто не стоит (или стоящий уходит). */
        boolean free(Pos p) {
            return !claimed.contains(p) && (!busy.contains(p) || leaving.contains(p));
        }
    }

    private Deposit target(ColonyView view, Navigator nav, Base base, Unit u) {
        Integer id = assigned.get(u.id());
        Deposit d = id == null ? null : byId(view, id);
        if (d == null || exhausted(d)) {
            assigned.remove(u.id());
            d = choose(view, nav, base, u).or(() -> nearestAny(view, nav, base)).orElse(null);
            if (d != null) {
                assigned.put(u.id(), d.id());
            }
        }
        return d;
    }

    /**
     * Идти к клетке рядом с {@code goal} (залежью или базой): к ближайшей, где никто не стоит и которую не выбрал
     * другой добытчик, при равенстве — ближе к базе. Таких нет — к ближайшей вообще: там подождём очереди.
     * Клетки у базы не бронируются: сдача груза — один такт.
     */
    void approach(ColonyView view, Orders orders, Navigator nav, Unit u, Pos goal, Pos basePos,
                  Traffic traffic) {
        boolean toBase = goal.equals(basePos);
        Pos best = null;
        Pos nearest = null;
        int bestCost = Integer.MAX_VALUE;
        int nearestCost = Integer.MAX_VALUE;
        for (Pos cell : goal.neighbours()) {
            if (!standable(view, cell)) {
                continue;
            }
            int walk = nav.distance(u.pos(), cell);
            if (walk < 0) {
                continue;
            }
            int carry = toBase ? 0 : Math.max(0, nav.distance(cell, basePos) - 1);
            int cost = walk * 4 + carry;
            if (cost < nearestCost) {
                nearestCost = cost;
                nearest = cell;
            }
            boolean taken = traffic.busy.contains(cell) || (!toBase && traffic.reserved.contains(cell));
            if (!taken && cost < bestCost) {
                bestCost = cost;
                best = cell;
            }
        }
        Pos cell = best != null ? best : nearest;
        if (cell == null) {
            return;
        }
        if (!toBase) {
            traffic.reserved.add(cell);
        }
        if (waiting.getOrDefault(u.id(), 0) >= BLOCKED_TICKS && hitBlocker(view, orders, nav, u, cell)) {
            return;
        }
        step(view, nav, u, cell, traffic).ifPresent(d -> orders.move(u.id(), d));
    }

    /** Сколько тактов рабочий ждёт, прежде чем ударить чужого, который загородил дорогу. */
    static final int BLOCKED_TICKS = 3;

    /**
     * С лиги 3: чужой стоит на шаге к цели — ударить его (кроме того, что у своей базы: там он не ранится).
     * {@code true} — ударил.
     */
    boolean hitBlocker(ColonyView view, Orders orders, Navigator nav, Unit u, Pos cell) {
        if (view.truce() || view.rules().melee().isEmpty() || u.type() != UnitType.WORKER) {
            return false;
        }
        int d = nav.distance(u.pos(), cell);
        for (Direction dir : Direction.values()) {
            Pos n = u.pos().step(dir);
            Optional<Unit> there = view.unitAt(n);
            if (there.isPresent() && there.get().colonyId() != view.myId() && !atHome(view, there.get())
                    && nav.distance(n, cell) < d) {
                orders.attack(u.id(), dir);
                return true;
            }
        }
        return false;
    }

    /** Чужой юнит у своей базы, где удар его не ранит (по видимым базам). */
    static boolean atHome(ColonyView view, Unit e) {
        int r = view.rules().melee().map(m -> m.homeRadius()).orElse(0);
        return r > 0 && view.visibleEnemyBases().stream()
                .anyMatch(b -> b.colonyId() == e.colonyId() && b.pos().manhattan(e.pos()) <= r);
    }

    /**
     * Шаг к {@code cell} только в свободную клетку: вперёд по кратчайшему пути; если вперёд занято — такт ждём, потом
     * обходим сбоку (шаг, после которого путь не длиннее); если стоим долго — шаг в любую свободную сторону.
     * Пустой рабочий уступает раньше гружёного. Столкнулся в прошлом такте — вперёд не идёт, чтобы два рабочих не
     * сталкивались снова и снова.
     */
    Optional<Direction> step(ColonyView view, Navigator nav, Unit u, Pos cell, Traffic traffic) {
        int d = nav.distance(u.pos(), cell);
        if (d <= 0) {
            return Optional.empty();
        }
        int waited = waiting.getOrDefault(u.id(), 0);
        if (bumped.contains(u.id())) {
            waited = waiting.merge(u.id(), 1, Integer::sum);
        }
        List<Direction> forward = new ArrayList<>();
        List<Direction> side = new ArrayList<>();
        List<Direction> any = new ArrayList<>();
        for (Direction dir : Direction.values()) {
            Pos n = u.pos().step(dir);
            if (!standable(view, n) || !traffic.free(n)) {
                continue;
            }
            int dn = nav.distance(n, cell);
            if (dn == d - 1) {
                forward.add(dir);
            } else if (dn == d) {
                side.add(dir);
            }
            any.add(dir);
        }
        Direction pick = null;
        if (!forward.isEmpty() && !bumped.contains(u.id())) {
            pick = forward.get(0);
        } else if (waited >= 1 && !side.isEmpty()) {
            pick = side.get(random.nextInt(side.size()));
        } else if (waited >= (u.carry() > 0 ? 4 : 2) && !any.isEmpty()) {
            pick = any.get(random.nextInt(any.size()));
        }
        if (pick == null) {
            waiting.merge(u.id(), 1, Integer::sum);
            return Optional.empty();
        }
        waiting.remove(u.id());
        traffic.claimed.add(u.pos().step(pick));
        traffic.leaving.add(u.pos());
        return Optional.of(pick);
    }

    /** Без дела у базы не стоять: там появляются новые юниты. Шаг на свободную клетку не рядом с базой. */
    private void stepAside(ColonyView view, Orders orders, Unit u, Pos basePos, Traffic traffic) {
        for (Direction d : Direction.values()) {
            Pos n = u.pos().step(d);
            if (standable(view, n) && traffic.free(n) && adjacent(n, basePos).isEmpty()) {
                traffic.claimed.add(n);
                traffic.leaving.add(u.pos());
                orders.move(u.id(), d);
                return;
            }
        }
    }

    /** Направление на соседнюю клетку {@code to} или пусто, если она не рядом. */
    static Optional<Direction> adjacent(Pos from, Pos to) {
        for (Direction d : Direction.values()) {
            if (from.step(d).equals(to)) {
                return Optional.of(d);
            }
        }
        return Optional.empty();
    }

    /** На клетке можно стоять: внутри карты, пол, не база и не залежь. */
    static boolean standable(ColonyView view, Pos p) {
        return view.inside(p) && view.terrain(p) == colony.api.Terrain.FLOOR && view.baseAt(p).isEmpty()
                && view.depositAt(p).isEmpty();
    }

    // ---- помощники для выбора залежи ----

    static Deposit byId(ColonyView view, int id) {
        for (Deposit d : view.deposits()) {
            if (d.id() == id) {
                return d;
            }
        }
        return null;
    }

    /** Обычная залежь видна и пуста. Домашняя не иссякает. */
    static boolean exhausted(Deposit d) {
        return d.kind() != DepositKind.HOME && d.visible() && d.amount() == 0;
    }

    /** Своя домашняя залежь — ближайшая к базе. */
    static Optional<Deposit> home(ColonyView view, Base base) {
        Deposit best = null;
        for (Deposit d : view.deposits()) {
            if (d.kind() == DepositKind.HOME
                    && (best == null || d.pos().manhattan(base.pos()) < best.pos().manhattan(base.pos()))) {
                best = d;
            }
        }
        return Optional.ofNullable(best);
    }

    /** Шагов от базы до соседней с залежью клетки плюс один; {@code -1} — не дойти. */
    static int fromBase(Navigator nav, ColonyView view, Base base, Deposit d) {
        int best = -1;
        for (Pos n : base.pos().neighbours()) {
            if (!view.inside(n) || view.terrain(n) != colony.api.Terrain.FLOOR || view.depositAt(n).isPresent()) {
                continue;
            }
            int dist = nav.distance(n, d.pos());
            if (dist >= 0 && (best < 0 || dist + 1 < best)) {
                best = dist + 1;
            }
        }
        return best;
    }

    /**
     * Залежь по выгоде: энергия за такт пути туда и обратно — чем ближе и полнее, тем лучше; у одной залежи не больше
     * двух рабочих (у богатой и центральной — трёх).
     */
    Optional<Deposit> bestByValue(ColonyView view, Navigator nav, Base base) {
        int carry = view.rules().workerCarry();
        Deposit best = null;
        double bestValue = 0;
        for (Deposit d : view.deposits()) {
            boolean home = d.kind() == DepositKind.HOME;
            if (exhausted(d) || (home && !d.equals(home(view, base).orElse(null)))) {
                continue;
            }
            if (crowd(d.id()) >= capacity(d)) {
                continue;
            }
            int dist = fromBase(nav, view, base, d);
            if (dist < 0) {
                continue;
            }
            int rate = home ? colony.engine.RuleSet.of(view).homeHarvestRate() : view.rules().harvestRate();
            int walk = Math.max(0, dist - 2);
            double value = (double) carry / ((double) carry / rate + 2.0 * walk + 2);
            if (!home && d.visible() && d.amount() < carry) {
                value *= d.amount() / (double) carry;
            }
            value += random.nextDouble() * 1e-6;
            if (value > bestValue) {
                bestValue = value;
                best = d;
            }
        }
        return Optional.ofNullable(best);
    }

    private static int capacity(Deposit d) {
        return d.kind() == DepositKind.RICH || d.kind() == DepositKind.CENTER ? 3 : 2;
    }

    /**
     * Лишнему рабочему (у всех выгодных жил уже полно своих) — ближайшая непустая жила без ограничений: пусть ждёт
     * очереди у жилы, а не стоит посреди прохода, где мешает всем.
     */
    static Optional<Deposit> nearestAny(ColonyView view, Navigator nav, Base base) {
        Deposit best = null;
        int bestD = Integer.MAX_VALUE;
        for (Deposit d : view.deposits()) {
            if (exhausted(d) || d.kind() == DepositKind.HOME) {
                continue;
            }
            int dist = fromBase(nav, view, base, d);
            if (dist >= 0 && dist < bestD) {
                bestD = dist;
                best = d;
            }
        }
        return Optional.ofNullable(best);
    }

    /** Сколько рабочих уже приписано к залежи. */
    int crowd(int depositId) {
        int n = 0;
        for (int id : assigned.values()) {
            if (id == depositId) {
                n++;
            }
        }
        return n;
    }
}
