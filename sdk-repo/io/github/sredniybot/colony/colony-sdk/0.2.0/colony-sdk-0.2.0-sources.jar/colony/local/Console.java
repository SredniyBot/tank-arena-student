package colony.local;

import colony.api.RejectCode;
import colony.api.Rejection;
import java.io.PrintStream;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.StringJoiner;
import java.util.function.LongSupplier;

/**
 * Консоль локальной игры. Отказы своей колонии печатаются не чаще раза в 2 секунды на код, чтобы не тонуть в
 * повторах; полный список — в просмотре. Исключения и таймауты — в поток ошибок (в IntelliJ — красным).
 */
final class Console {

    static final long QUIET_NANOS = 2_000_000_000L;

    private final PrintStream out;
    private final PrintStream err;
    private final LongSupplier clock;
    private final Map<RejectCode, Long> lastPrinted = new EnumMap<>(RejectCode.class);
    private final Map<RejectCode, Integer> counts = new EnumMap<>(RejectCode.class);
    private boolean stackShown;

    Console(PrintStream out, PrintStream err) {
        this(out, err, System::nanoTime);
    }

    Console(PrintStream out, PrintStream err, LongSupplier nanoClock) {
        this.out = out;
        this.err = err;
        this.clock = nanoClock;
    }

    void info(String line) {
        out.println(line);
    }

    void error(String line) {
        out.flush();
        err.println(line);
        err.flush();
    }

    /** Отказы за приказы прошлого такта; {@code tick} — кадр, где их показывает просмотр (и где колония видит их в {@code view.tick()}). */
    void rejections(int tick, List<Rejection> list) {
        long now = clock.getAsLong();
        for (Rejection r : list) {
            counts.merge(r.code(), 1, Integer::sum);
            Long last = lastPrinted.get(r.code());
            if (last != null && now - last < QUIET_NANOS) {
                continue;
            }
            lastPrinted.put(r.code(), now);
            String line = "такт " + tick + ": " + r.message();
            if (failure(r.code())) {
                error(line);
            } else {
                info(line);
            }
        }
    }

    /** Стек исключения из кода колонии — один раз за матч, без строк движка. */
    void stackOnce(Throwable t) {
        if (stackShown || t == null) {
            return;
        }
        stackShown = true;
        out.flush();
        printStack(t, "", 0);
        err.flush();
    }

    private void printStack(Throwable t, String prefix, int depth) {
        err.println(prefix + t);
        for (StackTraceElement e : t.getStackTrace()) {
            String cn = e.getClassName();
            if (cn.startsWith("colony.engine.") || cn.startsWith("java.util.concurrent.")) {
                break;
            }
            err.println("\tat " + e);
        }
        if (t.getCause() != null && t.getCause() != t && depth < 5) {
            printStack(t.getCause(), "Caused by: ", depth + 1);
        }
    }

    /** Сколько отказов каждого кода было. */
    Map<RejectCode, Integer> counts() {
        return Map.copyOf(counts);
    }

    /** «Отказов за матч: 42 — DEPOSIT_EMPTY 30, BLOCKED 12.» или {@code null}, если отказов не было. */
    String summary() {
        if (counts.isEmpty()) {
            return null;
        }
        int total = counts.values().stream().mapToInt(Integer::intValue).sum();
        StringJoiner j = new StringJoiner(", ");
        counts.entrySet().stream()
                .sorted(Map.Entry.<RejectCode, Integer>comparingByValue().reversed()
                        .thenComparing(Map.Entry.comparingByKey()))
                .forEach(e -> j.add(e.getKey().name() + " " + e.getValue()));
        return "Отказов за матч: " + total + " — " + j + ".";
    }

    static boolean failure(RejectCode code) {
        return code == RejectCode.EXCEPTION || code == RejectCode.TIMEOUT;
    }
}
