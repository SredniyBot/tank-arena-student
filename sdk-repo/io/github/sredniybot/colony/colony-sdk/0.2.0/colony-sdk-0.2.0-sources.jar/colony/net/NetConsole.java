package colony.net;

import colony.api.RejectCode;
import colony.api.Rejection;
import java.io.PrintStream;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;

/**
 * Консоль сетевой игры: строка на событие, отказы своей колонии — не чаще раза в 2 секунды на код (как в локальной
 * игре), ошибки — в поток ошибок (в IntelliJ — красным), стек исключения — один раз.
 */
final class NetConsole {

    private static final long QUIET_NANOS = 2_000_000_000L;

    private final PrintStream out;
    private final PrintStream err;
    private final Map<RejectCode, Long> lastPrinted = new EnumMap<>(RejectCode.class);
    private boolean stackShown;

    NetConsole(PrintStream out, PrintStream err) {
        this.out = out;
        this.err = err;
    }

    void line(String text) {
        out.println(text);
    }

    void error(String text) {
        out.flush();
        err.println(text);
        err.flush();
    }

    /** Отказы движка за прошлый такт; {@code tick} — такт обзора, где колония их видит. */
    void rejections(int tick, List<Rejection> list) {
        long now = System.nanoTime();
        for (Rejection r : list) {
            Long last = lastPrinted.get(r.code());
            if (last != null && now - last < QUIET_NANOS) {
                continue;
            }
            lastPrinted.put(r.code(), now);
            line("такт " + tick + ": " + r.message());
        }
    }

    /** Стек исключения из кода колонии — один раз за матч, без строк SDK. */
    void stackOnce(Throwable t) {
        if (stackShown || t == null) {
            return;
        }
        stackShown = true;
        out.flush();
        print(t, "", 0);
        err.flush();
    }

    void newMatch() {
        stackShown = false;
    }

    private void print(Throwable t, String prefix, int depth) {
        err.println(prefix + t);
        for (StackTraceElement e : t.getStackTrace()) {
            if (e.getClassName().startsWith("colony.") || e.getClassName().startsWith("java.util.concurrent.")) {
                break;
            }
            err.println("\tat " + e);
        }
        if (t.getCause() != null && t.getCause() != t && depth < 5) {
            print(t.getCause(), "Caused by: ", depth + 1);
        }
    }
}
