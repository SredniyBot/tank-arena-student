package colony.local;

import colony.api.Colony;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.engine.ColonySpec;
import colony.engine.Frame;
import colony.engine.Match;
import colony.engine.MatchConfig;
import colony.engine.RulesLoader;
import colony.engine.Version;
import colony.homework.Steps;
import colony.homework.Training;
import colony.net.Protocol;
import colony.net.ServerLink;
import colony.net.Token;
import java.io.IOException;
import java.net.ServerSocket;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.Duration;
import java.util.List;
import java.util.Locale;
import java.util.function.Supplier;

/**
 * Самопроверка {@code Main --selfcheck}: Java, версия SDK, папка проекта, короткий матч своей колонии на учебной
 * карте уровня 1, порт просмотра.
 * Печатает список и одно действие, если что-то мешает играть. Код 0 — играть можно.
 */
public final class SelfCheck {

    static final int SMOKE_TICKS = 50;
    static final Duration VERSION_TIMEOUT = Duration.ofSeconds(3);

    private SelfCheck() {}

    /** Самопроверка в текущей папке. 0 — всё хорошо, 1 — есть что исправить. */
    public static int run(Supplier<Colony> mine) {
        return run(mine, Env.system());
    }

    static int run(Supplier<Colony> mine, Env env) {
        return run(mine, env, null, null);
    }

    /** С адресом сервера — ещё проверка мира на сервере: сервер отвечает, токен подходит, версии совместимы. */
    static int run(Supplier<Colony> mine, Env env, URI server, Supplier<Token.Found> token) {
        Report r = new Report(env);
        env.out().println("Самопроверка «Колонии»");
        java(r);
        version(r, env);
        project(r, env.workDir());
        smoke(r, mine);
        port(r, env);
        if (server != null) {
            server(r, env, server, token);
        }
        return r.finish();
    }

    /**
     * Мир на сервере — отдельная проверка. Сервера не видно или токена нет — это не ошибка: дома и в CI сервера нет.
     * Ошибка — только то, что помешает играть и в классе: другой протокол, старый SDK, токен, который сервер не принял.
     */
    private static void server(Report r, Env env, URI server, Supplier<Token.Found> token) {
        String label = "Сервер мира " + server + ": ";
        Token.Found t = null;
        try {
            t = token.get();
        } catch (IllegalStateException e) {
            r.unknown("Токена нет: для игры на сервере положите его в ~/.colony/token (дома и в CI это не ошибка)");
        }
        if (t != null) {
            String warning = Token.gitWarning(env.workDir(), t.value());
            if (warning != null) {
                r.warn(warning);
            }
        }
        try (ServerLink link = new ServerLink(server, t == null ? "" : t.value())) {
            ServerLink.Reply info = link.info();
            if (info.status() != 200) {
                throw new IOException("ответ " + info.status());
            }
            String protocol = info.body().path("protocol").asText("?");
            String min = info.body().path("sdkMin").asText("0");
            if (Protocol.major(protocol) != Protocol.MAJOR) {
                r.fail(label + "протокол " + protocol + ", а у SDK — " + Protocol.VERSION,
                        "обновите SDK до версии, которую назовёт преподаватель.");
                return;
            }
            if (Protocol.compareVersions(Version.get(), min) < 0) {
                r.fail(label + "нужен SDK " + min + " или новее, а у вас " + Version.get(),
                        "в pom.xml поставьте <colony.sdk.version>" + min + "</colony.sdk.version> и нажмите Maven → Reload.");
                return;
            }
            r.ok(label + "отвечает (протокол " + protocol + ", " + switch (info.body().path("mode").asText()) {
                case "admission" -> "идёт допуск";
                case "challenge" -> "идут бои по вызову";
                default -> "мир " + (info.body().path("state").asText().equals("running") ? "идёт" : "на паузе");
            } + ")");
            if (t == null) {
                return;
            }
            ServerLink.Reply me = link.me();
            if (me.status() == 200) {
                r.ok("Токен из " + t.source() + " подходит: вы — «" + me.body().path("name").asText() + "»");
            } else if (me.status() == 401) {
                r.fail("Сервер не принял токен из " + t.source(),
                        "проверьте токен (одна строка, без пробелов) или попросите у преподавателя новый.");
            } else {
                r.unknown("Токен проверить не удалось: сервер ответил " + me.status());
            }
        } catch (IOException | RuntimeException e) {
            r.unknown(label + "сервер недоступен. В классе проверьте сеть и адрес colony.server; дома и в CI это "
                    + "нормально — играйте локально: Main --local");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    /** Итог проверок: отметки и первое действие, которое нужно сделать. */
    private static final class Report {
        private final Env env;
        private String action;

        Report(Env env) {
            this.env = env;
        }

        void ok(String text) {
            env.out().println("  [ок] " + text);
        }

        void unknown(String text) {
            env.out().println("  [??] " + text);
        }

        void warn(String text) {
            env.out().println("  [!]  " + text);
        }

        void fail(String text, String fix) {
            env.out().flush();
            env.err().println("  [X]  " + text);
            env.err().flush();
            if (action == null) {
                action = fix;
            }
        }

        int finish() {
            if (action == null) {
                env.out().println("Можно играть: запустите «Играть».");
                return 0;
            }
            env.out().println("Что сделать: " + action);
            return 1;
        }
    }

    private static void java(Report r) {
        Runtime.Version v = Runtime.version();
        if (v.feature() >= 21) {
            r.ok("Java " + v);
        } else {
            r.fail("Java " + v + " — нужна 21 или новее",
                    "в IntelliJ: File → Project Structure → SDK → Download JDK → версия 21.");
        }
    }

    private static void version(Report r, Env env) {
        String mine = Version.get();
        Published published = published(env.versionUrl());
        if (published.version() == null) {
            r.unknown("SDK " + mine + ": не удалось проверить, последняя ли это версия — " + published.problem());
            return;
        }
        String last = published.version();
        int cmp = compare(mine, last);
        if (cmp == 0) {
            r.ok("SDK " + mine + " — последняя версия");
        } else if (cmp < 0) {
            r.warn("SDK " + mine + ", а опубликована " + last + ". Обновите: Git → Update Project, затем "
                    + "Maven → Reload.");
        } else {
            r.ok("SDK " + mine + " (опубликована " + last + ")");
        }
    }

    /** Опубликованная версия или причина, по которой её не узнать. */
    record Published(String version, String problem) {}

    /** Версия с сайта; ждём не больше 3 секунд. */
    static Published published(URI url) {
        try (HttpClient client = HttpClient.newBuilder().connectTimeout(VERSION_TIMEOUT)
                .followRedirects(HttpClient.Redirect.NORMAL).build()) {
            HttpResponse<String> resp = client.send(HttpRequest.newBuilder(url).timeout(VERSION_TIMEOUT).GET().build(),
                    HttpResponse.BodyHandlers.ofString());
            String body = resp.body() == null ? "" : resp.body().strip();
            if (resp.statusCode() != 200) {
                return new Published(null, "сайт версий ответил " + resp.statusCode());
            }
            if (!body.matches("[0-9][0-9A-Za-z.\\-]{0,40}")) {
                return new Published(null, "на сайте версий непонятный ответ");
            }
            return new Published(body, null);
        } catch (java.net.http.HttpTimeoutException e) {
            return new Published(null, "сайт версий не ответил за " + VERSION_TIMEOUT.toSeconds() + " с");
        } catch (IOException | RuntimeException e) {
            return new Published(null, "нет связи с сайтом версий");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new Published(null, "проверка прервана");
        }
    }

    /** Сравнение версий вида {@code 0.1.0}, {@code 0.1.0-SNAPSHOT}: сборка {@code -SNAPSHOT} младше выпуска. */
    static int compare(String a, String b) {
        String[] pa = a.split("-", 2);
        String[] pb = b.split("-", 2);
        String[] na = pa[0].split("\\.");
        String[] nb = pb[0].split("\\.");
        for (int i = 0; i < Math.max(na.length, nb.length); i++) {
            int x = i < na.length ? number(na[i]) : 0;
            int y = i < nb.length ? number(nb[i]) : 0;
            if (x != y) {
                return Integer.compare(x, y);
            }
        }
        boolean qa = pa.length > 1;
        boolean qb = pb.length > 1;
        return qa == qb ? 0 : qa ? -1 : 1;
    }

    private static int number(String s) {
        try {
            return Integer.parseInt(s);
        } catch (NumberFormatException e) {
            return 0;
        }
    }

    private static void project(Report r, Path dir) {
        String path = dir.toString();
        if (path.toLowerCase(Locale.ROOT).contains("onedrive")) {
            r.warn("Проект лежит в OneDrive (" + path + "): синхронизация мешает сборке и портит файлы. "
                    + "Перенесите папку проекта, например в C:\\colony, и откройте её заново.");
        }
        try {
            Path probe = Files.createTempFile(dir, ".colony-selfcheck-", ".tmp");
            Files.delete(probe);
            r.ok("Папка проекта: " + path);
        } catch (IOException | RuntimeException e) {
            r.fail("В папку проекта нельзя писать (" + path + "): " + e.getMessage(),
                    "перенесите проект в папку, где у вас есть права на запись, например C:\\colony.");
        }
    }

    /** Короткий матч на первой учебной карте уровня 1: колония не бросает исключений и успевает за такт. */
    private static void smoke(Report r, Supplier<Colony> mine) {
        MatchConfig cfg = Steps.config(Steps.get(1), Training.seeds(1).get(0)).withMaxTicks(SMOKE_TICKS);
        try (Match match = Match.create(cfg, List.of(new ColonySpec("Вы", "ВЫ", mine)))) {
            while (!match.finished()) {
                match.step();
                Frame f = match.frame();
                for (Rejection rej : f.rejections().getOrDefault(1, List.of())) {
                    if (rej.code() == RejectCode.EXCEPTION) {
                        r.fail("Такт " + f.t() + ": " + failure(rej.message()),
                                "исправьте ошибку " + where(rej.message()) + "и запустите самопроверку снова.");
                        match.lastError(1).ifPresent(t -> new Console(r.env.out(), r.env.err()).stackOnce(t));
                        return;
                    }
                    if (rej.code() == RejectCode.TIMEOUT) {
                        r.fail("Такт " + f.t() + ": onTick работал дольше " + cfg.tickTimeoutMillis() + " мс",
                                "onTick должен успевать за " + cfg.tickTimeoutMillis()
                                        + " мс: уберите долгие циклы и ожидания.");
                        return;
                    }
                }
            }
        } catch (RuntimeException e) {
            r.fail("Матч не запустился: " + e, "покажите это сообщение преподавателю.");
            return;
        }
        r.ok("Колония отыграла " + SMOKE_TICKS + " тактов на учебной карте уровня 1 без ошибок");
    }

    /** «IllegalStateException в Crasher.java:14 — сообщение»: текст отказа движка без «код колонии упал» и хвоста. */
    static String failure(String message) {
        String m = message;
        for (String prefix : new String[] {"код колонии упал: ", "код колонии не создался: "}) {
            if (m.startsWith(prefix)) {
                m = m.substring(prefix.length());
            }
        }
        int tail = m.lastIndexOf("; ");
        return tail > 0 ? m.substring(0, tail) : m;
    }

    /** «в MyColony.java:42 » из текста отказа, если там есть место ошибки. */
    private static String where(String message) {
        int at = message.indexOf(" в ");
        if (at < 0) {
            return "";
        }
        String rest = message.substring(at + 3);
        int end = rest.indexOf(' ');
        String place = end < 0 ? rest : rest.substring(0, end);
        place = place.replaceAll("[;,]$", "");
        return place.contains(".java:") ? "в " + place + " " : "";
    }

    private static void port(Report r, Env env) {
        int preferred = env.viewerPort() > 0 ? env.viewerPort() : Env.VIEWER_PORT;
        try (ServerSocket s = new ServerSocket(preferred, 1, ViewerServer.loopback())) {
            r.ok("Порт просмотра " + preferred + " свободен");
            return;
        } catch (IOException e) {
            // занят — проверим, что найдётся другой
        }
        try (ViewerServer s = ViewerServer.start(preferred, new LiveFeed(), env.workDir().resolve("replays"), null)) {
            r.ok("Порт " + preferred + " занят (может, игра уже запущена) — просмотр возьмёт " + s.port());
        } catch (RuntimeException e) {
            r.fail("Не удалось открыть порт на 127.0.0.1: " + e.getMessage(),
                    "проверьте, не блокирует ли антивирус Java, и запустите снова.");
        }
    }
}
