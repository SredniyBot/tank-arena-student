package colony.local;

import colony.engine.Match;
import colony.engine.ReplayWriter;
import java.io.BufferedOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.FileAlreadyExistsException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.file.StandardOpenOption;
import java.util.zip.GZIPOutputStream;

/**
 * Запись повтора без полуфабрикатов: сначала {@code <имя>.json.gz.part} (список повторов его не видит), потом
 * переименование. Прерванная запись оставляет только {@code .part}. Имя занято — берём {@code _2}, {@code _3}…
 */
final class Replays {

    private Replays() {}

    /**
     * Записать повтор в {@code dir/<base>.json.gz} или под первым свободным именем {@code <base>_N.json.gz}.
     *
     * @return файл повтора
     * @throws IOException не удалось записать; временный файл удалён
     */
    static Path write(Match match, Path dir, String base) throws IOException {
        Files.createDirectories(dir);
        for (int i = 1; i < 1000; i++) {
            Path target = dir.resolve(base + (i == 1 ? "" : "_" + i) + ".json.gz");
            Path part = target.resolveSibling(target.getFileName() + ".part");
            if (Files.exists(target)) {
                continue;
            }
            try (OutputStream file = Files.newOutputStream(part, StandardOpenOption.CREATE_NEW,
                    StandardOpenOption.WRITE)) {
                // имя за нами: .part создан атомарно, второй запуск в ту же минуту возьмёт следующее
                try (GZIPOutputStream gz = new GZIPOutputStream(new BufferedOutputStream(file, 1 << 16), 1 << 16)) {
                    ReplayWriter.write(match, gz, false);
                }
            } catch (FileAlreadyExistsException e) {
                continue;
            } catch (IOException | RuntimeException e) {
                Files.deleteIfExists(part);
                throw e;
            }
            try {
                if (Files.exists(target)) {
                    Files.delete(part); // успели раньше нас — пишем под следующим именем
                    continue;
                }
                move(part, target);
                return target;
            } catch (IOException e) {
                Files.deleteIfExists(part);
                throw e;
            }
        }
        throw new IOException("нет свободного имени для повтора " + base);
    }

    private static void move(Path from, Path to) throws IOException {
        try {
            Files.move(from, to, StandardCopyOption.ATOMIC_MOVE);
        } catch (AtomicMoveNotSupportedException e) {
            Files.move(from, to);
        }
    }
}
