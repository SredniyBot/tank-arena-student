package colony.local;

import java.io.IOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.ArrayList;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * Запуск {@code git} без оболочки: аргументы — отдельными строками. Вывод идёт во временные файлы, поэтому
 * таймаут работает, даже если git молчит или пишет много.
 */
final class Git {

    /** Итог команды: код выхода ({@code -1} — git не запустился или не уложился во время), вывод, ошибки. */
    record Result(int code, String out, String err) {
        boolean ok() {
            return code == 0;
        }
    }

    static final long TIMEOUT_SECONDS = 60;

    private Git() {}

    /** Есть ли git в PATH. */
    static boolean available() {
        return run(Path.of("").toAbsolutePath(), 10, "--version").ok();
    }

    static Result run(Path dir, String... args) {
        return run(dir, TIMEOUT_SECONDS, args);
    }

    static Result run(Path dir, long timeoutSeconds, String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add("git");
        cmd.addAll(List.of(args));
        Path out = null;
        Path err = null;
        try {
            out = Files.createTempFile("colony-git-", ".out");
            err = Files.createTempFile("colony-git-", ".err");
            Process p = new ProcessBuilder(cmd).directory(dir.toFile())
                    .redirectOutput(out.toFile()).redirectError(err.toFile()).start();
            p.getOutputStream().close(); // git ничего не спросит: ввода нет
            if (!p.waitFor(timeoutSeconds, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return new Result(-1, "", "git не ответил за " + timeoutSeconds + " с");
            }
            return new Result(p.exitValue(), Files.readString(out, StandardCharsets.UTF_8),
                    Files.readString(err, StandardCharsets.UTF_8));
        } catch (IOException e) {
            return new Result(-1, "", String.valueOf(e.getMessage()));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new Result(-1, "", "прервано");
        } finally {
            delete(out);
            delete(err);
        }
    }

    /** То же, но вывод — в файл {@code target} (например, архив). */
    static Result toFile(Path dir, Path target, String... args) {
        List<String> cmd = new ArrayList<>();
        cmd.add("git");
        cmd.addAll(List.of(args));
        Path err = null;
        try {
            err = Files.createTempFile("colony-git-", ".err");
            Process p = new ProcessBuilder(cmd).directory(dir.toFile())
                    .redirectOutput(target.toFile()).redirectError(err.toFile()).start();
            p.getOutputStream().close(); // git ничего не спросит: ввода нет
            if (!p.waitFor(TIMEOUT_SECONDS, TimeUnit.SECONDS)) {
                p.destroyForcibly();
                return new Result(-1, "", "git не ответил за " + TIMEOUT_SECONDS + " с");
            }
            return new Result(p.exitValue(), "", Files.readString(err, StandardCharsets.UTF_8));
        } catch (IOException e) {
            return new Result(-1, "", String.valueOf(e.getMessage()));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return new Result(-1, "", "прервано");
        } finally {
            delete(err);
        }
    }

    private static void delete(Path p) {
        if (p != null) {
            try {
                Files.deleteIfExists(p);
            } catch (IOException ignored) {
                // временный файл — уберёт система
            }
        }
    }
}
