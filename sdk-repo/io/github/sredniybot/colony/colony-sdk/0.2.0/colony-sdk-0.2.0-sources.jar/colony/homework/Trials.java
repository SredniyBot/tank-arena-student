package colony.homework;

import colony.engine.RuleSet;
import colony.engine.RulesLoader;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.Collection;
import java.util.List;
import java.util.Optional;

/**
 * Двенадцать испытаний домашнего задания — один каталог для SDK ({@code Main --task}, {@code --practice},
 * {@code --try}) и сервера. Каждое пройденное — балл навсегда; засчитываются лучшие {@link #MAX_POINTS}.
 * Правила — лиги 1: только рабочие, счёт — сданная энергия.
 */
public final class Trials {

    /*
     * «Подарочное» (последний аргумент) — по калибровке docs/homework/calibration-2026-11-13.md: колония нейросети,
     * написанная с одного раза по тексту задания, проходит испытания 1, 2, 3, 6 и 11.
     */

    /** Больше баллов за задание не бывает: засчитываются лучшие 10 из 12. */
    public static final int MAX_POINTS = 10;
    /** Попыток в сутки на одно испытание (сутки — по Москве). */
    public static final int ATTEMPTS_PER_DAY = 5;
    /** Пауза между попытками, секунд. */
    public static final int PAUSE_SECONDS = 60;
    /** Сколько сервер ждёт приказы на такт, мс: часов нет — такт идёт, как только приказы пришли. */
    public static final int WAIT_MILLIS = 2000;

    private static final String FOR_ALL = "Для всех";
    private static final String STRUCTURE = "Структура";
    private static final String POWER = "Сила";
    private static final String SOON = "скоро";

    private static final List<Trial> ALL = List.of(
            new Trial(1, "Первый доход", FOR_ALL, "база, рядом жила",
                    "цикл «добыть — сдать»",
                    "У рабочего два дела: идти к жиле или нести груз на базу. Что делать сейчас, решает груз — "
                            + "помните его между тактами.",
                    null, new Trial.PerMap(50), 3, 200, true),
            new Trial(2, "Рост", FOR_ALL, "жилы рядом и подальше; у ближних места на одного",
                    "производство, учёт юнитов",
                    "Рабочий окупается за несколько ходок. Добывают только с соседних клеток жилы: считайте, сколько "
                            + "рабочих уже идёт к каждой.",
                    null, new Trial.Share(70), 3, 600, true),
            new Trial(3, "Лабиринт", FOR_ALL, "жилы за стенами, тупики, ловушки-«подковы»",
                    "поиск пути в ширину",
                    "Поиск в ширину: волна от цели по свободным клеткам даёт расстояние до каждой. Шаг «туда, где "
                            + "ближе по прямой» застревает в подкове.",
                    null, new Trial.Share(80), 3, 600, true),
            new Trial(4, "Узкий коридор", FOR_ALL, "одна жила за проходом шириной в клетку",
                    "очерёдность, заторы",
                    "Двое в одну клетку и обмен местами — столкновение. Нужна очередь: кто идёт, кто ждёт.",
                    SOON, new Trial.Share(70), 3, 600, false),
            new Trial(5, "Устойчивость", STRUCTURE, "посреди прогона жила иссякает, проход закрывается, рабочий исчезает",
                    "обработка ошибок, перестройка плана",
                    "Отказы приходят в lastRejections() следующего такта. План, который не пересчитывается, ломается "
                            + "первым же изменением.",
                    SOON, new Trial.Share(60), 3, 600, false),
            new Trial(6, "Читай мир", STRUCTURE, "жилы разной скорости и дальности, одна быстро иссякает",
                    "сравнение вариантов по данным",
                    "Сравнивайте жилы по энергии за такт: груз делить на время ходки туда, добычи и обратно. Запас "
                            + "виден только в обзоре.",
                    null, new Trial.Share(85), 3, 600, true),
            new Trial(7, "Туман", STRUCTURE, "жилы не видны заранее",
                    "разведка, память о карте",
                    "Обзор показывает только «сейчас». Что увидели однажды, запомните.",
                    SOON, new Trial.Share(75), 3, 600, false),
            new Trial(8, "Проход", STRUCTURE, "короткий путь через скалу, копать дорого",
                    "меняющаяся карта, сброс кеша",
                    "Путь, посчитанный один раз, устаревает, когда меняется карта.",
                    "с механикой «копание»", new Trial.Share(80), 3, 600, false),
            new Trial(9, "Роли", POWER, "карта, где однородная колония порог не берёт",
                    "свои типы, роли",
                    "Один класс на всех рабочих — один способ думать. Разным делам — разные роли.",
                    "с механикой «специализация»", new Trial.Share(80), 3, 600, false),
            new Trial(10, "Зона", POWER, "соперник оспаривает зону",
                    "выбор цели, координация",
                    "Держит тот, кого в зоне больше. Решите, кто идёт в зону, а кто кормит колонию.",
                    "с механикой «зоны»", new Trial.Share(80), 3, 600, false),
            new Trial(11, "Бронза", POWER, "карты для двоих, соперник — «Бронза»",
                    "код для любой карты",
                    "Колония, подогнанная под одну карту, проигрывает на следующей. Тренируйтесь на разных зёрнах.",
                    null, new Trial.Wins(4, "bronze", "Бронза"), 5, 600, true),
            new Trial(12, "Серебро", POWER, "карты для двоих, соперник — «Серебро»",
                    "то же, сильнее",
                    "«Серебро» выбирает жилы по выгоде, а не по близости.",
                    SOON, new Trial.Wins(4, "silver", "Серебро"), 5, 600, false));

    private Trials() {}

    public static List<Trial> all() {
        return ALL;
    }

    public static Optional<Trial> find(int number) {
        return ALL.stream().filter(t -> t.number() == number).findFirst();
    }

    /** Испытание по номеру или понятная ошибка. */
    public static Trial get(int number) {
        return find(number).orElseThrow(() -> new IllegalArgumentException("испытания " + number + " нет: есть 1–"
                + ALL.size()));
    }

    /** Первое открытое испытание, которого нет среди пройденных; пусто — открытые пройдены все. */
    public static Optional<Trial> next(Collection<Integer> passed) {
        return ALL.stream().filter(t -> t.available() && !passed.contains(t.number())).findFirst();
    }

    /** Баллы: пройденных испытаний, но не больше {@link #MAX_POINTS}. */
    public static int points(int passed) {
        return Math.min(MAX_POINTS, passed);
    }

    /** Правила испытания: лига 1, длина карты — своя у испытания. */
    public static RuleSet rules(Trial t) {
        ObjectNode json = RulesLoader.toJson(RulesLoader.league(1));
        json.put("maxTicks", t.ticks());
        return RulesLoader.fromJson(json);
    }
}
