package colony.protocol;

/**
 * Версии протокола и SDK. Протокол: мажорная.минорная; клиент и сервер понимают друг друга при равной мажорной,
 * а сервер не пускает клиента младше {@link #PROTOCOL_MIN}.
 *
 * <p>1.1 — ДЗ «лестница возможностей»: приказы {@code CONSTRUCT} (склад), {@code DIG}, {@code UPGRADE},
 * {@code ATTACK}; в обзоре постройки, прочность завалов, улучшения юнитов и возможности колонии; в рельефе карты
 * завал — {@code %}. Клиент 1.0 принял бы завал за пол, поэтому сервер 1.1 его не пускает.
 */
public final class Versions {

    /** Версия протокола {@code /api/v1}. */
    public static final String PROTOCOL = "1.1";
    public static final int MAJOR = 1;
    /** Клиента младше этой версии сервер не пускает: он неверно поймёт карту. */
    public static final String PROTOCOL_MIN = "1.1";

    private Versions() {}

    /** Мажорная часть {@code "1.2"} → 1; непонятная — -1. */
    public static int major(String version) {
        if (version == null) {
            return -1;
        }
        int dot = version.indexOf('.');
        try {
            return Integer.parseInt(dot < 0 ? version.strip() : version.substring(0, dot).strip());
        } catch (NumberFormatException e) {
            return -1;
        }
    }

    /** Сравнить версии по числам: {@code 0.1.0-SNAPSHOT} равна {@code 0.1.0}. */
    public static int compare(String a, String b) {
        String[] na = a.split("-", 2)[0].split("\\.");
        String[] nb = b.split("-", 2)[0].split("\\.");
        for (int i = 0; i < Math.max(na.length, nb.length); i++) {
            int x = i < na.length ? number(na[i]) : 0;
            int y = i < nb.length ? number(nb[i]) : 0;
            if (x != y) {
                return Integer.compare(x, y);
            }
        }
        return 0;
    }

    /**
     * Почему сервер не пускает клиента на протоколе {@code client}; {@code null} — пускает. Одна строка для входа
     * в матч и для начала попытки.
     */
    public static String refusal(String client) {
        if (major(client) != MAJOR) {
            return "SDK говорит на протоколе " + client + ", а сервер — на " + PROTOCOL + ": обновите SDK или сервер";
        }
        if (compare(client, PROTOCOL_MIN) < 0) {
            return "SDK говорит на протоколе " + client + ", а серверу нужен " + PROTOCOL_MIN + " или новее: обновите "
                    + "SDK (версия — в pom.xml)";
        }
        return null;
    }

    private static int number(String s) {
        try {
            return Integer.parseInt(s.strip());
        } catch (NumberFormatException e) {
            return 0;
        }
    }
}
