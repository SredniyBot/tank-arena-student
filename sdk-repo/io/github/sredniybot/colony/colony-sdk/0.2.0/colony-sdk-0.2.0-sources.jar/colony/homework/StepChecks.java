package colony.homework;

import colony.api.Colony;
import java.nio.file.Path;
import java.util.List;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.IntStream;
import java.util.stream.Stream;
import org.junit.jupiter.api.Assertions;
import org.junit.jupiter.api.DynamicTest;

/**
 * Уровень домашнего задания как тест JUnit: по тесту на каждую из пяти учебных карт и итог по всем ({@link Training}).
 *
 * <pre>{@code
 * @TestFactory
 * Stream<DynamicTest> уровень3() {
 *     return StepChecks.check(3, MyColony::new);
 * }
 * }</pre>
 *
 * Карта красная, только если {@code onTick} бросал исключение; итог зелёный, если на картах вместе сдано не меньше
 * цели × число карт — то же правило, что в попытке. У каждой
 * карты в сообщении — ссылка на страницу повтора в {@code replays/}: она открывается в браузере без сервера.
 * Карты те же при каждом запуске, поэтому «Rerun Failed» в IntelliJ играет те же карты, а запуск с жуком
 * останавливается на точках останова.
 */
public final class StepChecks {

    private StepChecks() {}

    /**
     * Тесты уровня {@code level} на учебных картах; повторы — в {@code replays/} текущей папки (папки проекта).
     *
     * @param level  номер уровня, 1–5
     * @param colony своя колония: {@code MyColony::new}
     */
    public static Stream<DynamicTest> check(int level, Supplier<Colony> colony) {
        return check(level, colony, Path.of(""));
    }

    static Stream<DynamicTest> check(int level, Supplier<Colony> colony, Path workDir) {
        return check(Steps.get(level), colony, workDir);
    }

    /** То же для уровня {@code s} — в тестах SDK, где нужна своя цель. */
    static Stream<DynamicTest> check(Step s, Supplier<Colony> colony, Path workDir) {
        Objects.requireNonNull(colony, "colony");
        List<Long> seeds = Training.seeds(s.number());
        Path dir = workDir.toAbsolutePath().normalize();
        // карты играются один раз: и тесты карт, и итог берут один и тот же результат
        Training.MapRun[] runs = new Training.MapRun[seeds.size()];
        java.util.function.IntFunction<Training.MapRun> run = i -> {
            if (runs[i] == null) {
                runs[i] = Training.play(s, i + 1, seeds.get(i), colony, dir);
            }
            return runs[i];
        };
        Stream<DynamicTest> maps = IntStream.range(0, seeds.size()).mapToObj(i -> DynamicTest.dynamicTest(
                "карта " + (i + 1) + ", зерно " + seeds.get(i), () -> verify(run.apply(i))));
        DynamicTest total = DynamicTest.dynamicTest("итого на " + seeds.size() + " картах", () -> {
            List<Training.MapRun> all = IntStream.range(0, seeds.size()).mapToObj(run).toList();
            int sum = all.stream().mapToInt(Training.MapRun::delivered).sum();
            int need = s.goal() * all.size();
            String each = String.join(" + ", all.stream().map(r -> String.valueOf(r.delivered())).toList());
            if (sum < need) {
                Assertions.fail("сдано " + each + " = " + sum + " из " + need + ", не хватило " + (need - sum)
                        + ". Уровень проходит, когда на картах вместе сдано не меньше цели.");
            }
            System.out.println("сдано " + each + " = " + sum + " из " + need + " — можно сдавать.");
        });
        return Stream.concat(maps, Stream.of(total));
    }

    /**
     * Карта: исключение в коде — провал со ссылкой на повтор и стеком; иначе — строка «сдано N (в среднем нужно M)».
     * Решает итог по всем картам: одна слабая карта уровень не губит.
     */
    static void verify(Training.MapRun r) {
        String replay = replayText(r);
        if (r.firstException() != null || r.exceptionTicks() > 0) {
            String first = r.firstFailure() != null ? r.firstFailure() : "код колонии бросал исключения";
            Assertions.fail(first + ". Тактов с исключением: " + r.exceptionTicks() + ". Сдано " + r.delivered()
                    + ". " + replay, r.firstException());
        }
        String timeouts = r.timeoutTicks() == 0 ? "" : " onTick не уложился во время на " + r.timeoutTicks()
                + " тактах.";
        System.out.println("сдано " + r.delivered() + " (в среднем нужно " + r.step().goal() + ")." + timeouts + " "
                + replay);
    }

    /** «Повтор: file:///C:/colony/replays/step3-3102.html»: такую ссылку IntelliJ делает кликабельной. */
    static String replayText(Training.MapRun r) {
        if (r.page() == null) {
            return "Повтор не записан: " + r.replayProblem();
        }
        return "Повтор: " + r.page().toUri().toASCIIString();
    }
}
