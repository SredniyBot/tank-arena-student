package colony.local;

import colony.api.Colony;
import java.io.File;
import java.io.IOException;
import java.io.UncheckedIOException;
import java.net.MalformedURLException;
import java.net.URISyntaxException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;
import java.util.function.Supplier;
import java.util.stream.Stream;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;
import javax.tools.Diagnostic;
import javax.tools.DiagnosticCollector;
import javax.tools.JavaCompiler;
import javax.tools.JavaFileObject;
import javax.tools.StandardJavaFileManager;
import javax.tools.ToolProvider;

/**
 * «Прошлая версия»: своя колония с тега git. Исходники {@code src/main/java} на теге выгружаются во временную папку,
 * компилируются JDK против текущего classpath и загружаются отдельным загрузчиком классов: классы тега важнее
 * текущих с теми же именами. Класс колонии — {@code colony.class} из {@code colony.properties} на теге (или в папке
 * проекта), по умолчанию {@code student.MyColony}.
 */
public final class PastVersion {

    /** Понятная ошибка: что не так и что сделать. */
    public static final class Failure extends RuntimeException {
        Failure(String message) {
            super(message);
        }

        Failure(String message, Throwable cause) {
            super(message, cause);
        }
    }

    private static final String TEMP_PREFIX = "colony-past-";

    private PastVersion() {}

    /**
     * Скомпилировать колонию с тега и вернуть фабрику: каждый вызов — новый экземпляр.
     *
     * @param projectDir папка проекта (репозиторий git)
     * @param tag        тег, например {@code v1}
     * @throws Failure нет git, нет тега, нет JDK, код не компилируется — с подсказкой по-русски
     */
    public static Supplier<Colony> load(Path projectDir, String tag) {
        return load(projectDir, tag, PastVersion.class.getClassLoader());
    }

    static Supplier<Colony> load(Path projectDir, String tag, ClassLoader parent) {
        checkTag(tag);
        Path dir = projectDir.toAbsolutePath().normalize();
        checkGit(dir);
        // «--» не нужен: имя тега проверено, а rev-parse получает его одной строкой без оболочки
        Git.Result found = Git.run(dir, "rev-parse", "--verify", "--quiet", "refs/tags/" + tag + "^{commit}");
        String commit = found.out().strip();
        if (!found.ok() || !commit.matches("[0-9a-f]{40}|[0-9a-f]{64}")) {
            throw new Failure("Тега «" + tag + "» нет. Создайте его на нужном коммите: git tag " + tag
                    + " — или посмотрите список: git tag");
        }
        JavaCompiler javac = ToolProvider.getSystemJavaCompiler();
        if (javac == null) {
            throw new Failure("Для прошлой версии нужен JDK, а программа запущена без компилятора. В IntelliJ: "
                    + "File → Project Structure → SDK — выберите JDK 21.");
        }
        sweepOld();
        Path work;
        try {
            work = Files.createTempDirectory(TEMP_PREFIX);
        } catch (IOException e) {
            throw new Failure("Не удалось создать временную папку: " + e.getMessage(), e);
        }
        deleteOnExit(work);
        Path src = work.resolve("src");
        Path classes = work.resolve("classes");
        Path zip = work.resolve("tag.zip");
        if (!Git.toFile(dir, zip, "archive", "--format=zip", commit, "src/main/java").ok()) {
            throw new Failure("На теге «" + tag + "» нет папки src/main/java.");
        }
        List<Path> sources = unzip(zip, src);
        if (sources.isEmpty()) {
            throw new Failure("На теге «" + tag + "» в src/main/java нет файлов .java.");
        }
        compile(javac, tag, sources, classes);
        deleteTree(src); // исходники и архив больше не нужны; классы нужны, пока идёт матч
        deleteTree(zip);

        // «./» — от папки проекта, а не от корня репозитория: проект может лежать в подпапке
        Git.Result props = Git.run(dir, "show", commit + ":./" + ColonyProperties.FILE);
        String className = props.ok() ? ColonyProperties.parse(props.out()).colonyClass()
                : ColonyProperties.load(dir).colonyClass();
        URLClassLoader loader = new ChildFirstLoader("colony-past", new URL[] {url(classes)}, parent);
        Class<?> type;
        try {
            // без инициализации: static колонии выполнится при её создании — в потоке колонии, под таймаутом
            type = Class.forName(className, false, loader);
        } catch (ClassNotFoundException | LinkageError e) {
            throw new Failure("На теге «" + tag + "» нет класса " + className
                    + ". Имя класса колонии задаёт colony.class в colony.properties.", e);
        }
        if (!Colony.class.isAssignableFrom(type)) {
            throw new Failure(className + " на теге «" + tag + "» не реализует colony.api.Colony.");
        }
        try {
            type.getDeclaredConstructor();
        } catch (NoSuchMethodException e) {
            throw new Failure(className + " на теге «" + tag + "»: нужен конструктор без параметров.", e);
        }
        return () -> {
            try {
                var c = type.getDeclaredConstructor();
                c.setAccessible(true);
                return (Colony) c.newInstance();
            } catch (ReflectiveOperationException e) {
                Throwable cause = e.getCause() != null ? e.getCause() : e;
                if (cause instanceof RuntimeException re) {
                    throw re;
                }
                if (cause instanceof Error er) {
                    throw er;
                }
                throw new IllegalStateException("не удалось создать " + className + ": " + cause, cause);
            }
        };
    }

    /**
     * Имя тега — как у git, только без экзотики: буквы, цифры, {@code . _ / -}; не с «-», без «..», «//», без «.» в
     * начале и в конце. Так имя нельзя принять за ключ git и нельзя разрезать на несколько аргументов.
     */
    static void checkTag(String tag) {
        if (tag == null || tag.isBlank()) {
            throw new Failure("Не задан тег прошлой версии: --opponent=past:v1");
        }
        if (tag.startsWith("-")) {
            throw new Failure("Тег не может начинаться с «-»: «" + tag + "».");
        }
        if (!tag.matches("[\\p{L}\\p{N}._/-]{1,100}") || tag.contains("..") || tag.contains("//")
                || tag.startsWith(".") || tag.startsWith("/") || tag.endsWith(".") || tag.endsWith("/")
                || tag.endsWith(".lock")) {
            throw new Failure("Тег «" + tag + "» не подходит: можно буквы, цифры и . _ / - (например v1, k1-final).");
        }
    }

    private static void compile(JavaCompiler javac, String tag, List<Path> sources, Path classes) {
        DiagnosticCollector<JavaFileObject> diagnostics = new DiagnosticCollector<>();
        try (StandardJavaFileManager files = javac.getStandardFileManager(diagnostics, Locale.ROOT,
                StandardCharsets.UTF_8)) {
            Files.createDirectories(classes);
            List<String> options = List.of("-d", classes.toString(), "-encoding", "UTF-8", "-proc:none",
                    "-nowarn", "-g", "-classpath", classpath());
            boolean ok = javac.getTask(null, files, diagnostics, options, null,
                    files.getJavaFileObjectsFromPaths(sources)).call();
            if (!ok) {
                StringBuilder msg = new StringBuilder("Код на теге «" + tag + "» не компилируется:");
                int shown = 0;
                for (Diagnostic<? extends JavaFileObject> d : diagnostics.getDiagnostics()) {
                    if (d.getKind() != Diagnostic.Kind.ERROR) {
                        continue;
                    }
                    if (shown++ == 5) {
                        msg.append("\n  …");
                        break;
                    }
                    String file = d.getSource() == null ? "" : Paths.get(d.getSource().toUri()).getFileName() + ":"
                            + d.getLineNumber() + ": ";
                    msg.append("\n  ").append(file).append(d.getMessage(Locale.ROOT));
                }
                throw new Failure(msg.toString());
            }
        } catch (IOException e) {
            throw new Failure("Не удалось скомпилировать код с тега «" + tag + "»: " + e.getMessage(), e);
        }
    }

    /** Текущий classpath плюс место, где лежит API студента (на случай укороченного classpath в IntelliJ). */
    private static String classpath() {
        Set<String> parts = new LinkedHashSet<>();
        try {
            var cs = Colony.class.getProtectionDomain().getCodeSource();
            if (cs != null) {
                parts.add(Paths.get(cs.getLocation().toURI()).toString());
            }
        } catch (URISyntaxException | RuntimeException e) {
            // нет — обойдёмся java.class.path
        }
        for (String p : System.getProperty("java.class.path", "").split(File.pathSeparator)) {
            if (!p.isBlank()) {
                parts.add(p);
            }
        }
        return String.join(File.pathSeparator, parts);
    }

    private static List<Path> unzip(Path zip, Path into) {
        List<Path> sources = new ArrayList<>();
        try (ZipInputStream in = new ZipInputStream(Files.newInputStream(zip), StandardCharsets.UTF_8)) {
            for (ZipEntry e; (e = in.getNextEntry()) != null; ) {
                Path target = into.resolve(e.getName()).normalize();
                if (!target.startsWith(into)) {
                    continue;
                }
                if (e.isDirectory()) {
                    Files.createDirectories(target);
                    continue;
                }
                Files.createDirectories(target.getParent());
                Files.copy(in, target);
                if (target.getFileName().toString().endsWith(".java")) {
                    sources.add(target);
                }
            }
        } catch (IOException e) {
            throw new Failure("Не удалось распаковать исходники с тега: " + e.getMessage(), e);
        }
        sources.sort(Comparator.naturalOrder());
        return sources;
    }

    private static void checkGit(Path dir) {
        if (!Git.available()) {
            throw new Failure("Не найден git. Установите Git (https://git-scm.com) и перезапустите IntelliJ.");
        }
        Git.Result inside = Git.run(dir, "rev-parse", "--is-inside-work-tree");
        if (!inside.ok()) {
            String why = inside.err().lines().findFirst().orElse("").strip();
            throw new Failure("Папка " + dir + " — не репозиторий git: прошлая версия берётся из тега git."
                    + (why.isEmpty() ? "" : " Git: " + why));
        }
    }

    private static URL url(Path dir) {
        try {
            return dir.toUri().toURL();
        } catch (MalformedURLException e) {
            throw new UncheckedIOException(e);
        }
    }

    private static void deleteOnExit(Path dir) {
        Runtime.getRuntime().addShutdownHook(new Thread(() -> deleteTree(dir), "colony-past-cleanup"));
    }

    /** Папки прошлых запусков старше суток: их оставляет программа, которую закрыли без завершения. */
    private static void sweepOld() {
        Path tmp = Path.of(System.getProperty("java.io.tmpdir"));
        long dayAgo = System.currentTimeMillis() - 24L * 3600 * 1000;
        try (Stream<Path> dirs = Files.list(tmp)) {
            dirs.filter(d -> d.getFileName().toString().startsWith(TEMP_PREFIX) && Files.isDirectory(d))
                    .filter(d -> {
                        try {
                            return Files.getLastModifiedTime(d).toMillis() < dayAgo;
                        } catch (IOException e) {
                            return false;
                        }
                    })
                    .forEach(PastVersion::deleteTree);
        } catch (IOException | RuntimeException ignored) {
            // не убрали — уберёт система
        }
    }

    private static void deleteTree(Path root) {
        try (Stream<Path> walk = Files.walk(root)) {
            walk.sorted(Comparator.reverseOrder()).forEach(p -> p.toFile().delete());
        } catch (IOException | RuntimeException ignored) {
            // временные файлы — уберёт система
        }
    }
}
