package colony.homework;

import colony.api.DepositKind;
import colony.engine.GameMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;
import java.util.SplittableRandom;

/**
 * Карты пяти шагов «лестницы возможностей» (прототип). У шага своё семейство, карта задаётся зерном: одно зерно —
 * одна и та же карта и в тренировке, и в попытке. Жилы не иссякают за матч.
 *
 * <p>Фоновая глубина задаётся здесь и студенту не называется. Чтобы она была ровной от карты к карте, генератор
 * сам прогоняет жадный шаг ({@link #greedy}, он повторяет {@code Pathfinder.SIMPLE}) и поиск в ширину и
 * отбрасывает карты не того вида:
 * <ul>
 *     <li>шаги 1–2: жадный шаг доходит до каждой жилы и обратно с любой клетки у базы;</li>
 *     <li>шаги 3–5: дальняя жила с вероятностью {@link #TRAP} закрыта карманом или стеной, где жадный шаг
 *     застревает с любой клетки у базы; иначе жадный шаг доходит до неё и обратно с любой клетки. Смешанные карты
 *     отбрасываются.</li>
 * </ul>
 */
public final class StepMaps {

    /** Доля карт шагов 3–5, где дальняя жила закрыта от жадного шага. */
    static final double TRAP = 0.4;

    private StepMaps() {}

    /** На карте шага {@code step} по зерну {@code seed} дальняя жила закрыта от жадного шага (только шаги 3–5). */
    public static boolean trap(int step, long seed) {
        return step >= 3 && new SplittableRandom(mix(mix(seed) + 7_000 + step)).nextDouble() < TRAP;
    }

    /** Карта шага {@code step} по зерну {@code seed}. */
    public static GameMap build(int step, long seed) {
        SplittableRandom rnd = new SplittableRandom(mix(mix(seed) + 7_000 + step));
        String name = "abilities-" + step + "-" + seed;
        boolean trap = rnd.nextDouble() < TRAP;
        for (int attempt = 0; attempt < 5000; attempt++) {
            TrialMaps.Grid g = switch (step) {
                case 1 -> trip(rnd);
                case 2 -> hire(rnd);
                case 3 -> depot(rnd, trap);
                case 4 -> rubble(rnd, trap);
                case 5 -> upgrade(rnd, trap);
                default -> throw new IllegalArgumentException("шага " + step + " нет: есть 1–5");
            };
            if (g != null) {
                return g.toMap(name);
            }
        }
        throw new IllegalStateException("не удалось построить карту " + name);
    }

    private static long mix(long z) {
        z = (z ^ (z >>> 33)) * 0xff51afd7ed558ccdL;
        z = (z ^ (z >>> 33)) * 0xc4ceb9fe1a85ec53L;
        return z ^ (z >>> 33);
    }

    // ---- 1. Ходка: база, жила в 4–8 шагах, редкие одиночные камни ----

    private static TrialMaps.Grid trip(SplittableRandom r) {
        TrialMaps.Grid g = new TrialMaps.Grid(16, 12, Map.of(DepositKind.NORMAL, 5000));
        int bx = 2 + r.nextInt(12);
        int by = 2 + r.nextInt(8);
        g.set(bx, by, '1');
        if (!g.place(r, '*', bx, by, 4, 8)) {
            return null;
        }
        int stones = 1 + r.nextInt(4);
        for (int i = 0; i < stones; i++) {
            g.stone(r);
        }
        return greedyToAll(g, bx, by) ? g : null;
    }

    // ---- 2. Найм: две-три жилы в 5–7 шагах, у каждой 1–2 открытые стороны (к базе), всего мест не меньше четырёх ----

    private static TrialMaps.Grid hire(SplittableRandom r) {
        TrialMaps.Grid g = new TrialMaps.Grid(20, 14, Map.of(DepositKind.NORMAL, 5000));
        int bx = 3 + r.nextInt(14);
        int by = 3 + r.nextInt(8);
        g.set(bx, by, '1');
        int deposits = 2 + r.nextInt(2);
        int sides = 0;
        for (int i = 0; i < deposits; i++) {
            int open = 1 + r.nextInt(2);
            if (!pocket(g, r, '*', bx, by, 5, 7, open)) {
                return null;
            }
            sides += open;
        }
        if (sides < 4) {
            return null;
        }
        int stones = r.nextInt(3);
        for (int i = 0; i < stones; i++) {
            g.stone(r);
        }
        return greedyToAll(g, bx, by) ? g : null;
    }

    // ---- 3. Склад: богатая жила в 34–40 шагах пути (две стороны), ближняя в нише; стены и карманы ----

    private static TrialMaps.Grid depot(SplittableRandom r, boolean trap) {
        TrialMaps.Grid g = new TrialMaps.Grid(40, 20, Map.of(DepositKind.NORMAL, 5000, DepositKind.RICH, 5000));
        int bx = 2 + r.nextInt(2);
        int by = 4 + r.nextInt(12);
        g.set(bx, by, '1');
        int fx = 33 + r.nextInt(4);
        int fy = 3 + r.nextInt(14);
        if (!pocketAt(g, '$', fx, fy, bx, by, 2)) {
            return null;
        }
        if (!pocket(g, r, '*', bx, by, 4, 6, 1)) {
            return null;
        }
        if (!obstacles(g, r, bx, by, fx, fy, trap, false)) {
            return null;
        }
        int d = path(g, bx, by, fx, fy, false);
        return d >= 34 && d <= 40 && greedyTrip(g, bx, by, nearDeposit(g), false) ? g : null;
    }

    // ---- 4. Завалы: стена поперёк карты, в ней пояс завала; обход — через дальний край ----

    private static TrialMaps.Grid rubble(SplittableRandom r, boolean trap) {
        int w = 32;
        int h = 20;
        TrialMaps.Grid g = new TrialMaps.Grid(w, h, Map.of(DepositKind.RICH, 5000));
        int bx = 2 + r.nextInt(3);
        int by = 4 + r.nextInt(12);
        g.set(bx, by, '1');
        int wx = 11 + r.nextInt(3);
        boolean gapTop = r.nextBoolean();
        for (int y = 0; y < h; y++) {
            boolean gap = gapTop ? y <= 1 : y >= h - 2;
            if (!gap) {
                g.set(wx, y, '#');
                g.set(wx + 1, y, '#');
            }
        }
        int fx = wx + 5 + r.nextInt(6);
        int fy = 3 + r.nextInt(h - 6);
        if (!g.clear(fx, fy, 2)) {
            return null;
        }
        g.set(fx, fy, '$');
        // дверь из завала — четыре клетки стены в два ряда; у «ловушки» — вне жадного пути, иначе — на нём
        List<int[]> starts = starts(g, bx, by);
        int line = greedyCrossing(g, starts.get(0), fx, fy, wx);
        int door = trap ? 2 + r.nextInt(h - 8) : line - 1 - r.nextInt(3);
        if (trap && Math.abs(door + 1.5 - line) < 4.5) {
            return null;
        }
        if (door < 2 || door + 3 > h - 3) {
            return null;
        }
        for (int y = door; y <= door + 3; y++) {
            g.set(wx, y, '%');
            g.set(wx + 1, y, '%');
        }
        int stones = r.nextInt(3);
        for (int i = 0; i < stones; i++) {
            g.stone(r);
        }
        if (trap ? !greedyStuck(g, bx, by, fx, fy, true) : !greedyTrip(g, bx, by, new int[] {fx, fy}, true)) {
            return null;
        }
        int direct = path(g, bx, by, fx, fy, true);
        int detour = path(g, bx, by, fx, fy, false);
        return direct >= 10 && direct <= 18 && detour >= direct + 16 ? g : null;
    }

    // ---- 5. Прокачка: ближняя жила в нише (одно место), дальняя богатая (четыре стороны) за стенами ----

    private static TrialMaps.Grid upgrade(SplittableRandom r, boolean trap) {
        TrialMaps.Grid g = new TrialMaps.Grid(30, 18, Map.of(DepositKind.NORMAL, 5000, DepositKind.RICH, 5000));
        int bx = 2 + r.nextInt(3);
        int by = 4 + r.nextInt(10);
        g.set(bx, by, '1');
        int fx = 18 + r.nextInt(8);
        int fy = 3 + r.nextInt(12);
        if (!g.clear(fx, fy, 2)) {
            return null;
        }
        g.set(fx, fy, '$');
        if (!pocket(g, r, '*', bx, by, 5, 7, 1)) {
            return null;
        }
        if (!obstacles(g, r, bx, by, fx, fy, trap, false)) {
            return null;
        }
        int d = path(g, bx, by, fx, fy, false);
        return d >= 17 && d <= 23 && greedyTrip(g, bx, by, nearDeposit(g), false) ? g : null;
    }

    // ---- препятствия между базой и дальней жилой ----

    /**
     * Отрезки стен; у «ловушки» ещё подкова, открытая к базе, прямо на жадном пути к дальней жиле. Проверяет вид
     * карты: у ловушки жадный шаг застревает с каждой клетки у базы, иначе — доходит и возвращается.
     */
    private static boolean obstacles(TrialMaps.Grid g, SplittableRandom r, int bx, int by, int fx, int fy,
                                     boolean trap, boolean dig) {
        List<int[]> starts = starts(g, bx, by);
        if (trap) {
            List<int[]> line = greedyLine(g, starts.get(0), fx, fy);
            if (line.size() < 12) {
                return false;
            }
            int[] at = line.get(line.size() / 3 + r.nextInt(line.size() / 3));
            int rad = 2 + r.nextInt(2);
            if (!cupAt(g, at[0], at[1], Integer.signum(bx - fx), rad)) {
                return false;
            }
        }
        int segments = 3 + r.nextInt(3);
        for (int i = 0; i < segments; i++) {
            g.segment(r, 3, 6);
        }
        return trap ? greedyStuck(g, bx, by, fx, fy, dig) : greedyTrip(g, bx, by, new int[] {fx, fy}, dig);
    }

    /**
     * Подкова радиуса {@code rad} с центром (x, y), открытая по оси x в сторону {@code ox}: заходишь в неё по прямой
     * и упираешься в дно.
     */
    private static boolean cupAt(TrialMaps.Grid g, int x, int y, int ox, int rad) {
        if (!g.clear(x, y, rad + 1)) {
            return false;
        }
        for (int dy = -rad; dy <= rad; dy++) {
            for (int dx = -rad; dx <= rad; dx++) {
                if (Math.max(Math.abs(dx), Math.abs(dy)) != rad) {
                    continue;
                }
                if (dx == rad * ox && Math.abs(dy) < rad) {
                    continue; // открытая сторона
                }
                g.set(x + dx, y + dy, '#');
            }
        }
        return true;
    }

    /** Жила {@code kind} в нише в {@code min..max} шагах от базы: см. {@link #pocketAt}. */
    private static boolean pocket(TrialMaps.Grid g, SplittableRandom r, char kind, int bx, int by, int min, int max,
                                  int open) {
        for (int i = 0; i < 300; i++) {
            int x = 2 + r.nextInt(g.w - 4);
            int y = 2 + r.nextInt(g.h - 4);
            int d = Math.abs(x - bx) + Math.abs(y - by);
            if (d >= min && d <= max && pocketAt(g, kind, x, y, bx, by, open)) {
                return true;
            }
        }
        return false;
    }

    /**
     * Жила {@code kind} в (x, y), открытая с {@code open} (1 или 2) сторон — тех, что смотрят на базу; остальные
     * стороны — стена. Вокруг ниши — пол.
     */
    private static boolean pocketAt(TrialMaps.Grid g, char kind, int x, int y, int bx, int by, int open) {
        if (!g.clear(x, y, 2)) {
            return false;
        }
        int sx = Integer.signum(bx - x);
        int sy = Integer.signum(by - y);
        int[] alongX = {sx == 0 ? 1 : sx, 0};
        int[] alongY = {0, sy == 0 ? 1 : sy};
        boolean xFirst = Math.abs(bx - x) >= Math.abs(by - y);
        List<int[]> openSides = new ArrayList<>();
        openSides.add(xFirst ? alongX : alongY);
        if (open == 2) {
            openSides.add(xFirst ? alongY : alongX);
        }
        g.set(x, y, kind);
        for (int[] s : new int[][] {{1, 0}, {-1, 0}, {0, 1}, {0, -1}}) {
            boolean isOpen = openSides.stream().anyMatch(o -> o[0] == s[0] && o[1] == s[1]);
            if (!isOpen) {
                g.set(x + s[0], y + s[1], '#');
            }
        }
        return true;
    }

    // ---- проверки ----

    /** Свободные клетки у базы — откуда выходят рабочие. */
    static List<int[]> starts(TrialMaps.Grid g, int bx, int by) {
        List<int[]> out = new ArrayList<>();
        for (int[] n : around(bx, by)) {
            if (g.floor(n[0], n[1])) {
                out.add(n);
            }
        }
        return out;
    }

    /** Жадный шаг доходит до каждой жилы и обратно (см. {@link #greedyTrip}). */
    private static boolean greedyToAll(TrialMaps.Grid g, int bx, int by) {
        if (starts(g, bx, by).size() < 2) {
            return false;
        }
        for (int y = 0; y < g.h; y++) {
            for (int x = 0; x < g.w; x++) {
                if ((g.at(x, y) == '*' || g.at(x, y) == '$') && !greedyTrip(g, bx, by, new int[] {x, y}, false)) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Жадный шаг доходит от каждой клетки у базы до жилы {@code d}, а от каждой её открытой стороны — до базы.
     * {@code dig}: как колония шага 4, которая разбирает завал по пути; разобранное остаётся открытым и на обратном
     * пути.
     */
    private static boolean greedyTrip(TrialMaps.Grid g0, int bx, int by, int[] d, boolean dig) {
        if (d == null) {
            return false;
        }
        List<int[]> starts = starts(g0, bx, by);
        if (starts.size() < 2) {
            return false;
        }
        TrialMaps.Grid g = copy(g0);
        for (int[] s : starts) {
            if (greedy(g, s[0], s[1], d[0], d[1], dig) < 0) {
                return false;
            }
        }
        for (int[] n : around(d[0], d[1])) {
            if (g.floor(n[0], n[1]) && greedy(g, n[0], n[1], bx, by, dig) < 0) {
                return false;
            }
        }
        return true;
    }

    /** Жадный шаг не доходит до (fx, fy) ни с одной клетки у базы. */
    private static boolean greedyStuck(TrialMaps.Grid g0, int bx, int by, int fx, int fy, boolean dig) {
        for (int[] s : starts(g0, bx, by)) {
            if (greedy(copy(g0), s[0], s[1], fx, fy, dig) >= 0) {
                return false;
            }
        }
        return true;
    }

    /** Ближняя жила ({@code *}) — у шагов 3 и 5 она одна. */
    private static int[] nearDeposit(TrialMaps.Grid g) {
        for (int y = 0; y < g.h; y++) {
            for (int x = 0; x < g.w; x++) {
                if (g.at(x, y) == '*') {
                    return new int[] {x, y};
                }
            }
        }
        return null;
    }

    /**
     * Сколько шагов делает жадный шаг ({@code Pathfinder.SIMPLE}) от (x, y), пока не встанет у цели (tx, ty);
     * {@code -1} — застрял (вернулся в клетку, где уже был). {@code dig}: как колония шага 4 — если соседняя клетка
     * ближе к цели завалена, рабочий разбирает её (в сетке {@code g} она становится полом) и идёт дальше.
     */
    static int greedy(TrialMaps.Grid g, int x, int y, int tx, int ty, boolean dig) {
        Set<Integer> seen = new HashSet<>();
        int steps = 0;
        while (steps < 4 * (g.w + g.h)) {
            if (x == tx && y == ty || Math.abs(x - tx) + Math.abs(y - ty) == 1 && !g.floor(tx, ty)) {
                return steps;
            }
            if (!seen.add(y * g.w + x)) {
                return -1;
            }
            int[] d = dig ? rubbleCloser(g, x, y, tx, ty) : null;
            if (d != null) {
                g.set(x + d[0], y + d[1], '.');
                seen.clear();
            } else {
                d = greedyStep(g, x, y, tx, ty);
            }
            if (d == null) {
                return -1;
            }
            x += d[0];
            y += d[1];
            steps++;
        }
        return -1;
    }

    private static final int[][] NESW = {{0, -1}, {1, 0}, {0, 1}, {-1, 0}};

    /** Соседний завал ближе к цели (в порядке N, E, S, W); {@code null} — нет такого. */
    private static int[] rubbleCloser(TrialMaps.Grid g, int x, int y, int tx, int ty) {
        int here = Math.abs(x - tx) + Math.abs(y - ty);
        for (int[] d : NESW) {
            int nx = x + d[0];
            int ny = y + d[1];
            if (g.at(nx, ny) == '%' && Math.abs(nx - tx) + Math.abs(ny - ty) < here) {
                return d;
            }
        }
        return null;
    }

    /** Один жадный шаг, как в {@code Pathfinder.SIMPLE}; {@code null} — шагнуть некуда. */
    private static int[] greedyStep(TrialMaps.Grid g, int x, int y, int tx, int ty) {
        int dx = tx - x;
        int dy = ty - y;
        int[] alongX = {dx > 0 ? 1 : -1, 0};
        int[] alongY = {0, dy > 0 ? 1 : -1};
        List<int[]> tries = new ArrayList<>();
        if (Math.abs(dx) >= Math.abs(dy)) {
            if (dx != 0) {
                tries.add(alongX);
            }
            if (dy != 0) {
                tries.add(alongY);
            }
        } else {
            tries.add(alongY);
            if (dx != 0) {
                tries.add(alongX);
            }
        }
        tries.addAll(List.of(NESW));
        for (int[] d : tries) {
            if (g.floor(x + d[0], y + d[1])) {
                return d;
            }
        }
        return null;
    }

    /** Клетки жадного пути от {@code s} до цели, пока он не повторится или не дойдёт. */
    private static List<int[]> greedyLine(TrialMaps.Grid g, int[] s, int tx, int ty) {
        List<int[]> out = new ArrayList<>();
        int x = s[0];
        int y = s[1];
        Set<Integer> seen = new HashSet<>();
        while (Math.abs(x - tx) + Math.abs(y - ty) > 1 && seen.add(y * g.w + x)) {
            int[] d = greedyStep(g, x, y, tx, ty);
            if (d == null) {
                break;
            }
            x += d[0];
            y += d[1];
            out.add(new int[] {x, y});
        }
        return out;
    }

    /** Строка, где жадный путь от {@code s} к цели пересекает столбец {@code wx} (стену шага 4, как будто её нет). */
    private static int greedyCrossing(TrialMaps.Grid g0, int[] s, int tx, int ty, int wx) {
        TrialMaps.Grid g = copy(g0);
        for (int y = 0; y < g.h; y++) {
            g.set(wx, y, '.');
            g.set(wx + 1, y, '.');
        }
        for (int[] p : greedyLine(g, s, tx, ty)) {
            if (p[0] == wx) {
                return p[1];
            }
        }
        return -1;
    }

    /**
     * Длина пути поиском в ширину от клетки у базы до клетки у жилы; {@code withRubble} — завал проходим (как будто
     * разобран). {@code -1} — не дойти.
     */
    static int path(TrialMaps.Grid g, int bx, int by, int fx, int fy, boolean withRubble) {
        int[] dist = new int[g.w * g.h];
        Arrays.fill(dist, -1);
        ArrayDeque<int[]> q = new ArrayDeque<>();
        for (int[] n : around(bx, by)) {
            if (open(g, n[0], n[1], withRubble)) {
                dist[n[1] * g.w + n[0]] = 0;
                q.add(n);
            }
        }
        while (!q.isEmpty()) {
            int[] p = q.poll();
            for (int[] n : around(p[0], p[1])) {
                if (open(g, n[0], n[1], withRubble) && dist[n[1] * g.w + n[0]] < 0) {
                    dist[n[1] * g.w + n[0]] = dist[p[1] * g.w + p[0]] + 1;
                    q.add(n);
                }
            }
        }
        int best = -1;
        for (int[] n : around(fx, fy)) {
            if (g.in(n[0], n[1]) && dist[n[1] * g.w + n[0]] >= 0) {
                int d = dist[n[1] * g.w + n[0]];
                best = best < 0 ? d : Math.min(best, d);
            }
        }
        return best;
    }

    private static boolean open(TrialMaps.Grid g, int x, int y, boolean withRubble) {
        char c = g.at(x, y);
        return c == '.' || withRubble && c == '%';
    }

    private static TrialMaps.Grid copy(TrialMaps.Grid g) {
        TrialMaps.Grid c = new TrialMaps.Grid(g.w, g.h, g.amounts);
        for (int y = 0; y < g.h; y++) {
            c.c[y] = g.c[y].clone();
        }
        return c;
    }

    private static int[][] around(int x, int y) {
        return new int[][] {{x, y - 1}, {x + 1, y}, {x, y + 1}, {x - 1, y}};
    }
}
