// Модель матча: повтор colony-replay v1 плюс то, что просмотр выводит из соседних кадров.
// Кадр хранит полное состояние; разницу между кадрами вычисляем один раз, при приёме.
import { shades, NEUTRAL, DIRS, safeColor, clip, int } from './util.js';

const LEVEL = { COLONY_DIED: 3, BASE_DESTROYED: 3, RAID: 2, TRUCE_END: 2, EVENT_STARTED: 2, ANNOUNCE: 2, DIED: 2, FRIENDLY_FIRE: 2, HIT: 1, PRODUCED: 1 };
export const MOMENT_LEAD = 3; // «следующее событие» показывает момент с запасом в три такта

export class Match {
  constructor(meta) {
    this.meta = meta;
    const m = meta.map;
    this.map = m;
    this.W = int(m.width) || m.rows[0].length; this.H = int(m.height) || m.rows.length;
    this.rules = meta.rules || {};
    this.features = this.rules.features || {};
    // лига — из версии правил: «league-3» → «Лига 3 «Соседи»»
    const lg = /^league-(\d+)$/.exec(String(meta.rulesVersion || this.rules.rulesVersion || ''));
    const LEAGUES = ['Добыча', 'Стены', 'Соседи', 'Центр', 'Танки'];
    this.league = lg ? `Лига ${lg[1]}` + (LEAGUES[lg[1] - 1] ? ` «${LEAGUES[lg[1] - 1]}»` : '') : '';
    // в лигах радиус центра — в шагах (ромб), в сезоне 1 — круг
    this.centerSteps = !!this.features.centerMajority;
    // клетки зоны центра — из заголовка повтора, ровно как считает движок; контур — рёбра между зоной и остальным
    this.centerZone = Array.isArray(m.centerZone) ? m.centerZone.map(p => [int(p[0]), int(p[1])]) : null;
    this.centerEdges = this.centerZone ? zoneEdges(this.centerZone) : null;
    // у своей базы юнит не ранится (лиги 3+): клетки не дальше homeRadius шагов от каждой базы
    this.homeRadius = this.features.homeGuard ? int(this.rules.homeRadius) : 0;
    this.wall = new Uint8Array(this.W * this.H);
    const cells = { C: [], L: [] };
    m.rows.forEach((row, y) => { for (let x = 0; x < this.W; x++) { const ch = row[x]; if (ch === '#') this.wall[y * this.W + x] = 1; else if (cells[ch]) cells[ch].push([x, y]); } });
    // центр и логово рисуем по клеткам карты (они бывают 2×2), а если их нет — по полям повтора
    const mid = list => list.length ? { x: list.reduce((a, p) => a + p[0], 0) / list.length, y: list.reduce((a, p) => a + p[1], 0) / list.length } : null;
    this.centerAt = mid(cells.C) || (m.center ? { x: int(m.center.x), y: int(m.center.y) } : null);
    this.lairAt = mid(cells.L) || (m.lair ? { x: int(m.lair.x), y: int(m.lair.y) } : null);
    // строки и цвет — от студентов: приводим к строкам и проверяем цвет
    this.colonyList = (meta.colonies || []).map((c, i) => {
      const name = clip(c.name ?? `Колония ${i + 1}`, 40), color = safeColor(c.color, i);
      return { id: int(c.id), name, sign: clip(c.sign || name.slice(0, 2), 3), color, bot: clip(c.bot ?? '', 80), pal: shades(color) };
    });
    this.colonies = new Map(this.colonyList.map(c => [c.id, c]));
    this.frames = [];
    this.finished = false;
    this.result = meta.result || null;
    this.events = [];      // все события с индексом кадра
    this.moments = [];     // яркие моменты для «следующего события» и меток шкалы
    this.combat = [];      // напряжённость боя по кадрам
    this.ruins = [];       // разрушенные базы
    this.maxHp = new Map();
    this.homeOwner = new Map();
    this.depMax = new Map();
    this.maxDeposits = 0; this.maxUnits = 0;
    this._prevMap = null;
    this._shellOwner = new Map(); // конец отрезка снаряда → id танка, выпустившего снаряд
    this._lastCombat = -99;
    this.version = 0;
  }

  pal(c) { return this.colonies.get(c)?.pal || NEUTRAL; }
  name(c) { return this.colonies.get(c)?.name || 'налётчики'; }
  get last() { return this.frames.length - 1; }
  // Общая арена: мир без конца, просмотр держит только последние такты.
  get endless() { return (this.rules.maxTicks || 0) >= 1e6; }
  isWall(x, y) { return x < 0 || y < 0 || x >= this.W || y >= this.H || this.wall[y * this.W + x] === 1; }
  unitMax(u) { return this.maxHp.get(u.id) || (u.k === 'T' ? this.rules.tankHp : u.k === 'W' ? this.rules.workerHp : 20) || u.hp || 1; }
  baseMax() { return this.rules.baseHp || 200; }

  add(frames) { for (const f of frames) this.ingest(f); this.version++; }

  // Выбросить первые k кадров (общая арена): номера кадров в событиях и моментах сдвигаются. Сколько выброшено.
  trim(k) {
    k = Math.min(k, this.frames.length - 1);
    if (k <= 0) return 0;
    this.frames.splice(0, k); this.combat.splice(0, k);
    // событие лежит и в events, и в moments одним объектом: сначала отбираем, потом сдвигаем каждый объект один раз
    const keep = list => list.filter(x => x.i >= k);
    const ev = keep(this.events), mo = keep(this.moments), ru = keep(this.ruins);
    for (const x of new Set([...ev, ...mo, ...ru])) x.i -= k;
    this.events = ev; this.moments = mo; this.ruins = ru;
    this._lastCombat -= k; this.version++;
    return k;
  }

  ingest(f) {
    const i = this.frames.length, prev = this.frames[i - 1] || null;
    f.units ||= []; f.bases ||= []; f.deposits ||= []; f.shots ||= []; f.events ||= []; f.rejections ||= {}; f.colonies ||= [];
    f.bases = f.bases.filter(b => b.hp > 0); // разрушенная база — руина, даже если движок оставил её с hp 0
    const cur = new Map();
    f.units.forEach((u, j) => cur.set(u.id, j));
    const pm = this._prevMap;
    f._prev = new Int32Array(f.units.length).fill(-1);
    f._deaths = []; f._hits = []; f._pops = []; f._flows = []; f._baseHits = []; f._fight = new Set();
    this.maxDeposits = Math.max(this.maxDeposits, f.deposits.length);
    this.maxUnits = Math.max(this.maxUnits, f.units.length);

    if (i === 0) {
      for (const d of f.deposits) if (d.kind === 'HOME') {
        const b = f.bases.find(b => Math.abs(b.x - d.x) + Math.abs(b.y - d.y) <= 2);
        if (b) this.homeOwner.set(d.id, b.c);
      }
    }
    for (const d of f.deposits) if (d.amount > (this.depMax.get(d.id) || 0)) this.depMax.set(d.id, d.amount);

    const basePos = new Map(f.bases.map(b => [b.c + ':' + b.x + ':' + b.y, b]));
    const ownBaseNear = u => DIRS.some(([dx, dy]) => basePos.has(u.c + ':' + (u.x + dx) + ':' + (u.y + dy)));
    const depAt = new Map(f.deposits.map(d => [d.x + ':' + d.y, d]));

    // чей снаряд: первый отрезок начинается у танка, продолжение — там, где кончился прошлый
    const owners = new Map();
    for (const s of f.shots) {
      if (s.kind === 'melee') { if (s.hit != null) f._fight.add(s.hit); continue; }
      let owner = this._shellOwner.get(s.c + ':' + s.fx + ':' + s.fy);
      if (owner === undefined) {
        const t = f.units.find(u => u.k === 'T' && u.c === s.c && Math.abs(u.x - s.fx) + Math.abs(u.y - s.fy) <= 1);
        if (t) { owner = t.id; t._tur = Math.atan2(s.ty - s.fy, s.tx - s.fx); t._fired = true; f._fight.add(t.id); }
      }
      s._u = owner;
      if (owner !== undefined && s.hit == null) owners.set(s.c + ':' + s.tx + ':' + s.ty, owner);
      if (s.hit != null) f._fight.add(s.hit);
    }
    this._shellOwner = owners;

    f.units.forEach((u, j) => {
      if (!this.maxHp.has(u.id) || u.hp > this.maxHp.get(u.id)) this.maxHp.set(u.id, u.hp);
      const pj = pm ? pm.get(u.id) : undefined;
      const p = pj !== undefined ? prev.units[pj] : null;
      if (p) {
        f._prev[j] = pj;
        const dx = u.x - p.x, dy = u.y - p.y;
        u._h = dx || dy ? Math.atan2(dy, dx) : p._h;
        if (u._tur === undefined) u._tur = p._tur;
        if (u.hp < p.hp) { f._hits.push({ id: u.id, c: u.c, x: u.x, y: u.y }); f._fight.add(u.id); }
        if (u.k === 'W' && u.carry < p.carry && ownBaseNear(u)) {
          const b = f.bases.find(b => b.c === u.c && Math.abs(b.x - u.x) + Math.abs(b.y - u.y) === 1);
          if (b) f._pops.push({ c: u.c, x: b.x, y: b.y, n: int(p.carry - u.carry) });
        }
        if (u.k === 'W' && u.carry > p.carry) {
          for (const [ddx, ddy] of DIRS) { const d = depAt.get((u.x + ddx) + ':' + (u.y + ddy)); if (d) { f._flows.push({ id: u.id, x: d.x, y: d.y }); break; } }
        }
      } else {
        const b = f.bases.find(b => b.c === u.c && Math.abs(b.x - u.x) + Math.abs(b.y - u.y) === 1);
        if (u._h === undefined) u._h = b ? Math.atan2(u.y - b.y, u.x - b.x) : 0;
      }
      if (u._h === undefined) u._h = 0;
    });

    let combat = f.shots.length;
    if (prev) {
      for (const u of prev.units) {
        if (cur.has(u.id)) continue;
        const shot = f.shots.find(s => s.hit === u.id);
        let killer = null;
        if (shot) {
          // линия к убийце ведёт к танку, а не к началу последнего отрезка снаряда
          const t = shot._u !== undefined ? (f.units.find(x => x.id === shot._u) || prev.units.find(x => x.id === shot._u)) : null;
          killer = t ? { c: shot.c, x: t.x, y: t.y, id: t.id } : { c: shot.c, x: shot.fx, y: shot.fy };
        } else {
          const r = prev.units.find(o => o.k === 'R' && o.c !== u.c && Math.abs(o.x - u.x) + Math.abs(o.y - u.y) <= 1);
          if (r) killer = { c: r.c, x: r.x, y: r.y, id: r.id };
        }
        f._deaths.push({ id: u.id, n: u.n, c: u.c, k: u.k, x: u.x, y: u.y, h: u._h, tur: u._tur, killer });
        if (killer) combat += 3;
      }
      const pb = new Map(prev.bases.map(b => [b.id, b]));
      const cb = new Set(f.bases.map(b => b.id));
      for (const b of f.bases) { const o = pb.get(b.id); if (o && b.hp < o.hp) { f._baseHits.push({ id: b.id, c: b.c, x: b.x, y: b.y }); combat += 2; } }
      for (const b of prev.bases) if (!cb.has(b.id)) this.ruins.push({ i, c: b.c, x: b.x, y: b.y });
    }
    this.combat.push(combat);

    for (const e of f.events) {
      const ev = { i, t: int(f.t), kind: String(e.kind), c: int(e.c), text: String(e.text ?? ''), x: e.x == null ? null : int(e.x), y: e.y == null ? null : int(e.y), level: LEVEL[e.kind] || 1 };
      if (e.kind === 'DIED') {
        const d = f._deaths.find(d => d.x === e.x && d.y === e.y) || f._deaths.find(d => d.c === ev.c && Math.abs(d.x - e.x) + Math.abs(d.y - e.y) <= 2);
        if (d) { ev.k = d.k; ev.n = d.n; ev.victim = d.c; if (d.killer) ev.killer = d.killer.c; }
      }
      this.events.push(ev);
      if (ev.level >= 3 || (ev.level === 2 && e.kind !== 'DIED' && e.kind !== 'FRIENDLY_FIRE')) this.moments.push(ev);
    }
    if (combat > 0 && i - this._lastCombat > 15) {
      const s = f.shots[0] || f._deaths[0] || f._baseHits[0];
      this.moments.push({ i, t: int(f.t), kind: 'FIGHT', c: s?.c ?? 0, text: 'Начало боя', x: s?.fx ?? s?.x ?? null, y: s?.fy ?? s?.y ?? null, level: 2 });
    }
    if (combat > 0) this._lastCombat = i;

    this._prevMap = cur;
    this.frames.push(f);
  }

  // Колония, за которую, скорее всего, играет студент.
  studentColony() {
    const c = this.colonyList.find(c => /^student\./.test(c.bot || '')) || this.colonyList.find(c => c.name === 'Вы');
    return c ? c.id : null;
  }

  // Место колонии: из итога, если он есть и мы в конце; иначе по счёту на кадре.
  ranking(i) {
    const f = this.frames[i];
    if (!f) return [];
    if (this.result && this.finished && i === this.last && this.result.ranking?.length) {
      const byId = new Map(f.colonies.map(c => [c.id, c]));
      return this.result.ranking.map(r => ({ ...(byId.get(r.id) || { id: r.id }), place: int(r.place), score: int(r.score) }));
    }
    const list = [...f.colonies].sort((a, b) => (b.alive - a.alive) || (b.score - a.score) || (b.energy - a.energy) || (a.id - b.id));
    let place = 0, lastKey = null;
    return list.map((c, idx) => { const key = c.alive + ':' + c.score; if (key !== lastKey) { place = idx + 1; lastKey = key; } return { ...c, place }; });
  }

  counts(i) {
    const f = this.frames[i], out = new Map();
    for (const c of this.colonyList) out.set(c.id, { W: 0, T: 0 });
    if (f) for (const u of f.units) { const o = out.get(u.c); if (o && (u.k === 'W' || u.k === 'T')) o[u.k]++; }
    return out;
  }

  // Следующий момент после уже показанного: переход идёт на момент − MOMENT_LEAD.
  nextMoment(i) { return this.moments.find(m => m.i - MOMENT_LEAD > i) || null; }

  // Гибель по-человечески: «Глеб ▸ Вера: танк».
  killText(e) {
    const kind = { W: 'рабочий', T: 'танк', R: 'налётчик' }[e.k] || 'юнит';
    const who = e.killer === 0 ? 'Налётчики' : this.name(e.killer);
    const num = e.n != null ? ' ' + e.n : '';
    return e.victim ? `${who} ▸ ${this.name(e.victim)}: ${kind}${num}` : `${who} ▸ налётчик${num}`;
  }
}

// Контур набора клеток: рёбра клеток, по другую сторону которых клетки набора нет. [[x0, y0, x1, y1], …]
export function zoneEdges(cells) {
  const set = new Set(cells.map(([x, y]) => x + ':' + y)), out = [];
  for (const [x, y] of cells) {
    if (!set.has(x + ':' + (y - 1))) out.push([x, y, x + 1, y]);
    if (!set.has(x + ':' + (y + 1))) out.push([x, y + 1, x + 1, y + 1]);
    if (!set.has((x - 1) + ':' + y)) out.push([x, y, x, y + 1]);
    if (!set.has((x + 1) + ':' + y)) out.push([x + 1, y, x + 1, y + 1]);
  }
  return out;
}

// Формат: только colony-replay v1. Более новую версию честно не открываем.
export function checkFormat(meta) {
  if (!meta || meta.format !== 'colony-replay') return 'Это не повтор «Колонии».';
  if (meta.version !== 1) return `Повтор версии ${int(meta.version)}, а просмотр понимает версию 1. Обновите SDK.`;
  if (!meta.map || !Array.isArray(meta.map.rows) || !meta.map.rows.length) return 'В повторе нет карты.';
  return null;
}

// Признак игры для живого режима: если он поменялся, это уже другая игра.
export function gameKey(meta) {
  return [meta.gameId ?? '', meta.seed ?? '', meta.map?.name ?? '', (meta.colonies || []).map(c => c.id + ':' + c.name + ':' + (c.bot ?? '')).join('|')].join('#');
}
