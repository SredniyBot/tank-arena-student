// Неподвижная часть поля: грунт, скалы, центр, логово. Рисуется один раз в отдельный холст.
import { rng, hashStr } from './util.js';

export const GROUND = '#D7DECD';

export function boardScale(m) { return Math.max(24, Math.min(56, Math.floor(3400 / Math.max(m.W, m.H)))); }

export function paintBoard(m, { ppc = boardScale(m), walls = true } = {}) {
  const W = m.W, H = m.H, cv = document.createElement('canvas');
  cv.width = W * ppc; cv.height = H * ppc;
  const wcv = document.createElement('canvas'); wcv.width = cv.width; wcv.height = cv.height;
  const g = cv.getContext('2d'), R = rng(hashStr(m.map.name + ':' + W + 'x' + H));
  const P = v => v * ppc;

  // грунт: ровный тон, крупные мягкие пятна, мелкая крошка
  g.fillStyle = GROUND; g.fillRect(0, 0, cv.width, cv.height);
  const patches = Math.round(W * H / 60);
  for (let i = 0; i < patches; i++) {
    const x = R() * cv.width, y = R() * cv.height, r = P(1.6 + R() * 3.8), dark = R() < 0.55;
    const gr = g.createRadialGradient(x, y, 0, x, y, r);
    gr.addColorStop(0, dark ? 'rgba(138,158,118,.06)' : 'rgba(252,252,244,.18)'); gr.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill();
  }
  const specks = Math.round(W * H * 2.2);
  for (let i = 0; i < specks; i++) {
    const x = R() * cv.width, y = R() * cv.height;
    g.fillStyle = R() < 0.5 ? 'rgba(118,134,100,.10)' : 'rgba(255,255,246,.14)';
    g.fillRect(x, y, Math.max(1.5, ppc * 0.05), Math.max(1.5, ppc * 0.05));
  }
  const light = g.createLinearGradient(0, 0, cv.width, cv.height);
  light.addColorStop(0, 'rgba(255,246,220,.22)'); light.addColorStop(0.55, 'rgba(255,255,255,0)'); light.addColorStop(1, 'rgba(96,124,140,.10)');
  g.fillStyle = light; g.fillRect(0, 0, cv.width, cv.height);
  // центр: кольцо по радиусу правила
  const c = m.centerAt;
  if (m.centerZone) {
    // зона центра — клетки движка: лёгкая заливка и пунктирный контур
    g.fillStyle = 'rgba(120,128,100,.14)';
    for (const [x, y] of m.centerZone) g.fillRect(P(x), P(y), ppc, ppc);
    g.setLineDash([P(0.28), P(0.22)]); g.strokeStyle = 'rgba(78,88,66,.42)'; g.lineWidth = Math.max(1.5, ppc * 0.06);
    g.beginPath(); for (const [x0, y0, x1, y1] of m.centerEdges) { g.moveTo(P(x0), P(y0)); g.lineTo(P(x1), P(y1)); } g.stroke(); g.setLineDash([]);
  } else if (c) {
    const r = (m.rules.centerRadius || 3) + 0.5, cx = P(c.x + 0.5), cy = P(c.y + 0.5);
    const gr = g.createRadialGradient(cx, cy, 0, cx, cy, P(r));
    gr.addColorStop(0, 'rgba(120,128,100,.16)'); gr.addColorStop(1, 'rgba(120,128,100,.04)');
    // в лигах радиус — в шагах: зона — ромб
    const zone = () => { g.beginPath(); if (m.centerSteps) { g.moveTo(cx, cy - P(r)); g.lineTo(cx + P(r), cy); g.lineTo(cx, cy + P(r)); g.lineTo(cx - P(r), cy); g.closePath(); } else g.arc(cx, cy, P(r), 0, Math.PI * 2); };
    g.fillStyle = gr; zone(); g.fill();
    g.setLineDash([P(0.28), P(0.22)]); g.strokeStyle = 'rgba(78,88,66,.42)'; g.lineWidth = Math.max(1.5, ppc * 0.06);
    zone(); g.stroke(); g.setLineDash([]);
  }
  // у своей базы юнит не ранится: ромб клеток в цвете колонии
  if (m.homeRadius > 0) {
    const r = m.homeRadius;
    m.map.rows.forEach((row, by) => { for (let bx = 0; bx < W; bx++) {
      const id = '123456789abcdefghijklmnopqrstuvwxyz'.indexOf(row[bx]) + 1; if (id <= 0) continue;
      const col = m.colonies.get(id); if (!col) continue;
      g.fillStyle = col.pal.hi; g.globalAlpha = 0.16;
      for (let dy = -r; dy <= r; dy++) for (let dx = -r; dx <= r; dx++) {
        const x = bx + dx, y = by + dy;
        if (Math.abs(dx) + Math.abs(dy) > r || x < 0 || y < 0 || x >= W || y >= H || m.wall[y * W + x]) continue;
        g.fillRect(P(x), P(y), ppc, ppc);
      }
      g.globalAlpha = 1;
    } });
  }
  // логово налётчиков: тёмный провал с каменной кромкой
  const L = m.lairAt;
  if (L) {
    const cx = P(L.x + 0.5), cy = P(L.y + 0.5);
    g.fillStyle = 'rgba(40,50,44,.18)'; g.beginPath(); g.ellipse(cx, cy + P(0.1), P(1.5), P(1.1), 0, 0, Math.PI * 2); g.fill();
    for (let i = 0; i < 11; i++) {
      const a = i / 11 * Math.PI * 2 + R() * 0.3, rx = P(1.05 + R() * 0.12), ry = P(0.8 + R() * 0.1);
      g.fillStyle = i % 2 ? '#9DA79A' : '#B1BAAD';
      g.beginPath(); g.ellipse(cx + Math.cos(a) * rx, cy + Math.sin(a) * ry, P(0.26), P(0.2), a, 0, Math.PI * 2); g.fill();
    }
    const gr = g.createRadialGradient(cx, cy, 0, cx, cy, P(0.9));
    gr.addColorStop(0, '#1F2522'); gr.addColorStop(0.7, '#3A433D'); gr.addColorStop(1, '#5B655D');
    g.fillStyle = gr; g.beginPath(); g.ellipse(cx, cy, P(0.85), P(0.62), 0, 0, Math.PI * 2); g.fill();
  }

  if (walls) paintWalls(wcv.getContext('2d'), m, ppc, R);
  return { canvas: cv, walls: wcv, ppc };
}

// Скалы: объединение клеток со скруглением выпуклых углов; тень, нижняя грань, верх, кромка света.
function paintWalls(g, m, ppc, R) {
  const W = m.W, H = m.H, w = (x, y) => m.isWall(x, y);
  const rad = ppc * 0.32;
  const path = (dx, dy, grow = 0) => {
    g.beginPath();
    for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
      if (!w(x, y)) continue;
      const n = w(x, y - 1), e = w(x + 1, y), s = w(x, y + 1), wst = w(x - 1, y);
      const tl = !n && !wst ? rad : 0, tr = !n && !e ? rad : 0, br = !s && !e ? rad : 0, bl = !s && !wst ? rad : 0;
      g.roundRect(x * ppc + dx - (wst ? 0 : grow), y * ppc + dy - (n ? 0 : grow), ppc + (wst ? 0 : grow) + (e ? 0 : grow), ppc + (n ? 0 : grow) + (s ? 0 : grow), [tl, tr, br, bl]);
    }
  };
  // мягкая тень на грунт: свет сверху слева
  g.save();
  try { g.filter = `blur(${Math.max(1, Math.round(ppc * 0.07))}px)`; } catch { /* без размытия */ }
  g.fillStyle = 'rgba(34,50,38,.34)'; path(ppc * 0.1, ppc * 0.22); g.fill();
  g.restore();
  // нижняя грань даёт высоту
  g.fillStyle = '#7C887A'; path(0, ppc * 0.16); g.fill();
  // верх: низкополигональный рельеф. Высота вершины — сколько скальных клеток её касается; свет сверху слева.
  const VW = W + 1, hgt = new Float32Array(VW * (H + 1)), jx = new Float32Array(VW * (H + 1)), jy = new Float32Array(VW * (H + 1));
  for (let y = 0; y <= H; y++) for (let x = 0; x <= W; x++) {
    const wi = (a, b) => a >= 0 && b >= 0 && a < W && b < H && w(a, b);
    const n = (wi(x - 1, y - 1) ? 1 : 0) + (wi(x, y - 1) ? 1 : 0) + (wi(x - 1, y) ? 1 : 0) + (wi(x, y) ? 1 : 0);
    const edge = x === 0 || y === 0 || x === W || y === H;
    hgt[y * VW + x] = n * 0.62 + (n === 4 ? R() * 0.5 : R() * 0.1);
    jx[y * VW + x] = edge || n < 4 ? 0 : (R() - 0.5) * 0.42; jy[y * VW + x] = edge || n < 4 ? 0 : (R() - 0.5) * 0.42;
  }
  const L = [-0.52, -0.62, 0.59], lo = [128, 140, 124], hi = [222, 228, 215];
  const shade = (a, b, c) => {
    const ux = b[0] - a[0], uy = b[1] - a[1], uz = b[2] - a[2], vx = c[0] - a[0], vy = c[1] - a[1], vz = c[2] - a[2];
    let nx = uy * vz - uz * vy, ny = uz * vx - ux * vz, nz = ux * vy - uy * vx; if (nz < 0) { nx = -nx; ny = -ny; nz = -nz; }
    const len = Math.hypot(nx, ny, nz) || 1, k = Math.max(0, Math.min(1, ((nx * L[0] + ny * L[1] + nz * L[2]) / len - 0.2) / 0.8));
    return 'rgb(' + lo.map((v, i) => Math.round(v + (hi[i] - v) * k)).join(',') + ')';
  };
  const V = (x, y) => [x + jx[y * VW + x], y + jy[y * VW + x], hgt[y * VW + x]];
  g.save(); path(0, 0); g.clip();
  g.fillStyle = '#C3CBBC'; g.fillRect(0, 0, W * ppc, H * ppc);
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (!w(x, y)) continue;
    const a = V(x, y), b = V(x + 1, y), c = V(x + 1, y + 1), d = V(x, y + 1);
    const tris = [[a, b, d], [b, c, d]];
    for (const t of tris) {
      g.fillStyle = shade(...t); g.strokeStyle = g.fillStyle; g.lineWidth = 1;
      g.beginPath(); g.moveTo(t[0][0] * ppc, t[0][1] * ppc); g.lineTo(t[1][0] * ppc, t[1][1] * ppc); g.lineTo(t[2][0] * ppc, t[2][1] * ppc); g.closePath(); g.fill(); g.stroke();
    }
  }
  g.restore();
  // светлая кромка только по открытым северным и западным краям: свет сверху слева
  g.strokeStyle = 'rgba(255,255,255,.7)'; g.lineWidth = Math.max(1.2, ppc * 0.05); g.lineCap = 'round'; g.beginPath();
  const inset = ppc * 0.05;
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) {
    if (!w(x, y)) continue;
    const n = w(x, y - 1), wst = w(x - 1, y), e = w(x + 1, y), s2 = w(x, y + 1);
    if (!n) { g.moveTo(x * ppc + (wst ? 0 : rad), y * ppc + inset); g.lineTo((x + 1) * ppc - (e ? 0 : rad), y * ppc + inset); }
    if (!wst) { g.moveTo(x * ppc + inset, y * ppc + (n ? 0 : rad)); g.lineTo(x * ppc + inset, (y + 1) * ppc - (s2 ? 0 : rad)); }
  }
  g.stroke();
}
