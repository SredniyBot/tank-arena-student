package colony.local;

import colony.api.Colony;
import colony.api.RejectCode;
import colony.engine.RuleSet;
import colony.engine.ColonySpec;
import colony.engine.GameMap;
import colony.engine.MapLoader;
import colony.engine.Match;
import colony.engine.MatchConfig;
import colony.engine.MatchResult;
import colony.engine.RulesLoader;
import colony.engine.Version;
import com.fasterxml.jackson.core.util.DefaultIndenter;
import com.fasterxml.jackson.core.util.DefaultPrettyPrinter;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.File;
import java.io.IOException;
import java.io.PrintStream;
import java.lang.management.ManagementFactory;
import java.lang.management.ThreadMXBean;
import java.net.MalformedURLException;
import java.net.URL;
import java.net.URLClassLoader;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.security.CodeSource;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.EnumMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Supplier;
import java.util.stream.Stream;

/**
 * Прогон без просмотра для преподавателя: колония студента против встроенных соперников (допуск) или против колонии
 * другого студента (бой по вызову), на всех картах и зёрнах.
 *
 * <pre>
 * java -cp colony-sdk.jar:… colony.local.Headless --colony-class=student.MyColony --classpath=a.jar
 *      [--league=3 | --rules=season1|season1-2b|league-N|файл.json]
 *      [--opponents=bronze,silver | --opponent-class=student.MyColony --opponent-classpath=b.jar]
 *      --maps=maps/ --seeds=1,2,3 --out=out/ [--ticks=3000] [--name=Вы] [--opponent-name=Соперник]
 * </pre>
 *
 * <ul>
 *   <li>Код студента грузится заново на каждый матч, своим загрузчиком классов: static-поля не переходят из матча
 *       в матч, и две колонии с одинаковыми именами классов не мешают друг другу.</li>
 *   <li>{@code out/report.json} переписывается после каждого матча с {@code "complete": false} и в конце — с
 *       {@code true}: если код студента оборвал прогон, видно, сколько сыграно.</li>
 *   <li>Соперники — боссы лиг по именам: {@code bronze} (лига 1), {@code silver} (2), {@code gold} (3),
 *       {@code platinum} (4), {@code diamond} (5); {@code planner} — планировщик ворот А (правила 2б), если
 *       {@code colony.gatebots.Gold} есть в classpath. Боссы лиг 3–5 играют только по правилам лиги.</li>
 *   <li>{@code --league=N}: правила лиги N; без {@code --opponents} соперник — её босс, без {@code --maps} —
 *       три дуэли лиги. Без {@code --league} и {@code --rules} — правила сезона 1, как раньше.</li>
 *   <li>Классы колоний из пакетов {@code colony.*} не принимаются: эти пакеты заняты движком и встроенными ботами.</li>
 * </ul>
 *
 * <p>Коды выхода: 0 — все матчи сыграны (даже если колония падала), 2 — неверные аргументы или колонию не загрузить.
 */
public final class Headless {

    static final String USAGE = """
            Headless — прогон без просмотра:
              --colony-class=<класс>     класс колонии, например student.MyColony (обязательно)
              --league=<1–5>             правила лиги; соперник по умолчанию — её босс, карты — её три дуэли
              --rules=<имя или файл>     правила: season1, season1-2b, league-N или файл .json (по умолчанию season1)
              --classpath=<jar или папка>[%1$s…]  где лежит колония
              --opponents=<имена>        боссы: bronze (лига 1), silver (2), gold (3), platinum (4), diamond (5);
                                         planner — планировщик 2б (по умолчанию bronze,silver или босс лиги)
              --opponent-class=<класс>   вместо них — колония другого студента (бой по вызову)
              --opponent-classpath=<jar или папка>[%1$s…]  где она лежит
              --opponent-name=<имя>      её имя в повторах (по умолчанию «Соперник»)
              --maps=<папка|файл|имя>[,…]       карты: папка с .json, файл или встроенная (по умолчанию steps-4)
              --seeds=1,2,3              зёрна (по умолчанию 1,2,3)
              --ticks=<число>            длина матча, до %2$d (по умолчанию из правил)
              --tick-timeout=<мс>        время колонии на такт, от 50 до 10000 (по умолчанию из правил)
              --name=<имя>               имя своей колонии в повторах (по умолчанию «Вы»)
              --out=<папка>              куда писать report.json и replays/ (обязательно)
              --args-file=<файл>         эти же флаги из файла UTF-8, по одному в строке (имена не по-латински
                                         в командной строке Windows портятся)"""
            .formatted(File.pathSeparator, LocalGame.MAX_TICKS);

    private static final List<String> FLAGS = List.of("colony-class", "classpath", "league", "rules", "opponents",
            "opponent-class", "opponent-classpath", "opponent-name", "maps", "seeds", "ticks", "tick-timeout", "name",
            "out");
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final DefaultPrettyPrinter PRETTY = new DefaultPrettyPrinter()
            .withObjectIndenter(new DefaultIndenter("  ", "\n"))
            .withArrayIndenter(new DefaultIndenter("  ", "\n"));

    private Headless() {}

    public static void main(String[] args) {
        int code = run(args, System.out, System.err);
        System.out.flush();
        System.exit(code);
    }

    static int run(String[] args, PrintStream out, PrintStream err) {
        Map<String, String> a;
        try {
            a = parse(withArgsFile(args));
        } catch (IllegalArgumentException e) {
            err.println(e.getMessage());
            err.println(USAGE);
            return 2;
        }
        if (a.get("colony-class") == null || a.get("out") == null) {
            err.println("Нужны --colony-class и --out.");
            err.println(USAGE);
            return 2;
        }
        Path outDir = Path.of(a.get("out")).toAbsolutePath().normalize();
        try {
            StudentClass mine = StudentClass.of("--colony-class", a.get("colony-class"), a.get("classpath"));
            League league = null;
            RuleSet rules;
            if (a.containsKey("league")) {
                if (a.containsKey("rules")) {
                    throw new IllegalArgumentException("--league и --rules вместе не бывают");
                }
                try {
                    league = new League(Integer.parseInt(a.get("league").strip()));
                } catch (IllegalArgumentException e) {
                    throw new IllegalArgumentException("--league: номер лиги от 1 до " + RulesLoader.LEAGUES);
                }
                rules = league.rules();
            } else if (a.containsKey("rules")) {
                String r = a.get("rules").strip();
                rules = RulesLoader.BUILTIN.contains(r) ? RulesLoader.builtin(r) : RulesLoader.load(Path.of(r));
            } else {
                rules = RulesLoader.season1();
            }
            int ruleLeague = RulesLoader.leagueOf(rules);
            StudentClass rival = null;
            List<String> opponents;
            if (a.containsKey("opponent-class")) {
                if (a.containsKey("opponents")) {
                    throw new IllegalArgumentException("--opponent-class и --opponents вместе не бывают: бой по вызову "
                            + "идёт только против колонии другого студента");
                }
                rival = StudentClass.of("--opponent-class", a.get("opponent-class"), a.get("opponent-classpath"));
                opponents = List.of("class:" + rival.className);
            } else {
                if (a.containsKey("opponent-classpath")) {
                    throw new IllegalArgumentException("--opponent-classpath без --opponent-class");
                }
                opponents = list(a.getOrDefault("opponents", league != null ? league.boss() : "bronze,silver"));
                for (String id : opponents) {
                    if (id.startsWith("past:")) {
                        throw new IllegalArgumentException("past:<тег> в прогоне не бывает; соперники — боссы лиг "
                                + "(bronze … diamond), planner или --opponent-class");
                    }
                    int bossLeague = League.bosses().indexOf(id) + 1;
                    if (bossLeague >= 3 && ruleLeague == 0) {
                        throw new IllegalArgumentException("«" + id + "» — босс лиги " + bossLeague + ", он играет "
                                + "только по правилам лиги: добавьте --league=" + bossLeague
                                + " (планировщик ворот А — planner)");
                    }
                    Opponent.parse(id, 1, outDir, true); // проверить имена до первого матча
                }
            }
            List<GameMap> maps = maps(a.getOrDefault("maps", league != null ? String.join(",", league.duels())
                    : LocalGame.DEFAULT_MAP));
            List<Long> seeds = new ArrayList<>();
            for (String s : list(a.getOrDefault("seeds", "1,2,3"))) {
                seeds.add(parseLong("--seeds", s));
            }
            if (a.containsKey("ticks")) {
                rules = LocalGame.withMaxTicks(rules, LocalGame.checkTicks(parseLong("--ticks", a.get("ticks"))));
            }
            Integer tickTimeout = null;
            if (a.containsKey("tick-timeout")) {
                long ms = parseLong("--tick-timeout", a.get("tick-timeout"));
                if (ms < 50 || ms > 10_000) {
                    throw new IllegalArgumentException("--tick-timeout: от 50 до 10000 мс");
                }
                tickTimeout = (int) ms;
            }
            Run run = new Run(mine, a.getOrDefault("name", ColonyProperties.DEFAULT_NAME), rival,
                    a.getOrDefault("opponent-name", "Соперник"), opponents, maps, seeds, rules, outDir, tickTimeout);
            return run.play(out);
        } catch (IllegalArgumentException e) {
            err.println(e.getMessage());
            return 2;
        } catch (IOException | RuntimeException e) {
            err.println("Прогон прерван: " + e);
            return 1;
        }
    }

    /**
     * Класс колонии студента. Проверяется один раз; на каждый матч — свой загрузчик, в котором классы студента
     * (из {@code --classpath} или, без него, из того места, откуда класс виден программе) идут раньше родителя.
     */
    static final class StudentClass {
        final String className;
        private final URL[] urls;

        private StudentClass(String className, URL[] urls) {
            this.className = className;
            this.urls = urls;
        }

        static StudentClass of(String flag, String className, String classpath) {
            if (className.isBlank()) {
                throw new IllegalArgumentException(flag + ": не задан класс колонии");
            }
            if (className.equals("colony") || className.startsWith("colony.")) {
                throw new IllegalArgumentException("Класс колонии " + className + " в пакете colony.*: эти пакеты "
                        + "заняты движком и встроенными ботами. Перенесите колонию в свой пакет, например student.");
            }
            URL[] urls = classpath == null || classpath.isBlank() ? whereVisible(flag, className)
                    : urls(flag, classpath);
            StudentClass sc = new StudentClass(className, urls);
            try (Fresh probe = sc.open()) {
                Class<?> type = probe.type;
                if (!Colony.class.isAssignableFrom(type)) {
                    throw new IllegalArgumentException(className + " не реализует colony.api.Colony");
                }
                try {
                    type.getDeclaredConstructor();
                } catch (NoSuchMethodException e) {
                    throw new IllegalArgumentException(className + ": нужен конструктор без параметров");
                }
            }
            return sc;
        }

        /** Новый загрузчик и фабрика колонии. Класс не инициализируется: его static выполнится в потоке колонии. */
        Fresh open() {
            URLClassLoader loader = new ChildFirstLoader("student:" + className, urls,
                    Headless.class.getClassLoader());
            try {
                return new Fresh(loader, Class.forName(className, false, loader));
            } catch (ClassNotFoundException | LinkageError e) {
                close(loader);
                throw new IllegalArgumentException("Класс колонии " + className + " не найден: " + e);
            }
        }

        private static URL[] urls(String flag, String classpath) {
            List<URL> urls = new ArrayList<>();
            for (String part : classpath.split(File.pathSeparator)) {
                if (part.isBlank()) {
                    continue;
                }
                Path p = Path.of(part.strip());
                if (!Files.exists(p)) {
                    throw new IllegalArgumentException(flag.replace("class", "classpath") + ": нет файла или папки "
                            + p);
                }
                try {
                    urls.add(p.toAbsolutePath().toUri().toURL());
                } catch (MalformedURLException e) {
                    throw new IllegalArgumentException(flag + ": " + e.getMessage());
                }
            }
            return urls.toArray(URL[]::new);
        }

        /** Без {@code --classpath}: место, откуда класс уже виден программе, — чтобы и тут грузить его заново. */
        private static URL[] whereVisible(String flag, String className) {
            try {
                Class<?> type = Class.forName(className, false, Headless.class.getClassLoader());
                CodeSource cs = type.getProtectionDomain().getCodeSource();
                if (cs == null || cs.getLocation() == null) {
                    throw new IllegalArgumentException(flag + ": не понять, откуда загружен " + className
                            + "; укажите --classpath");
                }
                return new URL[] {cs.getLocation()};
            } catch (ClassNotFoundException | LinkageError e) {
                throw new IllegalArgumentException("Класс колонии " + className + " не найден: " + e
                        + ". Укажите, где он лежит: --classpath");
            }
        }
    }

    /** Загрузчик одного матча и фабрика колонии из него. */
    static final class Fresh implements AutoCloseable {
        final URLClassLoader loader;
        final Class<?> type;

        Fresh(URLClassLoader loader, Class<?> type) {
            this.loader = loader;
            this.type = type;
        }

        Supplier<Colony> factory() {
            return () -> {
                try {
                    var c = type.getDeclaredConstructor();
                    c.setAccessible(true);
                    return (Colony) c.newInstance();
                } catch (ReflectiveOperationException e) {
                    Throwable cause = e.getCause() != null ? e.getCause() : e;
                    if (cause instanceof RuntimeException re) {
                        throw re;
                    }
                    if (cause instanceof Error er) {
                        throw er;
                    }
                    throw new IllegalStateException("не удалось создать " + type.getName() + ": " + cause, cause);
                }
            };
        }

        @Override
        public void close() {
            Headless.close(loader);
        }
    }

    private static void close(URLClassLoader loader) {
        try {
            loader.close();
        } catch (IOException ignored) {
            // jar не закрылся — не мешает прогону
        }
    }

    /** Один прогон: все матчи и отчёт. */
    private static final class Run {
        final StudentClass mine;
        final String name;
        final StudentClass rival;
        final String rivalName;
        final List<String> opponents;
        final List<GameMap> maps;
        final List<Long> seeds;
        final RuleSet rules;
        final Path outDir;
        final Integer tickTimeout;
        /** Идущий матч — для сердцебиения ({@code progress.json}). */
        volatile Match current;

        final ArrayNode matches = JSON.createArrayNode();
        final Map<RejectCode, Integer> allRejections = new EnumMap<>(RejectCode.class);
        final Map<String, int[]> byOpponent = new LinkedHashMap<>(); // матчей, побед, счёт, доход
        final String time = OffsetDateTime.now().truncatedTo(ChronoUnit.SECONDS).toString();
        int wins;
        int crashedMatches;
        long income;
        long score;
        int minIncome = Integer.MAX_VALUE;

        Run(StudentClass mine, String name, StudentClass rival, String rivalName, List<String> opponents,
            List<GameMap> maps, List<Long> seeds, RuleSet rules, Path outDir, Integer tickTimeout) {
            this.mine = mine;
            this.name = name;
            this.rival = rival;
            this.rivalName = rivalName;
            this.opponents = opponents;
            this.maps = maps;
            this.seeds = seeds;
            this.rules = rules;
            this.outDir = outDir;
            this.tickTimeout = tickTimeout;
        }

        int play(PrintStream out) throws IOException {
            Path replays = Files.createDirectories(outDir.resolve("replays"));
            writeReport(false);
            Thread beat = heartbeat();
            try {
                return playAll(out, replays);
            } finally {
                // после прогона сердцебиение не должно писать в каталог отчёта: его могут уже удалять
                beat.interrupt();
                try {
                    beat.join(2000);
                } catch (InterruptedException e) {
                    Thread.currentThread().interrupt();
                }
            }
        }

        private int playAll(PrintStream out, Path replays) throws IOException {
            int total = opponents.size() * maps.size() * seeds.size();
            for (String id : opponents) {
                for (GameMap map : maps) {
                    for (long seed : seeds) {
                        try (Fresh me = mine.open(); Fresh other = rival == null ? null : rival.open()) {
                            ColonySpec opp = other != null ? new ColonySpec(rivalName, null, other.factory())
                                    : Opponent.parse(id, seed, outDir, true).spec();
                            String line = playOne(id, map, seed, new ColonySpec(name, null, me.factory()), opp,
                                    replays);
                            // сначала отчёт (после последнего матча — полный), потом консоль: печать может
                            // навсегда ждать замок System.out, который держит брошенный код колонии
                            writeReport(matches.size() == total);
                            out.println(line);
                        }
                    }
                }
            }
            Path reportFile = writeReport(true);
            out.println("Матчей " + matches.size() + ", побед " + wins + ", с падениями " + crashedMatches
                    + ", доход всего " + income + ". Отчёт: " + reportFile);
            return 0;
        }

        /** Матч; возвращает строку итога для консоли — её печатают после записи отчёта. */
        private String playOne(String id, GameMap map, long seed, ColonySpec me, ColonySpec opp, Path replays)
                throws IOException {
            MatchConfig cfg = MatchConfig.of(rules, map, seed);
            if (tickTimeout != null) {
                cfg = cfg.withTickTimeoutMillis(tickTimeout);
            }
            try (Match match = Match.create(cfg, List.of(me, opp))) {
                current = match;
                match.run();
                MatchResult r = match.result();
                MatchResult.Placement p = r.of(1);
                MatchResult.Placement o = r.of(2);
                Map<RejectCode, Integer> rej = LocalGame.rejectionsByCode(match, 1);
                boolean crashed = p.exceptions() > 0 || p.timeouts() > 0;
                boolean opponentCrashed = o.exceptions() > 0 || o.timeouts() > 0;
                Path replay = Replays.write(match, replays,
                        LocalGame.safeName(id) + "-" + LocalGame.safeName(map.name()) + "-" + seed);

                ObjectNode m = matches.addObject();
                m.put("opponent", id).put("map", map.name()).put("seed", seed).put("ticks", r.ticks())
                        .put("place", p.place()).put("places", r.ranking().size()).put("score", p.score())
                        .put("opponentScore", o.score()).put("income", p.delivered())
                        .put("opponentIncome", o.delivered()).put("energy", p.energy()).put("alive", p.alive())
                        .put("crashed", crashed).put("exceptions", p.exceptions()).put("timeouts", p.timeouts())
                        .put("opponentCrashed", opponentCrashed);
                ObjectNode rn = m.putObject("rejections");
                rej.forEach((k, v) -> rn.put(k.name(), v));
                m.put("replay", outDir.relativize(replay).toString().replace('\\', '/'));

                rej.forEach((k, v) -> allRejections.merge(k, v, Integer::sum));
                int[] agg = byOpponent.computeIfAbsent(id, k -> new int[4]);
                agg[0]++;
                if (p.place() == 1 && p.score() > o.score()) {
                    agg[1]++;
                    wins++;
                }
                agg[2] += p.score();
                agg[3] += p.delivered();
                if (crashed) {
                    crashedMatches++;
                }
                income += p.delivered();
                score += p.score();
                minIncome = Math.min(minIncome, p.delivered());
                return id + " " + map.name() + " зерно " + seed + ": " + p.place() + " место, счёт " + p.score()
                        + " (у соперника " + o.score() + "), доход " + p.delivered()
                        + (crashed ? ", ПАДАЛА: исключений " + p.exceptions() + ", таймаутов " + p.timeouts() : "");
            } finally {
                current = null;
            }
        }

        /**
         * Сердцебиение: раз в секунду {@code progress.json} — такт идущего матча и, для каждой колонии, занят ли её
         * поток тактом и сколько процессорного времени он съел. Если матч зависнет и прогон его убьёт, по этому
         * файлу видно, чей такт шёл.
         */
        private Thread heartbeat() {
            Thread t = new Thread(() -> {
                ThreadMXBean mx = ManagementFactory.getThreadMXBean();
                while (true) {
                    try {
                        Thread.sleep(1000);
                        writeProgress(mx);
                    } catch (InterruptedException e) {
                        return;
                    } catch (IOException | RuntimeException e) {
                        // пропустим удар — следующий через секунду
                    }
                }
            }, "colony-heartbeat");
            t.setDaemon(true);
            t.start();
            return t;
        }

        private void writeProgress(ThreadMXBean mx) throws IOException {
            Match m = current;
            if (m == null || m.finished()) {
                // между матчами никто не думает: последний снимок идущего матча остаётся в файле
                return;
            }
            ObjectNode p = JSON.createObjectNode();
            p.put("tick", m.tick());
            ArrayNode colonies = p.putArray("colonies");
            for (Thread th : Thread.getAllStackTraces().keySet()) {
                String n = th.getName();
                if (!n.matches("colony-\\d+")) {
                    continue;
                }
                boolean idle = false;
                for (StackTraceElement e : th.getStackTrace()) {
                    if (e.getClassName().equals("java.util.concurrent.ThreadPoolExecutor")
                            && e.getMethodName().equals("getTask")) {
                        idle = true;
                        break;
                    }
                }
                long cpu = mx.isThreadCpuTimeSupported() ? mx.getThreadCpuTime(th.threadId()) / 1_000_000 : -1;
                colonies.addObject().put("id", Integer.parseInt(n.substring("colony-".length())))
                        .put("busy", th.isAlive() && !idle).put("cpuMillis", cpu);
            }
            Path file = outDir.resolve("progress.json");
            Path tmp = Files.createTempFile(outDir, "progress", ".tmp");
            try {
                Files.writeString(tmp, JSON.writeValueAsString(p) + "\n");
                try {
                    Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException e) {
                    Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(tmp);
            }
        }

        /** Отчёт целиком; {@code complete} — все матчи сыграны. Запись через временный файл. */
        private Path writeReport(boolean complete) throws IOException {
            int n = matches.size();
            ObjectNode report = JSON.createObjectNode();
            report.put("format", "colony-report").put("version", 1).put("sdkVersion", Version.get())
                    .put("rulesVersion", rules.rulesVersion()).put("colonyClass", mine.className);
            if (rival != null) {
                report.put("opponentClass", rival.className);
            }
            report.put("time", time).put("complete", complete);
            report.set("matches", matches);
            ObjectNode agg = report.putObject("aggregate");
            agg.put("matches", n).put("wins", wins).put("crashed", crashedMatches > 0)
                    .put("crashedMatches", crashedMatches).put("income", income)
                    .put("minIncome", n == 0 ? 0 : minIncome).put("meanScore", n == 0 ? 0 : (double) score / n);
            ObjectNode ar = agg.putObject("rejections");
            allRejections.forEach((k, v) -> ar.put(k.name(), v));
            ObjectNode bo = agg.putObject("byOpponent");
            byOpponent.forEach((k, v) -> bo.putObject(k).put("matches", v[0]).put("wins", v[1])
                    .put("meanScore", (double) v[2] / v[0]).put("income", v[3]));
            Path file = outDir.resolve("report.json");
            Path tmp = Files.createTempFile(outDir, "report", ".tmp");
            try {
                Files.writeString(tmp, JSON.writer(PRETTY).writeValueAsString(report) + "\n");
                try {
                    Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
                } catch (AtomicMoveNotSupportedException e) {
                    Files.move(tmp, file, StandardCopyOption.REPLACE_EXISTING);
                }
            } finally {
                Files.deleteIfExists(tmp);
            }
            return file;
        }
    }

    private static List<GameMap> maps(String arg) throws IOException {
        List<GameMap> maps = new ArrayList<>();
        for (String part : list(arg)) {
            Path p = Path.of(part);
            if (MapLoader.BUILTIN.contains(part)) {
                maps.add(MapLoader.builtin(part));
            } else if (Files.isDirectory(p)) {
                try (Stream<Path> files = Files.list(p)) {
                    List<Path> json = files.filter(f -> f.getFileName().toString().endsWith(".json")).sorted().toList();
                    if (json.isEmpty()) {
                        throw new IllegalArgumentException("--maps: в папке " + p + " нет карт .json");
                    }
                    for (Path f : json) {
                        maps.add(MapLoader.load(f));
                    }
                }
            } else if (Files.isRegularFile(p)) {
                maps.add(MapLoader.load(p));
            } else {
                throw new IllegalArgumentException("--maps: нет карты «" + part + "»");
            }
        }
        return maps;
    }

    private static List<String> list(String s) {
        List<String> parts = new ArrayList<>();
        for (String p : s.split(",")) {
            if (!p.isBlank()) {
                parts.add(p.strip());
            }
        }
        if (parts.isEmpty()) {
            throw new IllegalArgumentException("пустой список: «" + s + "»");
        }
        return parts;
    }

    private static long parseLong(String flag, String s) {
        try {
            return Long.parseLong(s.strip());
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException(flag + ": ждали число, а не «" + s + "»");
        }
    }

    /** {@code --args-file=<файл>}: флаги из файла UTF-8, по одному в строке, на его место в списке. */
    static String[] withArgsFile(String[] args) {
        List<String> all = new ArrayList<>();
        for (String arg : args) {
            if (!arg.strip().startsWith("--args-file=")) {
                all.add(arg);
                continue;
            }
            Path file = Path.of(arg.strip().substring("--args-file=".length()).strip());
            try {
                for (String line : Files.readAllLines(file, java.nio.charset.StandardCharsets.UTF_8)) {
                    if (line.startsWith("--args-file=")) {
                        throw new IllegalArgumentException("--args-file внутри " + file + " не бывает");
                    }
                    if (!line.isBlank()) {
                        all.add(line);
                    }
                }
            } catch (IOException e) {
                throw new IllegalArgumentException("--args-file: не прочитать " + file + ": " + e.getMessage());
            }
        }
        return all.toArray(String[]::new);
    }

    private static Map<String, String> parse(String[] args) {
        Map<String, String> m = new LinkedHashMap<>();
        for (String raw : args) {
            String arg = raw.strip();
            if (!arg.startsWith("--") || !arg.contains("=")) {
                throw new IllegalArgumentException("Неизвестный аргумент " + raw);
            }
            String key = arg.substring(2, arg.indexOf('='));
            if (!FLAGS.contains(key)) {
                throw new IllegalArgumentException("Неизвестный аргумент " + raw);
            }
            m.put(key, arg.substring(arg.indexOf('=') + 1).strip());
        }
        return m;
    }
}
