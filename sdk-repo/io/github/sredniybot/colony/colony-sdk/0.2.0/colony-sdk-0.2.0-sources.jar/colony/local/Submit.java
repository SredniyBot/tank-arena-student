package colony.local;

import colony.api.Colony;
import colony.homework.Step;
import colony.homework.Steps;
import colony.homework.Training;
import colony.net.Token;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.ZoneId;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.TreeMap;
import java.util.function.Supplier;
import java.util.stream.Collectors;

/**
 * «Сдать» ({@code Main --submit}): попытка на каждом непройденном шаге, где все пять учебных карт зелёные.
 * Уровень, у которого учебные карты вместе не набирают цели, пропускается: сначала тесты ({@code LevelsTest}).
 *
 * <p>С сервером ({@code colony.server} в {@code colony.properties} или {@code --server}) отметки и попытки — на
 * сервере, итог уходит в ведомость. Без сервера (прототип) попытка идёт у себя на новых картах, а пройденные шаги
 * записываются в {@code .colony/progress.json}; в ведомость они не попадают.
 */
final class Submit {

    /** Отметки о пройденных шагах без сервера, от папки проекта. */
    static final String PROGRESS = ".colony/progress.json";

    private static final SecureRandom RANDOM = new SecureRandom();
    private static final ZoneId MOSCOW = ZoneId.of("Europe/Moscow");
    private static final ObjectMapper JSON = new ObjectMapper();

    /** Сервер ДЗ: что пройдено и попытка шага. В тестах — подделка. */
    interface Server {
        /** Отметки студента или пусто с причиной в {@code why}. */
        Optional<Tasks.Status> status(StringBuilder why);

        /** Попытка шага на сервере, с выводом в консоль; 0 — попытка сыграна (пройдена или нет). */
        int attempt(int step);
    }

    /** Попытка у себя: зёрна новых карт и сколько сдано на каждой. */
    record LocalAttempt(List<Long> seeds, List<Integer> delivered) {}

    /** Игра колонии студента: учебные карты шага и попытка у себя. В тестах — подделка. */
    interface Player {
        List<Training.MapRun> training(Step s);

        LocalAttempt attempt(Step s);
    }

    private Submit() {}

    /** Из {@code Main --submit}: сервер задан — попытки на нём, иначе у себя. */
    static int run(Env env, Supplier<Colony> mine, URI server, Supplier<Token.Found> token) {
        Player player = player(env, mine);
        if (server == null) {
            return local(env, player, env.workDir().resolve(PROGRESS), LocalDate.now(MOSCOW));
        }
        Token.Found t;
        try {
            t = token.get();
        } catch (IllegalStateException e) {
            env.err().println(e.getMessage());
            return 1;
        }
        String warning = Token.gitWarning(env.workDir(), t.value());
        if (warning != null) {
            env.err().println(warning);
        }
        Server remote = new Server() {
            @Override
            public Optional<Tasks.Status> status(StringBuilder why) {
                return Tasks.status(server, () -> t, why);
            }

            @Override
            public int attempt(int step) {
                return Tasks.attempt(env, mine, step, server, t, Debugger::attached);
            }
        };
        return onServer(env, remote, player);
    }

    /** Настоящая игра: учебные карты и попытка у себя на новых картах (не учебных). */
    static Player player(Env env, Supplier<Colony> mine) {
        return new Player() {
            @Override
            public List<Training.MapRun> training(Step s) {
                return Training.playAll(s, mine, env.workDir());
            }

            @Override
            public LocalAttempt attempt(Step s) {
                List<Long> seeds = Steps.attemptSeeds(s, () -> {
                    long v;
                    do {
                        v = RANDOM.nextInt(1, 100_000);
                    } while (Training.isTraining(s.number(), v));
                    return v;
                });
                List<Integer> delivered = new ArrayList<>();
                for (int i = 0; i < seeds.size(); i++) {
                    delivered.add(Training.play(s, i + 1, seeds.get(i), mine, env.workDir()).delivered());
                }
                return new LocalAttempt(seeds, delivered);
            }
        };
    }

    // ---- с сервером ----

    static int onServer(Env env, Server server, Player player) {
        PrintStream out = env.out();
        StringBuilder why = new StringBuilder();
        Optional<Tasks.Status> st = server.status(why);
        if (st.isEmpty()) {
            env.err().println("Не узнать, какие уровни пройдены: " + why + ". Попытки не начаты.");
            return 1;
        }
        Tasks.Status status = st.get();
        out.println("Сдать: попытка на сервере — на каждом непройденном уровне, где учебные карты в сумме набирают цель.");
        if (!status.open() && status.deadline() != null) {
            out.println("Срок прошёл (" + status.deadline() + "): попытки играются, но баллов не дают.");
        }
        int code = 0;
        for (Step s : Steps.all()) {
            String head = s.label() + ": ";
            String on = status.passed().get(s.number());
            if (on != null) {
                out.println(head + "пройден " + day(on));
                continue;
            }
            int today = status.today().getOrDefault(s.number(), 0);
            if (status.leftToday(s.number()) <= 0) {
                out.println(head + "попыток на сегодня больше нет (" + today + " из " + status.perDay() + ")");
                continue;
            }
            String red = redMaps(player.training(s));
            if (red != null) {
                out.println(head + red);
                continue;
            }
            out.println(head + "учебные карты набирают цель — попытка на сервере");
            int c = server.attempt(s.number());
            if (c != 0) {
                out.println(head + "попытка не сыграна");
                code = c;
                continue;
            }
            Optional<Tasks.Status> after = server.status(new StringBuilder());
            if (after.isPresent()) {
                status = after.get();
                out.println(head + (status.passed().containsKey(s.number()) ? "попытка — уровень пройден ✓"
                        : "попытка — уровень не пройден"));
            }
        }
        out.println(summary(status.passed().keySet().stream().filter(n -> Steps.find(n).isPresent()).toList())
                + " Отметки — на сервере.");
        return code;
    }

    // ---- без сервера ----

    static int local(Env env, Player player, Path progressFile, LocalDate today) {
        PrintStream out = env.out();
        out.println("Сервер не задан (colony.server в colony.properties): попытки идут у себя, отметки — в "
                + PROGRESS + ". В ведомость они не попадают.");
        Map<Integer, String> passed = new TreeMap<>(readProgress(progressFile, env.err()));
        for (Step s : Steps.all()) {
            String head = s.label() + ": ";
            String on = passed.get(s.number());
            if (on != null) {
                out.println(head + "пройден " + day(on) + " (у себя)");
                continue;
            }
            String red = redMaps(player.training(s));
            if (red != null) {
                out.println(head + red);
                continue;
            }
            LocalAttempt a = player.attempt(s);
            Steps.Verdict v = Steps.judge(s, a.delivered());
            out.println(head + "попытка у себя на картах " + join(a.seeds()) + " — сдано " + join(a.delivered())
                    + " при цели " + s.total() + " вместе: " + (v.passed() ? "уровень пройден ✓"
                    : "уровень не пройден, повторы — в replays/step" + s.number() + "-<зерно>.html"));
            if (v.passed()) {
                passed.put(s.number(), today.toString());
                writeProgress(progressFile, passed, env.err());
            }
        }
        out.println(summary(List.copyOf(passed.keySet())) + " Это отметки у себя, в ведомость они не идут.");
        return 0;
    }

    // ---- общее ----

    /**
     * {@code null}, если учебные карты готовы к попытке: на них вместе сдано не меньше цели × число карт и
     * исключений не было (то же правило, что в попытке); иначе — почему нельзя, «сначала тесты».
     */
    static String redMaps(List<Training.MapRun> runs) {
        if (runs.isEmpty()) {
            return null;
        }
        List<Integer> crashed = runs.stream().filter(r -> r.exceptionTicks() > 0).map(Training.MapRun::map).toList();
        if (!crashed.isEmpty()) {
            return "на учебных картах " + join(crashed) + " колония бросала исключения — сначала тесты";
        }
        int sum = runs.stream().mapToInt(Training.MapRun::delivered).sum();
        int need = runs.get(0).step().goal() * runs.size();
        return sum >= need ? null : "на учебных картах вместе сдано " + sum + " из " + need + " — сначала тесты";
    }

    /** «Итог: пройдено уровней — 2 из 5 (1, 3), баллов 4 из 10.» */
    static String summary(List<Integer> passed) {
        List<Integer> sorted = passed.stream().sorted().toList();
        return "Итог: пройдено уровней — " + sorted.size() + " из " + Steps.all().size() + ", баллов "
                + sorted.size() * Steps.POINTS + " из " + Steps.all().size() * Steps.POINTS
                + (sorted.isEmpty() ? "." : " (" + join(sorted) + ").");
    }

    /** «2026-11-14…» → «14.11»; что-то другое — как есть. */
    static String day(String iso) {
        return iso != null && iso.length() >= 10 && iso.charAt(4) == '-' ? iso.substring(8, 10) + "."
                + iso.substring(5, 7) : String.valueOf(iso);
    }

    private static String join(List<? extends Number> list) {
        return list.stream().map(String::valueOf).collect(Collectors.joining(", "));
    }

    /** Отметки из {@code .colony/progress.json}: номер шага → дата. Нет файла или он испорчен — пусто. */
    static Map<Integer, String> readProgress(Path file, PrintStream err) {
        if (!Files.isRegularFile(file)) {
            return Map.of();
        }
        try {
            JsonNode passed = JSON.readTree(Files.readString(file, StandardCharsets.UTF_8)).path("passed");
            Map<Integer, String> out = new TreeMap<>();
            passed.fields().forEachRemaining(e -> {
                try {
                    out.put(Steps.get(Integer.parseInt(e.getKey())).number(), e.getValue().asText());
                } catch (IllegalArgumentException ignored) {
                    // чужой ключ — пропускаем
                }
            });
            return out;
        } catch (IOException | RuntimeException e) {
            err.println(PROGRESS + " не прочитан (" + e.getMessage() + "): считаю, что пройденных уровней нет.");
            return Map.of();
        }
    }

    static void writeProgress(Path file, Map<Integer, String> passed, PrintStream err) {
        ObjectNode root = JSON.createObjectNode();
        ObjectNode p = root.putObject("passed");
        passed.forEach((n, d) -> p.put(Integer.toString(n), d));
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, JSON.writerWithDefaultPrettyPrinter().writeValueAsString(root)
                    + System.lineSeparator(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            err.println(PROGRESS + " не записан: " + e.getMessage());
        }
    }
}
