package colony.sdk;

import colony.api.ColonyView;
import colony.api.DepositKind;
import colony.api.Pos;
import colony.api.UnitType;
import colony.engine.ColonySpec;
import colony.engine.GameMap;
import colony.engine.Match;
import colony.engine.MatchConfig;
import colony.engine.RuleSet;
import colony.engine.RulesLoader;
import colony.homework.Steps;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

/**
 * Тестовый мир для JUnit: карта строками превращается в {@link ColonyView} на такт 0. Нужен, чтобы проверить свой
 * {@link Pathfinder} без матча.
 *
 * <p>Легенда: {@code #} — стена, {@code .} — пол, {@code %} — завал, {@code 1} — своя база (ровно одна),
 * {@code W} — свой рабочий, {@code *} — жила, {@code $} — богатая жила. {@code x} растёт вправо, {@code y} — вниз.
 * Правила — как на картах ДЗ, все возможности включены: склад, завалы, улучшения.
 *
 * <pre>{@code ColonyView view = TestWorld.of("1.#.$", "W.#..", "..%..");}</pre>
 */
public final class TestWorld {

    private TestWorld() {}

    /**
     * Вид колонии 1 на такт 0. Рабочие {@code W} нумеруются с 1 по строкам, слева направо.
     *
     * <pre>{@code Optional<Direction> d = myPathfinder.next(TestWorld.of("W.$"), new Pos(0, 0), new Pos(2, 0));}</pre>
     *
     * @throws IllegalArgumentException строки разной длины, незнакомый знак, базы нет или их несколько
     */
    public static ColonyView of(String... rows) {
        List<String> map = new ArrayList<>();
        List<MatchConfig.StartUnit> workers = new ArrayList<>();
        for (int y = 0; y < rows.length; y++) {
            StringBuilder row = new StringBuilder(rows[y]);
            for (int x = 0; x < row.length(); x++) {
                if (row.charAt(x) == 'W') {
                    workers.add(new MatchConfig.StartUnit(1, UnitType.WORKER, new Pos(x, y)));
                    row.setCharAt(x, '.');
                }
            }
            map.add(row.toString());
        }
        GameMap gameMap = GameMap.of("test-world", 1, map,
                Map.of(DepositKind.NORMAL, 1000, DepositKind.RICH, 1000), List.of());
        MatchConfig cfg = MatchConfig.of(rules(), gameMap, 1L).withUnits(workers);
        try (Match m = Match.create(cfg, List.of(new ColonySpec("Тест", "ТС", () -> (view, orders) -> { })))) {
            return m.nextView(1);
        }
    }

    /** Правила уровней ДЗ (они же правила арены: все возможности открыты) без стартовых рабочих. */
    private static RuleSet rules() {
        ObjectNode json = RulesLoader.toJson(Steps.rules(Steps.get(3)));
        json.put("startWorkers", 0);
        ObjectNode f = (ObjectNode) json.get("features");
        f.put("depots", true);
        f.put("upgrades", true);
        return RulesLoader.fromJson(json);
    }
}
