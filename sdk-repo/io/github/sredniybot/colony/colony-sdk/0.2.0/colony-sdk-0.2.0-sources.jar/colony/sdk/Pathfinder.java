package colony.sdk;

import colony.api.ColonyView;
import colony.api.Direction;
import colony.api.Pos;
import colony.api.Terrain;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Куда шагнуть юниту, чтобы прийти к клетке {@code to}. Готовая реализация — {@link #SIMPLE}; свою можно написать,
 * реализовав один метод {@link #next}.
 *
 * <pre>{@code paths.next(view, worker.pos(), deposit.pos()).ifPresent(d -> orders.move(worker.id(), d));}</pre>
 */
public interface Pathfinder {

    /**
     * Шаг из {@code from} к {@code to}. Цель может быть закрытой клеткой — жилой, базой, складом: тогда
     * прийти — значит встать рядом с ней.
     *
     * <pre>{@code Optional<Direction> d = paths.next(view, worker.pos(), base.pos());}</pre>
     *
     * @return направление шага; пусто — уже пришли (стоим на {@code to} или рядом с закрытой {@code to})
     *         или шагнуть некуда
     */
    Optional<Direction> next(ColonyView view, Pos from, Pos to);

    /**
     * Кратчайший путь ({@link ShortestPath}): обходит стены и ведёт сквозь завал, если копать выгоднее обхода.
     *
     * <pre>{@code private final Pathfinder paths = Pathfinder.SHORTEST;}</pre>
     */
    Pathfinder SHORTEST = new ShortestPath();

    /**
     * Жадный шаг. Сначала — по оси, где до цели дальше; если там закрыто — по другой оси; если закрыто и там —
     * в первую открытую соседнюю клетку в порядке N, E, S, W. Путь не ищет и ничего не помнит: каждый вызов
     * смотрит только на соседние клетки. Юнитов не обходит. Закрытыми считает всё, что не проходит
     * {@link #passable}.
     *
     * <pre>{@code private final Pathfinder paths = Pathfinder.SIMPLE;}</pre>
     */
    Pathfinder SIMPLE = (view, from, to) -> {
        if (from.equals(to) || from.manhattan(to) == 1 && !passable(view, to)) {
            return Optional.empty();
        }
        int dx = to.x() - from.x();
        int dy = to.y() - from.y();
        Direction alongX = dx > 0 ? Direction.EAST : Direction.WEST;
        Direction alongY = dy > 0 ? Direction.SOUTH : Direction.NORTH;
        List<Direction> tries = new ArrayList<>();
        if (Math.abs(dx) >= Math.abs(dy)) {
            if (dx != 0) {
                tries.add(alongX);
            }
            if (dy != 0) {
                tries.add(alongY);
            }
        } else {
            tries.add(alongY);
            if (dx != 0) {
                tries.add(alongX);
            }
        }
        tries.addAll(List.of(Direction.values())); // по осям закрыто — любая открытая соседняя
        for (Direction d : tries) {
            if (passable(view, from.step(d))) {
                return Optional.of(d);
            }
        }
        return Optional.empty();
    };

    /**
     * Клетку можно пройти: она внутри карты, это пол, и на ней нет базы, постройки или жилы. Юниты не учитываются.
     *
     * <pre>{@code if (Pathfinder.passable(view, worker.pos().step(Direction.EAST))) { ... }}</pre>
     */
    static boolean passable(ColonyView view, Pos p) {
        return view.inside(p) && view.terrain(p) == Terrain.FLOOR && view.baseAt(p).isEmpty()
                && view.structureAt(p).isEmpty() && view.depositAt(p).isEmpty();
    }
}
