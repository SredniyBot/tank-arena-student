package colony.local;

import java.io.IOException;
import java.io.Reader;
import java.io.StringReader;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.Properties;

/**
 * {@code colony.properties} в папке проекта, в UTF-8:
 * <pre>
 * colony.name=Муравейник     имя колонии (по умолчанию «Вы»)
 * colony.sign=МР             знак из двух букв (по умолчанию — первые буквы имени)
 * colony.class=student.MyColony   класс колонии для «прошлой версии»
 * league=3                   своя лига: правила, карты и босс локальной игры (по умолчанию 1)
 * </pre>
 */
record ColonyProperties(String name, String sign, String colonyClass, int league) {

    static final String FILE = "colony.properties";
    static final String DEFAULT_NAME = "Вы";
    static final String DEFAULT_SIGN = "ВЫ";
    static final String DEFAULT_CLASS = "student.MyColony";

    static ColonyProperties defaults() {
        return new ColonyProperties(DEFAULT_NAME, DEFAULT_SIGN, DEFAULT_CLASS, League.DEFAULT);
    }

    /** Из папки проекта; файла нет — значения по умолчанию. */
    static ColonyProperties load(Path dir) {
        Path file = dir.resolve(FILE);
        if (!Files.isRegularFile(file)) {
            return defaults();
        }
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            return from(r);
        } catch (IOException e) {
            throw new UncheckedIOException("не удалось прочитать " + file, e);
        }
    }

    static ColonyProperties parse(String text) {
        try {
            return from(new StringReader(text));
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    private static ColonyProperties from(Reader r) throws IOException {
        Properties p = new Properties();
        p.load(r);
        String name = value(p, "colony.name");
        String sign = value(p, "colony.sign");
        String cls = value(p, "colony.class");
        if (name == null) {
            name = DEFAULT_NAME;
            sign = sign == null ? DEFAULT_SIGN : sign;
        }
        String league = value(p, "league");
        int n = League.DEFAULT;
        if (league != null) {
            try {
                n = new League(Integer.parseInt(league)).number();
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException("в " + FILE + " строка league=" + league + ": нужен номер лиги от 1 до "
                        + colony.engine.RulesLoader.LEAGUES);
            }
        }
        return new ColonyProperties(name, sign, cls == null ? DEFAULT_CLASS : cls, n);
    }

    private static String value(Properties p, String key) {
        String v = p.getProperty(key);
        return v == null || v.isBlank() ? null : v.strip();
    }
}
