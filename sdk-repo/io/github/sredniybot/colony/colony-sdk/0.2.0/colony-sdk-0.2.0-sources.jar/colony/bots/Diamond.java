package colony.bots;

import colony.api.ColonyView;
import colony.api.UnitType;

/**
 * «Алмаз» — босс лиги 5. Держит четыре танка: они стоят в зоне центра и бьют первого чужого на прямой. Пока танков
 * меньше двух, центр держат рабочие, как у «платины»; потом рабочие добывают. Охрана — двое рабочих, как у «золота»,
 * и пока копит на танки.
 */
public final class Diamond extends LeagueBoss {

    public Diamond() {
        this(1);
    }

    public Diamond(long seed) {
        super(seed);
    }

    @Override
    int tanks(ColonyView view) {
        return view.rules().tanks().map(t -> t.max()).orElse(0);
    }

    @Override
    int guards(ColonyView view, int workers) {
        return 2;
    }

    @Override
    int holders(ColonyView view, int workers) {
        long tanks = view.myUnits().stream().filter(u -> u.type() == UnitType.TANK).count();
        return tanks >= 2 || workers < 4 ? 0 : 3;
    }
}
