package colony.bots;

import colony.api.Base;
import colony.api.ColonyView;
import colony.api.Deposit;
import colony.api.Unit;
import colony.engine.Navigator;
import java.util.Optional;

/**
 * «Серебро» — второй соперник. Держит до восьми рабочих и раздаёт их по залежам: чем ближе и полнее залежь, тем
 * лучше; у одной залежи — не больше двух рабочих (у богатой — трёх). Под конец матча рабочих больше не строит.
 */
public final class Silver extends HarvestBot {

    static final int CAP = 8;
    /** За сколько тактов до конца перестаём строить: новый рабочий уже не окупится. */
    static final int STOP_BUILDING_BEFORE_END = 400;

    private final int reserve;
    private final int cap;

    public Silver() {
        this(1);
    }

    /** @param seed зерно матча: от него — запас энергии перед стройкой и выбор между равными залежами */
    public Silver(long seed) {
        this(seed, CAP);
    }

    /** Для проверок глубины: то же, но держит не больше {@code workers} рабочих. */
    public Silver(long seed, int workers) {
        super(seed);
        this.reserve = random.nextInt(21);
        this.cap = workers;
    }

    @Override
    int workerCap(ColonyView view) {
        return cap;
    }

    @Override
    boolean wantWorker(ColonyView view) {
        return view.tick() < view.maxTicks() - STOP_BUILDING_BEFORE_END
                && view.energy() >= view.rules().workerCost() + reserve;
    }

    @Override
    Optional<Deposit> choose(ColonyView view, Navigator nav, Base base, Unit worker) {
        return bestByValue(view, nav, base);
    }
}
