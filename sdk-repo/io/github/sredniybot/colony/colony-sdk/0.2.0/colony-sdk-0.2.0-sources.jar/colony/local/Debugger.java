package colony.local;

import java.lang.management.ManagementFactory;
import java.util.List;
import java.util.concurrent.atomic.AtomicBoolean;

/**
 * Есть ли агент отладки JDWP в параметрах JVM (подключился ли к нему отладчик, мы не знаем). На точке останова в {@code onTick} такт стоит дольше лимита движка, и колония получила бы
 * TIMEOUT; в локальной игре при отладчике лимит снимается.
 */
final class Debugger {

    static final String NOTICE = "Отладчик подключён: лимит времени такта снят";

    private static final AtomicBoolean NOTICE_SHOWN = new AtomicBoolean();

    private Debugger() {}

    /** В параметрах JVM есть агент отладки ({@code -agentlib:jdwp…} или {@code -Xrunjdwp…}). */
    static boolean isJdwp(List<String> jvmArguments) {
        for (String a : jvmArguments) {
            if (a.equals("-agentlib:jdwp") || a.startsWith("-agentlib:jdwp=") || a.equals("-Xrunjdwp")
                    || a.startsWith("-Xrunjdwp:")) {
                return true;
            }
        }
        return false;
    }

    static boolean attached() {
        return isJdwp(ManagementFactory.getRuntimeMXBean().getInputArguments());
    }

    /** {@code true} только в первый раз за программу: сообщение печатается один раз. */
    static boolean firstNotice() {
        return NOTICE_SHOWN.compareAndSet(false, true);
    }

    /** Для тестов. */
    static void resetNotice() {
        NOTICE_SHOWN.set(false);
    }
}
