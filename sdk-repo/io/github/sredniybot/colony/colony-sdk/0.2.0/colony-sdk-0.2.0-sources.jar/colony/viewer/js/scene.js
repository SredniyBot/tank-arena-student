// Сцена в момент T (дробный номер кадра). Общая для 2D и диорамы.
// Между кадрами a и b = a+1 юниты движутся линейно; при T = a сцена совпадает с кадром a.
import { clamp, lerp } from './util.js';

// отказы всей колонии: номер 0 у них — не первая база
const WHOLE_COLONY = new Set(['EXCEPTION', 'TIMEOUT', 'TOO_MANY_ORDERS']);
const angLerp = (a, b, k) => { let d = b - a; while (d > Math.PI) d -= 2 * Math.PI; while (d < -Math.PI) d += 2 * Math.PI; return a + d * k; };

export function compose(match, T, o) {
  const F = match.frames, n = F.length;
  T = clamp(T, 0, Math.max(0, n - 1));
  const a = Math.floor(T), b = Math.min(n - 1, a + 1), k = b === a ? 0 : T - a;
  const fa = F[a], fb = F[b];
  const reduced = !!o.reduced;
  const kk = reduced ? (k < 0.5 ? 0 : 1) : k;
  const msPerTick = 1000 / Math.max(0.25, o.speed || 1);
  const S = { T, a, b, k, kk, msPerTick, t: fa.t, frame: fa, units: [], dying: [], shots: [], fx: [], deaths: [], pops: [], flows: [], ruins: [], marks: [] };

  // кто в бою: стрелял или получил попадание в последние такты — у таких танков виден знак колонии
  const fight = new Set();
  for (let i = Math.max(0, a - 3); i <= b; i++) for (const id of F[i]._fight || []) fight.add(id);
  // юниты кадра b, приходящие из кадра a
  const posA = new Map();
  fb.units.forEach((u, j) => {
    const pj = b === a ? j : fb._prev[j];
    const p = pj >= 0 ? (b === a ? u : fa.units[pj]) : null;
    let x = u.x, y = u.y, alpha = 1, h = u._h, tur = u._tur ?? u._h;
    if (p) {
      const jump = Math.abs(u.x - p.x) + Math.abs(u.y - p.y) > 2;
      const kx = jump ? (kk < 0.5 ? 0 : 1) : kk;
      x = lerp(p.x, u.x, kx); y = lerp(p.y, u.y, kx);
      h = p.x !== u.x || p.y !== u.y ? u._h : p._h;
      if (p._tur !== undefined || u._tur !== undefined) tur = angLerp(p._tur ?? p._h, u._tur ?? h, reduced ? kk : clamp(k * 2.2, 0, 1));
      else tur = h;
    } else alpha = kk; // появляется в кадре b
    const src = p || u;
    S.units.push({ id: u.id, n: u.n ?? u.id, c: u.c, k: u.k, x, y, h, tur, hp: src.hp, max: match.unitMax(u), carry: src.carry || 0, alpha, born: !p, fight: fight.has(u.id), moving: !!p && (p.x !== u.x || p.y !== u.y), fired: !!u._fired && kk > 0 && k < 0.35, up: src.up || u.up || null });
    posA.set(u.id, S.units[S.units.length - 1]);
  });
  // гибнущие в кадре b: стоят на месте и тают
  if (b !== a) for (const d of fb._deaths) S.dying.push({ id: d.id, c: d.c, k: d.k, x: d.x, y: d.y, h: d.h, tur: d.tur ?? d.h, alpha: 1 - kk, hp: 0, max: 1, carry: 0 });

  // снаряды: летящие в такте b и только что упавшие в такте a
  const tail = 1.15;
  const shotOf = (s, prog, alpha, landed) => {
    const dx = s.tx - s.fx, dy = s.ty - s.fy, len = Math.hypot(dx, dy) || 1, ux = dx / len, uy = dy / len;
    const hx = s.fx + 0.5 + dx * prog, hy = s.fy + 0.5 + dy * prog;
    const tl = Math.min(tail, len * prog + (landed ? 0 : 0.35));
    return { c: s.c, hx, hy, tx: hx - ux * tl, ty: hy - uy * tl, ang: Math.atan2(dy, dx), alpha, hit: s.hit };
  };
  // удары лиг мгновенные: не летят, а вспыхивают — рабочий бьёт вплотную, танк — лучом по прямой
  const flying = s => s.kind !== 'melee' && s.kind !== 'strike';
  if (b !== a && kk > 0) for (const s of fb.shots) if (flying(s)) S.shots.push(shotOf(s, kk, 1, false));
  if (reduced) { if (kk === 0) for (const s of fa.shots) if (flying(s)) S.shots.push(shotOf(s, 1, 1, true)); }
  else if (k < 0.3) for (const s of fa.shots) if (flying(s)) S.shots.push(shotOf(s, 1, 1 - k / 0.3, true));

  // разовые эффекты гаснут за 200 мс настенного времени
  const FX_MS = 200;
  const back = Math.min(a, Math.ceil(FX_MS / msPerTick) + 1);
  for (let i = a - back; i <= a; i++) {
    const f = F[i]; if (!f) continue;
    const ms = (T - i) * msPerTick, age = reduced ? (T - i < 1 ? 0 : 1) : ms / FX_MS;
    if (age < 0 || age >= 1) continue;
    for (const h of f._hits) S.fx.push({ kind: 'hit', x: h.x + 0.5, y: h.y + 0.5, age, c: h.c });
    for (const h of f._baseHits) S.fx.push({ kind: 'hit', x: h.x + 0.5, y: h.y + 0.5, age, c: h.c, big: true });
    for (const s of f.shots) {
      if (s.kind === 'melee') S.fx.push({ kind: 'slash', x: s.tx + 0.5, y: s.ty + 0.5, ang: Math.atan2(s.ty - s.fy, s.tx - s.fx), age, c: s.c });
      else if (s.kind === 'strike') S.fx.push({ kind: 'beam', x: s.fx + 0.5, y: s.fy + 0.5, x1: s.tx + 0.5, y1: s.ty + 0.5, age, c: s.c });
      else if (s.hit == null) S.fx.push({ kind: 'puff', x: s.tx + 0.5, y: s.ty + 0.5, age });
    }
  }
  if (b !== a && !reduced) {
    const ms = k * msPerTick;
    if (ms < FX_MS) for (const s of fb.shots) {
      if (s.kind === 'melee') continue;
      const u = fb.units.find(u => u._fired && u.c === s.c && Math.abs(u.x - s.fx) + Math.abs(u.y - s.fy) <= 1);
      if (u || s.fx !== s.tx || s.fy !== s.ty) S.fx.push({ kind: 'muzzle', x: s.fx + 0.5, y: s.fy + 0.5, ang: Math.atan2(s.ty - s.fy, s.tx - s.fx), age: ms / FX_MS, c: s.c, first: !!u });
    }
  }

  // следы гибели держатся несколько тактов
  const TRACE = 12;
  for (let i = Math.max(1, a - TRACE); i <= a; i++) {
    for (const d of F[i]._deaths) S.deaths.push({ ...d, age: T - i });
  }
  for (const r of match.ruins) if (r.i <= a) S.ruins.push({ ...r, age: T - r.i });

  // доставка энергии: «+20» над базой, около секунды
  const POP_MS = 950;
  const pback = Math.min(a, Math.ceil(POP_MS / msPerTick) + 1, 3);
  for (let i = a - pback; i <= a; i++) {
    const f = F[i]; if (!f || !f._pops.length) continue;
    const age = Math.max((T - i) * msPerTick / POP_MS, (T - i) / 2.5); // на большой скорости не копим «+20»
    if (age >= 0 && age < 1) f._pops.forEach((p, idx) => S.pops.push({ ...p, age, idx }));
  }
  // добыча: крупица летит от залежи к рабочему в такте b
  if (b !== a && !reduced) for (const fl of fb._flows) { const u = posA.get(fl.id); if (u) S.flows.push({ x0: fl.x + 0.5, y0: fl.y + 0.5, x1: u.x + 0.5, y1: u.y + 0.5, k: kk, c: u.c }); }

  // отказы выбранной колонии: красные метки на юнитах
  if (o.selected != null) {
    const list = fa.rejections[String(o.selected)] || [];
    for (const r of list) {
      // номер в отказе — номер в колонии (первая база — 0); отказы всей колонии ни к кому не привязаны
      if (WHOLE_COLONY.has(r.code)) continue;
      const fu = fa.units.find(x => x.c === o.selected && (x.n ?? x.id) === r.unit);
      const u = fu && (posA.get(fu.id) || fu);
      if (u) S.marks.push({ x: u.x, y: u.y, unit: fu.id, code: r.code });
      else { const bs = fa.bases.find(x => x.c === o.selected && (x.n ?? x.id) === r.unit); if (bs) S.marks.push({ x: bs.x, y: bs.y, unit: r.unit, code: r.code, base: true }); }
    }
  }
  return S;
}

// Горячие точки около кадра a: выстрелы, гибель, удары по базам, налётчики.
const hotCache = new Map();
export function hotspots(match, a) {
  const key = a + ':' + match.version;
  if (hotCache.has(key)) return hotCache.get(key);
  const pts = [];
  for (let i = Math.max(0, a - 3); i <= Math.min(match.last, a + 1); i++) {
    const f = match.frames[i];
    for (const s of f.shots) pts.push({ x: (s.fx + s.tx) / 2 + 0.5, y: (s.fy + s.ty) / 2 + 0.5, w: 1, c: s.c });
    for (const d of f._deaths) if (d.killer) pts.push({ x: d.x + 0.5, y: d.y + 0.5, w: 3, c: d.c, k: d.killer.c });
    for (const h of f._baseHits) pts.push({ x: h.x + 0.5, y: h.y + 0.5, w: 2, c: h.c });
  }
  for (const r of match.ruins) if (r.i >= a - 3 && r.i <= a + 1) pts.push({ x: r.x + 0.5, y: r.y + 0.5, w: 12, c: r.c }); // гибель базы — главное событие
  const f = match.frames[a];
  if (f) for (const u of f.units) if (u.k === 'R') pts.push({ x: u.x + 0.5, y: u.y + 0.5, w: 0.6, c: 0 });
  const groups = [];
  for (const p of pts) {
    let g = groups.find(g => Math.hypot(g.x - p.x, g.y - p.y) < 6);
    if (!g) { g = { x: p.x, y: p.y, w: 0, n: 0, cols: new Set() }; groups.push(g); }
    g.x = (g.x * g.n + p.x) / (g.n + 1); g.y = (g.y * g.n + p.y) / (g.n + 1); g.n++; g.w += p.w;
    if (p.c) g.cols.add(p.c); if (p.k) g.cols.add(p.k);
  }
  groups.sort((x, y) => y.w - x.w);
  if (hotCache.size > 400) hotCache.clear();
  hotCache.set(key, groups);
  return groups;
}
