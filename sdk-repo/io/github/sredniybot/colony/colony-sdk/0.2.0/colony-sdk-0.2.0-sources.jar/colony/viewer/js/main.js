// Просмотр «Колонии»: повтор (?replay=имя) или живая игра (?live=1). Без параметров — список повторов.
import { $, clamp, clip, int, storeGet, storeSet } from './util.js';
import { Match, checkFormat, gameKey, MOMENT_LEAD } from './match.js';
import { compose } from './scene.js';
import { Camera, Director } from './camera.js';
import { Renderer2D } from './render2d.js';
import { Hud, SPEEDS, speedText } from './hud.js';
import { Minimap } from './minimap.js';
import { showStart, showLoading, showMessage, hideStart, pretty } from './start.js';

const q = new URLSearchParams(location.search);
const reducedMQ = matchMedia('(prefers-reduced-motion: reduce)');
if (storeGet('big', false)) document.documentElement.classList.add('big');

boot();

async function boot() {
  try { await Promise.race([Promise.all([document.fonts.load('600 16px Onest', 'Колония'), document.fonts.load('600 16px Onest', 'steps-4')]), new Promise(r => setTimeout(r, 1500))]); } catch { /* системный шрифт */ }
  if (q.has('live')) return startLive();
  if (q.has('replay')) return startReplay(q.get('replay'));
  return showStart();
}

// ------------------------------------------------------------------ загрузка
async function startReplay(name) {
  const ui = showLoading(`Загружаю повтор ${pretty(name)}`);
  document.title = `${pretty(name)} — Колония`;
  let data;
  try {
    // на сервере повторы домашнего задания лежат в его сеансе: ?session=homework
    const session = q.get('session') ? `?session=${encodeURIComponent(q.get('session'))}` : '';
    const r = await fetch(`api/replays/${encodeURIComponent(name)}${session}`, { cache: 'no-store' });
    if (r.status === 404) return showMessage(`Повтор «${pretty(name)}» не найден.`, 'Возможно, файл удалили или переименовали.');
    if (!r.ok) return showMessage('Не удалось загрузить повтор.', `Сервер ответил ${r.status}. Проверьте, что игра или стенд запущены.`);
    const total = +r.headers.get('Content-Length') || 0;
    if (r.body && total) {
      const reader = r.body.getReader(), chunks = []; let got = 0;
      for (;;) { const { done, value } = await reader.read(); if (done) break; chunks.push(value); got += value.length; ui.progress(got / total); }
      ui.text('Разбираю повтор');
      data = JSON.parse(await new Blob(chunks).text());
    } else data = await r.json();
  } catch {
    return showMessage('Не удалось прочитать повтор.', 'Файл повреждён или это не JSON.');
  }
  const bad = checkFormat(data);
  if (bad) return showMessage(bad, '');
  if (!data.frames?.length) return showMessage('В повторе нет ни одного такта.', '');
  const { frames, ...meta } = data;
  const match = new Match(meta);
  await new Promise(r => setTimeout(r, 0));
  match.add(frames);
  match.finished = true;
  hideStart();
  new Viewer(match, { live: false, name }).mount();
}

// Сервер лиг: ?session=world-N — какой мир показывать; без него сервер даёт самый живой, и просмотр держится за него.
let liveSession = new URLSearchParams(location.search).get('session');
const sessionQuery = () => (liveSession ? `session=${encodeURIComponent(liveSession)}` : '');
async function fetchMeta() {
  try {
    const r = await fetch('api/live/meta' + (liveSession ? '?' + sessionQuery() : ''), { cache: 'no-store' });
    if (r.ok && r.status !== 204) { const j = await r.json(); if (j && j.format === 'colony-replay') { if (j.session) liveSession = j.session; return j; } }
  } catch { /* сервер ещё не поднялся */ }
  return null;
}

async function startLive() {
  document.title = 'Игра — Колония';
  showLoading('Подключаюсь к игре');
  let meta = null, waited = 0;
  while (!(meta = await fetchMeta())) {
    if (waited++ === 2) showMessage('Игра ещё не началась.', ['Запустите ', ['Main'], ' — просмотр подключится сам.'], true);
    await sleep(1000);
  }
  const bad = checkFormat(meta);
  if (bad) return showMessage(bad, '');
  const match = new Match(meta);
  match.finished = false;
  const feed = new LiveFeed(match, gameKey(meta));
  while (!match.frames.length) { await feed.pull(); if (!match.frames.length) await sleep(250); }
  hideStart();
  const v = new Viewer(match, { live: true, feed });
  v.mount();
  feed.start(v);
}

const sleep = ms => new Promise(r => setTimeout(r, ms));
const capture = (el, e) => { try { el.setPointerCapture(e.pointerId); } catch { /* указатель уже отпущен */ } };

// Опрос кадров живой игры каждые 250 мс; если такт опоздал, просмотр держит кадр, а не выдумывает.
// Каждый запрос захватывает последний известный кадр ещё раз: если он не совпал, на порту уже другая игра.
// Кадры просим по номеру такта: общая арена отдаёт только последние, и первый пришедший кадр — не нулевой.
// На арене просмотр держит последние LIVE_KEEP–2·LIVE_KEEP кадров, иначе за часы съест память вкладки.
const LIVE_KEEP = 600;
class LiveFeed {
  constructor(match, key) { this.m = match; this.key = key; this.fails = 0; this.rate = 4; this.lastArrive = performance.now(); this.viewer = null; this.newGame = false; }
  async pull() {
    try {
      const have = this.m.frames.length, from = have ? this.m.frames[have - 1].t : 0;
      const r = await fetch(`api/live/frames?from=${from}${liveSession ? '&' + sessionQuery() : ''}`, { cache: 'no-store' });
      if (!r.ok) throw new Error(String(r.status));
      const j = await r.json();
      let frames = Array.isArray(j.frames) ? j.frames : [];
      if (have && frames.length) {
        const mine = this.m.frames[have - 1], theirs = frames[0];
        if (theirs.t !== mine.t || JSON.stringify(theirs.colonies) !== JSON.stringify(mine.colonies)) { this.newGame = true; return 0; }
        frames = frames.slice(1);
      }
      if (this.fails >= 3) { const meta = await fetchMeta(); if (meta && gameKey(meta) !== this.key) { this.newGame = true; return 0; } }
      const n = frames.length, now = performance.now();
      if (n) {
        const dt = (now - this.lastArrive) / 1000;
        if (have && dt > 0.05 && n < 40) this.rate = clamp(this.rate * 0.7 + (n / dt) * 0.3, 0.5, 200);
        this.lastArrive = now;
        this.m.add(frames);
        if (this.viewer && this.m.endless && this.m.frames.length > 2 * LIVE_KEEP) this.viewer.trim(this.m.frames.length - LIVE_KEEP);
      }
      if (j.result) this.m.result = j.result;
      if (j.finished) this.m.finished = true;
      this.fails = 0;
      return n;
    } catch { this.fails++; return 0; }
  }
  // Имена мест меняются посреди мира: «Аня (бот)», пока за Аню играет бот сервера, и «Аня», когда она вошла.
  async rename(viewer) {
    const meta = await fetchMeta();
    if (!meta || String(meta.gameId) !== String(this.m.meta.gameId)) return;
    for (const c of meta.colonies || []) {
      const col = this.m.colonies.get(int(c.id)), name = clip(c.name ?? '', 40);
      if (col && name && col.name !== name) { col.name = name; viewer.hud.rename(col); }
    }
    this.key = gameKey(meta);
  }
  start(viewer) {
    this.viewer = viewer;
    let named = performance.now();
    const loop = async () => {
      const n = await this.pull();
      if (this.newGame) { viewer.hud.toast('Началась новая игра'); setTimeout(() => location.reload(), 900); return; }
      if (performance.now() - named > 5000) { named = performance.now(); await this.rename(viewer); }
      viewer.onLive(n, this);
      if (!this.m.finished) setTimeout(loop, 250);
    };
    loop();
  }
}

// ------------------------------------------------------------------ просмотр
class Viewer {
  constructor(match, opts) {
    this.m = match; this.opts = opts; this.live = !!opts.live;
    this.T = 0; this.playing = true; this.speed = 4; // скорость не запоминаем: повтор всегда начинается одинаково
    this.selected = null; this.hoverCol = null; this.hoverUnit = null; this.pinned = null;
    this.follow = this.live; this.dio = false; this.dioApi = null; this.dioFailed = false;
    this.lastHud = 0; this.lastI = -1; this.dirty = true; this.prev = 0; this.phone = null;
  }

  mount() {
    const m = this.m;
    $('#app').hidden = false; $('#map').hidden = false;
    this.cam = new Camera(m);
    this.dir = new Director(m, this.cam);
    this.r2d = new Renderer2D($('#map'), m, this.cam);
    this.hud = new Hud(m, this);
    this.hud.build();
    this.mini = new Minimap($('#mini'), $('#miniWrap'), m);
    this.hud.setMode(this.live ? 'вживую' : 'повтор', this.live ? 'live' : '');
    this.hud.setPressed('big', document.documentElement.classList.contains('big'));
    document.title = `${m.map.name} — Колония`;

    // начальное состояние из ссылки
    const tq = q.get('t'), fq = q.get('focus');
    this.selected = fq && m.colonies.has(+fq) ? +fq : m.studentColony();
    if (tq !== null && !this.live) {
      const t = +tq, idx = m.frames.findIndex(f => f.t >= t);
      this.T = idx < 0 ? m.last : idx; this.playing = false;
    }
    if (this.live) this.T = Math.max(0, m.last - 1.25);
    this.camQuery = q.get('cam'); // x,y,клеток по короткой стороне — для воспроизводимых снимков
    this.dir.on = m.W >= 56 || m.colonyList.length >= 6;
    this.hud.setPressed('dir', this.dir.on);
    this.hud.setPlaying(this.playing); this.hud.setSpeed(this.speed);
    this.syncTotal();

    // проверка WebGL: контекст сразу отпускаем, чтобы не держать лишний
    this.webgl = (() => { try { const c = document.createElement('canvas'), gl = c.getContext('webgl2'); if (!gl) return false; gl.getExtension('WEBGL_lose_context')?.loseContext(); return true; } catch { return false; } })();
    if (!this.webgl) for (const b of document.querySelectorAll('[data-act="dio"]')) b.hidden = true;

    this.layout();
    this.bind();
    addEventListener('resize', () => { this.layout(); this.renderNow(true); });
    reducedMQ.addEventListener?.('change', () => this.renderNow(true));
    this.renderNow(true);
    requestAnimationFrame(t => this.frame(t));
    const view = q.get('view');
    if (this.webgl && (view === 'diorama' || (view !== '2d' && storeGet('dio', false)))) this.toggleDio(true);
  }

  // Длина шкалы: повтор — все кадры; живая игра — по плану матча, бегунок идёт слева направо.
  syncTotal() {
    const m = this.m, planned = this.live && !m.finished && !m.endless ? (m.rules.maxTicks || 0) - (m.frames[0]?.t || 0) : 0;
    this.hud.setTotal(Math.max(m.last, planned, 1));
  }

  // Размеры, отступы под панели, размер подписей.
  layout() {
    const W = innerWidth, H = innerHeight, dpr = Math.min(2, devicePixelRatio || 1);
    const phone = W <= 640, side = $('#side');
    // лист сворачиваем только при переходе в телефонную раскладку, а не при каждом повороте
    if (phone !== this.phone) { side.classList.toggle('collapsed', phone); $('#grip').setAttribute('aria-expanded', 'false'); }
    this.phone = phone;
    const collapsed = side.classList.contains('collapsed');
    if (phone && !collapsed) side.classList.add('collapsed');
    const cap = $('#caption').getBoundingClientRect(), sr = side.getBoundingClientRect(), tr = $('#time').getBoundingClientRect();
    if (phone && !collapsed) side.classList.remove('collapsed');
    const ins = phone
      ? { l: 6, r: 6, t: cap.bottom + 6, b: H - sr.top + 6 }
      : { l: 18, t: cap.bottom + 12, r: W - sr.left + 14, b: H - tr.top + 12 };
    const root = parseFloat(getComputedStyle(document.documentElement).fontSize) || 16;
    this.labelPx = Math.round(clamp(root * 1.05, 13, 26));
    document.documentElement.style.setProperty('--label-px', this.labelPx + 'px');
    const first = this.cam.W === 1, wasFit = this.cam.isFit() || first;
    this.cam.setViewport(W, H, ins);
    if (wasFit) this.cam.fitNow(); else this.cam.clampTarget();
    // телефон в портрете: карта шире экрана, поэтому открываем крупнее, на своей колонии
    if (first && phone && H > W * 1.2) {
      const ah = H - ins.t - ins.b, s = Math.min(this.cam.fitScale() * 2.4, ah / (this.m.H + 1.4));
      const b = this.m.frames[this.frameIndex].bases.find(b => b.c === this.selected);
      this.cam.lookAt(b ? b.x + 0.5 : this.m.W / 2, b ? b.y + 0.5 : this.m.H / 2, s);
      this.cam.cx = this.cam.target.cx; this.cam.cy = this.cam.target.cy; this.cam.s = this.cam.target.s;
    }
    if (this.camQuery) { const [x, y, n] = this.camQuery.split(',').map(Number); if (n) { this.dir.on = false; this.hud.setPressed('dir', false); const short = Math.min(W - ins.l - ins.r, H - ins.t - ins.b); this.cam.lookAt(x, y, short / n); this.cam.cx = this.cam.target.cx; this.cam.cy = this.cam.target.cy; this.cam.s = this.cam.target.s; } }
    this.r2d.resize(W, H, dpr, this.labelPx);
    if (this.dioApi) this.dioApi.resize(W, H, dpr);
    this.hud.measure();
    this.mini.layout();
    this.dirty = true;
  }

  // ---------------------------------------------------------------- время
  get frameIndex() { return Math.floor(this.T); }
  setPlaying(on) {
    if (on && !this.live && this.T >= this.m.last) this.T = 0;
    this.playing = on; this.hud.setPlaying(on);
    if (!on) this.follow = false;
    this.syncLive(); this.renderNow();
  }
  setSpeed(v) { this.speed = v; this.hud.setSpeed(v); if (this.live && this.follow) this.follow = false; this.syncLive(); }
  seek(T, pause) {
    this.T = clamp(T, 0, this.m.last);
    if (this.live) this.follow = false;
    if (pause) { this.playing = false; this.hud.setPlaying(false); }
    this.syncLive(); this.renderNow(true);
  }
  step(d) { this.seek(Math.round(this.T) + d, true); }
  next() {
    const mo = this.m.nextMoment(this.frameIndex);
    if (!mo) { this.hud.toast('Дальше ярких событий нет'); return; }
    this.seek(Math.max(0, mo.i - MOMENT_LEAD));
    if (mo.x != null && !this.cam.isFit()) this.cam.lookAt(mo.x + 0.5, mo.y + 0.5);
  }
  // Общая арена выбросила старые кадры: номер текущего кадра сдвигается вместе с ними.
  trim(k) {
    const d = this.m.trim(k);
    if (!d) return;
    this.T = Math.max(0, this.T - d); this.lastI -= d;
    this.hud.trimmed(d); this.syncTotal(); this.dirty = true;
  }
  goLive() { this.follow = true; this.playing = true; this.T = Math.max(0, this.m.last - 1.25); this.hud.setPlaying(true); this.syncLive(); this.renderNow(true); }
  syncLive() {
    if (!this.live) return;
    $('#liveBtn').hidden = this.follow || this.m.finished;
    this.hud.setMode(this.m.finished ? 'игра окончена' : this.follow ? 'вживую' : 'вживую, вы смотрите прошлое', this.m.finished ? '' : this.follow ? 'live' : 'stale');
  }
  onLive(n, feed) {
    const quiet = performance.now() - feed.lastArrive;
    this.liveWait = feed.fails >= 3 ? 'Связь с игрой потеряна, пробую снова' : (!this.m.finished && quiet > 3000 && this.follow) ? 'Ждём следующий такт' : null;
    this.liveRate = feed.rate;
    if (n || this.m.finished) { this.syncTotal(); this.syncLive(); }
    if (n && !this.follow) this.renderNow(true);
  }

  // ---------------------------------------------------------------- выбор
  select(id) {
    this.selected = this.selected === id ? null : id;
    if (this.selected != null && !this.cam.isFit()) {
      const b = this.m.frames[this.frameIndex].bases.find(b => b.c === this.selected);
      if (b) { this.setDirector(false); this.cam.lookAt(b.x + 0.5, b.y + 0.5); }
    }
    this.renderNow(true);
  }
  pin(id, at) {
    this.pinned = id; this.pinAt = at;
    if (id != null) this.setDirector(false);
    this.renderNow(true);
  }
  setDirector(on) { this.dir.on = on; this.hud.setPressed('dir', on); if (!on) this.dir.cur = null; this.dirty = true; }
  fit() { this.setDirector(false); this.pinned = null; this.cam.fit(); this.renderNow(true); }
  toggleBig() {
    const on = document.documentElement.classList.toggle('big');
    storeSet('big', on); this.hud.setPressed('big', on);
    this.layout(); this.renderNow(true);
  }

  async toggleDio(force) {
    const on = force ?? !this.dio;
    if (on && !this.dioApi) {
      if (this.dioFailed || !this.webgl) return;
      try {
        for (const b of document.querySelectorAll('[data-act="dio"]')) b.disabled = true;
        const mod = await import('./diorama.js');
        this.dioApi = mod.createDiorama({ container: $('#stage3d'), labels: $('#labels3d'), match: this.m, cam: this.cam, onLost: () => this.dioLost() });
        this.dioApi.resize(innerWidth, innerHeight, Math.min(2, devicePixelRatio || 1));
      } catch (e) {
        this.dioLost();
        return;
      } finally { if (!this.dioFailed) for (const b of document.querySelectorAll('[data-act="dio"]')) b.disabled = false; }
    }
    this.dio = on && !!this.dioApi;
    $('#stage3d').hidden = !this.dio; $('#labels3d').hidden = !this.dio; $('#map').hidden = this.dio;
    this.hud.setPressed('dio', this.dio);
    storeSet('dio', this.dio);
    this.renderNow(true);
  }
  // Диорама не загрузилась или видеокарта отобрала контекст: молча возвращаемся в 2D.
  dioLost() {
    this.dioFailed = true; this.dio = false; this.dioApi = null;
    $('#stage3d').hidden = true; $('#labels3d').hidden = true; $('#map').hidden = false;
    for (const b of document.querySelectorAll('[data-act="dio"]')) { b.disabled = true; b.setAttribute('aria-pressed', 'false'); b.title = 'Диорама недоступна на этом компьютере'; }
    storeSet('dio', false);
    this.renderNow(true);
  }

  copyLink() {
    if (this.live) { this.hud.toast('Ссылку на момент можно взять из повтора после игры'); return; }
    const f = this.m.frames[this.frameIndex];
    const u = new URL(location.href);
    u.search = ''; u.searchParams.set('replay', this.opts.name); u.searchParams.set('t', f.t);
    if (this.selected != null) u.searchParams.set('focus', this.selected);
    history.replaceState(null, '', u);
    const done = () => this.hud.toast(`Ссылка на такт ${f.t} скопирована`);
    (navigator.clipboard?.writeText(u.href) || Promise.reject()).then(done, () => this.hud.toast('Ссылка в адресной строке'));
  }

  // ---------------------------------------------------------------- ввод
  bind() {
    const surf = [$('#map'), $('#stage3d')];
    document.addEventListener('click', e => {
      const t = e.target.closest('[data-act],[data-seek],[data-speed],.col'); if (!t) { this.closeMenus(e); return; }
      if (t.dataset.speed) { this.setSpeed(+t.dataset.speed); $('#speedMenu').hidden = true; $('#speed').setAttribute('aria-expanded', 'false'); return; }
      if (t.dataset.seek !== undefined) { this.seek(+t.dataset.seek); if (t.dataset.unit) this.pin(+t.dataset.unit); return; }
      if (t.classList.contains('col')) { this.select(+t.dataset.id); return; }
      const act = t.dataset.act;
      if (act === 'play') this.setPlaying(!this.playing);
      else if (act === 'speed') { const mn = $('#speedMenu'); mn.hidden = !mn.hidden; t.setAttribute('aria-expanded', String(!mn.hidden)); }
      else if (act === 'next') this.next();
      else if (act === 'dir') { this.setDirector(!this.dir.on); if (this.dir.on) this.pinned = null; this.renderNow(); }
      else if (act === 'fit') this.fit();
      else if (act === 'dio') this.toggleDio();
      else if (act === 'big') this.toggleBig();
      else if (act === 'link') this.copyLink();
      else if (act === 'live') this.goLive();
      else if (act === 'help') $('#help').hidden = !$('#help').hidden;
      else if (act === 'rej') { this.hud.rejOpen = !this.hud.rejOpen; this.renderNow(true); }
      else if (act === 'unselect') this.select(this.selected);
      else if (act === 'unpin') this.pin(null);
      else if (act === 'sheet') { const s = $('#side'), closed = s.classList.toggle('collapsed'); t.setAttribute('aria-expanded', String(!closed)); }
      this.closeMenus(e);
    });
    $('#cols').addEventListener('pointerover', e => { const r = e.target.closest('.col'); this.hoverCol = r ? +r.dataset.id : null; this.dirty = true; });
    $('#cols').addEventListener('pointerleave', () => { this.hoverCol = null; this.dirty = true; });
    $('#side').addEventListener('click', e => { if (this.phone && e.target.closest('.side-head') && !e.target.closest('button')) $('#grip').click(); });

    // шкала времени: доля шкалы → кадр; в живой игре дальше последнего пришедшего кадра не уйти
    const track = $('#track');
    let scrub = false;
    const frac = e => { const r = track.getBoundingClientRect(); return [clamp((e.clientX - r.left) / r.width, 0, 1), e.clientX - r.left]; };
    track.addEventListener('pointerdown', e => { scrub = true; capture(track, e); this.seek(frac(e)[0] * this.hud.total); });
    track.addEventListener('pointermove', e => { const [f, px] = frac(e); this.hud.trackTip(px, f); if (scrub) this.seek(f * this.hud.total); });
    track.addEventListener('pointerup', () => { scrub = false; });
    track.addEventListener('pointerleave', () => { $('#trackTip').hidden = true; });

    // карта: перетаскивание, щипок, колёсико, щелчок
    const pts = new Map(); let drag = null, pinch = null;
    for (const el of surf) {
      el.addEventListener('pointerdown', e => {
        capture(el, e); pts.set(e.pointerId, [e.clientX, e.clientY]);
        if (pts.size === 1) drag = { x: e.clientX, y: e.clientY, moved: false };
        if (pts.size === 2) { const [a, b] = [...pts.values()]; pinch = { d: Math.hypot(a[0] - b[0], a[1] - b[1]), cx: (a[0] + b[0]) / 2, cy: (a[1] + b[1]) / 2 }; if (drag) drag.moved = true; }
      });
      el.addEventListener('pointermove', e => {
        if (pts.has(e.pointerId)) {
          const p = pts.get(e.pointerId), dx = e.clientX - p[0], dy = e.clientY - p[1];
          pts.set(e.pointerId, [e.clientX, e.clientY]);
          if (pinch && pts.size >= 2) {
            const [a, b] = [...pts.values()], d = Math.hypot(a[0] - b[0], a[1] - b[1]), cx = (a[0] + b[0]) / 2, cy = (a[1] + b[1]) / 2;
            this.manual(); this.cam.panBy(cx - pinch.cx, cy - pinch.cy); this.cam.zoomAt(cx, cy, d / pinch.d); this.cam.cx = this.cam.target.cx; this.cam.cy = this.cam.target.cy; this.cam.s = this.cam.target.s;
            pinch = { d, cx, cy }; this.dirty = true; return;
          }
          if (drag && (drag.moved || Math.hypot(e.clientX - drag.x, e.clientY - drag.y) > 5)) {
            if (!drag.moved) { drag.moved = true; el.classList.add('dragging'); }
            this.manual(); this.cam.panBy(dx, dy); this.dirty = true;
          }
          return;
        }
        if (e.pointerType === 'mouse') this.hover(e.clientX, e.clientY);
      });
      const up = e => {
        pts.delete(e.pointerId); if (pts.size < 2) pinch = null;
        if (drag && !drag.moved && pts.size === 0) this.click(e.clientX, e.clientY);
        if (pts.size === 0) { drag = null; el.classList.remove('dragging'); }
      };
      el.addEventListener('pointerup', up); el.addEventListener('pointercancel', up);
      el.addEventListener('pointerleave', () => { if (this.hoverUnit != null) { this.hoverUnit = null; this.hud.unitTip(null); this.dirty = true; } });
      el.addEventListener('wheel', e => { e.preventDefault(); this.manual(); this.cam.zoomAt(e.clientX, e.clientY, Math.exp(-clamp(e.deltaY, -120, 120) * 0.0016)); this.dirty = true; }, { passive: false });
      el.addEventListener('dblclick', e => { this.manual(); this.cam.zoomAt(e.clientX, e.clientY, 1.8); this.dirty = true; });
    }
    $('#mini').addEventListener('click', e => { const [x, y] = this.mini.toWorld(e.clientX, e.clientY); this.manual(); this.cam.lookAt(x, y); this.dirty = true; });

    // пробел на кнопке в фокусе не должен и ставить паузу, и нажимать кнопку
    addEventListener('keyup', e => { if (e.code === 'Space' && e.target.closest?.('button')) e.preventDefault(); });
    addEventListener('keydown', e => {
      if (e.target.closest && e.target.closest('input,textarea')) return;
      if (e.ctrlKey || e.metaKey || e.altKey) return; // Ctrl+F, Ctrl+1 и прочее — браузеру
      const k = e.key;
      if (e.code === 'Space') { e.preventDefault(); if (e.target.closest?.('button')) e.target.blur(); this.setPlaying(!this.playing); }
      else if (k === 'ArrowRight') { e.preventDefault(); this.step(e.shiftKey ? 10 : 1); }
      else if (k === 'ArrowLeft') { e.preventDefault(); this.step(e.shiftKey ? -10 : -1); }
      else if (k === 'ArrowUp' || k === 'ArrowDown') { e.preventDefault(); const i = SPEEDS.indexOf(this.speed); this.setSpeed(SPEEDS[clamp(i + (k === 'ArrowUp' ? 1 : -1), 0, SPEEDS.length - 1)]); this.hud.toast(`Скорость ${speedText(this.speed)}`); }
      else if (k === ',' || k === 'б' || k === 'Б') this.seek(0, true);
      else if (k === '.' || k === 'ю' || k === 'Ю') { if (this.live) this.goLive(); else this.seek(this.m.last, true); }
      else if (liveSession && /^world-\d+$/.test(liveSession) && /^Digit[1-5]$/.test(e.code)) location.search = `?live=1&session=world-${e.code.slice(5)}`;
      else if (/^Digit[1-9]$/.test(e.code)) { const id = this.hud.order[+e.code.slice(5) - 1]; if (id != null) this.select(id); }
      else if (e.code === 'KeyD') { this.setDirector(!this.dir.on); if (this.dir.on) this.pinned = null; this.renderNow(); }
      else if (e.code === 'KeyN') this.next();
      else if (e.code === 'KeyF') this.fit();
      else if (e.code === 'KeyV') this.toggleDio();
      else if (e.code === 'KeyP') this.toggleBig();
      else if (k === '+' || k === '=') { this.manual(); this.cam.zoomAt(...this.cam.focus(), 1.25); this.dirty = true; }
      else if (k === '-' || k === '_') { this.manual(); this.cam.zoomAt(...this.cam.focus(), 0.8); this.dirty = true; }
      else if (k === '?') $('#help').hidden = !$('#help').hidden;
      else if (k === 'Escape') { if (!$('#help').hidden) $('#help').hidden = true; else if (this.pinned != null) this.pin(null); else if (this.selected != null) this.select(this.selected); }
    });
  }
  closeMenus(e) {
    if (!e.target.closest('.speed-wrap')) { $('#speedMenu').hidden = true; $('#speed').setAttribute('aria-expanded', 'false'); }
    if (!e.target.closest('#help') && !e.target.closest('[data-act="help"]')) $('#help').hidden = true;
  }
  manual() { if (this.dir.on) this.setDirector(false); }
  surface() { return this.dio && this.dioApi ? this.dioApi : this.r2d; }
  hover(px, py) {
    const hit = this.surface().pick(px, py);
    const id = hit?.unit ? hit.unit.id : null;
    (this.dio ? $('#stage3d') : $('#map')).classList.toggle('over', !!hit);
    if (id !== this.hoverUnit) { this.hoverUnit = id; this.dirty = true; }
    this.hud.unitTip(hit?.unit || null, px, py);
  }
  click(px, py) {
    const hit = this.surface().pick(px, py);
    if (hit?.unit) this.pin(hit.unit.id, [px, py]);
    else if (hit?.base) this.select(hit.base.c);
    else if (this.pinned != null) this.pin(null);
  }

  // ---------------------------------------------------------------- кадр
  frame(now) {
    requestAnimationFrame(t => this.frame(t));
    const dt = this.prev ? Math.min(0.1, (now - this.prev) / 1000) : 0; this.prev = now;
    const m = this.m, before = this.T;
    if (this.live && this.follow) {
      const target = Math.max(0, m.last - 1.25), lag = target - this.T;
      if (lag > 40) this.T = target;
      else if (lag > 0) this.T = Math.min(m.last, this.T + dt * (this.liveRate || 4) * clamp(1 + lag * 0.6, 0.4, 4));
      if (m.finished && this.T >= m.last - 1.3) this.T = Math.min(m.last, this.T + dt * (this.liveRate || 4));
    } else if (this.playing) {
      this.T += dt * this.speed;
      if (this.T >= m.last) { this.T = m.last; if (!this.live) { this.playing = false; this.hud.setPlaying(false); } }
    }
    const moved = this.T !== before;
    const i = this.frameIndex;
    if (this.dir.on) this.dir.update(i, now);
    if (this.pinned != null && !this.dir.on) {
      const S = this.lastScene, u = S && S.units.find(u => u.id === this.pinned);
      if (u && !this.cam.isFit()) this.cam.lookAt(u.x + 0.5, u.y + 0.5);
    }
    const camMoving = this.cam.step(dt, reducedMQ.matches);
    if (!moved && !camMoving && !this.dirty) return;
    this.draw(now, i !== this.lastI && now - this.lastHud > 100 ? true : (!this.playing && i !== this.lastI));
  }

  renderNow(forceHud) { this.draw(performance.now(), true, forceHud); }

  draw(now, hud) {
    const m = this.m, i = this.frameIndex;
    const st = { selected: this.selected, reduced: reducedMQ.matches, liveWait: this.liveWait, live: this.live };
    const S = compose(m, this.T, { reduced: st.reduced, speed: this.follow ? (this.liveRate || 4) : this.speed, selected: this.selected });
    this.lastScene = S;
    const o = { selected: this.selected, hoverCol: this.hoverCol, hoverUnit: this.hoverUnit, pinned: this.pinned, reduced: st.reduced };
    let quad;
    if (this.dio && this.dioApi) { this.dioApi.render(S, o); quad = this.dioApi.viewQuad(); }
    else { this.r2d.render(S, o); const [x0, y0] = this.cam.toWorld(0, 0), [x1, y1] = this.cam.toWorld(innerWidth, innerHeight); quad = [[x0, y0], [x1, y0], [x1, y1], [x0, y1]]; }
    const miniOff = this.cam.isFit() || this.phone;
    $('#miniWrap').classList.toggle('off', miniOff);
    if (!miniOff) this.mini.render(S, quad);
    this.hud.tick(this.T);
    if (hud) {
      this.lastHud = now; this.lastI = i;
      this.hud.marks(st);
      this.hud.update(i, st);
      this.hud.card(i, this.pinned, this.pinAt); this.pinAt = null;
    }
    this.dirty = false;
  }
}
