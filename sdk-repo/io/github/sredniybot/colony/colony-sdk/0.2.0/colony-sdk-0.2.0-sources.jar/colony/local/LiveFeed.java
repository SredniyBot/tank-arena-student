package colony.local;

import colony.engine.Frame;
import colony.engine.Match;
import colony.engine.ReplayWriter;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.List;
import java.util.Optional;
import java.util.concurrent.atomic.AtomicLong;

/**
 * Живая игра для просмотра: заголовок повтора и кадры идущего матча. Матч пишет кадры в своём потоке, просмотр
 * читает их из потоков сервера. Новый матч заменяет прежний.
 */
public final class LiveFeed {

    /** Больше кадров за один ответ не отдаём: просмотр дозапросит остальное. */
    static final int MAX_FRAMES_PER_RESPONSE = 500;

    private static final AtomicLong COUNTER = new AtomicLong();

    /** Матч и его метка: по смене метки просмотр понимает, что на том же порту началась новая игра. */
    private record Live(Match match, String gameId) {}

    private volatile Live live;

    /** Показывать этот матч; {@code null} — игры нет. */
    public void show(Match m) {
        this.live = m == null ? null : new Live(m, m.config().seed() + "-" + System.currentTimeMillis() + "-"
                + COUNTER.incrementAndGet());
    }

    /** Матч, который сейчас показывается. */
    public Optional<Match> match() {
        Live l = live;
        return l == null ? Optional.empty() : Optional.of(l.match());
    }

    /** Метка показываемой игры: своя у каждого матча этой программы. */
    public Optional<String> gameId() {
        Live l = live;
        return l == null ? Optional.empty() : Optional.of(l.gameId());
    }

    /** Заголовок повтора без кадров и итога, плюс {@code gameId}; пусто, если игры нет. */
    Optional<ObjectNode> meta() {
        Live l = live;
        if (l == null) {
            return Optional.empty();
        }
        ObjectNode header = l.match().replayHeader();
        header.put("gameId", l.gameId());
        return Optional.of(header);
    }

    /**
     * Кадры с такта {@code from}: {@code {"gameId": "...", "frames": [...], "finished": false}}. {@code finished}
     * становится {@code true} только когда матч окончен и отданы все кадры; тогда рядом лежит {@code result}.
     * Пусто, если игры нет.
     */
    Optional<ObjectNode> frames(int from) {
        Live l = live;
        if (l == null) {
            return Optional.empty();
        }
        Match m = l.match();
        boolean over = m.finished();
        List<Frame> all = m.frames(Math.max(0, from));
        List<Frame> part = all.size() > MAX_FRAMES_PER_RESPONSE ? all.subList(0, MAX_FRAMES_PER_RESPONSE) : all;
        ObjectNode o = JsonNodeFactory.instance.objectNode();
        o.put("gameId", l.gameId());
        ArrayNode frames = o.putArray("frames");
        for (Frame f : part) {
            frames.add(f.toJson(false));
        }
        boolean finished = over && part.size() == all.size();
        o.put("finished", finished);
        if (finished) {
            o.set("result", ReplayWriter.resultJson(m.result()));
        }
        return Optional.of(o);
    }
}
