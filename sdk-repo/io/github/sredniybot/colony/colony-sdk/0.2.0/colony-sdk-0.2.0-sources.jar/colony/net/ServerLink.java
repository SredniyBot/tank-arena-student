package colony.net;

import com.fasterxml.jackson.databind.JsonNode;
import java.io.IOException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.time.Duration;

/** Запросы {@code /api/v1} к серверу: что спросили — то и вернулось, код и JSON. Токен — в заголовке. */
public final class ServerLink implements AutoCloseable {

    /** Ответ сервера: HTTP-код и тело (не JSON — пустой объект). */
    public record Reply(int status, JsonNode body) {
        public String code() {
            return body.path("code").asText("");
        }

        public String error() {
            return body.path("error").asText("сервер ответил " + status);
        }
    }

    private final URI base;
    private final String token;
    private final HttpClient http = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(3)).build();

    public ServerLink(URI server, String token) {
        String s = server.toString();
        this.base = URI.create(s.endsWith("/") ? s : s + "/");
        this.token = token;
    }

    public URI base() {
        return base;
    }

    public Reply info() throws IOException, InterruptedException {
        return send(HttpRequest.newBuilder(base.resolve("api/v1/info")).timeout(Duration.ofSeconds(3)).GET());
    }

    /** Кто я: имя по токену, без входа в матч. */
    public Reply me() throws IOException, InterruptedException {
        return send(authorized("api/v1/me", 3).GET());
    }

    Reply join(JsonNode body) throws IOException, InterruptedException {
        return send(authorized("api/v1/join", 5).POST(HttpRequest.BodyPublishers.ofString(body.toString())));
    }

    /** Длинный опрос; {@code session} — вид сеанса, чтобы сервер не путал мир на паре и попытку. */
    Reply view(int after, String game, String session) throws IOException, InterruptedException {
        String q = "api/v1/view?after=" + after + "&game=" + URLEncoder.encode(game, StandardCharsets.UTF_8)
                + "&session=" + URLEncoder.encode(session, StandardCharsets.UTF_8);
        return send(authorized(q, 20).GET());
    }

    Reply orders(JsonNode body, String session) throws IOException, InterruptedException {
        return send(authorized("api/v1/orders?session=" + URLEncoder.encode(session, StandardCharsets.UTF_8), 5)
                .POST(HttpRequest.BodyPublishers.ofString(body.toString())));
    }

    // ---- домашнее задание ----

    /** Шаги задания и что из них пройдено, сколько попыток осталось сегодня. */
    public Reply homework() throws IOException, InterruptedException {
        return send(authorized("api/v1/homework", 5).GET());
    }

    /**
     * Начать попытку: шаг {@code step} или, без номера, первый непройденный. Версия протокола — чтобы сервер не начал
     * попытку, которую этот SDK не сыграет.
     */
    public Reply startAttempt(Integer step) throws IOException, InterruptedException {
        com.fasterxml.jackson.databind.node.ObjectNode body = Protocol.JSON.createObjectNode()
                .put("protocol", Protocol.VERSION);
        if (step != null) {
            body.put("step", step);
        }
        return send(authorized("api/v1/homework/attempt", 10).POST(HttpRequest.BodyPublishers.ofString(
                body.toString())));
    }

    /** Итог попытки. */
    public Reply attempt(String id) throws IOException, InterruptedException {
        return send(authorized("api/v1/homework/attempt?id=" + URLEncoder.encode(id, StandardCharsets.UTF_8), 10)
                .GET());
    }

    /** Снимок исходников пройденной попытки. */
    public Reply snapshot(JsonNode body) throws IOException, InterruptedException {
        return send(authorized("api/v1/homework/snapshot", 30).POST(HttpRequest.BodyPublishers.ofString(
                body.toString())));
    }

    private HttpRequest.Builder authorized(String path, int timeoutSeconds) {
        return HttpRequest.newBuilder(base.resolve(path)).timeout(Duration.ofSeconds(timeoutSeconds))
                .header("Authorization", "Bearer " + token).header("Content-Type", "application/json");
    }

    private Reply send(HttpRequest.Builder b) throws IOException, InterruptedException {
        HttpResponse<String> r = http.send(b.build(), HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        JsonNode body;
        try {
            body = r.body() == null || r.body().isBlank() ? null : Protocol.JSON.readTree(r.body());
        } catch (IOException e) {
            body = null;
        }
        return new Reply(r.statusCode(), body == null ? Protocol.JSON.createObjectNode() : body);
    }

    @Override
    public void close() {
        http.close();
    }
}
