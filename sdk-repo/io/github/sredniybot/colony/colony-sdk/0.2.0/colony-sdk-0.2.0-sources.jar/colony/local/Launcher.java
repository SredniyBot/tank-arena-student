package colony.local;

import colony.api.Colony;
import colony.engine.Version;
import colony.net.NetGame;
import colony.net.Token;
import java.io.IOException;
import java.io.Reader;
import java.net.URI;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.Properties;
import java.util.function.Supplier;

/**
 * Запуск из {@code student.Main}:
 * <pre>
 * public static void main(String[] args) {
 *     Launcher.main(args, MyColony::new);
 * }
 * </pre>
 *
 * Аргументы — {@link #USAGE}.
 */
public final class Launcher {

    static final String USAGE = """
            Аргументы Main:
              (нет)                  с адресом сервера — играть на общей арене; без адреса — матч у себя с просмотром
              --server=<адрес>       адрес сервера курса, например http://185.81.251.155
                                     (или colony.server= в colony.properties)
              --selfcheck            самопроверка: Java, версия SDK, папка проекта, короткий матч
            Домашнее задание — пять уровней по 2 балла. Проверить уровень — тест LevelsTest:
              --submit               «Сдать»: попытка на сервере на каждом непройденном уровне, где учебные карты
                                     вместе набирают цель
              --task                 уровни и их цели
              --practice N           случайная карта уровня N в просмотре
              --practice N --seed S  та же карта ещё раз
              --practice N --headless  без просмотра: итог в консоль, повтор в replays/
              --try N                попытка у себя: новые карты уровня N, итог сразу
            Игра у себя:
              --local                играть у себя, даже если адрес сервера задан
              --map=<имя или путь>, --seed=<число>, --ticks=<до 20000>, --headless — карта, зерно, длина, без просмотра
            Токен — в COLONY_TOKEN или ~/.colony/token. Нет токена — консоль спросит код с экрана преподавателя.""";

    static final List<Long> LADDER_SEEDS = List.of(1L, 2L, 3L);
    /** Сколько побед из трёх карт нужно над боссом. */
    static final int BOSS_WINS = 2;

    private Launcher() {}

    /**
     * Разобрать аргументы и запустить. При ошибке программа завершается с кодом 1 (не играет) или 2 (неверные
     * аргументы). С просмотром программа работает, пока её не остановят.
     */
    public static void main(String[] args, Supplier<Colony> mine) {
        int code = run(args, mine, Env.system(), System.getenv(), Path.of(System.getProperty("user.home")));
        if (code != 0) {
            System.out.flush();
            System.exit(code);
        }
    }

    /** То же без выхода из программы: код 0 — успех, 1 — не получилось, 2 — неверные аргументы. */
    static int run(String[] args, Supplier<Colony> mine, Env env) {
        return run(args, mine, env, Map.of(), env.workDir());
    }

    /** То же; {@code vars} и {@code home} — откуда брать токен для мира на сервере. */
    static int run(String[] args, Supplier<Colony> mine, Env env, Map<String, String> vars, Path home) {
        Options o;
        try {
            o = Options.parse(args);
        } catch (IllegalArgumentException e) {
            env.err().println(e.getMessage());
            env.out().println(USAGE);
            return 2;
        }
        if (o.help) {
            env.out().println(USAGE);
            return 0;
        }
        URI server;
        try {
            server = o.local ? null : o.server != null ? o.server : serverFromProperties(env.workDir());
        } catch (IllegalArgumentException e) {
            env.err().println(e.getMessage());
            return 2;
        }
        URI moved = moved(server);
        if (moved != server) {
            env.out().println("Сервер переехал: " + server + " → " + moved + ". Токен прежний, менять ничего не нужно.");
            server = moved;
        }
        if (o.selfcheck) {
            return SelfCheck.run(mine, env, server, () -> Token.find(vars, home));
        }
        if (o.task || o.practice || o.tryIt || o.submit) {
            return homework(o, server, mine, env, vars, home);
        }
        String session = o.admission ? "admission" : o.challenge ? "challenge" : o.boss && server != null ? "boss"
                : "world";
        boolean localOnly = o.ladder || o.opponentGiven || o.mapGiven || o.seedGiven || o.ticks != null || o.headless;
        if (localOnly && (o.server != null || !session.equals("world"))) {
            env.err().println("На сервере нет --ladder, --opponent, --map, --seed, --ticks и --headless: это "
                    + "локальная игра. Уберите их или добавьте --local.");
            return 2;
        }
        if (!session.equals("world") || server != null && !localOnly) {
            if (server == null) {
                env.err().println("Для " + (o.admission ? "допуска" : "боя по вызову") + " нужен адрес сервера: "
                        + "colony.server в colony.properties или --server=http://адрес:8800.");
                return 2;
            }
            return network(server, session, mine, env, vars, home);
        }
        try {
            League league = new League(o.league != null ? o.league : ColonyProperties.load(env.workDir()).league());
            if (o.ladder) {
                return ladder(o, league, mine, env);
            }
            if (o.boss) {
                return boss(o, league, mine, env);
            }
            LocalGame.Builder b = LocalGame.builder().env(env).me(mine).seed(o.seed).headless(o.headless)
                    .league(league.number());
            if (o.opponentGiven) {
                b.opponent(o.opponent);
            }
            if (o.mapGiven) {
                b.map(o.map);
            }
            if (o.ticks != null) {
                b.ticks(o.ticks);
            }
            b.play();
            return 0;
        } catch (PastVersion.Failure e) {
            env.err().println(e.getMessage());
            return 1;
        } catch (IllegalArgumentException e) {
            env.err().println(capitalize(e.getMessage()));
            return 2;
        } catch (IllegalStateException | java.io.UncheckedIOException e) {
            env.err().println(capitalize(e.getMessage()));
            return 1;
        } catch (RuntimeException e) {
            // ошибка в самом SDK: не оставляем висеть программу с открытым просмотром
            env.err().println("Ошибка SDK: " + e + ". Покажите это сообщение преподавателю.");
            e.printStackTrace(env.err());
            return 1;
        }
    }

    /** Домашнее задание: задание, тренировка у себя или попытка на сервере. */
    private static int homework(Options o, URI server, Supplier<Colony> mine, Env env, Map<String, String> vars,
                                Path home) {
        Supplier<Token.Found> token = () -> Token.obtain(vars, home, server, env.out());
        try {
            if (o.submit) {
                return Submit.run(env, mine, server, token);
            }
            // прототип: задание, тренировка и попытка по одному шагу — у себя
            if (o.task) {
                return StepTasks.task(env);
            }
            if (o.practice) {
                return StepTasks.practice(env, mine, o.trial, o.seedGiven ? o.seed : null, o.headless);
            }
            if (o.tryIt) {
                return StepTasks.attempt(env, mine, o.trial);
            }
            if (o.task) {
                return Tasks.task(env, server, token);
            }
            if (o.practice) {
                return Tasks.practice(env, mine, o.trial, o.seedGiven ? o.seed : null, server, token);
            }
            if (server == null) {
                env.err().println("Попытка идёт на сервере: нужен его адрес — server= в colony.properties или "
                        + "--server=http://адрес. Тренироваться можно у себя: --practice.");
                return 2;
            }
            Token.Found t;
            try {
                t = token.get();
            } catch (IllegalStateException e) {
                env.err().println(e.getMessage());
                return 1;
            }
            String warning = Token.gitWarning(env.workDir(), t.value());
            if (warning != null) {
                env.err().println(warning);
            }
            return Tasks.attempt(env, mine, o.trial, server, t, Debugger::attached);
        } catch (IllegalArgumentException e) {
            env.err().println(capitalize(e.getMessage()));
            return 2;
        } catch (IllegalStateException | java.io.UncheckedIOException e) {
            env.err().println(capitalize(e.getMessage()));
            return 1;
        }
    }

    /** Игра на сервере: токен, предупреждение о токене в Git, сетевой цикл. */
    private static int network(URI server, String session, Supplier<Colony> mine, Env env, Map<String, String> vars,
                               Path home) {
        Token.Found token;
        try {
            token = Token.obtain(vars, home, server, env.out());
        } catch (IllegalStateException e) {
            env.err().println(e.getMessage());
            return 1;
        }
        String warning = Token.gitWarning(env.workDir(), token.value());
        if (warning != null) {
            env.err().println(warning);
        }
        try {
            return NetGame.builder().server(server).token(token.value()).me(mine).session(session)
                    .debugger(Debugger::attached).console(env.out(), env.err()).build().run();
        } catch (RuntimeException e) {
            env.err().println("Ошибка SDK: " + e + ". Покажите это сообщение преподавателю.");
            e.printStackTrace(env.err());
            return 1;
        }
    }

    /** Адрес сервера из {@code colony.properties} ({@code colony.server}) или {@code null}. */
    static URI serverFromProperties(Path dir) {
        Path file = dir.resolve(ColonyProperties.FILE);
        if (!Files.isRegularFile(file)) {
            return null;
        }
        Properties p = new Properties();
        try (Reader r = Files.newBufferedReader(file, StandardCharsets.UTF_8)) {
            p.load(r);
        } catch (IOException e) {
            return null;
        }
        String v = p.getProperty("colony.server", p.getProperty("server", "")).strip();
        if (p.getProperty("colony.token") != null || p.getProperty("token") != null) {
            throw new IllegalArgumentException("В colony.properties лежит токен. Уберите его оттуда: токен — только в "
                    + Token.ENV + " или ~/.colony/token, а colony.properties хранится в Git.");
        }
        return v.isEmpty() ? null : serverUri(v, "colony.server в colony.properties");
    }

    /**
     * Прежние адреса сервера курса и куда они переехали. У студентов адрес записан в {@code colony.properties},
     * а этот файл они правят сами; новый SDK ведёт старый адрес на новый, чтобы обновление не трогало их файл.
     */
    static final Map<String, URI> MOVED = Map.of("185.81.251.116", URI.create("http://185.81.251.155"));

    /** Новый адрес вместо переехавшего; иначе тот же объект (и {@code null} для {@code null}). */
    static URI moved(URI server) {
        if (server == null) {
            return null;
        }
        URI to = MOVED.get(server.getHost());
        return to == null ? server : to;
    }

    static URI serverUri(String v, String where) {
        try {
            URI u = URI.create(v.strip());
            if ((!"http".equals(u.getScheme()) && !"https".equals(u.getScheme())) || u.getHost() == null) {
                throw new IllegalArgumentException();
            }
            return u;
        } catch (IllegalArgumentException e) {
            throw new IllegalArgumentException(where + ": «" + v + "» — не адрес. Пример: http://192.168.1.10:8800");
        }
    }

    /**
     * Проверка босса: по матчу на каждой из трёх карт лиги, зерно 1. Выиграл две — локально проверка пройдена;
     * официальная — на сервере.
     */
    private static int boss(Options o, League league, Supplier<Colony> mine, Env env) {
        if (o.opponentGiven || o.mapGiven || o.seedGiven || o.ticks != null) {
            throw new IllegalArgumentException("Проверка босса всегда одна и та же: три карты лиги, зерно 1. "
                    + "Уберите --opponent, --map, --seed и --ticks.");
        }
        Opponent boss = Opponent.boss(league.boss(), 1);
        env.out().println(league.title() + ": проверка босса " + boss.quoted() + " — 3 карты по "
                + League.BOSS_TICKS + " тактов, нужно выиграть " + BOSS_WINS);
        int wins = 0;
        for (String map : league.duels()) {
            LocalGame.Played p = LocalGame.builder().env(env).me(mine).league(league.number()).opponent(league.boss())
                    .map(map).seed(1).ticks(League.BOSS_TICKS).headless(true).quiet(true).play();
            boolean won = p.me().place() == 1 && p.me().score() > p.result().of(2).score();
            if (won) {
                wins++;
            }
            env.out().println("  " + map + ": " + (won ? "победа" : "поражение") + ", счёт " + p.me().score() + " : "
                    + p.result().of(2).score());
        }
        if (wins >= BOSS_WINS) {
            env.out().println("Побед " + wins + " из 3 — босс побеждён локально. Официальная проверка — Main --boss "
                    + "с адресом сервера класса (server= в colony.properties).");
        } else {
            env.out().println("Побед " + wins + " из 3, нужно " + BOSS_WINS + ". Повторы — в replays.");
        }
        return 0;
    }

    private static int ladder(Options o, League league, Supplier<Colony> mine, Env env) {
        if (o.opponentGiven || o.mapGiven || o.seedGiven || o.ticks != null) {
            throw new IllegalArgumentException("Лестница всегда одна и та же: боссы лиг до своей на тренировочной "
                    + "карте лиги, зёрна 1–3. Уберите --opponent, --map, --seed и --ticks.");
        }
        java.nio.file.Path file = env.workDir().resolve(LadderResults.FILE);
        List<LadderResults.Entry> before = LadderResults.read(file);
        String time = OffsetDateTime.now().truncatedTo(ChronoUnit.SECONDS).toString();
        String commit = LadderResults.commit(env.workDir());
        String map = league.trainingMap();
        env.out().println("Лестница, " + league.title() + ": " + bossList(league) + " на " + map + ", зёрна 1–3"
                + (commit == null ? "" : ", коммит " + commit));
        List<LadderResults.Entry> now = new ArrayList<>();
        for (String opponent : league.ladder()) {
            for (long seed : LADDER_SEEDS) {
                LocalGame.Played p = LocalGame.builder().env(env).me(mine).league(league.number()).opponent(opponent)
                        .seed(seed).headless(true).quiet(true).play();
                now.add(new LadderResults.Entry(time, opponent, p.map(), seed, p.me().place(), p.me().score(),
                        Version.get(), commit));
                env.out().println("  «" + p.opponent().name().toLowerCase(Locale.ROOT) + "», зерно " + seed + ": "
                        + p.me().place() + " место, счёт " + p.me().score() + " (у " + p.opponent().quoted() + " "
                        + p.result().of(2).score() + ")");
            }
        }
        LadderResults.append(file, now);

        for (String opponent : league.ladder()) {
            long wins = now.stream().filter(e -> e.opponent().equals(opponent) && e.place() == 1).count();
            String name = Opponent.boss(opponent, 1).name();
            env.out().println("«" + name + "»: побед " + wins + " из " + LADDER_SEEDS.size() + ". "
                    + record(opponent, map, before, now));
        }
        env.out().println("Записано в " + LadderResults.FILE + ", повторы — в replays. Закоммитьте "
                + LadderResults.FILE + ": преподаватель увидит рост.");
        return 0;
    }

    /** ««бронза» и «серебро»». */
    private static String bossList(League league) {
        List<String> names = league.ladder().stream().map(id -> "«" + Opponent.boss(id, 1).name()
                .toLowerCase(Locale.ROOT) + "»").toList();
        if (names.size() == 1) {
            return names.get(0);
        }
        return String.join(", ", names.subList(0, names.size() - 1)) + " и " + names.get(names.size() - 1);
    }

    /** «Рекорд против «бронзы»: счёт 57 (зерно 2, 2026-11-09) — новый!» Рекорды — на той же карте. */
    static String record(String opponent, String map, List<LadderResults.Entry> before,
                         List<LadderResults.Entry> now) {
        String who = Opponent.boss(opponent, 1).quoted();
        Comparator<LadderResults.Entry> byScore = Comparator.comparingInt(LadderResults.Entry::score);
        Optional<LadderResults.Entry> old = before.stream().filter(e -> e.opponent().equals(opponent)
                && e.map().equals(map)).max(byScore);
        Optional<LadderResults.Entry> fresh = now.stream().filter(e -> e.opponent().equals(opponent)).max(byScore);
        LadderResults.Entry best = old.isPresent() && fresh.isPresent()
                ? (fresh.get().score() > old.get().score() ? fresh.get() : old.get())
                : old.or(() -> fresh).orElseThrow();
        if (best.score() == 0) {
            return "Рекорда против " + who + " пока нет: счёт 0.";
        }
        String day = best.time().length() >= 10 ? best.time().substring(0, 10) : best.time();
        String line = "Рекорд против " + who + ": счёт " + best.score() + " (зерно " + best.seed() + ", " + day + ")";
        boolean beaten = fresh.isPresent() && old.isPresent() && fresh.get().score() > old.get().score();
        if (beaten) {
            return line + " — новый!";
        }
        return line + ".";
    }

    private static String capitalize(String s) {
        if (s == null || s.isEmpty()) {
            return "Ошибка";
        }
        return Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    /** Разобранные аргументы. */
    static final class Options {
        boolean help;
        boolean selfcheck;
        boolean ladder;
        boolean boss;
        boolean headless;
        Integer league;
        String opponent;
        boolean opponentGiven;
        String map;
        boolean mapGiven;
        long seed = LocalGame.DEFAULT_SEED;
        boolean seedGiven;
        Integer ticks;
        URI server;
        boolean local;
        boolean admission;
        boolean challenge;
        boolean task;
        boolean practice;
        boolean tryIt;
        boolean submit;
        /** Номер испытания для --practice и --try; {@code null} — следующее непройденное. */
        Integer trial;

        static Options parse(String[] args) {
            Options o = new Options();
            List<String> list = new ArrayList<>();
            for (String a : args == null ? new String[0] : args) {
                if (!a.isBlank()) {
                    list.add(a.strip());
                }
            }
            for (int i = 0; i < list.size(); i++) {
                String arg = list.get(i);
                String next = i + 1 < list.size() ? list.get(i + 1) : null;
                if (arg.equals("--task")) {
                    o.task = true;
                } else if (arg.equals("--submit")) {
                    o.submit = true;
                } else if (arg.equals("--practice") || arg.equals("--try") || arg.startsWith("--practice=")
                        || arg.startsWith("--try=")) {
                    boolean practice = arg.startsWith("--practice");
                    o.practice |= practice;
                    o.tryIt |= !practice;
                    String n = arg.contains("=") ? value(arg) : next != null && next.matches("\\d+") ? list.get(++i)
                            : null;
                    if (n != null) {
                        o.trial = trialNumber(n, practice ? "--practice" : "--try");
                    }
                } else if (arg.equals("--seed") && next != null && !next.startsWith("--")) {
                    o.seed = seedValue(list.get(++i));
                    o.seedGiven = true;
                } else if (arg.equals("--help") || arg.equals("-h")) {
                    o.help = true;
                } else if (arg.equals("--selfcheck")) {
                    o.selfcheck = true;
                } else if (arg.equals("--ladder")) {
                    o.ladder = true;
                } else if (arg.equals("--boss")) {
                    o.boss = true;
                } else if (arg.startsWith("--league=")) {
                    try {
                        o.league = new League(Integer.parseInt(value(arg))).number();
                    } catch (IllegalArgumentException e) {
                        throw new IllegalArgumentException("--league ждёт номер лиги от 1 до "
                                + colony.engine.RulesLoader.LEAGUES + ", а не «" + value(arg) + "».");
                    }
                } else if (arg.equals("--headless")) {
                    o.headless = true;
                } else if (arg.startsWith("--opponent=")) {
                    o.opponent = value(arg);
                    o.opponentGiven = true;
                    if (!League.isBoss(o.opponent) && !(o.opponent.startsWith("past:") && o.opponent.length() > 5)) {
                        throw new IllegalArgumentException("Нет соперника «" + o.opponent + "». Можно: --opponent="
                                + String.join("|", League.bosses()) + " или --opponent=past:<тег>.");
                    }
                } else if (arg.startsWith("--server=")) {
                    o.server = serverUri(value(arg), "--server");
                } else if (arg.equals("--local")) {
                    o.local = true;
                } else if (arg.equals("--admission")) {
                    o.admission = true;
                } else if (arg.equals("--challenge")) {
                    o.challenge = true;
                } else if (arg.startsWith("--map=")) {
                    o.map = value(arg);
                    o.mapGiven = true;
                } else if (arg.startsWith("--seed=")) {
                    o.seed = seedValue(value(arg));
                    o.seedGiven = true;
                } else if (arg.startsWith("--ticks=")) {
                    try {
                        o.ticks = LocalGame.checkTicks(Long.parseLong(value(arg)));
                    } catch (NumberFormatException e) {
                        throw new IllegalArgumentException("--ticks ждёт число от 1 до " + LocalGame.MAX_TICKS
                                + ", а не «" + value(arg) + "».");
                    }
                } else {
                    throw new IllegalArgumentException("Неизвестный аргумент " + arg + ".");
                }
            }
            if (o.local && (o.server != null || o.admission || o.challenge)) {
                throw new IllegalArgumentException("--local — это игра без сервера: уберите --server, --admission "
                        + "и --challenge.");
            }
            if (o.admission && o.challenge) {
                throw new IllegalArgumentException("Либо --admission, либо --challenge.");
            }
            homeworkRules(o);
            return o;
        }

        /** Домашнее задание не смешивается с другими режимами; зёрна попытки выбирает сервер. */
        private static void homeworkRules(Options o) {
            int modes = (o.task ? 1 : 0) + (o.practice ? 1 : 0) + (o.tryIt ? 1 : 0) + (o.submit ? 1 : 0);
            if (modes == 0) {
                return;
            }
            if (modes > 1) {
                throw new IllegalArgumentException("Либо --task, либо --practice, либо --try, либо --submit.");
            }
            if (o.ladder || o.boss || o.admission || o.challenge || o.selfcheck || o.opponentGiven || o.mapGiven
                    || o.ticks != null || o.league != null) {
                throw new IllegalArgumentException("Домашнее задание играет на картах и правилах шагов: уберите "
                        + "--ladder, --boss, --admission, --challenge, --selfcheck, --opponent, --map, --ticks "
                        + "и --league.");
            }
            if (o.headless && !o.practice) {
                throw new IllegalArgumentException("--headless — для тренировки: --practice N --headless.");
            }
            if ((o.tryIt || o.submit) && o.seedGiven) {
                throw new IllegalArgumentException("В попытке карты новые. Сыграть карту ещё раз — "
                        + "--practice N --seed S.");
            }
            if (o.task && o.seedGiven) {
                throw new IllegalArgumentException("--seed — для тренировки: --practice N --seed S.");
            }
        }

        private static int trialNumber(String v, String flag) {
            try {
                return colony.homework.Steps.get(Integer.parseInt(v)).number();
            } catch (IllegalArgumentException e) {
                throw new IllegalArgumentException(flag + " ждёт номер уровня от 1 до "
                        + colony.homework.Steps.all().size() + ", а не «" + v + "».");
            }
        }

        private static long seedValue(String v) {
            try {
                return Long.parseLong(v);
            } catch (NumberFormatException e) {
                throw new IllegalArgumentException("--seed ждёт целое число, а не «" + v + "».");
            }
        }

        private static String value(String arg) {
            String v = arg.substring(arg.indexOf('=') + 1).strip();
            if (v.isEmpty()) {
                throw new IllegalArgumentException("У " + arg + " нет значения.");
            }
            return v;
        }
    }
}
