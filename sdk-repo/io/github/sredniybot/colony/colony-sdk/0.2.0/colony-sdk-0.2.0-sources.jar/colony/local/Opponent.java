package colony.local;

import colony.api.Colony;
import colony.bots.Bronze;
import colony.bots.Diamond;
import colony.bots.Gold;
import colony.bots.Platinum;
import colony.bots.Silver;
import colony.engine.ColonySpec;
import java.lang.reflect.Constructor;
import java.nio.file.Path;
import java.util.Objects;
import java.util.function.Supplier;

/**
 * Соперник в локальной игре и в прогоне преподавателя.
 *
 * @param id       как его называют в командной строке и в {@code ladder-results.json}: {@code bronze}, {@code past:v1}
 * @param name     имя в просмотре: «Бронза»
 * @param sign     знак из двух букв: «БР»
 * @param genitive для фраз «против …», «у …»: «бронзы»
 * @param factory  создаёт колонию
 */
record Opponent(String id, String name, String sign, String genitive, Supplier<Colony> factory) {

    /** Планировщик ворот А (правила 2б) — для прогонов преподавателя, если в classpath есть colony-gatebots. */
    static final String PLANNER_CLASS = "colony.gatebots.Gold";

    private static final java.util.Set<String> BOTS = java.util.Set.of("bronze", "silver", "gold", "platinum",
            "diamond", "planner");

    Opponent {
        Objects.requireNonNull(factory, "factory");
    }

    /** Колония для матча. Встроенные соперники (боссы лиг, планировщик) — колонии-боты. */
    ColonySpec spec() {
        ColonySpec spec = new ColonySpec(name, sign, factory);
        return BOTS.contains(id) ? spec.asBot() : spec;
    }

    /** «бронзы» в кавычках: «против «бронзы»». */
    String quoted() {
        return id.equals("custom") ? genitive : "«" + genitive + "»";
    }

    static Opponent bronze(long seed) {
        return new Opponent("bronze", "Бронза", "БР", "бронзы", () -> new Bronze(seed));
    }

    static Opponent silver(long seed) {
        return new Opponent("silver", "Серебро", "СР", "серебра", () -> new Silver(seed));
    }

    static Opponent gold(long seed) {
        return new Opponent("gold", "Золото", "ЗЛ", "золота", () -> new Gold(seed));
    }

    static Opponent platinum(long seed) {
        return new Opponent("platinum", "Платина", "ПЛ", "платины", () -> new Platinum(seed));
    }

    static Opponent diamond(long seed) {
        return new Opponent("diamond", "Алмаз", "АЛ", "алмаза", () -> new Diamond(seed));
    }

    /** Босс по имени: {@code bronze}, {@code silver}, {@code gold}, {@code platinum}, {@code diamond}. */
    static Opponent boss(String id, long seed) {
        return switch (id) {
            case "bronze" -> bronze(seed);
            case "silver" -> silver(seed);
            case "gold" -> gold(seed);
            case "platinum" -> platinum(seed);
            case "diamond" -> diamond(seed);
            default -> throw new IllegalArgumentException("нет босса «" + id + "»");
        };
    }

    static Opponent custom(Supplier<Colony> factory) {
        return new Opponent("custom", "Соперник", "СП", "соперника", factory);
    }

    /** Своя колония с тега git: компилируется сразу, чтобы ошибка была видна до матча. */
    static Opponent past(Path projectDir, String tag) {
        return new Opponent("past:" + tag, "Прошлая версия", "ПВ", "прошлой версии",
                PastVersion.load(projectDir, tag));
    }

    /** Планировщик ворот А из {@code colony-gatebots}, если он есть в classpath. */
    static Opponent planner(long seed) {
        Class<?> type;
        try {
            type = Class.forName(PLANNER_CLASS, true, Thread.currentThread().getContextClassLoader() != null
                    ? Thread.currentThread().getContextClassLoader() : Opponent.class.getClassLoader());
        } catch (ClassNotFoundException e) {
            throw new IllegalArgumentException("планировщик недоступен: в classpath нет класса " + PLANNER_CLASS
                    + " (модуль colony-gatebots)");
        }
        if (!Colony.class.isAssignableFrom(type)) {
            throw new IllegalArgumentException(PLANNER_CLASS + " не реализует colony.api.Colony");
        }
        Supplier<Colony> factory = () -> {
            try {
                try {
                    Constructor<?> c = type.getConstructor(long.class);
                    return (Colony) c.newInstance(seed);
                } catch (NoSuchMethodException e) {
                    return (Colony) type.getConstructor().newInstance();
                }
            } catch (ReflectiveOperationException e) {
                throw new IllegalStateException("не удалось создать " + PLANNER_CLASS + ": " + e, e);
            }
        };
        return new Opponent("planner", "Планировщик", "ПН", "планировщика", factory);
    }

    /**
     * Соперник по имени: босс лиги ({@code bronze} … {@code diamond}) или {@code past:<тег>}; с {@code allowPlanner}
     * — ещё {@code planner}.
     *
     * @throws IllegalArgumentException непонятное имя — с подсказкой
     */
    static Opponent parse(String id, long seed, Path projectDir, boolean allowPlanner) {
        String s = id.strip();
        if (League.isBoss(s)) {
            return boss(s, seed);
        }
        if (s.startsWith("past:") && s.length() > "past:".length()) {
            return past(projectDir, s.substring("past:".length()));
        }
        if (allowPlanner && s.equals("planner")) {
            return planner(seed);
        }
        throw new IllegalArgumentException("нет соперника «" + s + "»; есть: " + String.join(", ", League.bosses())
                + ", past:<тег>" + (allowPlanner ? ", planner" : ""));
    }
}
