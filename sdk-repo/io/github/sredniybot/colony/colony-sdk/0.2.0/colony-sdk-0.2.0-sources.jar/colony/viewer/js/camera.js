// Камера одна на оба вида: центр (cx, cy) в клетках и масштаб s — пикселей на клетку.
// Режиссёр сам ведёт камеру к событиям: бой, гибель, удар по базе, налёт; переключается не чаще раза в 6 с.
import { clamp, lerp } from './util.js';
import { hotspots } from './scene.js';

export class Camera {
  constructor(match) {
    this.m = match;
    this.W = 1; this.H = 1;
    this.ins = { l: 0, t: 0, r: 0, b: 0 };
    this.cx = match.W / 2; this.cy = match.H / 2; this.s = 20;
    this.target = { cx: this.cx, cy: this.cy, s: this.s };
  }
  setViewport(W, H, ins) {
    const first = this.W === 1;
    this.W = W; this.H = H; this.ins = ins;
    if (first) { this.fitNow(); }
  }
  focus() { return [(this.ins.l + this.W - this.ins.r) / 2, (this.ins.t + this.H - this.ins.b) / 2]; }
  fitScale() {
    const aw = Math.max(80, this.W - this.ins.l - this.ins.r), ah = Math.max(80, this.H - this.ins.t - this.ins.b);
    return Math.min(aw / (this.m.W + 1.4), ah / (this.m.H + 1.4));
  }
  minScale() { return this.fitScale() * 0.85; }
  maxScale() { return Math.max(this.fitScale() * 6, 72); }
  fit() { Object.assign(this.target, { cx: this.m.W / 2, cy: this.m.H / 2, s: this.fitScale() }); }
  fitNow() { this.fit(); this.cx = this.target.cx; this.cy = this.target.cy; this.s = this.target.s; }
  isFit() { return Math.abs(this.target.s - this.fitScale()) < 0.5; }
  lod(s = this.s) { return s < 11 ? 'far' : s > 36 ? 'near' : 'mid'; }
  toScreen(x, y) { const [fx, fy] = this.focus(); return [fx + (x - this.cx) * this.s, fy + (y - this.cy) * this.s]; }
  toWorld(px, py, st = this) { const [fx, fy] = this.focus(); return [st.cx + (px - fx) / st.s, st.cy + (py - fy) / st.s]; }
  clampTarget() {
    const t = this.target;
    t.s = clamp(t.s, this.minScale(), this.maxScale());
    const [fx, fy] = this.focus();
    const halfW = (fx - this.ins.l) / t.s, halfH = (fy - this.ins.t) / t.s;
    const mw = this.m.W, mh = this.m.H;
    t.cx = mw <= halfW * 2 ? mw / 2 : clamp(t.cx, halfW - 0.4, mw - halfW + 0.4);
    t.cy = mh <= halfH * 2 ? mh / 2 : clamp(t.cy, halfH - 0.4, mh - halfH + 0.4);
  }
  zoomAt(px, py, factor) {
    const t = this.target, [wx, wy] = this.toWorld(px, py, t);
    const s = clamp(t.s * factor, this.minScale(), this.maxScale());
    const [fx, fy] = this.focus();
    t.s = s; t.cx = wx - (px - fx) / s; t.cy = wy - (py - fy) / s;
    this.clampTarget();
  }
  panBy(dx, dy) { const t = this.target; t.cx -= dx / t.s; t.cy -= dy / t.s; this.clampTarget(); this.cx = t.cx; this.cy = t.cy; }
  lookAt(x, y, s) { const t = this.target; t.cx = x; t.cy = y; if (s) t.s = s; this.clampTarget(); }
  step(dt, cut) {
    const t = this.target;
    if (cut) { this.cx = t.cx; this.cy = t.cy; this.s = t.s; return false; }
    const k = 1 - Math.pow(0.035, dt);
    const moving = Math.abs(this.cx - t.cx) + Math.abs(this.cy - t.cy) > 0.002 || Math.abs(this.s - t.s) > 0.01;
    // масштаб — по логарифму, чтобы приближение шло равномерно
    this.cx = lerp(this.cx, t.cx, k); this.cy = lerp(this.cy, t.cy, k);
    this.s = Math.exp(lerp(Math.log(this.s), Math.log(t.s), k));
    return moving;
  }
}

export class Director {
  constructor(match, cam) {
    this.m = match; this.cam = cam; this.on = false;
    this.cur = null; this.since = -1e9; this.quietSince = -1e9;
  }
  // Возвращает подпись «что сейчас происходит» для боя или null.
  update(a, now) {
    if (!this.on) return;
    const hs = hotspots(this.m, a).filter(h => h.w >= 2.5);
    const best = hs[0] || null;
    const keep = this.cur && now - this.since < 6000;
    if (best) {
      this.quietSince = now;
      const near = this.cur && Math.hypot(best.x - this.cur.x, best.y - this.cur.y) < 7;
      if (!this.cur || near || (!keep && best.w > (this.cur.w || 0) * 0.6) || (!keep && now - this.since > 9000)) {
        if (!near) this.since = now;
        this.cur = { x: best.x, y: best.y, w: best.w };
      }
    } else if (this.cur && now - this.quietSince > 4500) { this.cur = null; this.since = now; }
    if (this.cur) {
      const fit = this.cam.fitScale(), short = Math.min(this.cam.W - this.cam.ins.l - this.cam.ins.r, this.cam.H - this.cam.ins.t - this.cam.ins.b);
      const s = Math.max(fit * 1.25, short / 22);
      // центр плавно идёт за боем, без рывков на каждый выстрел
      const t = this.cam.target, x = this.cur.x, y = this.cur.y;
      this.cam.lookAt(Math.abs(t.cx - x) < 2.5 ? t.cx : x, Math.abs(t.cy - y) < 2 ? t.cy : y, s);
    } else this.cam.fit();
  }
}
