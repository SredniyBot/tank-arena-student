package colony.net;

import colony.api.Colony;
import colony.api.ColonyView;
import colony.api.Orders;
import colony.api.RejectCode;
import colony.api.Rejection;
import java.util.concurrent.CancellationException;
import java.util.concurrent.ExecutionException;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.Future;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.function.Supplier;

/**
 * Код колонии студента в своём потоке с лимитом времени — как в локальной игре: не уложился — колония стоит,
 * упал — колония стоит, а причина с классом исключения и строкой кода уходит на сервер и в консоль.
 */
final class ColonyCall implements AutoCloseable {

    /** Исход вызова: всё хорошо ({@code failure == null}) или почему колония стоит; исключение — для стека. */
    record Outcome(Rejection failure, Throwable error) {}

    private final Supplier<Colony> factory;
    private final ExecutorService thread = Executors.newSingleThreadExecutor(r -> {
        Thread t = new Thread(r, "colony");
        t.setDaemon(true);
        return t;
    });
    private Colony colony;
    private Future<?> running;

    ColonyCall(Supplier<Colony> factory) {
        this.factory = factory;
    }

    /** Вызвать {@code onTick} и ждать не дольше {@code limitMillis}. */
    Outcome call(ColonyView view, Orders orders, long limitMillis) throws InterruptedException {
        if (running != null && !running.isDone()) {
            return stand(RejectCode.TIMEOUT, "прошлый такт ещё считается; в этот такт колония стоит", null);
        }
        Future<?> f = thread.submit(() -> {
            if (colony == null) {
                colony = factory.get();
                if (colony == null) {
                    throw new IllegalStateException("фабрика колонии вернула null");
                }
            }
            colony.onTick(view, orders);
            return null;
        });
        running = f;
        try {
            f.get(limitMillis, TimeUnit.MILLISECONDS);
            return new Outcome(null, null);
        } catch (TimeoutException e) {
            f.cancel(true);
            return stand(RejectCode.TIMEOUT, "код колонии не уложился в " + limitMillis
                    + " мс до срока такта; в этот такт колония стоит", null);
        } catch (ExecutionException e) {
            return stand(RejectCode.EXCEPTION, "код колонии упал: " + describe(e.getCause())
                    + "; в этот такт колония стоит", e.getCause());
        } catch (CancellationException e) {
            return stand(RejectCode.TIMEOUT, "вызов отменён; в этот такт колония стоит", null);
        }
    }

    private static Outcome stand(RejectCode code, String text, Throwable error) {
        return new Outcome(new Rejection(0, code, text), error);
    }

    /** «NullPointerException в MyColony.java:42 — сообщение», как в локальной игре. */
    static String describe(Throwable t) {
        String type = t.getClass().getSimpleName().isEmpty() ? t.getClass().getName() : t.getClass().getSimpleName();
        String where = null;
        for (StackTraceElement e : t.getStackTrace()) {
            String cn = e.getClassName();
            if (e.getModuleName() != null || cn.startsWith("java.") || cn.startsWith("javax.") || cn.startsWith("jdk.")
                    || cn.startsWith("sun.") || cn.startsWith("com.sun.") || cn.startsWith("colony.")) {
                continue;
            }
            where = e.getFileName() == null ? cn : e.getFileName() + ":" + e.getLineNumber();
            break;
        }
        String text = type + (where == null ? "" : " в " + where);
        String m = t.getMessage();
        if (m != null && !m.isBlank() && m.length() <= 120 && m.lines().count() == 1) {
            text += " — " + m;
        }
        return text;
    }

    @Override
    public void close() {
        thread.shutdownNow();
    }
}
