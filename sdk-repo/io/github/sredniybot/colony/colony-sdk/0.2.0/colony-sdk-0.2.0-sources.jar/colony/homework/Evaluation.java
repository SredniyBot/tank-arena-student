package colony.homework;

import java.util.List;

/**
 * Итог попытки по условию испытания — без сети и файлов. Пороги «доля эталона» сравниваются точно, в процентах
 * показывается округление вниз: 79,9% — это «79%», и попытка не пройдена.
 */
public final class Evaluation {

    private Evaluation() {}

    /** Пройдена, не пройдена или не завершена (сервер остановили — попытка не считается). */
    public enum Outcome { PASSED, FAILED, INCOMPLETE }

    /**
     * Карта попытки глазами студента.
     *
     * @param seed      зерно карты
     * @param played    матч сыгран до конца
     * @param problem   почему не сыгран («связь пропала на такте 140»); {@code null} — сыгран
     * @param stopped   матч прервала остановка сервера — не вина студента
     * @param delivered сдано энергии
     * @param won       победа над соперником (для испытаний на двоих)
     */
    public record MapResult(long seed, boolean played, String problem, boolean stopped, int delivered, boolean won) {

        public static MapResult played(long seed, int delivered, boolean won) {
            return new MapResult(seed, true, null, false, delivered, won);
        }

        public static MapResult missed(long seed, String problem, boolean stopped) {
            return new MapResult(seed, false, problem, stopped, 0, false);
        }
    }

    /**
     * Итог.
     *
     * @param percent доля эталона в процентах, округлённая вниз ({@code null} — не про долю)
     * @param detail  короткое объяснение: «61% эталона при пороге 80%», «на карте 4410 сдано 31 из 50»
     */
    public record Verdict(Outcome outcome, Integer percent, String detail) {

        public boolean passed() {
            return outcome == Outcome.PASSED;
        }
    }

    /**
     * @param reference сдано эталоном на тех же картах, по порядку; нужен только для условия «доля эталона»
     */
    public static Verdict judge(Trial trial, List<MapResult> maps, List<Integer> reference) {
        for (MapResult m : maps) {
            if (m.stopped()) {
                return new Verdict(Outcome.INCOMPLETE, null, "сервер остановили посреди попытки — она не считается");
            }
        }
        if (maps.size() < trial.maps()) {
            return new Verdict(Outcome.INCOMPLETE, null, "сыграно карт " + maps.size() + " из " + trial.maps());
        }
        for (MapResult m : maps) {
            if (!m.played()) {
                return new Verdict(Outcome.FAILED, null, "карта " + m.seed() + " не сыграна: " + m.problem());
            }
        }
        return switch (trial.goal()) {
            case Trial.PerMap p -> perMap(p, maps);
            case Trial.Share s -> share(s, maps, reference);
            case Trial.Wins w -> wins(w, maps);
        };
    }

    private static Verdict perMap(Trial.PerMap p, List<MapResult> maps) {
        for (MapResult m : maps) {
            if (m.delivered() < p.energy()) {
                return new Verdict(Outcome.FAILED, null, "на карте " + m.seed() + " сдано " + m.delivered() + " из "
                        + p.energy());
            }
        }
        return new Verdict(Outcome.PASSED, null, "на каждой карте не меньше " + p.energy());
    }

    private static Verdict share(Trial.Share s, List<MapResult> maps, List<Integer> reference) {
        if (reference == null || reference.size() != maps.size()) {
            throw new IllegalArgumentException("нужен итог эталона на каждой карте");
        }
        long mine = maps.stream().mapToLong(MapResult::delivered).sum();
        long ref = reference.stream().mapToLong(Integer::longValue).sum();
        int percent = ref <= 0 ? 100 : (int) Math.min(999, mine * 100 / ref);
        boolean ok = ref <= 0 || mine * 100 >= (long) s.percent() * ref;
        return new Verdict(ok ? Outcome.PASSED : Outcome.FAILED, percent, percent + "% эталона при пороге "
                + s.percent() + "%");
    }

    private static Verdict wins(Trial.Wins w, List<MapResult> maps) {
        int won = (int) maps.stream().filter(MapResult::won).count();
        return new Verdict(won >= w.need() ? Outcome.PASSED : Outcome.FAILED, null, "побед " + won + " из "
                + maps.size() + (won >= w.need() ? "" : ", нужно " + w.need()));
    }
}
