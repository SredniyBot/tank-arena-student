package colony.homework;

import colony.api.Colony;
import colony.engine.ColonySpec;
import colony.engine.Match;
import colony.engine.MatchConfig;
import colony.engine.MatchResult;
import colony.engine.RuleSet;
import colony.engine.RulesLoader;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Optional;
import java.util.SplittableRandom;
import java.util.function.LongSupplier;
import java.util.function.Supplier;

/**
 * ДЗ «лестница возможностей» (прототип ветки {@code demo/homework-abilities}): каталог шагов, правила и карты шага,
 * игра одной карты и итог попытки. Один каталог для {@code Main --task}, {@code --practice}, {@code --try} и для
 * замеров ({@code colony.gatebots.StepsRun}).
 *
 * <p>Каждый шаг даёт колонии одну новую возможность. Карта шага разрешает основу (ходить, добывать, сдавать,
 * выпускать рабочих) и возможность своего шага; остальные новые приказы на ней отклоняются. Поэтому шаги можно
 * проходить в любом порядке. Цель — одно число энергии на каждой карте шага.
 */
public final class Steps {

    /** Попыток в сутки на шаг (сутки — по Москве). */
    public static final int ATTEMPTS_PER_DAY = 5;

    /** Груз рабочего на всех шагах: 20, как в правилах сезона 1. */
    static final int CARRY = 20;
    /** Шаг 3: склад. */
    static final int DEPOT_COST = 80;
    static final int MAX_DEPOTS = 2;
    static final int DEPOT_VISION = 3;
    /** Шаг 4: прочность завала. */
    static final int RUBBLE = 4;
    /** Шаг 5: цена улучшения. */
    static final int UPGRADE_COST = 40;

    /** Баллов за уровень. */
    public static final int POINTS = 2;

    /** Предел рабочих на уровнях — как на арене. */
    static final int WORKERS = 12;

    // Студент видит только номер, цель и карту. Поля ability/example — для преподавателя и замеров, студенту не печатаются.
    private static final List<Step> ALL = List.of(
            new Step(1, "Уровень 1", "много мелких жил, у каждой одно место", "", 1200, 3, 300, WORKERS),
            new Step(2, "Уровень 2", "у базы почти пусто, богатый прииск далеко", "", 2000, 3, 480, WORKERS),
            new Step(3, "Уровень 3", "богатые жилы в залах за завалами", "", 1200, 3, 480, WORKERS),
            new Step(4, "Уровень 4", "жилы рядом и далеко, высокая цель", "", 5500, 3, 480, WORKERS),
            new Step(5, "Уровень 5", "жилы иссякают, проходы засыпает, открываются новые", "", 1600, 3, 600,
                    WORKERS));

    private Steps() {}

    public static List<Step> all() {
        return ALL;
    }

    public static Optional<Step> find(int number) {
        return ALL.stream().filter(s -> s.number() == number).findFirst();
    }

    /** Уровень по номеру или понятная ошибка. */
    public static Step get(int number) {
        return find(number).orElseThrow(() -> new IllegalArgumentException("уровня " + number + " нет: есть 1–"
                + ALL.size()));
    }

    // ---- правила и карта ----

    /**
     * Правила уровня — правила арены ({@code arena.json}): старт 2 рабочих и 50 энергии, рабочий 25, склад 50,
     * прокачка 25, без содержания, все возможности открыты. Своё у уровня — длина карты и иссякание: на 1–4 жилы
     * не иссякают, на 5-м иссякают и по ходу открываются новые.
     */
    public static RuleSet rules(Step s) {
        ObjectNode json = RulesLoader.toJson(RulesLoader.builtin("arena"));
        json.put("rulesVersion", "level-" + s.number());
        json.put("maxTicks", s.ticks());
        json.put("maxWorkers", s.workers());
        json.put("truceTicks", 0);
        // числа, под которые подобраны цели уровней, не зависят от правок арены: богатая и центральная жила
        // добываются как обычная, события — только на уровне 5
        json.put("richHarvestRate", 0);
        json.put("centerHarvestRate", 0);
        ObjectNode f = (ObjectNode) json.get("features");
        f.put("passableForeign", false);
        f.put("endlessDeposits", s.number() != 5);
        f.put("events", false);
        if (s.number() == 5) {
            f.put("events", true);
            json.put("eventEvery", 150);
            json.put("eventAnnounceTicks", 60);
            json.put("eventDepositAmount", 700);
        }
        return RulesLoader.fromJson(json);
    }

    /** Матч шага на карте {@code seed}. */
    public static MatchConfig config(Step s, long seed) {
        LevelMaps.Plan plan = LevelMaps.plan(s.number(), seed);
        return MatchConfig.of(rules(s), plan.map(), seed).withScript(plan.script());
    }

    // ---- игра ----

    /** Итог карты: сдано и исключений в коде колонии. */
    public record Played(int delivered, int exceptions) {}

    /** Сыграть карту шага колонией {@code me}. */
    public static Played play(Step s, long seed, Supplier<Colony> me) {
        try (Match m = Match.create(config(s, seed), specs(me))) {
            m.run();
            return played(m.result());
        }
    }

    /** Участник матча шага: колония студента. */
    public static List<ColonySpec> specs(Supplier<Colony> me) {
        return List.of(new ColonySpec("Студент", "СТ", me));
    }

    /** Итог матча глазами колонии 1. */
    public static Played played(MatchResult r) {
        MatchResult.Placement p = r.of(1);
        return new Played(p.delivered(), p.exceptions());
    }

    // ---- попытка ----

    /** Итог попытки: пройдена ли и короткое объяснение. */
    public record Verdict(boolean passed, String detail) {}

    /** Итог попытки: уровень пройден, если на всех картах вместе сдано не меньше {@link Step#total()}. */
    public static Verdict judge(Step s, List<Integer> delivered) {
        int sum = delivered.stream().mapToInt(d -> Math.max(0, d)).sum();
        return new Verdict(sum >= s.total(), "сдано " + sum + " из " + s.total() + " на " + delivered.size()
                + " картах вместе");
    }

    /** Зёрна попытки {@code a}: разные, от 1 до 99999 — воспроизводимо (для замеров). */
    public static List<Long> seeds(Step s, int a) {
        SplittableRandom r = new SplittableRandom(s.number() * 1_000_003L + a * 7_919L + 555);
        return attemptSeeds(s, () -> r.nextInt(1, 100_000));
    }

    /**
     * Зёрна одной попытки из источника {@code draw}: все разные и не учебные.
     */
    public static List<Long> attemptSeeds(Step s, LongSupplier draw) {
        LinkedHashSet<Long> out = new LinkedHashSet<>();
        while (out.size() < s.maps()) {
            long d = draw.getAsLong();
            if (!Training.isTraining(s.number(), d)) {
                out.add(d);
            }
        }
        return List.copyOf(new ArrayList<>(out));
    }
}
