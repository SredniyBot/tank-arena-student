package colony.homework;

import java.io.IOException;
import java.io.InputStream;
import java.io.UncheckedIOException;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * Страница повтора, которая открывается в браузере прямо с диска: 2D-рисовальщик просмотра и сам повтор внутри
 * одного {@code .html}, без сервера. Рисует то же, что просмотр в 2D: завалы, склады, кирки и сумки.
 *
 * <p>Модули просмотра ({@code colony/viewer/js}) склеиваются в один скрипт: каждый — в своей области видимости,
 * {@code import} становится чтением из таблицы модулей. Повтор лежит внутри в сжатом виде (gzip, base64) и
 * распаковывается браузером.
 */
final class ReplayPage {

    /** Модули просмотра, которые нужны рисовальщику, в порядке зависимостей. */
    static final List<String> MODULES = List.of("util.js", "board.js", "scene.js", "match.js", "camera.js",
            "render2d.js");

    private static final String VIEWER = "colony/viewer/";
    private static final Pattern IMPORT = Pattern.compile("^import \\{([^}]*)} from '\\./([\\w-]+\\.js)';\\s*$");
    private static final Pattern EXPORT = Pattern.compile("^export (?:const|let|class|function\\*?|async function) "
            + "([A-Za-z_$][\\w$]*)");

    private static volatile String bundle;

    private ReplayPage() {}

    /**
     * Страница целиком.
     *
     * @param title     заголовок: «Шаг 3 «Склад» · карта 2, зерно 3102»
     * @param goal      цель шага
     * @param delivered сдано за матч
     * @param file      имя файла повтора рядом со страницей: {@code step3-3102.json.gz}
     * @param replayGz  повтор {@code colony-replay}, сжатый gzip
     */
    static String html(String title, int goal, int delivered, String file, byte[] replayGz) {
        String info = "{\"goal\":" + goal + ",\"delivered\":" + delivered + ",\"file\":"
                + jsonString(file) + "}";
        return template()
                .replace("{{TITLE}}", escapeHtml(title))
                .replace("{{INFO}}", info.replace("<", "\\u003c"))
                .replace("{{DATA}}", Base64.getEncoder().encodeToString(replayGz))
                .replace("{{MODULES}}", modules());
    }

    /** Модули просмотра одним скриптом: {@code const M = {}; M['util.js'] = (() => { …; return {…}; })();}. */
    static String modules() {
        String b = bundle;
        if (b == null) {
            StringBuilder out = new StringBuilder("const M = {};\n");
            for (String name : MODULES) {
                out.append(module(name, resource(VIEWER + "js/" + name)));
            }
            b = out.toString().replace("</script", "<\\/script");
            bundle = b;
        }
        return b;
    }

    /** Один модуль в своей области видимости. Незнакомая форма {@code import} или {@code export} — ошибка. */
    static String module(String name, String source) {
        StringBuilder body = new StringBuilder();
        List<String> exports = new ArrayList<>();
        for (String line : source.split("\r?\n", -1)) {
            Matcher im = IMPORT.matcher(line);
            if (im.matches()) {
                body.append("const {").append(im.group(1).replace(" as ", ": ")).append("} = M['")
                        .append(im.group(2)).append("'];\n");
                continue;
            }
            if (line.startsWith("import ") || line.startsWith("import{")) {
                throw new IllegalStateException(name + ": такой import страница повтора не понимает: " + line);
            }
            Matcher ex = EXPORT.matcher(line);
            if (ex.find()) {
                exports.add(ex.group(1));
                line = line.substring("export ".length());
            } else if (line.startsWith("export ")) {
                throw new IllegalStateException(name + ": такой export страница повтора не понимает: " + line);
            }
            body.append(line).append('\n');
        }
        return "M['" + name + "'] = (() => {\n" + body + "return { " + String.join(", ", exports) + " };\n})();\n";
    }

    private static String template() {
        return resource(VIEWER + "replay-page.html");
    }

    private static String resource(String path) {
        try (InputStream in = ReplayPage.class.getClassLoader().getResourceAsStream(path)) {
            if (in == null) {
                throw new IllegalStateException("в SDK нет " + path);
            }
            return new String(in.readAllBytes(), StandardCharsets.UTF_8);
        } catch (IOException e) {
            throw new UncheckedIOException(e);
        }
    }

    static String escapeHtml(String s) {
        return s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;").replace("\"", "&quot;");
    }

    private static String jsonString(String s) {
        StringBuilder b = new StringBuilder("\"");
        for (char c : s.toCharArray()) {
            switch (c) {
                case '"' -> b.append("\\\"");
                case '\\' -> b.append("\\\\");
                default -> {
                    if (c < 0x20) {
                        b.append(String.format("\\u%04x", (int) c));
                    } else {
                        b.append(c);
                    }
                }
            }
        }
        return b.append('"').toString();
    }
}
