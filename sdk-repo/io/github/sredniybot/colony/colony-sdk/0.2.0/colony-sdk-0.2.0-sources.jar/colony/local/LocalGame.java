package colony.local;

import colony.api.Colony;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.engine.RuleSet;
import colony.engine.ColonySpec;
import colony.engine.Frame;
import colony.engine.GameMap;
import colony.engine.MapLoader;
import colony.engine.Match;
import colony.engine.MatchConfig;
import colony.engine.MatchResult;
import colony.engine.RulesLoader;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.awt.Desktop;
import java.awt.GraphicsEnvironment;
import java.io.IOException;
import java.io.PrintStream;
import java.net.URI;
import java.nio.file.Files;
import java.nio.file.Path;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.EnumMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.BooleanSupplier;
import java.util.function.Consumer;
import java.util.function.Supplier;

/**
 * Локальная игра: своя колония против встроенного соперника на своём компьютере, без сети.
 *
 * <pre>
 * LocalGame.play(MyColony::new);                         // против босса своей лиги, просмотр в браузере
 * LocalGame.builder().me(MyColony::new).opponent("silver").seed(3).headless(true).run();
 * </pre>
 *
 * Правила, тренировочная карта и соперник по умолчанию — своей лиги ({@code league=N} в {@code colony.properties},
 * по умолчанию 1).
 *
 * Матч идёт так быстро, как может; просмотр показывает его с выбранной скоростью. Повтор пишется в
 * {@code replays/<дата-время>-<карта>-<зерно>.json.gz} в папке проекта.
 */
public final class LocalGame {

    /** Карта сезона 1 — для самопроверки и прогона преподавателя; локальная игра берёт карту лиги. */
    static final String DEFAULT_MAP = "steps-4";
    static final long DEFAULT_SEED = 1;
    /** Дольше матч не бывает: все кадры держатся в памяти. */
    static final int MAX_TICKS = 20_000;
    static final DateTimeFormatter STAMP = DateTimeFormatter.ofPattern("yyyy-MM-dd-HHmm");

    private static final LiveFeed FEED = new LiveFeed();
    private static ViewerServer viewer;

    private LocalGame() {}

    /** Матч против босса своей лиги на её тренировочной карте с просмотром в браузере. */
    public static MatchResult play(Supplier<Colony> mine) {
        return builder().me(mine).run();
    }

    public static Builder builder() {
        return new Builder();
    }

    /** Сервер просмотра этой программы или {@code null}. */
    static synchronized ViewerServer viewer() {
        return viewer;
    }

    /** Остановить просмотр (для тестов). */
    static synchronized void closeViewer() {
        if (viewer != null) {
            viewer.close();
            viewer = null;
        }
        FEED.show(null);
    }

    /** Запустить просмотр, если он ещё не запущен. {@code true} — запущен только что. */
    private static synchronized boolean ensureViewer(int port, Path replays) {
        if (viewer != null) {
            return false;
        }
        viewer = ViewerServer.start(port, FEED, replays, null);
        return true;
    }

    /** Сыгранный матч. */
    record Played(MatchResult result, Path replay, Opponent opponent, String map, long seed) {

        MatchResult.Placement me() {
            return result.of(1);
        }
    }

    /** Параметры матча. Обязательна только своя колония. */
    public static final class Builder {

        private Supplier<Colony> mine;
        private String name;
        private String sign;
        private String opponentId;
        private Supplier<Colony> opponentFactory;
        private String mapName;
        private Integer league;
        private Path mapPath;
        private GameMap mapObject;
        private RuleSet rulesOverride;
        private boolean alone;
        private long seed = DEFAULT_SEED;
        private Integer ticks;
        private boolean headless;
        private boolean quiet;
        private Env env = Env.system();
        private BooleanSupplier debugger = Debugger::attached;
        private Consumer<MatchConfig> matchHook = cfg -> { };
        private List<colony.engine.ScriptEvent> script = List.of();

        private Builder() {}

        /** Своя колония: {@code me(MyColony::new)}. */
        public Builder me(Supplier<Colony> colony) {
            this.mine = Objects.requireNonNull(colony, "colony");
            return this;
        }

        /** Имя и знак своей колонии; по умолчанию — из {@code colony.properties}, иначе «Вы». */
        public Builder name(String colonyName, String colonySign) {
            this.name = colonyName;
            this.sign = colonySign;
            return this;
        }

        /** Соперник: босс лиги ({@code bronze} … {@code diamond}) или {@code past:<тег git>}. */
        public Builder opponent(String id) {
            this.opponentId = Objects.requireNonNull(id, "id");
            this.opponentFactory = null;
            return this;
        }

        /** Свой соперник, например вторая версия своей колонии. */
        public Builder opponent(Supplier<Colony> colony) {
            this.opponentFactory = Objects.requireNonNull(colony, "colony");
            this.opponentId = null;
            return this;
        }

        /** Встроенная карта ({@code league-3-duel-b}, {@code league-3-world}, {@code steps-4}…) или путь к файлу. */
        public Builder map(String nameOrPath) {
            this.mapName = Objects.requireNonNull(nameOrPath, "map");
            this.mapPath = null;
            return this;
        }

        public Builder map(Path file) {
            this.mapPath = Objects.requireNonNull(file, "map");
            this.mapName = null;
            return this;
        }

        /** Готовая карта — например, карта испытания домашнего задания по зерну. */
        public Builder map(GameMap map) {
            this.mapObject = Objects.requireNonNull(map, "map");
            this.mapName = null;
            this.mapPath = null;
            return this;
        }

        /** Свои правила вместо правил лиги (испытания домашнего задания). */
        public Builder rules(RuleSet rules) {
            this.rulesOverride = Objects.requireNonNull(rules, "rules");
            return this;
        }

        /** События сценария карты (шаг «Устойчивость» ДЗ). */
        public Builder script(List<colony.engine.ScriptEvent> events) {
            this.script = List.copyOf(events);
            return this;
        }

        /** Без соперника: колония одна на карте (испытания на сданную энергию). */
        public Builder alone() {
            this.alone = true;
            return this;
        }

        /** Лига: правила, карта и соперник по умолчанию. По умолчанию — из {@code colony.properties}, иначе 1. */
        public Builder league(int number) {
            this.league = new League(number).number();
            return this;
        }

        /** Зерно: одинаковое зерно — одинаковый матч. По умолчанию 1. */
        public Builder seed(long value) {
            this.seed = value;
            return this;
        }

        /** Длина матча в тактах, от 1 до 20000; по умолчанию — из правил (3000). */
        public Builder ticks(int value) {
            this.ticks = checkTicks(value);
            return this;
        }

        /** Без просмотра: итог в консоль, повтор в {@code replays/}. */
        public Builder headless(boolean value) {
            this.headless = value;
            return this;
        }

        /** Папка проекта: здесь {@code replays/} и {@code colony.properties}. По умолчанию — текущая. */
        public Builder workDir(Path dir) {
            this.env = env.withWorkDir(dir);
            return this;
        }

        /** Желаемый порт просмотра; занят — возьмём свободный. По умолчанию 8765. */
        public Builder viewerPort(int port) {
            this.env = env.withViewerPort(port);
            return this;
        }

        /** Открывать ли браузер. По умолчанию — да, если система умеет. */
        public Builder openBrowser(boolean open) {
            this.env = env.withBrowser(open);
            return this;
        }

        Builder console(PrintStream out, PrintStream err) {
            this.env = env.withConsole(out, err);
            return this;
        }

        /** Как узнать, что подключён отладчик (в тестах — своё). */
        Builder debugger(BooleanSupplier detector) {
            this.debugger = detector;
            return this;
        }

        /** Увидеть настройки матча перед началом (для тестов). */
        Builder matchHook(Consumer<MatchConfig> hook) {
            this.matchHook = hook;
            return this;
        }

        Builder env(Env value) {
            this.env = value;
            return this;
        }

        /** Без строк начала и итога: их печатает лестница. Отказы и ошибки колонии — как обычно. */
        Builder quiet(boolean value) {
            this.quiet = value;
            return this;
        }

        /** Сыграть матч. Просмотр (если он есть) работает и после матча, пока программа не остановлена. */
        public MatchResult run() {
            return play().result();
        }

        Played play() {
            if (mine == null) {
                throw new IllegalStateException("нет своей колонии: LocalGame.builder().me(MyColony::new)");
            }
            Path workDir = env.workDir();
            ColonyProperties props = ColonyProperties.load(workDir);
            League lg = new League(league != null ? league : props.league());
            String opponentId = this.opponentId != null ? this.opponentId : lg.boss();
            String mapName = this.mapName != null || mapPath != null ? this.mapName : lg.trainingMap();
            if (!alone && opponentFactory == null && opponentId.startsWith("past:")) {
                env.out().println("Собираю прошлую версию с тега " + opponentId.substring("past:".length()) + "…");
            }
            Opponent opponent = alone ? null : opponentFactory != null ? Opponent.custom(opponentFactory)
                    : Opponent.parse(opponentId, seed, workDir, false);
            GameMap map = mapObject != null ? mapObject : mapPath != null ? MapLoader.load(workDir.resolve(mapPath))
                    : resolveMap(mapName, workDir);
            RuleSet base = rulesOverride != null ? rulesOverride : lg.rules();
            RuleSet rules = ticks == null ? base : withMaxTicks(base, ticks);
            MatchConfig cfg = MatchConfig.of(rules, map, seed).withScript(script);
            boolean debugging = debugger.getAsBoolean();
            if (debugging) {
                cfg = cfg.withTickTimeoutMillis(Integer.MAX_VALUE);
            }
            matchHook.accept(cfg);

            ColonySpec me = name != null ? new ColonySpec(name, sign, mine)
                    : new ColonySpec(props.name(), props.sign(), mine);

            Console console = new Console(env.out(), env.err());
            if (debugging && Debugger.firstNotice()) {
                console.info(Debugger.NOTICE);
            }
            if (!quiet) {
                console.info("Колония: " + lg.title() + ", карта " + map.name() + (opponent == null ? ""
                        : ", против " + opponent.quoted()) + ", зерно " + seed);
            }
            Path replays = workDir.resolve("replays");
            boolean live = !headless && startViewer(console, replays);

            Path replay = null;
            String replayProblem = null;
            MatchResult result;
            try (Match match = Match.create(cfg, opponent == null ? List.of(me) : List.of(me, opponent.spec()))) {
                if (live) {
                    FEED.show(match);
                }
                while (!match.finished()) {
                    match.step();
                    Frame f = match.frame();
                    List<Rejection> mineNow = f.rejections().getOrDefault(1, List.of());
                    if (!mineNow.isEmpty()) {
                        console.rejections(f.t(), mineNow); // кадр, где отказ виден в просмотре
                        if (mineNow.stream().anyMatch(r -> r.code() == RejectCode.EXCEPTION)) {
                            console.stackOnce(match.lastError(1).orElse(null));
                        }
                    }
                }
                result = match.result();
                try {
                    replay = Replays.write(match, replays, replayBase(map.name(), seed));
                } catch (IOException | RuntimeException e) {
                    replayProblem = e.getMessage() == null ? e.toString() : e.getMessage();
                }
            }

            if (replayProblem != null) {
                console.error("Повтор не записан: " + replayProblem);
            }
            if (quiet) {
                return new Played(result, replay, opponent, map.name(), seed);
            }
            MatchResult.Placement my = result.of(1);
            String tail = replay == null ? "" : " Повтор: " + workDir.relativize(replay);
            if (opponent == null) {
                console.info("Итог: сдано " + my.delivered() + " энергии." + tail);
            } else {
                MatchResult.Placement other = result.of(2);
                console.info("Итог: " + my.place() + " место из " + result.ranking().size() + ", счёт " + my.score()
                        + " (у " + opponent.quoted() + " " + other.score() + ")." + tail);
            }
            String summary = console.summary();
            if (summary != null) {
                console.info(summary);
            }
            if (live) {
                console.info("Просмотр открыт, пока работает программа. Остановить — Stop в IntelliJ или Ctrl+C.");
            }
            return new Played(result, replay, opponent, map.name(), seed);
        }

        private boolean startViewer(Console console, Path replays) {
            boolean fresh;
            try {
                fresh = ensureViewer(env.viewerPort(), replays);
            } catch (RuntimeException e) {
                console.error("Просмотр не запустился (" + e.getMessage() + "). Матч идёт без него.");
                return false;
            }
            URI live = viewer().uri().resolve("/?live=1");
            console.info("Просмотр: " + live);
            if (fresh && env.openBrowser()) {
                browse(live);
            }
            return true;
        }
    }

    /** Встроенная карта или файл (путь — от папки проекта); понятная ошибка, если нет ни того ни другого. */
    static GameMap resolveMap(String nameOrPath, Path workDir) {
        if (MapLoader.BUILTIN.contains(nameOrPath)) {
            return MapLoader.builtin(nameOrPath);
        }
        Path file = workDir.resolve(nameOrPath);
        if (!Files.isRegularFile(file)) {
            throw new IllegalArgumentException("нет карты «" + nameOrPath + "»: встроенные — "
                    + String.join(", ", MapLoader.BUILTIN) + "; другую укажите путём к файлу .json");
        }
        return MapLoader.load(file);
    }

    /** Правила с другой длиной матча: и движок, и просмотр видят одну и ту же длину. */
    static RuleSet withMaxTicks(RuleSet rules, int ticks) {
        ObjectNode json = RulesLoader.toJson(rules);
        json.put("maxTicks", ticks);
        return RulesLoader.fromJson(json);
    }

    /** Имя повтора без расширения: {@code 2026-11-09-1412-steps-4-7}; занятое {@link Replays} дополнит {@code _2}. */
    static String replayBase(String mapName, long seed) {
        return LocalDateTime.now().format(STAMP) + "-" + safeName(mapName) + "-" + seed;
    }

    /** Длина матча от 1 до {@link #MAX_TICKS}: все кадры держатся в памяти, опечатка не должна её съесть. */
    static int checkTicks(long value) {
        if (value < 1 || value > MAX_TICKS) {
            throw new IllegalArgumentException("--ticks: от 1 до " + MAX_TICKS + ", а не " + value);
        }
        return (int) value;
    }

    /** Имя, которое примет любая файловая система: без {@code <>:"/\|?*} и управляющих знаков. */
    static String safeName(String name) {
        String s = name.replaceAll("[<>:\"/\\\\|?*\\p{Cntrl}]", "_").strip();
        while (s.endsWith(".")) {
            s = s.substring(0, s.length() - 1);
        }
        return s.isEmpty() ? "map" : s;
    }

    /** Отказы колонии за матч по кодам. */
    static Map<RejectCode, Integer> rejectionsByCode(Match match, int colonyId) {
        Map<RejectCode, Integer> counts = new EnumMap<>(RejectCode.class);
        for (Frame f : match.frames()) {
            for (Rejection r : f.rejections().getOrDefault(colonyId, List.of())) {
                counts.merge(r.code(), 1, Integer::sum);
            }
        }
        return counts;
    }

    /** Открыть браузер, если система умеет; адрес уже напечатан, так что неудача не страшна. */
    static void browse(URI uri) {
        Thread t = new Thread(() -> {
            try {
                if (!GraphicsEnvironment.isHeadless() && Desktop.isDesktopSupported()
                        && Desktop.getDesktop().isSupported(Desktop.Action.BROWSE)) {
                    Desktop.getDesktop().browse(uri);
                }
            } catch (Exception | LinkageError e) {
                // браузер не открылся — адрес в консоли
            }
        }, "colony-browser");
        t.setDaemon(true);
        t.start();
    }
}
