package colony.homework;

/**
 * Уровень ДЗ (1–5): своё семейство карт и цель. Студент видит номер, цель и карту — без подсказок.
 *
 * @param number  номер, 1–5
 * @param title   «Ходка»
 * @param ability что нового может колония, одной фразой
 * @param example один вызов новой возможности
 * @param goal    сколько энергии сдать на каждой карте
 * @param maps    карт в попытке
 * @param ticks   тактов на карте
 * @param workers больше стольких рабочих у колонии на картах шага не бывает
 */
public record Step(int number, String title, String ability, String example, int goal, int maps, int ticks,
                   int workers) {

    /** «Уровень 2» в кавычках-ёлочках. */
    public String quoted() {
        return "«" + title + "»";
    }

    /** «уровень 2» — в середине фразы. */
    public String label() {
        return "уровень " + number;
    }

    /** Сколько сдать на всех картах попытки вместе. */
    public int total() {
        return goal * maps;
    }

    /** Условие попытки одной строкой — для студента. */
    public String goalText() {
        return "на " + maps + " картах вместе сдать " + total() + " энергии (в среднем " + goal + " на карту), "
                + ticks + " тактов на карте";
    }
}
