// Диорама: то же поле, но макетом на подставке — мягкий свет, тени, камень, кристаллы, техника.
// Данные те же, что у 2D: сцена из scene.js, камера из camera.js. Подписи — HTML поверх, чтобы текст был чётким.
// Все наборы одинаковых деталей (InstancedMesh) растут по мере надобности: в живой игре юнитов становится больше.
import * as THREE from 'three';
import { RoundedBoxGeometry } from 'three/addons/RoundedBoxGeometry.js';
import { paintBoard } from './board.js';
import { clamp, easeOut, rgba, rng, hashStr, clip, clipName, DANGER } from './util.js';
import { hotspots } from './scene.js';
import { groupUnits, tankTags, BASE_GLOW } from './render2d.js';

const PITCH = 0.98, FOV = 28, TANF = Math.tan(THREE.MathUtils.degToRad(FOV) / 2);
const UP = new THREE.Vector3(0, 1, 0);
const UNIT_SCALE = 1.25; // техника крупнее клетки: она главное на поле

export function createDiorama({ container, labels, match: m, cam, onLost }) {
  const W = m.W, H = m.H, R = rng(hashStr(m.map.name + ':3d'));
  const renderer = new THREE.WebGLRenderer({ antialias: true, powerPreference: 'high-performance' });
  if (!renderer.getContext()) throw new Error('нет WebGL');
  renderer.shadowMap.enabled = true; renderer.shadowMap.type = THREE.PCFSoftShadowMap;
  renderer.toneMapping = THREE.ACESFilmicToneMapping; renderer.toneMappingExposure = 0.92;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  container.appendChild(renderer.domElement);
  renderer.domElement.addEventListener('webglcontextlost', e => { e.preventDefault(); container.replaceChildren(); labels.replaceChildren(); onLost?.(); });

  const scene = new THREE.Scene();
  scene.background = new THREE.Color('#CCD6CD');
  const big = Math.max(W, H);
  scene.fog = new THREE.Fog('#CCD6CD', big * 2.2, big * 5);
  const camera = new THREE.PerspectiveCamera(FOV, 1, 0.5, big * 8);
  const mat = (color, o = {}) => new THREE.MeshStandardMaterial({ color, roughness: 0.8, metalness: 0.02, ...o });

  // --- свет
  scene.add(new THREE.HemisphereLight('#EEF3FF', '#8A977A', 0.95));
  const sun = new THREE.DirectionalLight('#FFEBD0', 2.45);
  sun.position.set(W / 2 - big * 0.42, big * 0.72, H / 2 - big * 0.34); sun.target.position.set(W / 2, 0, H / 2);
  scene.add(sun, sun.target);
  sun.castShadow = true; sun.shadow.mapSize.set(2048, 2048);
  const sc = big * 0.62;
  Object.assign(sun.shadow.camera, { left: -sc, right: sc, top: sc, bottom: -sc, near: 1, far: big * 2.5 }); sun.shadow.camera.updateProjectionMatrix();
  sun.shadow.bias = -0.0004; sun.shadow.normalBias = 0.03; sun.shadow.radius = 4;
  const fill = new THREE.DirectionalLight('#C8D8FF', 0.35); fill.position.set(W / 2 + big * 0.4, big * 0.4, H / 2 + big * 0.5); scene.add(fill);

  // --- подставка и стол
  const plinth = new THREE.Mesh(new RoundedBoxGeometry(W + 1.4, 1.6, H + 1.4, 4, 0.55), [mat('#8A7A62'), mat('#8A7A62'), mat('#DCE3D5'), mat('#5C4F3F'), mat('#7D6E58'), mat('#7D6E58')]);
  plinth.position.set(W / 2, -0.8, H / 2); plinth.receiveShadow = true; scene.add(plinth);
  const table = new THREE.Mesh(new THREE.PlaneGeometry(big * 12, big * 12), mat('#C3CDC2', { roughness: 1 }));
  table.rotation.x = -Math.PI / 2; table.position.set(W / 2, -1.6, H / 2); table.receiveShadow = true; scene.add(table);

  // --- грунт: тот же рисунок, что в 2D, но без скал; под скалами — каменное ложе
  const gp = clamp(Math.floor(2048 / big), 16, 40);
  const board = paintBoard(m, { ppc: gp, walls: false });
  { const g = board.canvas.getContext('2d'); g.fillStyle = '#A3AD9E'; for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (m.isWall(x, y)) { g.beginPath(); g.roundRect(x * gp - gp * 0.1, y * gp - gp * 0.1, gp * 1.2, gp * 1.2, gp * 0.4); g.fill(); } }
  const groundTex = new THREE.CanvasTexture(board.canvas); groundTex.colorSpace = THREE.SRGBColorSpace; groundTex.anisotropy = 8;
  const ground = new THREE.Mesh(new THREE.PlaneGeometry(W, H), new THREE.MeshStandardMaterial({ map: groundTex, color: '#D3DCC9', roughness: 1 }));
  ground.rotation.x = -Math.PI / 2; ground.position.set(W / 2, 0.002, H / 2); ground.receiveShadow = true; scene.add(ground);

  // --- слой на земле: пятна баз, следы гибели, отказы, бои. Перерисовывается раз в такт, не больше 1024 px.
  const OPX = clamp(Math.floor(1024 / big), 8, 28);
  const ocan = document.createElement('canvas'); ocan.width = W * OPX; ocan.height = H * OPX; const o2 = ocan.getContext('2d');
  const overTex = new THREE.CanvasTexture(ocan); overTex.colorSpace = THREE.SRGBColorSpace;
  const over = new THREE.Mesh(new THREE.PlaneGeometry(W, H), new THREE.MeshBasicMaterial({ map: overTex, transparent: true, depthWrite: false }));
  over.rotation.x = -Math.PI / 2; over.position.set(W / 2, 0.02, H / 2); over.renderOrder = 1; scene.add(over);

  // --- скалы: низкополигональные глыбы на клетках стены; ниже и мельче техники, чтобы не спорить с игрой
  function rockGeo(seed) {
    const geo = new THREE.IcosahedronGeometry(1, 1), pos = geo.attributes.position, r2 = rng(seed);
    const jit = new Map();
    for (let i = 0; i < pos.count; i++) {
      const key = pos.getX(i).toFixed(3) + ',' + pos.getY(i).toFixed(3) + ',' + pos.getZ(i).toFixed(3);
      if (!jit.has(key)) jit.set(key, 0.84 + r2() * 0.26);
      const k = jit.get(key);
      pos.setXYZ(i, pos.getX(i) * k, Math.max(pos.getY(i) * k, -0.05), pos.getZ(i) * k);
    }
    geo.computeVertexNormals(); return geo;
  }
  const rockGeos = [rockGeo(1), rockGeo(2), rockGeo(3)];
  const rockMat = new THREE.MeshStandardMaterial({ color: '#ffffff', flatShading: true, roughness: 0.95 });
  const cells = [];
  for (let y = 0; y < H; y++) for (let x = 0; x < W; x++) if (m.isWall(x, y)) cells.push([x, y]);
  const rocks = rockGeos.map(g => { const r = new THREE.InstancedMesh(g, rockMat, cells.length + 8); r.count = 0; return r; });
  const M = new THREE.Matrix4(), Q = new THREE.Quaternion(), S = new THREE.Vector3(), V = new THREE.Vector3(), C = new THREE.Color();
  const ROCK_COLORS = ['#87927F', '#909A88', '#7F8A77', '#97A08F'];
  for (const [x, y] of cells) {
    const n = [[0, -1], [1, 0], [0, 1], [-1, 0]].filter(([dx, dy]) => m.isWall(x + dx, y + dy)).length;
    const v = Math.floor(R() * 3), inner = n === 4, rk = rocks[v];
    Q.setFromAxisAngle(UP, R() * Math.PI * 2);
    const r = 0.58 + R() * 0.08;
    S.set(r, inner ? 0.48 + R() * 0.26 : 0.3 + R() * 0.18, r);
    V.set(x + 0.5 + (R() - 0.5) * 0.1, 0, y + 0.5 + (R() - 0.5) * 0.1);
    M.compose(V, Q, S); rk.setMatrixAt(rk.count, M); rk.setColorAt(rk.count, C.set(ROCK_COLORS[Math.floor(R() * 4)])); rk.count++;
  }
  rocks.forEach(r => { r.castShadow = true; r.receiveShadow = true; r.instanceMatrix.needsUpdate = true; if (r.instanceColor) r.instanceColor.needsUpdate = true; scene.add(r); });

  // кусты — мягкие шапки зелени у скал
  {
    const geo = new THREE.IcosahedronGeometry(0.24, 0); geo.scale(1, 0.7, 1); geo.translate(0, 0.13, 0);
    const n = Math.round(W * H / 30), bushes = new THREE.InstancedMesh(geo, new THREE.MeshStandardMaterial({ color: '#ffffff', flatShading: true, roughness: 1 }), n);
    bushes.count = 0;
    for (let i = 0; i < n * 3 && bushes.count < n; i++) {
      const x = 1 + R() * (W - 2), y = 1 + R() * (H - 2), cx = Math.floor(x), cy = Math.floor(y);
      if (m.isWall(cx, cy)) continue;
      let nearWall = false; for (let dy = -1; dy <= 1; dy++) for (let dx = -1; dx <= 1; dx++) if (m.isWall(cx + dx, cy + dy)) nearWall = true;
      if (!nearWall) continue;
      Q.setFromAxisAngle(UP, R() * 6); S.setScalar(0.5 + R() * 0.6); V.set(x, 0, y);
      M.compose(V, Q, S); bushes.setMatrixAt(bushes.count, M); bushes.setColorAt(bushes.count, C.set(['#9CB287', '#8DA67A', '#A9BC93'][bushes.count % 3])); bushes.count++;
    }
    bushes.castShadow = true; bushes.receiveShadow = true; scene.add(bushes);
  }
  // логово
  if (m.lairAt) {
    const L = m.lairAt, grp = new THREE.Group();
    const pit = new THREE.Mesh(new THREE.CylinderGeometry(0.85, 0.6, 0.05, 28), mat('#1E2420', { roughness: 1 })); pit.position.y = 0.03; pit.scale.z = 0.75; grp.add(pit);
    for (let i = 0; i < 10; i++) { const a = i / 10 * Math.PI * 2, r = new THREE.Mesh(rockGeos[i % 3], new THREE.MeshStandardMaterial({ color: ROCK_COLORS[i % 4], flatShading: true, roughness: 0.95 })); r.scale.set(0.24, 0.18 + R() * 0.1, 0.24); r.position.set(Math.cos(a) * 1.05, 0, Math.sin(a) * 0.8); r.castShadow = true; grp.add(r); }
    grp.position.set(L.x + 0.5, 0, L.y + 0.5); scene.add(grp);
  }

  // --- набор одинаковых деталей с растущей ёмкостью
  class Pool {
    constructor(geo, material, cap = 32, { shadow = true } = {}) { this.geo = geo; this.mat = material; this.shadow = shadow; this.mesh = null; this.make(cap); }
    make(cap) {
      const old = this.mesh;
      this.mesh = new THREE.InstancedMesh(this.geo, this.mat, cap);
      this.mesh.count = 0; this.mesh.frustumCulled = false; this.mesh.castShadow = this.shadow; this.mesh.receiveShadow = this.shadow;
      this.cap = cap; scene.add(this.mesh);
      if (old) { scene.remove(old); old.dispose(); }
    }
    ensure(n) { if (n > this.cap) this.make(Math.max(n + 16, Math.ceil(this.cap * 1.6))); }
    reset() { this.mesh.count = 0; }
    add(matrix, color) {
      if (this.mesh.count >= this.cap) return; // ensure() вызывается заранее; это последняя страховка
      const i = this.mesh.count++; this.mesh.setMatrixAt(i, matrix); if (color) this.mesh.setColorAt(i, C.set(color));
    }
    done() { this.mesh.instanceMatrix.needsUpdate = true; if (this.mesh.instanceColor) this.mesh.instanceColor.needsUpdate = true; }
  }

  // --- кристаллы: ёмкость — по данным повтора, растёт с трофеями и событиями
  const crystalGeo = new THREE.OctahedronGeometry(0.22, 0);
  const litMat = mat('#F6BB2F', { emissive: '#FF9A12', emissiveIntensity: 0.45, roughness: 0.3, flatShading: true });
  const dimMat = mat('#BFC6BB', { roughness: 0.6, flatShading: true });
  const SETS = { HOME: [[-0.25, 0.1, 0.45], [0.22, 0.12, 0.5], [0, 0.04, 0.66]], NORMAL: [[-0.28, 0.1, 0.5], [0.26, 0.12, 0.55], [0, 0.04, 0.75]], RICH: [[-0.45, 0.12, 0.6], [0.45, 0.16, 0.62], [0, 0.05, 0.9], [-0.2, 0.32, 0.48], [0.25, 0.32, 0.46]], CENTER: [[-0.55, 0.14, 0.62], [0.55, 0.16, 0.66], [0, 0.04, 1.05], [-0.3, 0.34, 0.52], [0.34, 0.34, 0.5], [-0.22, -0.22, 0.6], [0.26, -0.2, 0.64]], LOOT: [[-0.2, 0.1, 0.36], [0.2, 0.06, 0.44]] };
  const lit = new Pool(crystalGeo, litMat, m.maxDeposits * 7 + 16, { shadow: true }), dim = new Pool(crystalGeo, dimMat, m.maxDeposits * 7 + 16, { shadow: true });
  const pads = new Pool(new THREE.CylinderGeometry(0.48, 0.5, 0.06, 28), new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.9 }), 16, { shadow: false });
  const crystalTilt = new Map();
  let depKey = '';
  const E = new THREE.Euler();
  function updateDeposits(f) {
    const key = f.t + ':' + f.deposits.length;
    if (key === depKey) return; depKey = key;
    lit.ensure(f.deposits.length * 7); dim.ensure(f.deposits.length * 7); pads.ensure(f.deposits.length);
    lit.reset(); dim.reset(); pads.reset();
    for (const d of f.deposits) {
      const set = SETS[d.kind] || SETS.NORMAL, home = d.kind === 'HOME';
      const max = m.depMax.get(d.id) || d.amount || 1, nLit = home ? set.length : Math.round(clamp(d.amount / max, 0, 1) * set.length);
      if (!crystalTilt.has(d.id)) crystalTilt.set(d.id, set.map(() => [(R() - 0.5) * 0.4, R() * 3, (R() - 0.5) * 0.4]));
      const tilt = crystalTilt.get(d.id), k = d.kind === 'LOOT' ? 0.8 : 1;
      set.forEach(([ox, oy, hh], i) => {
        const on = i < nLit;
        E.set(tilt[i][0], tilt[i][1], tilt[i][2]); Q.setFromEuler(E);
        S.set(k, (on ? hh : hh * 0.45) * 4.2 * k, k); V.set(d.x + 0.5 + ox, (on ? hh : hh * 0.45) * 0.6 * k, d.y + 0.5 + oy);
        M.compose(V, Q, S); (on ? lit : dim).add(M);
      });
      if (home) { Q.identity(); S.set(1, 1, 1); V.set(d.x + 0.5, 0.03, d.y + 0.5); M.compose(V, Q, S); pads.add(M, m.pal(m.homeOwner.get(d.id)).l); }
    }
    lit.done(); dim.done(); pads.done();
  }

  // --- базы
  const bases = new Map();
  function baseObj(b) {
    if (bases.has(b.id)) return bases.get(b.id);
    const pal = m.pal(b.c), grp = new THREE.Group();
    const pad = new THREE.Mesh(new THREE.CylinderGeometry(1.15, 1.25, 0.12, 40), mat(pal.l, { roughness: 0.9 })); pad.position.y = 0.06; grp.add(pad);
    const body = new THREE.Mesh(new RoundedBoxGeometry(1.3, 0.8, 1.3, 3, 0.14), mat('#F1F2EC', { roughness: 0.7 })); body.position.y = 0.5; grp.add(body);
    const roof = new THREE.Mesh(new RoundedBoxGeometry(1.0, 0.26, 1.0, 3, 0.09), mat(pal.m, { roughness: 0.6 })); roof.position.y = 0.98; grp.add(roof);
    const tower = new THREE.Mesh(new THREE.CylinderGeometry(0.1, 0.14, 0.62, 12), mat('#E4E7DF')); tower.position.set(0.38, 1.25, -0.38); grp.add(tower);
    const beacon = new THREE.Mesh(new THREE.SphereGeometry(0.1, 16, 12), mat(pal.hi, { emissive: pal.m, emissiveIntensity: 0.9 })); beacon.position.set(0.38, 1.62, -0.38); grp.add(beacon);
    for (const sx of [-1, 1]) { const win = new THREE.Mesh(new THREE.BoxGeometry(0.3, 0.14, 0.02), mat('#2F3A40', { roughness: 0.3 })); win.position.set(sx * 0.3, 0.55, 0.66); grp.add(win); }
    grp.traverse(o => { if (o.isMesh) { o.castShadow = true; o.receiveShadow = true; } });
    grp.scale.setScalar(1.15); grp.position.set(b.x + 0.5, 0, b.y + 0.5); scene.add(grp);
    const ruin = new THREE.Group();
    for (let i = 0; i < 4; i++) { const p = new THREE.Mesh(new RoundedBoxGeometry(0.5 + R() * 0.3, 0.25 + R() * 0.3, 0.4 + R() * 0.3, 2, 0.06), mat(i ? '#B7BDB3' : pal.d, { roughness: 1 })); p.position.set((R() - 0.5) * 0.9, 0.12, (R() - 0.5) * 0.9); p.rotation.set((R() - 0.5) * 0.6, R() * 3, (R() - 0.5) * 0.6); p.castShadow = true; ruin.add(p); }
    ruin.position.copy(grp.position); ruin.visible = false; scene.add(ruin);
    const o = { grp, ruin, c: b.c, x: b.x, y: b.y }; bases.set(b.id, o); return o;
  }
  for (const b of m.frames[0].bases) baseObj(b);

  // --- юниты: по набору на деталь; начальная ёмкость — по самому многолюдному кадру повтора
  const start = Math.ceil((m.maxUnits || 16) * 1.3) + 16;
  const white = () => new THREE.MeshStandardMaterial({ color: '#ffffff', roughness: 0.65 });
  const P_ = {
    wChassis: new Pool(new RoundedBoxGeometry(0.56, 0.14, 0.32, 2, 0.05), white(), start),
    wCab: new Pool(new RoundedBoxGeometry(0.18, 0.2, 0.28, 2, 0.05), mat('#F3F4EF'), start),
    wBed: new Pool(new RoundedBoxGeometry(0.3, 0.08, 0.3, 2, 0.03), white(), start),
    wCargo: new Pool(new THREE.OctahedronGeometry(0.11, 0), litMat, start),
    tTrack: new Pool(new RoundedBoxGeometry(1.0, 0.22, 0.24, 2, 0.07), mat('#262C30', { roughness: 0.9 }), start * 2),
    tHull: new Pool(new RoundedBoxGeometry(0.84, 0.24, 0.58, 2, 0.07), white(), start),
    tTurret: new Pool(new THREE.CylinderGeometry(0.24, 0.28, 0.2, 6), white(), start),
    tBarrel: new Pool((() => { const g = new THREE.CylinderGeometry(0.045, 0.05, 0.62, 10); g.rotateZ(Math.PI / 2); return g; })(), mat('#23292D', { roughness: 0.5, metalness: 0.3 }), start),
    rBody: new Pool(new THREE.CylinderGeometry(0.36, 0.42, 0.26, 6), mat('#353B3F', { roughness: 0.75 }), 16),
    rTop: new Pool(new THREE.CylinderGeometry(0.2, 0.32, 0.14, 6), mat('#596166', { roughness: 0.7 }), 16),
    rVisor: new Pool(new THREE.BoxGeometry(0.1, 0.07, 0.32), mat('#E03A3A', { emissive: '#B01818', emissiveIntensity: 0.6 }), 16),
    wreck: new Pool(new RoundedBoxGeometry(0.8, 0.22, 0.56, 2, 0.06), mat('#6E726B', { roughness: 1 }), 32),
    hpBg: new Pool(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#1C2328', transparent: true, opacity: 0.55, depthWrite: false }), 32, { shadow: false }),
    hpFg: new Pool(new THREE.PlaneGeometry(1, 1).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#ffffff', depthWrite: false }), 32, { shadow: false }),
    mine: new Pool(new THREE.RingGeometry(0.36, 0.5, 28).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.9, depthWrite: false }), 32, { shadow: false }),
  };
  const shotGeo = new THREE.CylinderGeometry(0.05, 0.05, 1, 8); shotGeo.rotateZ(Math.PI / 2);
  const shots = new Pool(shotGeo, new THREE.MeshStandardMaterial({ color: '#FFE08A', emissive: '#FFC23C', emissiveIntensity: 2.2 }), 64, { shadow: false });
  const base = new THREE.Matrix4(), loc = new THREE.Matrix4(), out = new THREE.Matrix4(), qL = new THREE.Quaternion(), sL = new THREE.Vector3(), vL = new THREE.Vector3();
  const put = (pool, x, y, ang, ox, oy, oz, sx = 1, sy = 1, sz = 1, color = null) => {
    base.makeRotationY(-ang); base.setPosition(x, 0, y);
    qL.identity(); vL.set(ox, oy, oz); sL.set(sx, sy, sz); loc.compose(vL, qL, sL);
    out.multiplyMatrices(base, loc);
    pool.add(out, color);
  };
  // кольцо выбора — одна сетка, а не перерисовка слоя земли
  const ring = new THREE.Mesh(new THREE.RingGeometry(0.78, 0.92, 40).rotateX(-Math.PI / 2), new THREE.MeshBasicMaterial({ color: '#ffffff', transparent: true, opacity: 0.95, depthWrite: false }));
  ring.renderOrder = 2; ring.visible = false; scene.add(ring);

  // --- вспышки и дым
  const radialTex = (rgb, a) => { const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d'); const gr = x.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, `rgba(${rgb},${a})`); gr.addColorStop(1, `rgba(${rgb},0)`); x.fillStyle = gr; x.fillRect(0, 0, 128, 128); const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; return t; };
  const flashTex = radialTex('255,240,190', 1), smokeTex = radialTex('140,140,135', 0.8), redTex = radialTex('255,90,70', 1);
  const sprites = Array.from({ length: 160 }, () => { const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: smokeTex, transparent: true, depthWrite: false })); s.visible = false; scene.add(s); return s; });

  // --- подписи
  const lblBase = new Map(), tagEls = [], popEls = [];
  const el = cls => { const e = document.createElement('div'); e.className = cls; labels.appendChild(e); return e; };
  const toScreen = (x, y, h) => { V.set(x, h, y).project(camera); return [(V.x + 1) / 2 * vw, (1 - V.y) / 2 * vh, V.z < 1]; };

  let vw = 1, vh = 1, overKey = '';
  function resize(Wp, Hp, dpr) { vw = Wp; vh = Hp; renderer.setPixelRatio(dpr); renderer.setSize(Wp, Hp, false); overKey = ''; }

  function applyCamera() {
    const [fx, fy] = cam.focus();
    const D = (vh / cam.s) * Math.sin(PITCH) / (2 * TANF) * (cam.isFit() ? 1.1 : 1); // на общем плане чуть дальше, чтобы подставка влезла
    camera.aspect = vw / vh; camera.near = Math.max(0.3, D * 0.1); camera.far = D * 6 + big * 4;
    camera.position.set(cam.cx, D * Math.sin(PITCH), cam.cy + D * Math.cos(PITCH));
    camera.lookAt(cam.cx, 0, cam.cy);
    camera.setViewOffset(vw, vh, vw / 2 - fx, vh / 2 - fy, vw, vh);
    camera.updateProjectionMatrix(); camera.updateMatrixWorld();
  }

  // Слой земли зависит только от номера такта и выбора — перерисовка и загрузка в видеокарту раз в такт.
  function paintOverlay(Sc, o, far) {
    const X = x => x * OPX, g = o2;
    g.clearRect(0, 0, ocan.width, ocan.height);
    for (const b of Sc.frame.bases) { const x = X(b.x + 0.5), y = X(b.y + 0.5), r = OPX * BASE_GLOW, gr = g.createRadialGradient(x, y, r * 0.15, x, y, r); gr.addColorStop(0, rgba(m.pal(b.c).m, 0.32)); gr.addColorStop(1, rgba(m.pal(b.c).m, 0)); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill(); }
    for (const d of Sc.deaths) { const a = 0.38 * clamp(1 - d.age / 12, 0, 1); if (a <= 0) continue; g.fillStyle = `rgba(55,48,38,${a})`; g.beginPath(); g.ellipse(X(d.x + 0.5), X(d.y + 0.5), OPX * 0.75, OPX * 0.55, 0.3, 0, Math.PI * 2); g.fill(); }
    for (const r of Sc.ruins) { g.fillStyle = 'rgba(55,48,38,.34)'; g.beginPath(); g.ellipse(X(r.x + 0.5), X(r.y + 0.5), OPX * 1.4, OPX * 1.1, 0, 0, Math.PI * 2); g.fill(); }
    for (const d of Sc.frame.deposits) { if (d.kind === 'HOME' || d.amount <= 0) continue; const x = X(d.x + 0.5), y = X(d.y + 0.5), r = OPX * (d.kind === 'CENTER' ? 2 : 1.2), gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, 'rgba(255,200,60,.35)'); gr.addColorStop(1, 'rgba(255,200,60,0)'); g.fillStyle = gr; g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fill(); }
    if (!far) for (const d of Sc.deaths) if (d.killer && d.age < 2.5) { g.strokeStyle = rgba(m.pal(d.killer.c).d, 0.85); g.lineWidth = Math.max(2, OPX * 0.1); g.setLineDash([OPX * 0.2, OPX * 0.4]); g.beginPath(); g.moveTo(X(d.x + 0.5), X(d.y + 0.5)); g.lineTo(X(d.killer.x + 0.5), X(d.killer.y + 0.5)); g.stroke(); g.setLineDash([]); }
    for (const k of Sc.marks) { g.strokeStyle = rgba(DANGER, 0.85); g.lineWidth = Math.max(2, OPX * 0.12); g.setLineDash([OPX * 0.3, OPX * 0.25]); g.beginPath(); g.arc(X(k.x + 0.5), X(k.y + 0.5), OPX * (k.base ? 1.5 : 0.85), 0, Math.PI * 2); g.stroke(); g.setLineDash([]); }
    if (far) for (const hs of hotspots(m, Sc.a)) { if (hs.w < 3) break; const r = OPX * (3 + Math.min(2, hs.w / 12)); g.strokeStyle = rgba(DANGER, 0.85); g.lineWidth = Math.max(2, OPX * 0.15); g.setLineDash([OPX * 0.7, OPX * 0.5]); g.beginPath(); g.arc(X(hs.x), X(hs.y), r, 0, Math.PI * 2); g.stroke(); g.setLineDash([]); }
    overTex.needsUpdate = true;
  }

  let lastScene = null;
  function render(Sc, o) {
    lastScene = Sc;
    applyCamera();
    const far = cam.lod() === 'far', us = UNIT_SCALE * (far ? 1.15 : 1);
    updateDeposits(Sc.frame);
    // базы и руины
    const alive = new Set(Sc.frame.bases.map(b => b.id));
    for (const b of Sc.frame.bases) baseObj(b);
    for (const [id, ob] of bases) { ob.grp.visible = alive.has(id); ob.ruin.visible = !alive.has(id) && Sc.ruins.some(r => r.x === ob.x && r.y === ob.y); }
    // юниты: ёмкость наборов — до заполнения, чтобы ничего не терялось
    const all = Sc.units.concat(Sc.dying), nW = all.filter(u => u.k === 'W').length, nT = all.filter(u => u.k === 'T').length, nR = all.filter(u => u.k === 'R').length;
    for (const p of [P_.wChassis, P_.wCab, P_.wBed, P_.wCargo]) p.ensure(nW);
    for (const p of [P_.tHull, P_.tTurret, P_.tBarrel]) p.ensure(nT);
    P_.tTrack.ensure(nT * 2);
    for (const p of [P_.rBody, P_.rTop, P_.rVisor]) p.ensure(nR);
    P_.wreck.ensure(Sc.deaths.length); P_.hpBg.ensure(all.length); P_.hpFg.ensure(all.length); P_.mine.ensure(all.length);
    shots.ensure(Sc.shots.length);
    for (const k in P_) P_[k].reset();
    shots.reset();
    for (const u of all) {
      if (u.alpha < (u.born ? 0.15 : 0.5)) continue;
      const pal = m.pal(u.c), x = u.x + 0.5, y = u.y + 0.5, s = us * (u.born ? 0.6 + 0.4 * u.alpha : 1);
      // выбранная колония видна не только цветом: белое кольцо на земле под каждым её юнитом
      if (o.selected != null && u.c === o.selected) put(P_.mine, x, y, 0, 0, 0.035, 0, s * (u.k === 'T' ? 1.5 : 1.2), 1, s * (u.k === 'T' ? 1.5 : 1.2));
      if (u.k === 'W') {
        put(P_.wChassis, x, y, u.h, 0, 0.1 * s, 0, s, s, s, pal.d);
        put(P_.wCab, x, y, u.h, 0.17 * s, 0.26 * s, 0, s, s, s);
        put(P_.wBed, x, y, u.h, -0.1 * s, 0.21 * s, 0, s, s, s, pal.m);
        if (u.carry > 0) put(P_.wCargo, x, y, u.h, -0.1 * s, 0.33 * s, 0, s, 1.3 * s, s);
      } else if (u.k === 'T') {
        put(P_.tTrack, x, y, u.h, 0, 0.11 * s, -0.29 * s, s, s, s);
        put(P_.tTrack, x, y, u.h, 0, 0.11 * s, 0.29 * s, s, s, s);
        put(P_.tHull, x, y, u.h, -0.02 * s, 0.32 * s, 0, s, s, s, pal.m);
        put(P_.tTurret, x, y, u.tur, 0, 0.53 * s, 0, s, s, s, pal.hi);
        put(P_.tBarrel, x, y, u.tur, (0.48 - (u.fired ? 0.12 : 0)) * s, 0.55 * s, 0, s, s, s);
      } else {
        put(P_.rBody, x, y, u.h, 0, 0.16 * s, 0, s, s, s);
        put(P_.rTop, x, y, u.h, -0.04 * s, 0.34 * s, 0, s, s, s);
        put(P_.rVisor, x, y, u.h, 0.3 * s, 0.22 * s, 0, s, s, s);
      }
      // здоровье — плоская полоска на земле перед юнитом, только у раненых
      if (!far && u.hp < u.max && u.alpha > 0.5) {
        const f = clamp(u.hp / u.max, 0, 1), w = 0.9;
        put(P_.hpBg, x, y + 0.72, 0, 0, 0.03, 0, w + 0.08, 1, 0.2);
        put(P_.hpFg, x - (w * (1 - f)) / 2, y + 0.72, 0, 0, 0.035, 0, Math.max(0.02, w * f), 1, 0.12, f < 0.35 ? DANGER : (u.c ? pal.hi : '#9AA3A8'));
      }
    }
    for (const d of Sc.deaths) if (d.age < 6 && d.k !== 'W' && !far) put(P_.wreck, d.x + 0.5, d.y + 0.5, d.h + 0.4, 0, 0.11 - 0.03 * d.age, 0, us, us, us);
    for (const s of Sc.shots) {
      const len = Math.max(0.3, Math.hypot(s.hx - s.tx, s.hy - s.ty)), mx = (s.hx + s.tx) / 2, my = (s.hy + s.ty) / 2;
      put(shots, mx, my, s.ang, 0, 0.6, 0, len, s.alpha * 1.3, s.alpha * 1.3);
    }
    for (const k in P_) P_[k].done();
    shots.done();
    // кольцо выбора
    const sel = Sc.units.find(u => u.id === o.pinned || u.id === o.hoverUnit);
    ring.visible = !!sel && !far; if (sel) { ring.position.set(sel.x + 0.5, 0.04, sel.y + 0.5); ring.scale.setScalar(us); }
    // вспышки и дым; разовые — не дольше 200 мс
    let si = 0;
    const sp = (x, y, h, scale, tex, color, opacity, add) => { if (si >= sprites.length) return; const s = sprites[si++]; s.visible = true; s.position.set(x, h, y); s.scale.setScalar(scale); s.material.map = tex; s.material.color.set(color); s.material.opacity = opacity; s.material.blending = add ? THREE.AdditiveBlending : THREE.NormalBlending; };
    for (const e of Sc.fx) {
      if (e.kind === 'muzzle' && e.first) { const tx = e.x + Math.cos(e.ang) * 0.85, ty = e.y + Math.sin(e.ang) * 0.85; sp(tx, ty, 0.6, 1.0 - e.age * 0.5, flashTex, '#FFF2C4', 1 - e.age, true); if (!o.reduced) sp(tx + Math.cos(e.ang) * 0.3 * e.age, ty + Math.sin(e.ang) * 0.3 * e.age, 0.75 + e.age * 0.4, 0.6 + e.age * 0.8, smokeTex, '#BFC0BA', 0.5 * (1 - e.age), false); }
      else if (e.kind === 'hit') sp(e.x, e.y, 0.5, (e.big ? 2.4 : 1.5) * (1 - e.age * 0.4), redTex, '#FFB08A', o.reduced ? 0.8 : 1 - e.age, true);
      else if (e.kind === 'puff') sp(e.x, e.y, 0.45, 0.6 + e.age * 0.6, smokeTex, '#C9CAC4', 0.6 * (1 - e.age), false);
    }
    for (const d of Sc.deaths) {
      const ms = d.age * Sc.msPerTick;
      if (ms < 200 && !o.reduced) sp(d.x + 0.5, d.y + 0.5, 0.6, 2.6 * easeOut(ms / 200), flashTex, '#FFD7A0', 1 - ms / 200, true);
      if (!o.reduced && d.age < 5 && d.k !== 'W') for (let i = 0; i < 5; i++) { const ph = d.age + i * 0.4, a = clamp(0.55 * (1 - ph / 6), 0, 0.55); if (a > 0) sp(d.x + 0.5 + 0.22 * ph + Math.sin(i * 2.1) * 0.2, d.y + 0.5 - 0.1 * ph, 0.5 + 0.5 * ph, 0.7 + 0.35 * ph, smokeTex, '#8E8F8A', a, false); }
    }
    for (let i = si; i < sprites.length; i++) sprites[i].visible = false;

    const key = Sc.a + ':' + o.selected + ':' + far + ':' + Sc.marks.length;
    if (key !== overKey) { overKey = key; paintOverlay(Sc, o, far); }
    renderer.render(scene, camera);
    labelsPass(Sc, o, far);
  }

  // Подписи: имена баз, знак колонии над танком в бою и на метке армии, «+20».
  function labelsPass(Sc, o, far) {
    for (const b of Sc.frame.bases) {
      let e = lblBase.get(b.id);
      const c = m.colonies.get(b.c), text = c ? clipName(c.name, 16) : '';
      if (!e) { e = el('l3'); e.style.background = m.pal(b.c).d; lblBase.set(b.id, e); }
      if (e.textContent !== text) e.textContent = text; // имя колонии может смениться посреди живой игры
      const [x, y, vis] = toScreen(b.x + 0.5, b.y + 2.1, 0);
      e.style.display = vis ? 'block' : 'none'; e.style.left = x + 'px'; e.style.top = y + 'px';
      e.style.opacity = o.hoverCol && o.hoverCol !== b.c ? 0.35 : 1;
    }
    const alive = new Set(Sc.frame.bases.map(b => b.id));
    for (const [id, e] of lblBase) if (!alive.has(id)) e.style.display = 'none';
    const tags = [];
    if (far) for (const g of groupUnits(Sc.units)) tags.push({ x: g.x, y: g.y, text: g.k === 'R' ? (g.n > 1 ? `налётчики ${g.n}` : 'налётчик') : `${m.colonies.get(g.c)?.sign || ''}${g.n > 1 ? ' ' + g.n : ''}`, bg: g.k === 'R' ? '#2B3034' : m.pal(g.c).d });
    else for (const t of tankTags(Sc.units, m)) tags.push(t);
    while (tagEls.length < tags.length) tagEls.push(el('t3'));
    tagEls.forEach((e, i) => {
      const t = tags[i]; e.style.display = t ? 'block' : 'none';
      if (!t) return;
      const [x, y] = toScreen(t.x + 0.5, t.y + 0.5, far ? 1.6 : 1.1);
      e.style.left = x + 'px'; e.style.top = y + 'px'; if (e.textContent !== t.text) e.textContent = t.text; e.style.background = t.bg;
    });
    const pops = far ? [] : Sc.pops;
    while (popEls.length < pops.length) popEls.push(el('p3'));
    popEls.forEach((e, i) => { const p = pops[i]; e.style.display = p ? 'block' : 'none'; if (p) { const [x, y] = toScreen(p.x + 0.5 + (p.idx % 3 - 1) * 0.5, p.y + 0.5, 2 + 1.3 * easeOut(p.age)); e.style.left = x + 'px'; e.style.top = y + 'px'; e.style.opacity = 1 - p.age * p.age; e.textContent = '+' + p.n; } });
  }

  const ray = new THREE.Raycaster(), ndc = new THREE.Vector2(), plane = new THREE.Plane(new THREE.Vector3(0, 1, 0), 0), hitP = new THREE.Vector3();
  function groundAt(px, py) {
    ndc.set(px / vw * 2 - 1, -(py / vh) * 2 + 1); ray.setFromCamera(ndc, camera);
    return ray.ray.intersectPlane(plane, hitP) ? [hitP.x, hitP.z] : null;
  }
  function pick(px, py) {
    if (!lastScene) return null;
    const p = groundAt(px, py); if (!p) return null;
    let best = null, bd = cam.lod() === 'far' ? 0 : 0.9;
    for (const u of lastScene.units) { if (u.alpha < 0.5) continue; const d = Math.hypot(u.x + 0.5 - p[0], u.y + 0.5 - p[1]); if (d < bd) { bd = d; best = { unit: u }; } }
    if (best) return best;
    for (const b of lastScene.frame.bases) if (Math.abs(b.x + 0.5 - p[0]) < 1 && Math.abs(b.y + 0.5 - p[1]) < 1) return { base: b };
    return null;
  }
  function viewQuad() { return [groundAt(0, 0), groundAt(vw, 0), groundAt(vw, vh), groundAt(0, vh)].map(q => q || [cam.cx, cam.cy]); }
  // для проверки: ёмкость наборов и сколько в них сейчас (живая игра с ростом числа юнитов)
  function stats() { return Object.fromEntries(Object.entries({ ...P_, shots, lit, dim }).map(([k, p]) => [k, [p.mesh.count, p.cap]])); }
  return { resize, render, pick, viewQuad, stats };
}
