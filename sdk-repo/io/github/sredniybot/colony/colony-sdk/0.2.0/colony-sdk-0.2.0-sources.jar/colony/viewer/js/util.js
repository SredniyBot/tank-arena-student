// Общие мелочи: числа, цвета, слова.

export const clamp = (v, a, b) => Math.max(a, Math.min(b, v));
export const lerp = (a, b, k) => a + (b - a) * k;
export const easeOut = k => 1 - Math.pow(1 - k, 3);
export const smooth = k => k * k * (3 - 2 * k);

export const DIRS = [[0, -1], [1, 0], [0, 1], [-1, 0]]; // N E S W, y растёт на юг

// --- цвета
export function hexToRgb(hex) {
  const h = hex.replace('#', '');
  const n = parseInt(h.length === 3 ? h.split('').map(c => c + c).join('') : h, 16);
  return [n >> 16, (n >> 8) & 255, n & 255];
}
export const rgbToHex = ([r, g, b]) => '#' + [r, g, b].map(v => clamp(Math.round(v), 0, 255).toString(16).padStart(2, '0')).join('');
export const rgba = (hex, a) => { const [r, g, b] = hexToRgb(hex); return `rgba(${r},${g},${b},${a})`; };
const mix = (c1, c2, k) => c1.map((v, i) => lerp(v, c2[i], k));

// Оттенки колонии из одного цвета повтора: основной, тёмный (контур, текст), светлый (площадка), блик.
export function shades(hex) {
  const m = hexToRgb(hex);
  return {
    m: rgbToHex(m),
    d: rgbToHex(mix(m, [18, 24, 32], 0.42)),
    l: rgbToHex(mix(m, [255, 255, 255], 0.62)),
    hi: rgbToHex(mix(m, [255, 255, 255], 0.28)),
    ink: rgbToHex(mix(m, [12, 16, 22], 0.2)),
  };
}

export const NEUTRAL = { m: '#4A5056', d: '#2B3034', l: '#C9CDC9', hi: '#6D747A', ink: '#2B3034' };
export const DANGER = '#E03A3A';
export const ENERGY = { m: '#EDB12C', hi: '#FFD866', d: '#B37A06' };

// --- числа и слова
const nf = new Intl.NumberFormat('ru-RU');
export const num = v => nf.format(Math.round(v));
// Число в узкий столбец таблицы: до 99 999 — целиком, дальше — «123 тыс», «4,5 млн» (бесконечный мир копит много).
export const numShort = v => {
  const n = Math.round(v), a = Math.abs(n);
  if (a < 100_000) return nf.format(n);
  if (a < 1_000_000) return Math.round(n / 1000) + ' тыс';
  return (n / 1e6).toFixed(a < 10_000_000 ? 1 : 0).replace('.', ',') + ' млн';
};
export function plural(n, one, few, many) {
  const a = Math.abs(n) % 100, b = a % 10;
  if (a > 10 && a < 20) return many;
  if (b > 1 && b < 5) return few;
  if (b === 1) return one;
  return many;
}
export const KIND_NAME = { W: 'рабочий', T: 'танк', R: 'налётчик' };
export function bytes(n) {
  if (n < 1024) return `${n} Б`;
  if (n < 1024 * 1024) return `${num(n / 1024)} КБ`;
  return `${(n / 1024 / 1024).toFixed(1).replace('.', ',')} МБ`;
}
export function when(iso) {
  const d = new Date(iso);
  if (isNaN(d)) return '';
  const today = new Date();
  const time = d.toLocaleTimeString('ru-RU', { hour: '2-digit', minute: '2-digit' });
  if (d.toDateString() === today.toDateString()) return `сегодня, ${time}`;
  return `${d.toLocaleDateString('ru-RU', { day: 'numeric', month: 'long' })}, ${time}`;
}

export const $ = (sel, root = document) => root.querySelector(sel);

// Строки из повтора (имена студентов, тексты, цвета) в DOM попадают только через textContent и setProperty.
// h('li', { class: 'x', title: '…', style: { '--c': '#123456' }, data: { seek: 4 } }, 'текст', узел, …)
export function h(tag, props, ...kids) {
  const e = document.createElement(tag);
  if (props) for (const [k, v] of Object.entries(props)) {
    if (v === undefined || v === null || v === false) continue;
    if (k === 'class') e.className = v;
    else if (k === 'text') e.textContent = String(v);
    else if (k === 'style') for (const [p, sv] of Object.entries(v)) e.style.setProperty(p, String(sv));
    else if (k === 'data') for (const [p, dv] of Object.entries(v)) e.dataset[p] = String(dv);
    else e.setAttribute(k, v === true ? '' : String(v));
  }
  for (const k of kids) if (k !== null && k !== undefined && k !== false) e.append(k instanceof Node ? k : String(k));
  return e;
}
// Значки — только наши собственные константы SVG, без данных повтора.
export function icon(svg) { const t = document.createElement('template'); t.innerHTML = svg.trim(); return t.content.firstChild; }

export const PALETTE = ['#2F6FDB', '#E3762C', '#13998A', '#8A5CD8', '#3E9A3E', '#CC4A9C', '#3CA6DA', '#8C6239', '#263F8C', '#8DB032', '#5E6E80', '#6B3F86', '#7A7A1F', '#0E6E8C', '#E07AA8', '#5BC8A0', '#4B3FC8', '#1F6B3A', '#B89B6A', '#8DA2BC', '#B07AE0', '#3A3A3A', '#9C8AA5', '#D18FD1'];
export const safeColor = (c, i = 0) => (typeof c === 'string' && /^#[0-9a-f]{6}$/i.test(c) ? c : PALETTE[Math.abs(i) % PALETTE.length]);
export const int = v => { const n = Number(v); return Number.isFinite(n) ? n : 0; };
export const clip = (s, n) => { s = String(s ?? ''); return s.length > n ? s.slice(0, n - 1) + '…' : s; };
// Имя колонии на карте: хвост в скобках («Аня Петрова (бот)») не обрезается — режется само имя.
// Короткое имя для карты: «Фамилия И.» без хвоста «(бот)»; «Студент 5», «Гость 2» — как есть.
export const shortName = (s, n = 14) => {
  s = String(s ?? '').replace(/ \([^()]{1,8}\)$/, '').trim();
  const p = s.split(/\s+/);
  return p.length >= 2 && /^\p{Lu}/u.test(p[1]) ? clip(p[0], n - 3) + ' ' + p[1][0] + '.' : clip(s, n);
};
export const clipName = (s, n) => { s = String(s ?? ''); const t = / \([^()]{1,8}\)$/.exec(s); return t && s.length > n ? clip(s.slice(0, t.index), n - t[0].length) + t[0] : clip(s, n); };

export function storeGet(key, fallback) {
  try { const v = localStorage.getItem('colony.viewer.' + key); return v === null ? fallback : JSON.parse(v); } catch { return fallback; }
}
export function storeSet(key, value) {
  try { localStorage.setItem('colony.viewer.' + key, JSON.stringify(value)); } catch { /* приватный режим */ }
}

// Детерминированный шум для рельефа: одна и та же карта выглядит одинаково при каждом открытии.
export function rng(seed) {
  let a = seed >>> 0 || 1;
  return () => { a = (a + 0x6D2B79F5) | 0; let t = Math.imul(a ^ (a >>> 15), 1 | a); t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t; return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
export function hashStr(s) { let h = 2166136261; for (let i = 0; i < s.length; i++) { h ^= s.charCodeAt(i); h = Math.imul(h, 16777619); } return h >>> 0; }
