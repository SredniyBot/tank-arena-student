package colony.local;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.sun.net.httpserver.HttpExchange;
import com.sun.net.httpserver.HttpServer;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.OutputStream;
import java.io.UncheckedIOException;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URI;
import java.net.UnknownHostException;
import java.nio.charset.CharacterCodingException;
import java.nio.charset.CodingErrorAction;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.BasicFileAttributes;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Optional;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.concurrent.atomic.AtomicInteger;
import java.util.stream.Stream;
import java.util.zip.GZIPInputStream;

/**
 * Сервер просмотра на {@code 127.0.0.1}: страница просмотра из ресурсов SDK, живая игра, повторы, материалы стенда.
 *
 * <ul>
 *   <li>{@code GET /} — {@code colony/viewer/index.html}; остальная статика — из {@code colony/viewer/**};</li>
 *   <li>{@code GET /api/live/meta} — заголовок повтора идущей игры и её {@code gameId}; игры нет — {@code 204};</li>
 *   <li>{@code GET /api/live/frames?from=N} — {@code {"gameId", "frames": [...], "finished": false}}, в конце —
 *       с {@code result};</li>
 *   <li>{@code GET /api/replays} — {@code [{"name", "size", "modified"}]}, новые первыми;</li>
 *   <li>{@code GET /api/replays/{name}} — повтор, {@code .json.gz} распакован;</li>
 *   <li>{@code GET /docs/**} — файлы из каталога материалов, если он задан (стенд).</li>
 * </ul>
 *
 * Запросы с чужим именем хоста отклоняются: страница из интернета не прочтёт повторы через подмену DNS.
 */
public final class ViewerServer implements AutoCloseable {

    /** Сколько портов подряд пробуем, начиная с желаемого, прежде чем взять любой свободный. */
    static final int PORT_ATTEMPTS = 10;

    private static final String VIEWER = "colony/viewer/";
    private static final ObjectMapper JSON = new ObjectMapper();
    private static final Map<String, String> TYPES = Map.ofEntries(
            Map.entry("html", "text/html; charset=utf-8"),
            Map.entry("js", "text/javascript; charset=utf-8"),
            Map.entry("mjs", "text/javascript; charset=utf-8"),
            Map.entry("css", "text/css; charset=utf-8"),
            Map.entry("json", "application/json; charset=utf-8"),
            Map.entry("woff2", "font/woff2"),
            Map.entry("woff", "font/woff"),
            Map.entry("svg", "image/svg+xml"),
            Map.entry("png", "image/png"),
            Map.entry("jpg", "image/jpeg"),
            Map.entry("jpeg", "image/jpeg"),
            Map.entry("webp", "image/webp"),
            Map.entry("ico", "image/x-icon"),
            Map.entry("md", "text/markdown; charset=utf-8"),
            Map.entry("txt", "text/plain; charset=utf-8"),
            Map.entry("pdf", "application/pdf"));

    private final HttpServer server;
    private final ExecutorService executor;
    private final LiveFeed feed;
    private final Path replays;
    private final Path docs;
    private final URI uri;

    private ViewerServer(HttpServer server, ExecutorService executor, LiveFeed feed, Path replays, Path docs) {
        this.server = server;
        this.executor = executor;
        this.feed = feed;
        this.replays = replays.toAbsolutePath().normalize();
        this.docs = docs == null ? null : docs.toAbsolutePath().normalize();
        this.uri = URI.create("http://127.0.0.1:" + server.getAddress().getPort() + "/");
    }

    /**
     * Запустить сервер на {@code 127.0.0.1}. Желаемый порт занят — берём следующий, затем любой свободный.
     *
     * @param preferredPort желаемый порт; {@code 0} — любой свободный
     * @param feed          живая игра
     * @param replaysDir    каталог повторов; может ещё не существовать
     * @param docsDir       каталог материалов для {@code /docs/}; {@code null} — не отдавать
     * @return запущенный сервер; адрес — {@link #uri()}
     */
    public static ViewerServer start(int preferredPort, LiveFeed feed, Path replaysDir, Path docsDir) {
        if (System.getProperty("sun.net.httpserver.nodelay") == null) {
            // JDK шлёт заголовки и тело отдельно: без TCP_NODELAY каждый ответ ждёт ~40 мс подтверждения TCP
            System.setProperty("sun.net.httpserver.nodelay", "true");
        }
        HttpServer http = bind(preferredPort);
        AtomicInteger n = new AtomicInteger();
        ExecutorService ex = Executors.newFixedThreadPool(4, r -> {
            Thread t = new Thread(r, "colony-viewer-" + n.incrementAndGet());
            t.setDaemon(true);
            return t;
        });
        ViewerServer s = new ViewerServer(http, ex, feed, replaysDir, docsDir);
        http.createContext("/", s::handle);
        http.setExecutor(ex);
        http.start();
        return s;
    }

    private static HttpServer bind(int preferred) {
        InetAddress loopback = loopback();
        IOException last = null;
        List<Integer> ports = new ArrayList<>();
        if (preferred > 0) {
            for (int i = 0; i < PORT_ATTEMPTS && preferred + i <= 65535; i++) {
                ports.add(preferred + i);
            }
        }
        ports.add(0);
        for (int port : ports) {
            try {
                return HttpServer.create(new InetSocketAddress(loopback, port), 0);
            } catch (IOException e) {
                last = e; // обычно BindException: порт занят
            }
        }
        throw new UncheckedIOException("не удалось открыть порт на 127.0.0.1", last);
    }

    static InetAddress loopback() {
        try {
            return InetAddress.getByAddress("localhost", new byte[] {127, 0, 0, 1});
        } catch (UnknownHostException e) {
            throw new IllegalStateException(e);
        }
    }

    /** Адрес просмотра: {@code http://127.0.0.1:<порт>/}. */
    public URI uri() {
        return uri;
    }

    public int port() {
        return uri.getPort();
    }

    /** Адрес, на котором слушает сокет. */
    public InetSocketAddress address() {
        return server.getAddress();
    }

    /** Остановить сервер. */
    @Override
    public void close() {
        server.stop(0);
        executor.shutdownNow();
    }

    // ---- обработка запросов ----

    private void handle(HttpExchange ex) {
        try {
            if (!localHost(ex.getRequestHeaders().getFirst("Host"))) {
                text(ex, 403, "доступ только с этого компьютера");
                return;
            }
            String method = ex.getRequestMethod();
            if (!method.equals("GET") && !method.equals("HEAD")) {
                ex.getResponseHeaders().set("Allow", "GET, HEAD");
                text(ex, 405, "только GET");
                return;
            }
            Optional<String> decoded = decode(ex.getRequestURI().getRawPath());
            if (decoded.isEmpty()) {
                text(ex, 400, "неверный адрес");
                return;
            }
            route(ex, decoded.get());
        } catch (IOException e) {
            // браузер закрыл соединение — не наша беда
        } catch (RuntimeException e) {
            try {
                text(ex, 500, "ошибка сервера: " + e);
            } catch (IOException | RuntimeException ignored) {
                // ответ уже начат
            }
        } finally {
            ex.close();
        }
    }

    private void route(HttpExchange ex, String path) throws IOException {
        if (path.equals("/api/live/meta")) {
            Optional<ObjectNode> meta = feed.meta();
            if (meta.isEmpty()) {
                noStore(ex);
                ex.sendResponseHeaders(204, -1);
            } else {
                json(ex, 200, JSON.writeValueAsBytes(meta.get()));
            }
        } else if (path.equals("/api/live/frames")) {
            Optional<ObjectNode> frames = feed.frames(fromParam(ex.getRequestURI().getRawQuery()));
            if (frames.isEmpty()) {
                json(ex, 404, error("игра не идёт"));
            } else {
                json(ex, 200, JSON.writeValueAsBytes(frames.get()));
            }
        } else if (path.equals("/api/replays") || path.equals("/api/replays/")) {
            json(ex, 200, JSON.writeValueAsBytes(listReplays()));
        } else if (path.startsWith("/api/replays/")) {
            replay(ex, path.substring("/api/replays/".length()));
        } else if (path.startsWith("/api/")) {
            json(ex, 404, error("нет такого адреса"));
        } else if (path.startsWith("/docs/") && docs != null) {
            docFile(ex, path.substring("/docs/".length()));
        } else if (path.equals("/") || path.equals("/index.html")) {
            resource(ex, "index.html");
        } else {
            resource(ex, path.substring(1));
        }
    }

    private static byte[] error(String message) throws IOException {
        return JSON.writeValueAsBytes(JsonNodeFactory.instance.objectNode().put("error", message));
    }

    static int fromParam(String rawQuery) {
        if (rawQuery == null) {
            return 0;
        }
        for (String part : rawQuery.split("&")) {
            if (part.startsWith("from=")) {
                try {
                    return Math.max(0, Integer.parseInt(part.substring(5)));
                } catch (NumberFormatException e) {
                    return 0;
                }
            }
        }
        return 0;
    }

    private ArrayNode listReplays() throws IOException {
        ArrayNode list = JsonNodeFactory.instance.arrayNode();
        if (!Files.isDirectory(replays)) {
            return list;
        }
        record Item(String name, long size, java.nio.file.attribute.FileTime modified) {}
        List<Item> items = new ArrayList<>();
        try (Stream<Path> files = Files.list(replays)) {
            for (Path p : (Iterable<Path>) files::iterator) {
                String name = p.getFileName().toString();
                if (!replayName(name)) {
                    continue;
                }
                try {
                    BasicFileAttributes a = Files.readAttributes(p, BasicFileAttributes.class);
                    if (a.isRegularFile()) {
                        items.add(new Item(name, a.size(), a.lastModifiedTime()));
                    }
                } catch (IOException e) {
                    // файл исчез между list и чтением — пропускаем
                }
            }
        }
        items.sort(Comparator.comparing(Item::modified).reversed().thenComparing(Item::name));
        for (Item i : items) {
            list.addObject().put("name", i.name()).put("size", i.size())
                    .put("modified", i.modified().toInstant().toString());
        }
        return list;
    }

    static boolean replayName(String name) {
        String n = name.toLowerCase(Locale.ROOT);
        return n.endsWith(".json") || n.endsWith(".json.gz");
    }

    private void replay(HttpExchange ex, String name) throws IOException {
        if (!replayName(name)) {
            json(ex, 404, error("это не повтор"));
            return;
        }
        Optional<Path> file = inside(replays, name);
        if (file.isEmpty()) {
            json(ex, 400, error("неверное имя повтора"));
            return;
        }
        if (!Files.isRegularFile(file.get())) {
            json(ex, 404, error("повтор не найден"));
            return;
        }
        byte[] body;
        try (InputStream raw = Files.newInputStream(file.get())) {
            InputStream in = name.toLowerCase(Locale.ROOT).endsWith(".gz") ? new GZIPInputStream(raw, 1 << 16) : raw;
            ByteArrayOutputStream buf = new ByteArrayOutputStream();
            in.transferTo(buf);
            body = buf.toByteArray();
        } catch (IOException e) {
            json(ex, 500, error("повтор не читается: " + e.getMessage()));
            return;
        }
        json(ex, 200, body);
    }

    private void docFile(HttpExchange ex, String rel) throws IOException {
        Optional<Path> file = inside(docs, rel);
        String type = file.map(p -> contentType(p.getFileName().toString())).orElse(null);
        if (file.isEmpty() || type == null || !Files.isRegularFile(file.get())) {
            text(ex, 404, "не найдено");
            return;
        }
        send(ex, 200, type, Files.readAllBytes(file.get()), "no-cache");
    }

    private void resource(HttpExchange ex, String rel) throws IOException {
        String type = contentType(rel);
        if (type == null || !safeRelative(rel)) {
            text(ex, 404, "не найдено");
            return;
        }
        try (InputStream in = ViewerServer.class.getClassLoader().getResourceAsStream(VIEWER + rel)) {
            if (in == null) {
                text(ex, 404, "не найдено");
                return;
            }
            send(ex, 200, type, in.readAllBytes(), "no-cache");
        }
    }

    // ---- безопасность путей ----

    /** Относительный путь без {@code ..}, {@code .}, пустых частей, обратных косых, двоеточий и управляющих знаков. */
    static boolean safeRelative(String rel) {
        if (rel.isEmpty() || rel.startsWith("/") || rel.contains("\\") || rel.contains(":")) {
            return false;
        }
        for (char c : rel.toCharArray()) {
            if (c < 0x20 || c == 0x7f) {
                return false;
            }
        }
        for (String part : rel.split("/", -1)) {
            if (part.isEmpty() || part.equals(".") || part.equals("..")) {
                return false;
            }
        }
        return true;
    }

    /** Файл внутри каталога {@code root} или пусто, если путь пытается выйти наружу. */
    static Optional<Path> inside(Path root, String rel) {
        if (!safeRelative(rel)) {
            return Optional.empty();
        }
        try {
            Path p = root.resolve(rel).normalize();
            return p.startsWith(root) && !p.equals(root) ? Optional.of(p) : Optional.empty();
        } catch (java.nio.file.InvalidPathException e) {
            return Optional.empty();
        }
    }

    /** Раскодировать {@code %XX} в пути как UTF-8; плюс остаётся плюсом. Пусто — адрес испорчен. */
    static Optional<String> decode(String raw) {
        if (raw == null || raw.isEmpty()) {
            return Optional.of("/");
        }
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(raw.length());
        int i = 0;
        while (i < raw.length()) {
            char c = raw.charAt(i);
            if (c == '%') {
                if (i + 2 >= raw.length()) {
                    return Optional.empty();
                }
                int hi = Character.digit(raw.charAt(i + 1), 16);
                int lo = Character.digit(raw.charAt(i + 2), 16);
                if (hi < 0 || lo < 0) {
                    return Optional.empty();
                }
                bytes.write(hi * 16 + lo);
                i += 3;
            } else {
                int end = raw.indexOf('%', i);
                end = end < 0 ? raw.length() : end;
                bytes.writeBytes(raw.substring(i, end).getBytes(StandardCharsets.UTF_8));
                i = end;
            }
        }
        try {
            return Optional.of(StandardCharsets.UTF_8.newDecoder()
                    .onMalformedInput(CodingErrorAction.REPORT)
                    .onUnmappableCharacter(CodingErrorAction.REPORT)
                    .decode(java.nio.ByteBuffer.wrap(bytes.toByteArray())).toString());
        } catch (CharacterCodingException e) {
            return Optional.empty();
        }
    }

    /** Имя хоста из заголовка {@code Host} — этот компьютер. Без заголовка (HTTP/1.0) — пускаем. */
    static boolean localHost(String host) {
        if (host == null) {
            return true;
        }
        String h = host.strip().toLowerCase(Locale.ROOT);
        if (h.startsWith("[")) {
            int end = h.indexOf(']');
            h = end < 0 ? h : h.substring(0, end + 1);
        } else {
            int colon = h.indexOf(':');
            h = colon < 0 ? h : h.substring(0, colon);
        }
        return h.equals("127.0.0.1") || h.equals("localhost") || h.equals("[::1]");
    }

    /** Тип содержимого по расширению; {@code null} — такие файлы не отдаём. */
    static String contentType(String name) {
        int dot = name.lastIndexOf('.');
        int slash = name.lastIndexOf('/');
        if (dot < 0 || dot < slash) {
            return null;
        }
        return TYPES.get(name.substring(dot + 1).toLowerCase(Locale.ROOT));
    }

    // ---- ответы ----

    private static void noStore(HttpExchange ex) {
        ex.getResponseHeaders().set("Cache-Control", "no-store");
    }

    private static void json(HttpExchange ex, int code, byte[] body) throws IOException {
        send(ex, code, "application/json; charset=utf-8", body, "no-store");
    }

    private static void text(HttpExchange ex, int code, String message) throws IOException {
        send(ex, code, "text/plain; charset=utf-8", message.getBytes(StandardCharsets.UTF_8), "no-store");
    }

    private static void send(HttpExchange ex, int code, String type, byte[] body, String cache) throws IOException {
        ex.getResponseHeaders().set("Content-Type", type);
        ex.getResponseHeaders().set("Cache-Control", cache);
        ex.getResponseHeaders().set("X-Content-Type-Options", "nosniff");
        if (ex.getRequestMethod().equals("HEAD")) {
            ex.getResponseHeaders().set("Content-Length", Integer.toString(body.length));
            ex.sendResponseHeaders(code, -1);
            return;
        }
        ex.sendResponseHeaders(code, body.length == 0 ? -1 : body.length);
        try (OutputStream out = ex.getResponseBody()) {
            out.write(body);
        }
    }
}
