package colony.local;

import java.io.PrintStream;
import java.net.URI;
import java.nio.file.Path;

/**
 * Окружение запуска: папка проекта, консоль, просмотр, адрес опубликованной версии. В программе — {@link #system()},
 * в тестах — своё.
 *
 * @param workDir     папка проекта: здесь {@code replays/}, {@code ladder-results.json}, {@code colony.properties}
 * @param out         обычный вывод
 * @param err         ошибки (в IntelliJ — красным)
 * @param openBrowser открывать ли браузер с просмотром
 * @param viewerPort  желаемый порт просмотра; {@code 0} — любой свободный
 * @param versionUrl  где опубликована последняя версия SDK
 */
record Env(Path workDir, PrintStream out, PrintStream err, boolean openBrowser, int viewerPort, URI versionUrl) {

    static final int VIEWER_PORT = 8765;
    static final URI VERSION_URL = URI.create(
            "https://raw.githubusercontent.com/SredniyBot/tank-arena-student/main/sdk-repo/version.txt");

    Env {
        workDir = workDir.toAbsolutePath().normalize();
    }

    /** Текущая папка, {@code System.out}, порт 8765. Браузер не открывается при {@code -Dcolony.browser=false}. */
    static Env system() {
        boolean browser = !"false".equalsIgnoreCase(System.getProperty("colony.browser", "true"));
        return new Env(Path.of(""), System.out, System.err, browser, VIEWER_PORT, VERSION_URL);
    }

    Env withWorkDir(Path dir) {
        return new Env(dir, out, err, openBrowser, viewerPort, versionUrl);
    }

    Env withConsole(PrintStream newOut, PrintStream newErr) {
        return new Env(workDir, newOut, newErr, openBrowser, viewerPort, versionUrl);
    }

    Env withBrowser(boolean open) {
        return new Env(workDir, out, err, open, viewerPort, versionUrl);
    }

    Env withViewerPort(int port) {
        return new Env(workDir, out, err, openBrowser, port, versionUrl);
    }
}
