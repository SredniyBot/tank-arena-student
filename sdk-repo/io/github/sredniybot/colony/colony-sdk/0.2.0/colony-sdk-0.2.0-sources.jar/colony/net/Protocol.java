package colony.net;

import colony.api.Base;
import colony.api.Building;
import colony.api.ColonyView;
import colony.api.Deposit;
import colony.api.DepositKind;
import colony.api.EventKind;
import colony.api.GameEvent;
import colony.api.Pos;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.api.Rules;
import colony.api.Structure;
import colony.engine.RuleSet;
import colony.api.Unit;
import colony.api.UnitType;
import colony.api.Upgrade;
import colony.engine.Match;
import colony.engine.RulesLoader;
import colony.protocol.Board;
import colony.protocol.Order;
import colony.protocol.Versions;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.json.JsonMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.util.ArrayList;
import java.util.Base64;
import java.util.BitSet;
import java.util.EnumSet;
import java.util.Iterator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/**
 * Кодек протокола {@code /api/v1}: JSON поверх HTTP. Значения — типы {@code colony.api} и {@code colony.protocol},
 * JSON живёт только здесь. Читатель терпимый: неизвестные поля, значения перечислений (юнит, залежь, постройка,
 * улучшение, отказ, событие из новой версии) и ключи правил пропускает. Внутри мажорной версии протокол только
 * дополняется; что менялось — {@link Versions}.
 *
 * <p>Пометки пути ({@code Orders.mark}) по сети не идут: их рисует только просмотр у себя.
 */
public final class Protocol {

    /** Версия протокола: мажорная.минорная. */
    public static final String VERSION = Versions.PROTOCOL;
    /** Клиент и сервер понимают друг друга, если мажорная версия совпадает. */
    public static final int MAJOR = Versions.MAJOR;

    /** Терпимый {@link ObjectMapper}: лишние поля не ошибка. */
    public static final ObjectMapper JSON = JsonMapper.builder()
            .disable(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES)
            .build();

    private Protocol() {}

    public static int major(String version) {
        return Versions.major(version);
    }

    public static int compareVersions(String a, String b) {
        return Versions.compare(a, b);
    }

    // ---- карта и правила ----

    /** Карта для входа: имя, размеры и рельеф. Правила — отдельно ({@link #rulesJson}). */
    public static ObjectNode boardJson(Board board) {
        ObjectNode o = JSON.createObjectNode();
        o.put("name", board.name());
        o.put("width", board.width());
        o.put("height", board.height());
        ArrayNode rows = o.putArray("terrain");
        board.terrain().forEach(rows::add);
        return o;
    }

    public static Board board(JsonNode map, RuleSet rules) {
        int width = map.path("width").asInt();
        int height = map.path("height").asInt();
        List<String> rows = new ArrayList<>();
        for (JsonNode r : map.path("terrain")) {
            rows.add(r.asText());
        }
        if (width <= 0 || height <= 0 || rows.size() != height || rows.stream().anyMatch(r -> r.length() != width)) {
            throw new IllegalArgumentException("сервер прислал испорченную карту");
        }
        return new Board(map.path("name").asText("?"), width, height, rows, rules);
    }

    /** Правила для отправки: ключи — как в файле правил. */
    public static ObjectNode rulesJson(RuleSet rules) {
        return RulesLoader.toJson(rules);
    }

    /**
     * Правила с сервера. Поле, которого этот SDK не знает, пропускается; поле, которого нет у сервера, берётся
     * из правил сезона 1.
     */
    public static RuleSet rules(JsonNode json) {
        ObjectNode merged = RulesLoader.toJson(RulesLoader.season1());
        overlay(merged, json);
        return RulesLoader.fromJson(merged);
    }

    private static void overlay(ObjectNode base, JsonNode from) {
        if (from == null || !from.isObject()) {
            return;
        }
        for (Iterator<Map.Entry<String, JsonNode>> it = base.fields(); it.hasNext(); ) {
            Map.Entry<String, JsonNode> e = it.next();
            JsonNode v = from.get(e.getKey());
            if (v == null) {
                continue;
            }
            JsonNode mine = e.getValue();
            if (mine.isObject()) {
                overlay((ObjectNode) mine, v);
            } else if (mine.isNumber() && v.isIntegralNumber() || mine.isBoolean() && v.isBoolean()
                    || mine.isTextual() && v.isTextual()) {
                e.setValue(v);
            }
        }
    }

    // ---- обзор ----

    /**
     * Обзор колонии для отправки: то же содержание, что у {@link ColonyView}, без неизменной части правил и
     * рельефа. Возможности колонии ({@code abilities}: склад, завалы, улучшения) идут в каждом обзоре — они свои у
     * каждой колонии. Постройки, завалы и улучшения пишутся, только если они есть.
     */
    public static ObjectNode viewJson(ColonyView v) {
        ObjectNode o = JSON.createObjectNode();
        o.put("tick", v.tick());
        o.put("maxTicks", v.maxTicks());
        o.put("myId", v.myId());
        o.put("energy", v.energy());
        o.put("truce", v.truce());
        BitSet seen = new BitSet(v.width() * v.height());
        List<Structure> others = new ArrayList<>();
        ArrayNode rubble = JSON.createArrayNode();
        for (int y = 0; y < v.height(); y++) {
            for (int x = 0; x < v.width(); x++) {
                Pos p = new Pos(x, y);
                if (v.isVisible(p)) {
                    seen.set(y * v.width() + x);
                    v.structureAt(p).filter(s -> s.colonyId() != v.myId()).ifPresent(others::add);
                }
                int left = v.rubble(p);
                if (left > 0) {
                    rubble.addArray().add(x).add(y).add(left);
                }
            }
        }
        o.put("visible", Base64.getEncoder().encodeToString(seen.toByteArray()));
        units(o.putArray("myUnits"), v.myUnits());
        bases(o.putArray("myBases"), v.myBases());
        units(o.putArray("enemies"), v.visibleEnemies());
        bases(o.putArray("enemyBases"), v.visibleEnemyBases());
        if (!v.myStructures().isEmpty()) {
            structures(o.putArray("myStructures"), v.myStructures());
        }
        if (!others.isEmpty()) {
            structures(o.putArray("structures"), others);
        }
        if (!rubble.isEmpty()) {
            o.set("rubble", rubble);
        }
        // обвалы сценария (уровень 5): рельеф клиент получил при входе, закрытые с тех пор клетки идут с обзором
        List<Pos> closed = Match.closedCells(v).stream()
                .sorted(java.util.Comparator.comparingInt(Pos::y).thenComparingInt(Pos::x)).toList();
        if (!closed.isEmpty()) {
            ArrayNode c = o.putArray("closed");
            closed.forEach(p -> c.addArray().add(p.x()).add(p.y()));
        }
        o.set("abilities", abilities(v.rules()));
        ArrayNode ds = o.putArray("deposits");
        for (Deposit d : v.deposits()) {
            ds.addObject().put("id", d.id()).put("x", d.pos().x()).put("y", d.pos().y()).put("kind", d.kind().name())
                    .put("amount", d.amount()).put("visible", d.visible()).put("rate", d.rate());
        }
        ArrayNode rs = o.putArray("rejections");
        for (Rejection r : v.lastRejections()) {
            rs.addObject().put("unit", r.unitId()).put("code", r.code().name()).put("text", r.message());
        }
        ArrayNode es = o.putArray("events");
        for (GameEvent e : v.events()) {
            ObjectNode n = es.addObject().put("tick", e.tick()).put("kind", e.kind().name()).put("text", e.message());
            if (e.pos() != null) {
                n.put("x", e.pos().x()).put("y", e.pos().y());
            }
        }
        return o;
    }

    private static void units(ArrayNode a, List<Unit> units) {
        for (Unit u : units) {
            ObjectNode n = a.addObject().put("id", u.id()).put("colonyId", u.colonyId()).put("type", u.type().name())
                    .put("x", u.pos().x()).put("y", u.pos().y()).put("hp", u.hp()).put("carry", u.carry());
            if (!u.upgrades().isEmpty()) {
                ArrayNode up = n.putArray("upgrades");
                u.upgrades().forEach(x -> up.add(x.name()));
            }
        }
    }

    private static void structures(ArrayNode a, List<Structure> list) {
        for (Structure s : list) {
            a.addObject().put("id", s.id()).put("colonyId", s.colonyId()).put("type", s.type().name())
                    .put("x", s.pos().x()).put("y", s.pos().y());
        }
    }

    /** Возможности колонии: только те, что у неё есть. */
    static ObjectNode abilities(Rules r) {
        ObjectNode o = JSON.createObjectNode();
        r.depot().ifPresent(d -> o.putObject("depot").put("cost", d.cost()).put("max", d.max())
                .put("vision", d.vision()));
        r.dig().ifPresent(d -> o.putObject("dig").put("durability", d.durability()));
        r.upgrades().ifPresent(u -> o.putObject("upgrades").put("cost", u.cost()));
        return o;
    }

    /** Возможности из обзора; {@code null} — сервер их не прислал (протокол 1.0): берутся правила карты. */
    static Abilities abilities(JsonNode n) {
        if (n == null || !n.isObject()) {
            return null;
        }
        JsonNode d = n.get("depot");
        JsonNode g = n.get("dig");
        JsonNode u = n.get("upgrades");
        return new Abilities(
                d == null ? Optional.empty() : Optional.of(new Rules.Depot(d.path("cost").asInt(),
                        d.path("max").asInt(), d.path("vision").asInt())),
                g == null ? Optional.empty() : Optional.of(new Rules.Dig(g.path("durability").asInt())),
                u == null ? Optional.empty() : Optional.of(new Rules.Upgrades(u.path("cost").asInt())));
    }

    /** Возможности колонии, пришедшие в обзоре. */
    record Abilities(Optional<Rules.Depot> depot, Optional<Rules.Dig> dig, Optional<Rules.Upgrades> upgrades) {

        /** Правила колонии: неизменная часть — с доски, возможности — эти. */
        Rules over(Rules r) {
            return new Rules(r.league(), r.maxTicks(), r.truceTicks(), r.startEnergy(), r.workerCost(), r.maxWorkers(),
                    r.workerHp(), r.workerCarry(), r.harvestRate(), r.workerVision(), r.baseVision(),
                    r.foreignPassable(), r.melee(), r.centre(), r.tanks(), r.tickTimeoutMillis(), depot, dig, upgrades);
        }
    }

    private static void bases(ArrayNode a, List<Base> bases) {
        for (Base b : bases) {
            a.addObject().put("id", b.id()).put("colonyId", b.colonyId()).put("x", b.pos().x()).put("y", b.pos().y())
                    .put("hp", b.hp());
        }
    }

    /** Обзор из JSON и неизменной части мира. */
    public static ColonyView view(JsonNode json, Board board) {
        BitSet seen = BitSet.valueOf(Base64.getDecoder().decode(json.path("visible").asText("")));
        List<Deposit> deposits = new ArrayList<>();
        for (JsonNode d : json.path("deposits")) {
            DepositKind kind = constant(DepositKind.class, d.path("kind").asText());
            if (kind != null) {
                deposits.add(new Deposit(d.path("id").asInt(), pos(d), kind, d.path("amount").asInt(-1),
                        d.path("visible").asBoolean(), d.path("rate").asInt(0)));
            }
        }
        List<Rejection> rejections = new ArrayList<>();
        for (JsonNode r : json.path("rejections")) {
            RejectCode code = constant(RejectCode.class, r.path("code").asText());
            if (code != null) {
                rejections.add(new Rejection(r.path("unit").asInt(), code, r.path("text").asText("")));
            }
        }
        List<GameEvent> events = new ArrayList<>();
        for (JsonNode e : json.path("events")) {
            EventKind kind = constant(EventKind.class, e.path("kind").asText());
            if (kind != null) {
                Pos p = e.hasNonNull("x") && e.hasNonNull("y") ? pos(e) : null;
                events.add(new GameEvent(e.path("tick").asInt(), kind, e.path("text").asText(""), p));
            }
        }
        int[] rubble = new int[board.width() * board.height()];
        for (JsonNode r : json.path("rubble")) {
            Pos p = new Pos(r.path(0).asInt(-1), r.path(1).asInt(-1));
            if (board.inside(p)) {
                rubble[p.y() * board.width() + p.x()] = Math.max(0, r.path(2).asInt());
            }
        }
        Set<Pos> closed = new java.util.HashSet<>();
        for (JsonNode c : json.path("closed")) {
            Pos p = new Pos(c.path(0).asInt(-1), c.path(1).asInt(-1));
            if (board.inside(p)) {
                closed.add(p);
            }
        }
        Rules rules = board.rules().forColony();
        Abilities abilities = abilities(json.get("abilities"));
        if (abilities != null) {
            rules = abilities.over(rules);
        }
        return new NetView(board, rules, json.path("tick").asInt(), json.path("maxTicks").asInt(),
                json.path("myId").asInt(), json.path("energy").asInt(), json.path("truce").asBoolean(), seen,
                readUnits(json.path("myUnits")), readBases(json.path("myBases")), readUnits(json.path("enemies")),
                readBases(json.path("enemyBases")), readStructures(json.path("myStructures")),
                readStructures(json.path("structures")), rubble, closed, deposits, rejections, events);
    }

    private static List<Unit> readUnits(JsonNode a) {
        List<Unit> out = new ArrayList<>();
        for (JsonNode u : a) {
            UnitType type = constant(UnitType.class, u.path("type").asText());
            if (type != null) {
                Set<Upgrade> up = EnumSet.noneOf(Upgrade.class);
                for (JsonNode x : u.path("upgrades")) {
                    Upgrade k = constant(Upgrade.class, x.asText());
                    if (k != null) {
                        up.add(k);
                    }
                }
                out.add(new Unit(u.path("id").asInt(), u.path("colonyId").asInt(), type, pos(u), u.path("hp").asInt(),
                        u.path("carry").asInt(), up));
            }
        }
        return out;
    }

    private static List<Structure> readStructures(JsonNode a) {
        List<Structure> out = new ArrayList<>();
        for (JsonNode s : a) {
            Building type = constant(Building.class, s.path("type").asText());
            if (type != null) {
                out.add(new Structure(s.path("id").asInt(), s.path("colonyId").asInt(), type, pos(s)));
            }
        }
        return out;
    }

    private static List<Base> readBases(JsonNode a) {
        List<Base> out = new ArrayList<>();
        for (JsonNode b : a) {
            out.add(new Base(b.path("id").asInt(), b.path("colonyId").asInt(), pos(b), b.path("hp").asInt()));
        }
        return out;
    }

    private static Pos pos(JsonNode n) {
        return new Pos(n.path("x").asInt(), n.path("y").asInt());
    }

    /** Значение перечисления по имени; незнакомое — {@code null}. */
    static <E extends Enum<E>> E constant(Class<E> type, String name) {
        try {
            return Enum.valueOf(type, name);
        } catch (IllegalArgumentException | NullPointerException e) {
            return null;
        }
    }

    // ---- приказы ----

    public static ObjectNode orderJson(Order order) {
        return JSON.valueToTree(order.toMap());
    }

    /** Тело {@code POST /api/v1/orders}. */
    public static ObjectNode ordersJson(String gameId, int tick, List<Order> orders) {
        ObjectNode o = JSON.createObjectNode();
        o.put("gameId", gameId);
        o.put("tick", tick);
        ArrayNode a = o.putArray("orders");
        orders.forEach(x -> a.add(orderJson(x)));
        return o;
    }

    /** Разобранные приказы и понятные причины, по которым остальные не приняты. */
    public record Parsed(List<Order> orders, List<String> errors) {}

    /** Разобрать список приказов; испорченный приказ не роняет остальные. */
    public static Parsed parseOrders(JsonNode list) {
        List<Order> orders = new ArrayList<>();
        List<String> errors = new ArrayList<>();
        if (list == null || !list.isArray()) {
            errors.add("нет списка приказов");
            return new Parsed(orders, errors);
        }
        int n = 0;
        for (JsonNode o : list) {
            n++;
            try {
                if (!o.isObject()) {
                    throw new IllegalArgumentException("это не объект");
                }
                orders.add(Order.fromMap(JSON.convertValue(o, Map.class)));
            } catch (IllegalArgumentException e) {
                errors.add("приказ " + n + ": " + e.getMessage());
            }
        }
        return new Parsed(orders, errors);
    }
}
