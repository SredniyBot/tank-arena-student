package colony.net;

import colony.protocol.Board;
import colony.api.Base;
import colony.api.ColonyView;
import colony.api.Deposit;
import colony.api.GameEvent;
import colony.api.Pos;
import colony.api.Rejection;
import colony.api.Rules;
import colony.api.Structure;
import colony.api.Terrain;
import colony.api.Unit;
import java.util.BitSet;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;

/** Обзор колонии, пришедший с сервера. Ведёт себя как обзор локальной игры. */
final class NetView implements ColonyView {

    private final Board board;
    private final Rules rules;
    private final int tick;
    private final int maxTicks;
    private final int myId;
    private final int energy;
    private final boolean truce;
    private final BitSet visible;
    private final List<Unit> myUnits;
    private final List<Base> myBases;
    private final List<Unit> enemies;
    private final List<Base> enemyBases;
    private final List<Structure> myStructures;
    /** Прочность завалов по клеткам ({@code y * width + x}); 0 — завала нет. */
    private final int[] rubble;
    /** Клетки, закрытые сценарием карты (обвалом) после входа: на доске это пол. */
    private final Set<Pos> closed;
    private final List<Deposit> deposits;
    private final List<Rejection> rejections;
    private final List<GameEvent> events;
    private final Map<Pos, Unit> unitCell = new HashMap<>();
    private final Map<Pos, Base> baseCell = new HashMap<>();
    private final Map<Pos, Structure> structureCell = new HashMap<>();
    private final Map<Pos, Deposit> depositCell = new HashMap<>();

    NetView(Board board, Rules rules, int tick, int maxTicks, int myId, int energy, boolean truce, BitSet visible,
            List<Unit> myUnits, List<Base> myBases, List<Unit> enemies, List<Base> enemyBases,
            List<Structure> myStructures, List<Structure> otherStructures, int[] rubble, Set<Pos> closed,
            List<Deposit> deposits, List<Rejection> rejections, List<GameEvent> events) {
        this.board = board;
        this.rules = rules;
        this.tick = tick;
        this.maxTicks = maxTicks;
        this.myId = myId;
        this.energy = energy;
        this.truce = truce;
        this.visible = visible;
        this.myUnits = List.copyOf(myUnits);
        this.myBases = List.copyOf(myBases);
        this.enemies = List.copyOf(enemies);
        this.enemyBases = List.copyOf(enemyBases);
        this.myStructures = List.copyOf(myStructures);
        this.rubble = rubble;
        this.closed = Set.copyOf(closed);
        this.deposits = List.copyOf(deposits);
        this.rejections = List.copyOf(rejections);
        this.events = List.copyOf(events);
        // как в движке: в перемирие в одной клетке свой юнит главнее чужого
        this.myUnits.forEach(u -> unitCell.putIfAbsent(u.pos(), u));
        this.enemies.forEach(u -> unitCell.putIfAbsent(u.pos(), u));
        this.myBases.forEach(b -> baseCell.put(b.pos(), b));
        this.enemyBases.forEach(b -> baseCell.put(b.pos(), b));
        this.myStructures.forEach(s -> structureCell.put(s.pos(), s));
        otherStructures.forEach(s -> structureCell.put(s.pos(), s));
        this.deposits.forEach(d -> depositCell.put(d.pos(), d));
    }

    @Override
    public int tick() {
        return tick;
    }

    @Override
    public int maxTicks() {
        return maxTicks;
    }

    @Override
    public int myId() {
        return myId;
    }

    @Override
    public int energy() {
        return energy;
    }

    @Override
    public Rules rules() {
        return rules;
    }

    @Override
    public int width() {
        return board.width();
    }

    @Override
    public int height() {
        return board.height();
    }

    @Override
    public boolean inside(Pos p) {
        return board.inside(p);
    }

    /** Стена — с доски или обвал из обзора; завал — пока у него осталась прочность, разобранный — пол. */
    @Override
    public Terrain terrain(Pos p) {
        if (board.terrain(p) == Terrain.WALL || closed.contains(p)) {
            return Terrain.WALL;
        }
        return rubble(p) > 0 ? Terrain.RUBBLE : Terrain.FLOOR;
    }

    @Override
    public int rubble(Pos p) {
        return inside(p) ? rubble[p.y() * board.width() + p.x()] : 0;
    }

    @Override
    public boolean isVisible(Pos p) {
        return inside(p) && visible.get(p.y() * board.width() + p.x());
    }

    @Override
    public boolean truce() {
        return truce;
    }

    @Override
    public List<Unit> myUnits() {
        return myUnits;
    }

    @Override
    public List<Base> myBases() {
        return myBases;
    }

    @Override
    public List<Unit> visibleEnemies() {
        return enemies;
    }

    @Override
    public List<Base> visibleEnemyBases() {
        return enemyBases;
    }

    @Override
    public List<Structure> myStructures() {
        return myStructures;
    }

    @Override
    public List<Deposit> deposits() {
        return deposits;
    }

    @Override
    public Optional<Unit> unitAt(Pos p) {
        return inside(p) ? Optional.ofNullable(unitCell.get(p)) : Optional.empty();
    }

    @Override
    public Optional<Base> baseAt(Pos p) {
        return inside(p) ? Optional.ofNullable(baseCell.get(p)) : Optional.empty();
    }

    @Override
    public Optional<Structure> structureAt(Pos p) {
        return inside(p) ? Optional.ofNullable(structureCell.get(p)) : Optional.empty();
    }

    @Override
    public Optional<Deposit> depositAt(Pos p) {
        return inside(p) ? Optional.ofNullable(depositCell.get(p)) : Optional.empty();
    }

    @Override
    public List<Rejection> lastRejections() {
        return rejections;
    }

    @Override
    public List<GameEvent> events() {
        return events;
    }

    @Override
    public String toString() {
        return "ColonyView[колония " + myId + ", такт " + tick + ", энергия " + energy + ", юнитов " + myUnits.size()
                + ", сервер]";
    }
}
