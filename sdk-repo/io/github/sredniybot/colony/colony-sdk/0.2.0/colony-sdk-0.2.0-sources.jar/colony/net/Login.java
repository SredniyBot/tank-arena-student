package colony.net;

import com.fasterxml.jackson.databind.JsonNode;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.io.PrintStream;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.attribute.PosixFilePermissions;
import java.nio.charset.Charset;
import java.time.Duration;
import java.util.Locale;
import java.util.Objects;
import java.util.Optional;

/**
 * Вход на сервер через GitHub, как {@code gh auth login}: консоль печатает код, студент вводит его на
 * github.com/login/device, сервер узнаёт его GitHub-логин и отдаёт токен. Токен ложится в {@code ~/.colony/token}
 * ({@link Token#file}), так что вход нужен один раз на компьютере. Client ID приложения GitHub SDK берёт у сервера
 * ({@code /api/v1/info}): его настраивает преподаватель. Токен GitHub нужен только на время входа и не сохраняется.
 *
 * <p>Запасной путь, если сеть не пускает к GitHub и преподаватель его включил: код с экрана преподавателя и своё имя
 * из списка группы.
 */
public final class Login {

    /** GitHub по умолчанию. */
    public static final URI GITHUB = URI.create("https://github.com/");

    static final String DEVICE_GRANT = "urn:ietf:params:oauth:grant-type:device_code";
    /** Сколько ошибок сети подряд терпим, пока ждём подтверждения. */
    static final int NETWORK_RETRIES = 3;

    /** Пауза между опросами GitHub; в тестах — без ожидания. */
    @FunctionalInterface
    public interface Pause {
        void sleep(long millis) throws InterruptedException;
    }

    private final URI server;
    private final URI github;
    private final Path home;
    private final PrintStream out;
    private final Pause pause;
    private final BufferedReader in;
    private final HttpClient http = HttpClient.newBuilder().version(HttpClient.Version.HTTP_1_1)
            .connectTimeout(Duration.ofSeconds(5)).build();

    private Login(Builder b) {
        this.server = slash(Objects.requireNonNull(b.server, "server"));
        this.github = slash(b.github);
        this.home = Objects.requireNonNull(b.home, "home");
        this.out = Objects.requireNonNull(b.out, "out");
        this.pause = b.pause;
        this.in = b.in != null ? b.in : new BufferedReader(new InputStreamReader(System.in, Charset.defaultCharset()));
    }

    public static Builder builder() {
        return new Builder();
    }

    /** Настройки входа: сервер, домашняя папка (где {@code .colony/token}), куда печатать. */
    public static final class Builder {
        private URI server;
        private URI github = GITHUB;
        private Path home = Path.of(System.getProperty("user.home"));
        private PrintStream out = System.out;
        private Pause pause = Thread::sleep;
        private BufferedReader in;

        public Builder server(URI server) {
            this.server = server;
            return this;
        }

        /** Адрес GitHub; другой — только для тестов. */
        public Builder github(URI github) {
            this.github = Objects.requireNonNull(github);
            return this;
        }

        public Builder home(Path home) {
            this.home = home;
            return this;
        }

        public Builder out(PrintStream out) {
            this.out = out;
            return this;
        }

        public Builder pause(Pause pause) {
            this.pause = Objects.requireNonNull(pause);
            return this;
        }

        /** Откуда читать код и номер при входе по коду; по умолчанию — консоль. */
        public Builder in(BufferedReader in) {
            this.in = Objects.requireNonNull(in);
            return this;
        }

        public Login build() {
            return new Login(this);
        }
    }

    /**
     * Войти и сохранить токен.
     *
     * @return токен; пусто — сервер не предлагает входа (токен выдаёт преподаватель) или не отвечает
     * @throws IllegalStateException вход не удался — в тексте сказано, что случилось и что делать
     */
    public Optional<Token.Found> run() {
        try {
            JsonNode ways = ways();
            String clientId = ways.path("github").path("clientId").asText("");
            boolean byCode = ways.path("code").asBoolean(false);
            JsonNode me;
            if (!clientId.isBlank()) {
                try {
                    me = server("POST", "api/v1/login/github", Protocol.JSON.createObjectNode()
                            .put("githubToken", githubToken(clientId)));
                } catch (GithubDown e) {
                    if (!byCode) {
                        throw e;
                    }
                    out.println("GitHub не отвечает. Войдём по коду преподавателя.");
                    me = byCode();
                }
            } else if (byCode) {
                me = byCode();
            } else {
                return Optional.empty();
            }
            String token = me.path("token").asText("");
            Path file = save(token);
            out.println("Вход выполнен: " + me.path("name").asText("?") + (me.hasNonNull("github") ? " (GitHub "
                    + me.path("github").asText() + ")" : "") + ". Токен сохранён в " + file + ".");
            out.flush();
            return Optional.of(new Token.Found(token, "файла " + file));
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            throw new IllegalStateException("Вход прерван.");
        }
    }

    /** Способы входа из {@code /api/v1/info}: {@code {"github": {"clientId"}, "code": true}}; сервер молчит — пусто. */
    private JsonNode ways() throws InterruptedException {
        try (ServerLink link = new ServerLink(server, null)) {
            ServerLink.Reply r = link.info();
            return r.status() == 200 ? r.body().path("login") : Protocol.JSON.missingNode();
        } catch (IOException e) {
            return Protocol.JSON.missingNode();
        }
    }

    // ---- GitHub: код для устройства ----

    /** Код, опрос до подтверждения, токен GitHub. */
    private String githubToken(String clientId) throws InterruptedException {
        JsonNode code;
        try {
            code = post(github.resolve("login/device/code"), "client_id=" + enc(clientId));
        } catch (IOException e) {
            throw githubDown(e);
        }
        if (code.hasNonNull("error") || !code.hasNonNull("device_code")) {
            throw refused(code);
        }
        String userCode = code.path("user_code").asText();
        String uri = code.path("verification_uri").asText(github.resolve("login/device").toString());
        long expires = code.path("expires_in").asLong(900);
        long interval = Math.max(1, code.path("interval").asLong(5));
        out.println("Вход на сервер через GitHub — один раз на этом компьютере.");
        out.println("Открой " + uri + " и введи код " + userCode);
        out.println("Жду подтверждения, код действует " + minutes(expires) + " мин.");
        out.flush();

        String form = "client_id=" + enc(clientId) + "&device_code=" + enc(code.path("device_code").asText())
                + "&grant_type=" + enc(DEVICE_GRANT);
        long waited = 0;
        int failures = 0;
        while (true) {
            pause.sleep(interval * 1000);
            waited += interval;
            JsonNode r;
            try {
                r = post(github.resolve("login/oauth/access_token"), form);
                failures = 0;
            } catch (IOException e) {
                if (++failures >= NETWORK_RETRIES) {
                    throw githubDown(e);
                }
                continue;
            }
            String error = r.path("error").asText("");
            switch (error) {
                case "" -> {
                    String token = r.path("access_token").asText("");
                    if (token.isEmpty()) {
                        throw refused(r);
                    }
                    return token;
                }
                case "authorization_pending" -> { }
                case "slow_down" -> interval = Math.max(interval + 5, r.path("interval").asLong(0));
                case "expired_token" -> throw expired(expires);
                case "access_denied" -> throw new IllegalStateException("Вход отменён на GitHub. Запусти программу "
                        + "ещё раз, чтобы войти.");
                default -> throw refused(r);
            }
            if (waited >= expires) {
                throw expired(expires);
            }
        }
    }

    private JsonNode post(URI uri, String form) throws IOException, InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(uri).timeout(Duration.ofSeconds(10))
                .header("Accept", "application/json").header("Content-Type", "application/x-www-form-urlencoded")
                .POST(HttpRequest.BodyPublishers.ofString(form)).build();
        HttpResponse<String> r = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        try {
            JsonNode n = Protocol.JSON.readTree(r.body());
            if (n != null && n.isObject()) {
                return n;
            }
        } catch (IOException e) {
            // ниже — «GitHub ответил непонятно»
        }
        return Protocol.JSON.createObjectNode().put("error", "HTTP " + r.statusCode());
    }

    /** GitHub не отвечает: можно войти по коду, если сервер его предлагает. */
    private static final class GithubDown extends IllegalStateException {
        GithubDown(String message) {
            super(message);
        }
    }

    private GithubDown githubDown(IOException e) {
        String why = e.getMessage() == null ? e.getClass().getSimpleName() : e.getMessage();
        return new GithubDown("GitHub не отвечает (" + why + "). Если сеть не пускает к GitHub, попроси у "
                + "преподавателя токен и сохрани его одной строкой в " + Token.file(home) + ".");
    }

    private static IllegalStateException refused(JsonNode r) {
        String why = r.path("error_description").asText(r.path("error").asText("непонятный ответ"));
        return new IllegalStateException("GitHub отказал во входе: " + why + ". Скажи преподавателю.");
    }

    private static IllegalStateException expired(long seconds) {
        return new IllegalStateException("Код истёк: на GitHub его не ввели за " + minutes(seconds) + " мин. "
                + "Запусти программу ещё раз — будет новый код.");
    }

    private static long minutes(long seconds) {
        return Math.max(1, (seconds + 59) / 60);
    }

    // ---- код с экрана преподавателя ----

    /**
     * Код с экрана, фамилия и имя — и токен. Сервер ищет имя в списке группы и называет, кого нашёл; студент
     * подтверждает. Не нашлось, нашлось несколько или «нет» — ещё раз, всего три попытки.
     */
    private JsonNode byCode() throws InterruptedException {
        out.println("Вход по коду с экрана преподавателя. Введи код:");
        out.flush();
        String code = line();
        server("GET", "api/v1/login/code?code=" + enc(code), null); // неверный или истёкший код — сразу отказ
        for (int attempt = 0; attempt < 3; attempt++) {
            out.println("Напиши фамилию и имя:");
            out.flush();
            String typed = line();
            Reply r = call("GET", "api/v1/login/code?code=" + enc(code) + "&name=" + enc(typed), null);
            if (r.status() != 200) {
                String why = r.body().path("code").asText("");
                if (!why.equals("NO_STUDENT") && !why.equals("AMBIGUOUS") && !why.equals("EMPTY_NAME")) {
                    throw refusedBy(r);
                }
                out.println(capital(r.body().path("error").asText("имя не нашлось")) + ".");
                continue;
            }
            String name = r.body().path("name").asText();
            out.println("Это ты — " + name + "? Напиши «да» или «нет»:");
            out.flush();
            if (yes(line())) {
                return server("POST", "api/v1/login/code", Protocol.JSON.createObjectNode().put("code", code)
                        .put("name", name));
            }
            out.println("Тогда напиши фамилию и имя точнее, как в ведомости.");
        }
        throw new IllegalStateException("Вход прерван: имя так и не нашлось. Скажи преподавателю, как ты записан в "
                + "ведомости.");
    }

    private static boolean yes(String s) {
        String a = s.strip().toLowerCase(Locale.ROOT);
        return a.equals("да") || a.equals("д") || a.equals("yes") || a.equals("y");
    }

    private static String capital(String s) {
        return s.isEmpty() ? s : Character.toUpperCase(s.charAt(0)) + s.substring(1);
    }

    private String line() {
        try {
            String s = in.readLine();
            if (s == null) {
                throw new IllegalStateException("Вход прерван: консоль закрыта для ввода.");
            }
            return s.strip();
        } catch (IOException e) {
            throw new IllegalStateException("Вход прерван: " + e.getMessage() + ".");
        }
    }

    // ---- сервер ----

    /** Запрос к серверу; не 200 — отказ с его объяснением. */
    private JsonNode server(String method, String path, JsonNode body) throws InterruptedException {
        Reply r = call(method, path, body);
        if (r.status() != 200 || body != null && r.body().path("token").asText("").isBlank()) {
            throw refusedBy(r);
        }
        return r.body();
    }

    private static IllegalStateException refusedBy(Reply r) {
        return new IllegalStateException("Сервер не пустил: " + r.body().path("error").asText("ответ " + r.status())
                + ".");
    }

    private record Reply(int status, JsonNode body) {}

    /** Запрос к серверу как есть: код ответа и тело (не JSON — пустой объект). */
    private Reply call(String method, String path, JsonNode body) throws InterruptedException {
        HttpRequest req = HttpRequest.newBuilder(server.resolve(path)).timeout(Duration.ofSeconds(20))
                .header("Content-Type", "application/json").method(method, body == null
                        ? HttpRequest.BodyPublishers.noBody() : HttpRequest.BodyPublishers.ofString(body.toString()))
                .build();
        HttpResponse<String> r;
        try {
            r = http.send(req, HttpResponse.BodyHandlers.ofString(StandardCharsets.UTF_8));
        } catch (IOException e) {
            throw new IllegalStateException("Сервер " + server + " не отвечает: " + e.getMessage() + ".");
        }
        JsonNode n;
        try {
            n = Protocol.JSON.readTree(r.body());
        } catch (IOException e) {
            n = null;
        }
        if (n == null || !n.isObject()) {
            n = Protocol.JSON.createObjectNode();
        }
        return new Reply(r.statusCode(), n);
    }

    /** Токен — в {@code ~/.colony/token}, только для владельца, где это умеет файловая система. */
    private Path save(String token) {
        Path file = Token.file(home);
        try {
            Files.createDirectories(file.getParent());
            Files.writeString(file, token + System.lineSeparator(), StandardCharsets.UTF_8);
            try {
                Files.setPosixFilePermissions(file, PosixFilePermissions.fromString("rw-------"));
            } catch (UnsupportedOperationException | IOException e) {
                // Windows: папка пользователя и так закрыта от других
            }
        } catch (IOException e) {
            throw new IllegalStateException("Вход выполнен, но токен не записался в " + file + ": " + e.getMessage()
                    + ". Проверь, что в эту папку можно писать, и запусти программу ещё раз.");
        }
        return file;
    }

    private static String enc(String s) {
        return URLEncoder.encode(s, StandardCharsets.UTF_8);
    }

    private static URI slash(URI u) {
        String s = u.toString();
        return URI.create(s.endsWith("/") ? s : s + "/");
    }
}
