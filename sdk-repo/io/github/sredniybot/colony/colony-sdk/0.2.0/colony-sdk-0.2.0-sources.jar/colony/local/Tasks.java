package colony.local;

import colony.api.Colony;
import colony.homework.Step;
import colony.homework.Steps;
import colony.net.NetGame;
import colony.net.Protocol;
import colony.net.ServerLink;
import colony.net.Token;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Supplier;

/**
 * Домашнее задание «лестница возможностей» с сервером: что пройдено и сколько попыток осталось
 * ({@link #status}), попытка шага на сервере ({@link #attempt}). Колония играет здесь, на ноутбуке, и подключается
 * к серверу по сети; карты и движок — на сервере. Тренировка — у себя ({@link StepTasks}).
 */
final class Tasks {

    /**
     * Что сервер знает о студенте по шагам 1–5.
     *
     * @param passed   пройденные шаги: номер → дата {@code yyyy-MM-dd}
     * @param today    попыток сегодня по шагу, считая идущую
     * @param points   баллы: по одному за пройденный шаг
     * @param open     срок не прошёл (или его нет)
     * @param deadline срок текстом или {@code null}
     * @param perDay   попыток в сутки на шаг
     * @param left     сколько попыток по шагу осталось сегодня
     * @param max      сколько баллов можно получить
     */
    record Status(Map<Integer, String> passed, Map<Integer, Integer> today, int points, boolean open,
                  String deadline, int perDay, Map<Integer, Integer> left, int max) {

        /** Шаг пройден. */
        boolean isPassed(int step) {
            return passed.containsKey(step);
        }

        /** Попыток по шагу осталось сегодня. */
        int leftToday(int step) {
            return left.getOrDefault(step, perDay);
        }
    }

    private Tasks() {}

    /** Строка сервера как предложение: с точкой в конце, но без второй. */
    static String sentence(String s) {
        String t = s == null ? "" : s.strip();
        return t.endsWith(".") || t.endsWith("!") || t.endsWith("?") ? t : t + ".";
    }

    /** Статус с сервера или пусто (сервера нет, токена нет, сеть) — с причиной в {@code why}. */
    static Optional<Status> status(URI server, Supplier<Token.Found> token, StringBuilder why) {
        if (server == null) {
            why.append("сервер не задан (server= в colony.properties)");
            return Optional.empty();
        }
        Token.Found t;
        try {
            t = token.get();
        } catch (IllegalStateException e) {
            why.append("нет токена");
            return Optional.empty();
        }
        try (ServerLink link = new ServerLink(server, t.value())) {
            ServerLink.Reply r = link.homework();
            if (r.status() != 200) {
                why.append(r.error());
                return Optional.empty();
            }
            return Optional.of(parse(r.body()));
        } catch (IOException e) {
            why.append("сервер недоступен");
            return Optional.empty();
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            why.append("прервано");
            return Optional.empty();
        }
    }

    /** Ответ {@code GET /api/v1/homework}. */
    static Status parse(JsonNode b) {
        int perDay = b.path("perDay").asInt(Steps.ATTEMPTS_PER_DAY);
        Map<Integer, String> passed = new HashMap<>();
        Map<Integer, Integer> today = new HashMap<>();
        Map<Integer, Integer> left = new HashMap<>();
        for (JsonNode x : b.path("steps")) {
            int n = x.path("number").asInt();
            if (x.hasNonNull("passedOn")) {
                passed.put(n, x.get("passedOn").asText());
            }
            today.put(n, x.path("today").asInt());
            left.put(n, x.path("left").asInt(Math.max(0, perDay - x.path("today").asInt())));
        }
        return new Status(passed, today, b.path("points").asInt(), b.path("open").asBoolean(true),
                b.hasNonNull("deadlineText") ? b.get("deadlineText").asText() : null, perDay, left,
                b.path("max").asInt(Steps.all().size()));
    }

    // ---- Main --task ----

    /** Шаги задания и, если сервер ответил, что пройдено и сколько попыток осталось. */
    static int task(Env env, URI server, Supplier<Token.Found> token) {
        StringBuilder why = new StringBuilder();
        Optional<Status> st = status(server, token, why);
        var out = env.out();
        out.println("Домашнее задание «Колония»: " + Steps.all().size() + " уровней."
                + st.map(s -> " Баллы: " + s.points() + " из " + s.max() + ".").orElse(""));
        if (st.isPresent()) {
            Status s = st.get();
            out.println(s.deadline() == null ? "Срок пока не назначен."
                    : s.open() ? "Срок: " + s.deadline() + ". Засчитывается попытка, начатая до него."
                    : "Срок прошёл (" + s.deadline() + "): новые попытки играются, но баллов не дают.");
        } else {
            out.println("Отметок нет: " + why + ". Ниже — само задание.");
        }
        out.println("Уровень пройден, если на картах попытки вместе сдано не меньше цели. Попыток в сутки на уровень — "
                + st.map(Status::perDay).orElse(Steps.ATTEMPTS_PER_DAY) + ". За уровень — " + Steps.POINTS
                + " балла.");
        for (Step s : Steps.all()) {
            out.println();
            out.println(s.title() + state(s, st) + ": " + s.goalText() + ".");
        }
        return 0;
    }

    private static String state(Step s, Optional<Status> st) {
        if (st.isEmpty()) {
            return "";
        }
        String on = st.get().passed().get(s.number());
        if (on != null) {
            return " — пройден " + on.substring(8, 10) + "." + on.substring(5, 7);
        }
        return " — не пройден, попыток сегодня осталось " + st.get().leftToday(s.number()) + " из "
                + st.get().perDay();
    }

    // ---- Main --practice ----

    /** Тренировка у себя: шаг по номеру или первый непройденный (по серверу; без сервера — шаг 1). */
    static int practice(Env env, Supplier<Colony> mine, Integer number, Long seed, URI server,
                        Supplier<Token.Found> token) {
        int n = number != null ? Steps.get(number).number() : status(server, token, new StringBuilder())
                .flatMap(s -> Steps.all().stream().filter(x -> !s.isPassed(x.number())).findFirst())
                .map(Step::number).orElse(1);
        return StepTasks.practice(env, mine, n, seed, false);
    }

    // ---- попытка ----

    /**
     * Попытка шага {@code number} (без номера — первого непройденного) на сервере: сервер выбирает новые карты и
     * играет их своим движком, колония отвечает по сети. Пройденная попытка просит снимок кода.
     */
    static int attempt(Env env, Supplier<Colony> mine, Integer number, URI server, Token.Found token,
                       java.util.function.BooleanSupplier debugger) {
        var out = env.out();
        String id;
        try (ServerLink link = new ServerLink(server, token.value())) {
            ServerLink.Reply r = link.startAttempt(number);
            if (r.status() != 200) {
                env.err().println("Попытка не начата: " + sentence(r.error()));
                return 1;
            }
            JsonNode b = r.body();
            id = b.path("attempt").asText();
            if (b.path("resumed").asBoolean()) {
                out.println("Попытка уже идёт — подключаюсь к ней.");
            }
            out.println(b.path("intro").asText());
        } catch (IOException e) {
            env.err().println("Сервер " + server + " недоступен: " + e.getMessage() + ". Попытка не начата.");
            return 1;
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            return 1;
        }
        int code = NetGame.builder().server(server).token(token.value()).me(mine).session("homework")
                .debugger(debugger).console(out, env.err()).build().run();
        if (code != 0) {
            return code;
        }
        return afterAttempt(env, server, token, id);
    }

    /** После попытки: если она пройдена, отправить снимок своего кода. */
    private static int afterAttempt(Env env, URI server, Token.Found token, String id) {
        try (ServerLink link = new ServerLink(server, token.value())) {
            ServerLink.Reply r = link.attempt(id);
            if (r.status() != 200 || !r.body().path("snapshotWanted").asBoolean()) {
                return 0;
            }
            List<Snapshot.File> files;
            try {
                files = Snapshot.collect(env.workDir());
            } catch (IllegalStateException e) {
                env.err().println("Снимок кода не отправлен: " + e.getMessage() + ". Балл засчитан; покажите это "
                        + "сообщение преподавателю.");
                return 0;
            }
            ObjectNode body = Protocol.JSON.createObjectNode().put("attempt", id);
            ArrayNode list = body.putArray("files");
            files.forEach(f -> list.addObject().put("path", f.path()).put("text", f.text()));
            ServerLink.Reply s = link.snapshot(body);
            if (s.status() == 200) {
                long kb = Math.max(1, (s.body().path("bytes").asLong() + 1023) / 1024);
                env.out().println("Снимок кода отправлен: файлов " + s.body().path("files").asInt() + ", " + kb
                        + " КБ. Его сравнят с работами группы — правила в RULES.md.");
            } else {
                env.err().println("Снимок кода не принят: " + sentence(s.error()) + " Балл засчитан; покажите это "
                        + "сообщение преподавателю.");
            }
        } catch (IOException e) {
            env.err().println("Снимок кода не отправлен: сервер недоступен. Балл засчитан.");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
        return 0;
    }
}
