package colony.homework;

import colony.api.DepositKind;
import colony.engine.GameMap;
import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.SplittableRandom;

/**
 * Карты испытаний: у каждого открытого испытания своё семейство, карта задаётся зерном. Одно зерно — одна и та же
 * карта и на сервере, и в тренировке. Попытка на сервере берёт новые зёрна, поэтому заученный маршрут не помогает.
 */
public final class TrialMaps {

    private TrialMaps() {}

    /** Карта испытания {@code trial} по зерну {@code seed}. */
    public static GameMap map(int trial, long seed) {
        // перемешать: у SplittableRandom соседние зёрна, кратные его шагу, дают сдвинутые копии одной цепочки
        SplittableRandom rnd = new SplittableRandom(mix(mix(seed) + trial));
        String name = "trial-" + trial + "-" + seed;
        for (int attempt = 0; attempt < 200; attempt++) {
            Grid g = switch (trial) {
                case 1 -> firstIncome(rnd);
                case 2 -> growth(rnd);
                case 3 -> maze(rnd, 26, 20, 4);
                case 6 -> readTheWorld(rnd);
                case 11 -> duel(rnd);
                default -> throw new IllegalArgumentException("у испытания " + trial + " пока нет карт");
            };
            if (g != null && g.playable()) {
                return g.toMap(name);
            }
        }
        throw new IllegalStateException("не удалось построить карту " + name);
    }

    /** Перемешивание 64 бит (финал MurmurHash3). */
    private static long mix(long z) {
        z = (z ^ (z >>> 33)) * 0xff51afd7ed558ccdL;
        z = (z ^ (z >>> 33)) * 0xc4ceb9fe1a85ec53L;
        return z ^ (z >>> 33);
    }

    // ---- семейства ----

    /** «Первый доход»: база, жила в 3–6 шагах, иногда вторая подальше, редкие камни. */
    private static Grid firstIncome(SplittableRandom r) {
        Grid g = new Grid(14, 10, Map.of(DepositKind.NORMAL, 400));
        int bx = 2 + r.nextInt(10);
        int by = 2 + r.nextInt(6);
        g.set(bx, by, '1');
        if (!g.place(r, '*', bx, by, 3, 6)) {
            return null;
        }
        if (r.nextBoolean()) {
            g.place(r, '*', bx, by, 7, 11);
        }
        int stones = r.nextInt(5);
        for (int i = 0; i < stones; i++) {
            g.stone(r);
        }
        return g;
    }

    /** «Рост»: две ближние жилы в нишах (добывать можно с одной клетки, запас мал) и три богатые подальше. */
    private static Grid growth(SplittableRandom r) {
        Grid g = new Grid(24, 16, Map.of(DepositKind.NORMAL, 150, DepositKind.RICH, 1500));
        int bx = 4 + r.nextInt(5);
        int by = 5 + r.nextInt(6);
        g.set(bx, by, '1');
        for (int i = 0; i < 2; i++) {
            if (!g.nook(r, bx, by, 3, 6)) {
                return null;
            }
        }
        for (int i = 0; i < 3; i++) {
            if (!g.place(r, '$', bx, by, 10, 17)) {
                return null;
            }
        }
        for (int i = 0; i < 3; i++) {
            g.segment(r, 2, 4);
        }
        return g;
    }

    /** «Лабиринт»: жилы в подковах, открытых от базы, пустые подковы-ловушки и тупики. */
    private static Grid maze(SplittableRandom r, int w, int h, int deposits) {
        Grid g = new Grid(w, h, Map.of(DepositKind.NORMAL, 500, DepositKind.RICH, 1200));
        int bx = 2 + r.nextInt(3);
        int by = 3 + r.nextInt(h - 6);
        g.set(bx, by, '1');
        for (int i = 0; i < deposits; i++) {
            if (!g.horseshoeDeposit(r, i % 2 == 0 ? '*' : '$', bx, by, 9, w - 3)) {
                return null;
            }
        }
        for (int i = 0; i < 2; i++) {
            g.cup(r, bx, by, 6, w - 6);
        }
        for (int i = 0; i < 4; i++) {
            g.segment(r, 3, 6);
        }
        return g;
    }

    /** «Читай мир»: домашняя жила (медленная, вечная), две ближние маленькие, богатые подальше. */
    private static Grid readTheWorld(SplittableRandom r) {
        Grid g = new Grid(24, 18, Map.of(DepositKind.NORMAL, 80, DepositKind.RICH, 2000));
        int bx = 4 + r.nextInt(5);
        int by = 5 + r.nextInt(8);
        g.set(bx, by, '1');
        if (!g.place(r, 'H', bx, by, 2, 3)) {
            return null;
        }
        for (int i = 0; i < 2; i++) {
            if (!g.place(r, '*', bx, by, 3, 6)) {
                return null;
            }
        }
        for (int i = 0; i < 2; i++) {
            if (!g.place(r, '$', bx, by, 8, 13)) {
                return null;
            }
        }
        if (!g.place(r, '$', bx, by, 15, 22)) {
            return null;
        }
        for (int i = 0; i < 3; i++) {
            g.segment(r, 2, 5);
        }
        return g;
    }

    /** «Бронза»: левая половина — как в «Лабиринте», правая — она же, повёрнутая на 180°. */
    private static Grid duel(SplittableRandom r) {
        Grid half = maze(r, 16, 20, 3);
        if (half == null || !half.playable()) {
            return null;
        }
        Grid g = new Grid(32, 20, half.amounts);
        for (int y = 0; y < 20; y++) {
            for (int x = 0; x < 16; x++) {
                char c = half.at(x, y);
                g.set(x, y, c);
                g.set(31 - x, 19 - y, c == '1' ? '2' : c);
            }
        }
        return g.spawnTies() ? null : g;
    }

    // ---- сетка ----

    /** Черновик карты: клетки, запасы, проверки. */
    static final class Grid {
        final int w;
        final int h;
        final char[][] c;
        final Map<DepositKind, Integer> amounts;

        Grid(int w, int h, Map<DepositKind, Integer> amounts) {
            this.w = w;
            this.h = h;
            this.amounts = amounts;
            this.c = new char[h][w];
            for (char[] row : c) {
                java.util.Arrays.fill(row, '.');
            }
        }

        boolean in(int x, int y) {
            return x >= 0 && y >= 0 && x < w && y < h;
        }

        char at(int x, int y) {
            return in(x, y) ? c[y][x] : '#';
        }

        void set(int x, int y, char ch) {
            if (in(x, y)) {
                c[y][x] = ch;
            }
        }

        boolean floor(int x, int y) {
            return at(x, y) == '.';
        }

        /** Вокруг клетки (по Чебышёву {@code r}) только пол. */
        boolean clear(int x, int y, int r) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    if (!floor(x + dx, y + dy)) {
                        return false;
                    }
                }
            }
            return true;
        }

        /** Залежь {@code kind} в {@code min..max} шагах от базы на свободном месте; {@code false} — не нашлось. */
        boolean place(SplittableRandom r, char kind, int bx, int by, int min, int max) {
            for (int i = 0; i < 300; i++) {
                int x = 1 + r.nextInt(w - 2);
                int y = 1 + r.nextInt(h - 2);
                int d = Math.abs(x - bx) + Math.abs(y - by);
                if (d >= min && d <= max && clear(x, y, 1)) {
                    set(x, y, kind);
                    return true;
                }
            }
            return false;
        }

        /** Обычная залежь в нише: стены с трёх сторон, открыта сторона к базе — добывать можно с одной клетки. */
        boolean nook(SplittableRandom r, int bx, int by, int min, int max) {
            for (int i = 0; i < 300; i++) {
                int x = 2 + r.nextInt(w - 4);
                int y = 2 + r.nextInt(h - 4);
                int d = Math.abs(x - bx) + Math.abs(y - by);
                if (d < min || d > max || !clear(x, y, 2)) {
                    continue;
                }
                int ox = Math.abs(bx - x) >= Math.abs(by - y) ? Integer.signum(bx - x) : 0;
                int oy = ox == 0 ? Integer.signum(by - y) : 0;
                set(x, y, '*');
                int[][] sides = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};
                for (int[] s : sides) {
                    if (s[0] != ox || s[1] != oy) {
                        set(x + s[0], y + s[1], '#');
                    }
                }
                return true;
            }
            return false;
        }

        /**
         * Залежь в подкове радиуса 2: закрытая сторона смотрит на базу, открытая — от неё. Идущий к жиле «по прямой»
         * упирается в стену.
         */
        boolean horseshoeDeposit(SplittableRandom r, char kind, int bx, int by, int minX, int maxX) {
            for (int i = 0; i < 300; i++) {
                int x = minX + r.nextInt(Math.max(1, maxX - minX));
                int y = 3 + r.nextInt(h - 6);
                if (!clear(x, y, 3)) {
                    continue;
                }
                int dx = x - bx;
                int dy = y - by;
                // открыто — от базы по главной оси
                int ox = Math.abs(dx) >= Math.abs(dy) ? Integer.signum(dx) : 0;
                int oy = ox == 0 ? Integer.signum(dy) : 0;
                shoe(x, y, ox, oy);
                set(x, y, kind);
                return true;
            }
            return false;
        }

        /** Пустая подкова-ловушка: открыта к базе, идущий «по прямой» заходит внутрь и упирается. */
        void cup(SplittableRandom r, int bx, int by, int minX, int maxX) {
            for (int i = 0; i < 100; i++) {
                int x = minX + r.nextInt(Math.max(1, maxX - minX));
                int y = 3 + r.nextInt(h - 6);
                if (!clear(x, y, 3)) {
                    continue;
                }
                int dx = bx - x;
                int dy = by - y;
                int ox = Math.abs(dx) >= Math.abs(dy) ? Integer.signum(dx) : 0;
                int oy = ox == 0 ? Integer.signum(dy) : 0;
                shoe(x, y, ox, oy);
                return;
            }
        }

        /** Стены кольца радиуса 2 вокруг (x, y), кроме стороны (ox, oy). */
        private void shoe(int x, int y, int ox, int oy) {
            for (int ddy = -2; ddy <= 2; ddy++) {
                for (int ddx = -2; ddx <= 2; ddx++) {
                    if (Math.max(Math.abs(ddx), Math.abs(ddy)) != 2) {
                        continue;
                    }
                    boolean open = ox != 0 ? ddx == 2 * ox : ddy == 2 * oy;
                    if (!open) {
                        set(x + ddx, y + ddy, '#');
                    }
                }
            }
        }

        /** Отрезок стены длиной {@code min..max}, не вплотную к базам, залежам и другим стенам. */
        void segment(SplittableRandom r, int min, int max) {
            for (int i = 0; i < 100; i++) {
                int len = min + r.nextInt(max - min + 1);
                boolean horizontal = r.nextBoolean();
                int x = 1 + r.nextInt(w - 2);
                int y = 1 + r.nextInt(h - 2);
                boolean ok = true;
                for (int k = 0; k < len && ok; k++) {
                    ok = clear(horizontal ? x + k : x, horizontal ? y : y + k, 1);
                }
                if (!ok) {
                    continue;
                }
                for (int k = 0; k < len; k++) {
                    set(horizontal ? x + k : x, horizontal ? y : y + k, '#');
                }
                return;
            }
        }

        /** Одиночный камень, не вплотную ни к чему. */
        void stone(SplittableRandom r) {
            for (int i = 0; i < 100; i++) {
                int x = r.nextInt(w);
                int y = r.nextInt(h);
                if (clear(x, y, 1)) {
                    set(x, y, '#');
                    return;
                }
            }
        }

        /** У каждой базы хотя бы две свободные соседние клетки, к каждой залежи можно подойти от каждой базы. */
        boolean playable() {
            return playable(false);
        }

        /** То же; с {@code rubble} завал считается проходимым (его можно разобрать). */
        boolean playable(boolean rubble) {
            List<int[]> bases = new ArrayList<>();
            List<int[]> deposits = new ArrayList<>();
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    char ch = c[y][x];
                    if (ch == '1' || ch == '2') {
                        bases.add(new int[] {x, y});
                    } else if (ch == '*' || ch == '$' || ch == 'H') {
                        deposits.add(new int[] {x, y});
                    }
                }
            }
            if (bases.isEmpty() || deposits.isEmpty()) {
                return false;
            }
            for (int[] b : bases) {
                int free = 0;
                for (int[] n : around(b[0], b[1])) {
                    if (floor(n[0], n[1])) {
                        free++;
                    }
                }
                if (free < 2) {
                    return false;
                }
                boolean[] seen = reach(b[0], b[1], rubble);
                for (int[] d : deposits) {
                    boolean ok = false;
                    for (int[] n : around(d[0], d[1])) {
                        ok |= in(n[0], n[1]) && seen[n[1] * w + n[0]];
                    }
                    if (!ok) {
                        return false;
                    }
                }
            }
            return true;
        }

        /** Клетки пола, до которых можно дойти от соседей клетки (x, y). */
        boolean[] reach(int x, int y) {
            return reach(x, y, false);
        }

        private boolean walk(int x, int y, boolean rubble) {
            return floor(x, y) || rubble && at(x, y) == '%';
        }

        /** То же; с {@code rubble} — и сквозь завалы. */
        boolean[] reach(int x, int y, boolean rubble) {
            boolean[] seen = new boolean[w * h];
            ArrayDeque<int[]> q = new ArrayDeque<>();
            for (int[] n : around(x, y)) {
                if (walk(n[0], n[1], rubble)) {
                    seen[n[1] * w + n[0]] = true;
                    q.add(n);
                }
            }
            while (!q.isEmpty()) {
                int[] p = q.poll();
                for (int[] n : around(p[0], p[1])) {
                    if (walk(n[0], n[1], rubble) && !seen[n[1] * w + n[0]]) {
                        seen[n[1] * w + n[0]] = true;
                        q.add(n);
                    }
                }
            }
            return seen;
        }

        /**
         * Две свободные соседние клетки базы на равном расстоянии от центра: тогда новый юнит встаёт по порядку
         * N, E, S, W, а у повёрнутой базы этот порядок другой.
         */
        boolean spawnTies() {
            for (int y = 0; y < h; y++) {
                for (int x = 0; x < w; x++) {
                    if (c[y][x] != '1' && c[y][x] != '2') {
                        continue;
                    }
                    List<Long> seen = new ArrayList<>();
                    for (int[] n : around(x, y)) {
                        if (!floor(n[0], n[1])) {
                            continue;
                        }
                        long ddx = 2L * n[0] - (w - 1);
                        long ddy = 2L * n[1] - (h - 1);
                        long d = ddx * ddx + ddy * ddy;
                        if (seen.contains(d)) {
                            return true;
                        }
                        seen.add(d);
                    }
                }
            }
            return false;
        }

        private static int[][] around(int x, int y) {
            return new int[][] {{x, y - 1}, {x + 1, y}, {x, y + 1}, {x - 1, y}};
        }

        GameMap toMap(String name) {
            int players = 0;
            List<String> rows = new ArrayList<>();
            for (char[] row : c) {
                String s = new String(row);
                rows.add(s);
                players += s.chars().filter(ch -> ch == '1' || ch == '2').count();
            }
            Map<DepositKind, Integer> used = new java.util.EnumMap<>(DepositKind.class);
            for (Map.Entry<DepositKind, Integer> e : amounts.entrySet()) {
                char mark = e.getKey() == DepositKind.NORMAL ? '*' : '$';
                if (rows.stream().anyMatch(s -> s.indexOf(mark) >= 0)) {
                    used.put(e.getKey(), e.getValue());
                }
            }
            return GameMap.of(name, players, rows, used, List.of());
        }
    }
}
