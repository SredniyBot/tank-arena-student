package colony.bots;

import colony.api.Base;
import colony.api.ColonyView;
import colony.api.Deposit;
import colony.api.DepositKind;
import colony.api.Direction;
import colony.api.Orders;
import colony.api.Pos;
import colony.api.Terrain;
import colony.api.Unit;
import colony.api.UnitType;
import colony.engine.Navigator;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.Set;
import java.util.TreeMap;
import java.util.TreeSet;

/**
 * Основа боссов лиг 3–5. Рабочие делятся на роли: охрана, отряд центра (старшие номера) и добытчики, которые
 * работают, как «серебро». Сколько кого — решает босс.
 * <ul>
 *   <li>Охрана: когда у наших рабочих чужие, ближайшие к ним бросают добычу, идут к чужим и бьют; иначе
 *       добывают.</li>
 *   <li>Отряд центра стоит в зоне центра и добывает центральную жилу; бьёт чужого рядом; если чужих в зоне
 *       заметно больше — уходит к базе на {@value #RETREAT} тактов.</li>
 *   <li>Танки отходят от чужого вплотную, бьют первого чужого на прямой; иначе идут в зону центра.</li>
 * </ul>
 */
abstract class LeagueBoss extends HarvestBot {

    /** Сколько тактов отряд центра пережидает у базы после отступления. */
    static final int RETREAT = 40;
    /** На каком расстоянии от наших добытчиков охрана замечает чужих. */
    static final int WATCH = 8;

    private final int reserve;
    private int retreatUntil = -1;
    /** Танк → такт, с которого он снова может бить (по нашему счёту). */
    private final Map<Integer, Integer> tankReady = new TreeMap<>();

    LeagueBoss(long seed) {
        super(seed);
        this.reserve = random.nextInt(21);
    }

    /** Сколько рабочих в охране при {@code workers} рабочих. */
    abstract int guards(ColonyView view, int workers);

    /** Сколько рабочих в отряде центра. */
    abstract int holders(ColonyView view, int workers);

    /** Сколько держать танков. */
    int tanks(ColonyView view) {
        return 0;
    }

    @Override
    int workerCap(ColonyView view) {
        return view.rules().maxWorkers() > 0 ? view.rules().maxWorkers() : 8;
    }

    @Override
    boolean wantWorker(ColonyView view) {
        long tanks = view.myUnits().stream().filter(u -> u.type() == UnitType.TANK).count();
        if (tanks < tanks(view) && workers(view) >= 5) {
            return false; // после пяти рабочих копит на танки
        }
        return view.tick() < view.maxTicks() - 400 && view.energy() >= view.rules().workerCost() + reserve;
    }

    @Override
    Optional<UnitType> special(ColonyView view) {
        int want = tanks(view);
        long have = view.myUnits().stream().filter(u -> u.type() == UnitType.TANK).count();
        if (have < want && workers(view) >= 5 && view.energy() >= view.rules().tanks().map(x -> x.cost()).orElse(Integer.MAX_VALUE - 100) + reserve
                && view.tick() < view.maxTicks() - 400) {
            return Optional.of(UnitType.TANK);
        }
        return Optional.empty();
    }

    @Override
    Optional<Deposit> choose(ColonyView view, Navigator nav, Base base, Unit worker) {
        return bestByValue(view, nav, base);
    }

    @Override
    Set<Integer> roles(ColonyView view, Orders orders, Navigator nav, Base base, Traffic traffic) {
        Set<Integer> handled = new TreeSet<>();
        List<Unit> workers = view.myUnits().stream().filter(u -> u.type() == UnitType.WORKER).toList();
        int n = workers.size();
        int g = Math.min(guards(view, n), n);
        int h = Math.min(holders(view, n), n - g);
        List<Pos> zone = zone(view);
        if (zone.isEmpty()) {
            h = 0;
        }
        // охрана: когда у наших рабочих чужие, ближайшие к ним бросают добычу и бьют; иначе все добывают
        List<Unit> threats = threats(view);
        if (!threats.isEmpty() && g > 0) {
            List<Unit> byDistance = new ArrayList<>(workers);
            byDistance.sort(Comparator.comparingInt((Unit u) -> nearest(u, threats)).thenComparingInt(Unit::id));
            for (Unit u : byDistance) {
                if (handled.size() >= g || nearest(u, threats) > 2 * WATCH) {
                    break;
                }
                handled.add(u.id());
                guard(view, orders, nav, base, u, threats, traffic);
            }
        }
        int holding = 0;
        for (int i = n - 1; i >= 0 && holding < h; i--) {
            Unit u = workers.get(i);
            if (handled.contains(u.id())) {
                continue;
            }
            if (u.carry() > 0 && !inZone(view, u.pos(), zone)) {
                continue; // сначала донесёт груз
            }
            handled.add(u.id());
            holding++;
            hold(view, orders, nav, base, u, zone, traffic);
        }
        for (Unit t : view.myUnits()) {
            if (t.type() == UnitType.TANK) {
                handled.add(t.id());
                tank(view, orders, nav, t, zone, traffic);
            }
        }
        return handled;
    }

    // ---- охрана ----

    /** Чужие юниты не дальше {@value #WATCH} шагов от наших рабочих; в перемирие и без ударов — никого. */
    List<Unit> threats(ColonyView view) {
        if (view.truce() || view.rules().melee().isEmpty()) {
            return List.of();
        }
        List<Unit> out = new ArrayList<>();
        for (Unit e : view.visibleEnemies()) {
            if (!atHome(view, e) && view.myUnits().stream().anyMatch(m -> m.type() == UnitType.WORKER
                    && m.pos().manhattan(e.pos()) <= WATCH)) {
                out.add(e);
            }
        }
        return out;
    }

    private static int nearest(Unit u, List<Unit> others) {
        int best = Integer.MAX_VALUE;
        for (Unit o : others) {
            best = Math.min(best, u.pos().manhattan(o.pos()));
        }
        return best;
    }

    private void guard(ColonyView view, Orders orders, Navigator nav, Base base, Unit u, List<Unit> threats,
                       Traffic traffic) {
        if (hitNeighbour(view, orders, u)) {
            return;
        }
        Unit target = null;
        int best = Integer.MAX_VALUE;
        for (Unit e : threats) {
            int d = nav.distance(u.pos(), e.pos());
            if (d >= 0 && d < best) {
                best = d;
                target = e;
            }
        }
        if (target != null) {
            approach(view, orders, nav, u, target.pos(), base.pos(), traffic);
        }
    }

    /** Ударить соседнего чужого (сначала самого раненого); {@code true} — ударил. */
    boolean hitNeighbour(ColonyView view, Orders orders, Unit u) {
        if (view.truce() || view.rules().melee().isEmpty()) {
            return false;
        }
        Direction pick = null;
        int weakest = Integer.MAX_VALUE;
        for (Direction d : Direction.values()) {
            Optional<Unit> there = view.unitAt(u.pos().step(d));
            if (there.isPresent() && there.get().colonyId() != view.myId() && !atHome(view, there.get())
                    && there.get().hp() < weakest) {
                weakest = there.get().hp();
                pick = d;
            }
        }
        if (pick == null) {
            return false;
        }
        orders.attack(u.id(), pick);
        return true;
    }

    // ---- центр ----

    /** Клетки зоны центра, где можно стоять: не дальше {@code centerRadius} шагов от центральной жилы. */
    static List<Pos> zone(ColonyView view) {
        List<Pos> centre = view.deposits().stream().filter(d -> d.kind() == DepositKind.CENTER).map(Deposit::pos)
                .toList();
        List<Pos> out = new ArrayList<>();
        if (centre.isEmpty() || view.rules().centre().isEmpty()) {
            return out;
        }
        int r = view.rules().centre().get().radius();
        for (Pos c : centre) {
            for (int dy = -r; dy <= r; dy++) {
                for (int dx = -r; dx <= r; dx++) {
                    Pos p = new Pos(c.x() + dx, c.y() + dy);
                    if (p.manhattan(c) <= r && standable(view, p) && !out.contains(p)) {
                        out.add(p);
                    }
                }
            }
        }
        out.sort(Comparator.comparingInt(Pos::y).thenComparingInt(Pos::x));
        return out;
    }

    static boolean inZone(ColonyView view, Pos p, List<Pos> zone) {
        return zone.contains(p);
    }

    private void hold(ColonyView view, Orders orders, Navigator nav, Base base, Unit u, List<Pos> zone,
                      Traffic traffic) {
        if (hitNeighbour(view, orders, u)) {
            return;
        }
        long ours = view.myUnits().stream().filter(m -> zone.contains(m.pos())).count();
        long theirs = view.visibleEnemies().stream().filter(e -> zone.contains(e.pos())).count();
        if (theirs > ours + 2 && retreatUntil < view.tick()) {
            retreatUntil = view.tick() + RETREAT;
        }
        if (view.tick() < retreatUntil) {
            if (u.carry() > 0 && HarvestBot.adjacent(u.pos(), base.pos()).isPresent()) {
                orders.transfer(u.id(), HarvestBot.adjacent(u.pos(), base.pos()).get(), u.carry());
            } else {
                approach(view, orders, nav, u, base.pos(), base.pos(), traffic);
            }
            return;
        }
        if (zone.contains(u.pos())) {
            if (u.carry() < view.rules().workerCarry()) {
                for (Direction d : Direction.values()) {
                    Optional<Deposit> dep = view.depositAt(u.pos().step(d));
                    if (dep.isPresent() && dep.get().kind() == DepositKind.CENTER && !exhausted(dep.get())) {
                        orders.harvest(u.id(), d);
                        return;
                    }
                }
            }
            return;
        }
        Pos best = null;
        int bestD = Integer.MAX_VALUE;
        for (Pos p : zone) {
            if (traffic.busy.contains(p) || traffic.claimed.contains(p)) {
                continue;
            }
            // сначала места у центральной жилы: там отряд и добывает, и не даёт добывать чужим
            int d = nav.distance(u.pos(), p) + (nextToCentre(view, p) ? 0 : 6);
            if (nav.distance(u.pos(), p) >= 0 && d < bestD) {
                bestD = d;
                best = p;
            }
        }
        if (best != null) {
            traffic.claimed.add(best);
            Pos goal = best;
            step(view, nav, u, goal, traffic).ifPresent(d -> orders.move(u.id(), d));
        }
    }

    private static boolean nextToCentre(ColonyView view, Pos p) {
        for (Direction d : Direction.values()) {
            Optional<Deposit> dep = view.depositAt(p.step(d));
            if (dep.isPresent() && dep.get().kind() == DepositKind.CENTER) {
                return true;
            }
        }
        return false;
    }

    // ---- танки ----

    private void tank(ColonyView view, Orders orders, Navigator nav, Unit t, List<Pos> zone, Traffic traffic) {
        // вплотную танк слабее рабочих: сначала отойти, бить — издалека
        if (!view.truce() && nearestEnemy(view, t.pos()) <= 1) {
            Direction away = null;
            int bestGap = 1;
            for (Direction d : Direction.values()) {
                Pos n = t.pos().step(d);
                int gap = nearestEnemy(view, n);
                if (standable(view, n) && traffic.free(n) && gap > bestGap) {
                    bestGap = gap;
                    away = d;
                }
            }
            if (away != null) {
                traffic.claimed.add(t.pos().step(away));
                traffic.leaving.add(t.pos());
                orders.move(t.id(), away);
                return;
            }
        }
        int ready = tankReady.getOrDefault(t.id(), 0);
        if (!view.truce() && view.tick() >= ready) {
            Optional<Direction> line = lineTarget(view, t);
            if (line.isPresent()) {
                orders.fire(t.id(), line.get());
                tankReady.put(t.id(), view.tick() + view.rules().tanks().map(x -> x.cooldown()).orElse(1));
                return;
            }
        }
        Unit near = null;
        int best = Integer.MAX_VALUE;
        for (Unit e : view.visibleEnemies()) {
            int d = nav.distance(t.pos(), e.pos());
            if (d >= 0 && d < best && d <= 12) {
                best = d;
                near = e;
            }
        }
        Pos goal = near != null ? near.pos() : zone.isEmpty() ? null : zone.get(zone.size() / 2);
        if (goal == null || t.pos().equals(goal)) {
            return;
        }
        if (near == null && zone.contains(t.pos())) {
            return;
        }
        step(view, nav, t, goal, traffic).ifPresent(d -> orders.move(t.id(), d));
    }

    private static int nearestEnemy(ColonyView view, Pos p) {
        int best = Integer.MAX_VALUE;
        for (Unit e : view.visibleEnemies()) {
            best = Math.min(best, e.pos().manhattan(p));
        }
        return best;
    }

    /** Направление, в котором на прямой до {@code strikeRange} клеток стоит чужой (свои не мешают). */
    static Optional<Direction> lineTarget(ColonyView view, Unit t) {
        for (Direction d : Direction.values()) {
            Pos p = t.pos();
            int range = view.rules().tanks().map(x -> x.range()).orElse(0);
            for (int k = 1; k <= range; k++) {
                p = p.step(d);
                if (!view.inside(p) || view.terrain(p) == Terrain.WALL || view.baseAt(p).isPresent()) {
                    break;
                }
                Optional<Unit> u = view.unitAt(p);
                if (u.isPresent() && u.get().colonyId() != view.myId()) {
                    return Optional.of(d);
                }
            }
        }
        return Optional.empty();
    }
}
