package colony.homework;

import colony.api.Colony;
import colony.api.RejectCode;
import colony.api.Rejection;
import colony.engine.Frame;
import colony.engine.Match;
import colony.engine.MatchConfig;
import colony.engine.MatchResult;
import colony.engine.ReplayWriter;
import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.lang.management.ManagementFactory;
import java.nio.file.AtomicMoveNotSupportedException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.StandardCopyOption;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.zip.GZIPOutputStream;

/**
 * Учебные карты шагов: пять на шаг, одни у всех и не меняются. На них шаг проверяется тестом
 * ({@link StepChecks}) и перед попыткой ({@code Main --submit}); попытка идёт на новых картах.
 *
 * <p>Каждая сыгранная карта оставляет в {@code replays/} повтор {@code step3-3102.json.gz} (его открывает
 * просмотр) и страницу {@code step3-3102.html}: она открывается в браузере прямо с диска.
 */
public final class Training {

    /**
     * Зёрна учебных карт. На шагах 3–5 по две карты из пяти — с ловушкой для жадного шага ({@link StepMaps#trap}):
     * шаг 3 — карты 2 и 4, шаг 4 — 1 и 3, шаг 5 — 2 и 5. Эталонные колонии прототипа со своим поиском пути
     * проходят все карты своего шага с запасом от 3 %.
     */
    private static final Map<Integer, List<Long>> SEEDS = Map.of(
            1, List.of(1101L, 1103L, 1106L, 1110L, 1112L),
            2, List.of(2101L, 2104L, 2105L, 2107L, 2111L),
            3, List.of(3100L, 3102L, 3104L, 3106L, 3107L),
            4, List.of(4101L, 4102L, 4105L, 4106L, 4108L),
            5, List.of(5102L, 5100L, 5105L, 5107L, 5101L));

    private Training() {}

    /** Зёрна пяти учебных карт шага. */
    public static List<Long> seeds(int step) {
        return SEEDS.get(Steps.get(step).number());
    }

    /** Учебная ли это карта шага: попытка берёт другие. */
    public static boolean isTraining(int step, long seed) {
        return seeds(step).contains(seed);
    }

    /**
     * Итог одной карты.
     *
     * @param map            номер карты, с 1
     * @param exceptionTicks сколько тактов {@code onTick} бросал исключение
     * @param firstException первое исключение колонии (копия со стеком) или {@code null}
     * @param firstFailure   отказ, которым движок описал первое исключение: «такт 12: …», или {@code null}
     * @param timeoutTicks   сколько тактов {@code onTick} не уложился во время
     * @param page           страница повтора ({@code .html}) или {@code null}, если не записана
     * @param replayProblem  почему повтор не записан, или {@code null}
     */
    public record MapRun(Step step, int map, long seed, int delivered, int exceptionTicks, Throwable firstException,
                         String firstFailure, int timeoutTicks, Path page, String replayProblem) {

        /** Цель шага на карте достигнута. */
        public boolean reached() {
            return delivered >= step.goal();
        }

        /** Карта зелёная: цель есть и исключений не было. */
        public boolean passed() {
            return reached() && exceptionTicks == 0;
        }

        public int missing() {
            return Math.max(0, step.goal() - delivered);
        }
    }

    /** Сыграть все учебные карты шага по порядку. */
    public static List<MapRun> playAll(Step s, Supplier<Colony> colony, Path workDir) {
        List<MapRun> out = new ArrayList<>();
        List<Long> seeds = seeds(s.number());
        for (int i = 0; i < seeds.size(); i++) {
            out.add(play(s, i + 1, seeds.get(i), colony, workDir));
        }
        return out;
    }

    /**
     * Сыграть карту шага {@code s} с зерном {@code seed} без просмотра и записать повтор и страницу в
     * {@code workDir/replays}. Под отладчиком лимит времени такта снят: точки останова не дают таймаутов.
     */
    public static MapRun play(Step s, int map, long seed, Supplier<Colony> colony, Path workDir) {
        Objects.requireNonNull(colony, "colony");
        MatchConfig cfg = Steps.config(s, seed);
        if (debugging()) {
            cfg = cfg.withTickTimeoutMillis(Integer.MAX_VALUE);
        }
        Throwable first = null;
        String firstText = null;
        try (Match m = Match.create(cfg, Steps.specs(colony))) {
            while (!m.finished()) {
                m.step();
                if (first != null || firstText != null) {
                    continue;
                }
                Frame f = m.frame();
                for (Rejection r : f.rejections().getOrDefault(1, List.of())) {
                    if (r.code() == RejectCode.EXCEPTION) {
                        firstText = "такт " + f.t() + ": " + r.message();
                        first = m.lastError(1).map(Training::trimmed).orElse(null);
                        break;
                    }
                }
            }
            MatchResult.Placement me = m.result().of(1);
            Path page = null;
            String problem = null;
            try {
                page = writeReplay(m, s, map, seed, me.delivered(), workDir.resolve("replays"));
            } catch (IOException | RuntimeException e) {
                problem = e.getMessage() == null ? e.toString() : e.getMessage();
            }
            return new MapRun(s, map, seed, me.delivered(), me.exceptions(), first, firstText, me.timeouts(), page,
                    problem);
        }
    }

    /** {@code step3-3102}: имя повтора и страницы без расширения. */
    static String baseName(Step s, long seed) {
        return "step" + s.number() + "-" + seed;
    }

    private static Path writeReplay(Match m, Step s, int map, long seed, int delivered, Path dir)
            throws IOException {
        ByteArrayOutputStream bytes = new ByteArrayOutputStream(1 << 16);
        try (GZIPOutputStream gz = new GZIPOutputStream(bytes, 1 << 16)) {
            ReplayWriter.write(m, gz, false);
        }
        byte[] gz = bytes.toByteArray();
        Files.createDirectories(dir);
        String base = baseName(s, seed);
        replace(dir.resolve(base + ".json.gz"), gz);
        String title = s.title() + " · карта " + map + ", зерно " + seed;
        Path page = dir.resolve(base + ".html").toAbsolutePath().normalize();
        String html = ReplayPage.html(title, s.goal(), delivered, base + ".json.gz", gz);
        replace(page, html.getBytes(StandardCharsets.UTF_8));
        return page;
    }

    /** Записать файл целиком: сначала {@code .part}, потом переименование поверх старого. */
    private static void replace(Path target, byte[] content) throws IOException {
        Path part = target.resolveSibling(target.getFileName() + ".part");
        try {
            Files.write(part, content);
            try {
                Files.move(part, target, StandardCopyOption.REPLACE_EXISTING, StandardCopyOption.ATOMIC_MOVE);
            } catch (AtomicMoveNotSupportedException e) {
                Files.move(part, target, StandardCopyOption.REPLACE_EXISTING);
            }
        } finally {
            Files.deleteIfExists(part);
        }
    }

    /** Копия исключения колонии без строк движка и пула потоков: в стеке остаётся код колонии. */
    static Throwable trimmed(Throwable t) {
        return trimmed(t, 0);
    }

    private static Throwable trimmed(Throwable t, int depth) {
        Throwable cause = t.getCause() != null && t.getCause() != t && depth < 5 ? trimmed(t.getCause(), depth + 1)
                : null;
        List<StackTraceElement> keep = new ArrayList<>();
        for (StackTraceElement e : t.getStackTrace()) {
            String cn = e.getClassName();
            if (cn.startsWith("colony.engine.") || cn.startsWith("java.util.concurrent.")) {
                break;
            }
            keep.add(e);
        }
        ColonyException copy = new ColonyException(t.toString(), cause);
        copy.setStackTrace(keep.toArray(StackTraceElement[]::new));
        return copy;
    }

    /** Исключение колонии, как его напечатала бы JVM: то же имя класса, сообщение и стек. */
    static final class ColonyException extends RuntimeException {
        private final String text;

        ColonyException(String text, Throwable cause) {
            super(text, cause, false, true);
            this.text = text;
        }

        @Override
        public String toString() {
            return text;
        }
    }

    /** Есть ли агент отладки в параметрах JVM: запуск с жуком в IntelliJ. */
    static boolean debugging() {
        for (String a : ManagementFactory.getRuntimeMXBean().getInputArguments()) {
            if (a.startsWith("-agentlib:jdwp") || a.startsWith("-Xrunjdwp")) {
                return true;
            }
        }
        return false;
    }
}
